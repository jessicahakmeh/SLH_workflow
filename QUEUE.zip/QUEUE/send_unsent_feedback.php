<?php
// send_unsent_feedback.php
// Run from Windows Task Scheduler using PHP CLI.
// Example task action:
//   Program/script: C:\xampp\php\php.exe
//   Add arguments: "C:\xampp\htdocs\QUEUE\send_unsent_feedback.php"
//   Start in: C:\xampp\htdocs\QUEUE

ini_set('display_errors', '1');
error_reporting(E_ALL);

if (php_sapi_name() !== 'cli') {
    echo "This script must be run from the command line.\n";
    exit(1);
}

require_once __DIR__ . '/config.php';

$cronLogFile = __DIR__ . '/logs/unsent_feedback_cron.log';
if (!is_dir(__DIR__ . '/logs')) {
    @mkdir(__DIR__ . '/logs', 0777, true);
}

function formatWhatsAppNumber($mobile, $countryCode = '+961') {
    $mobileDigits = preg_replace('/\D+/', '', (string)$mobile);
    $countryDigits = preg_replace('/\D+/', '', (string)$countryCode);

    if ($mobileDigits === '') {
        return '';
    }

    if ($countryDigits !== '' && strpos($mobileDigits, $countryDigits) === 0) {
        return $mobileDigits;
    }

    return $countryDigits . $mobileDigits;
}

function interpretWhatsAppApiResponse($httpCode, $responseBody) {
    $httpCode = (int)$httpCode;
    $raw = trim((string)$responseBody);
    $normalized = strtolower(strip_tags($raw));

    $providerCode = null;
    if ($raw !== '') {
        $parts = explode(';', strip_tags($raw));
        if (count($parts) >= 3) {
            $candidate = trim((string)$parts[2]);
            if ($candidate !== '' && preg_match('/^-?\d+$/', $candidate) === 1) {
                $providerCode = (int)$candidate;
            }
        }
    }

    $isHttpOk = ($httpCode >= 200 && $httpCode < 300);
    $hasMediaErrorHint = (
        strpos($normalized, 'media') !== false ||
        strpos($normalized, 'pdf') !== false ||
        strpos($normalized, 'url') !== false ||
        strpos($normalized, 'file') !== false ||
        strpos($normalized, 'not found') !== false
    );
    $hasGenericErrorHint = (
        strpos($normalized, 'error') !== false ||
        strpos($normalized, 'failed') !== false ||
        strpos($normalized, 'invalid') !== false ||
        strpos($normalized, 'denied') !== false ||
        strpos($normalized, 'rejected') !== false ||
        strpos($normalized, 'unable') !== false
    );

    $success = $isHttpOk;
    $errorType = '';

    if (!$isHttpOk) {
        $success = false;
        $errorType = 'http_error';
    } elseif ($providerCode !== null && $providerCode !== 0) {
        $success = false;
        $errorType = $hasMediaErrorHint ? 'media_error' : 'provider_error';
    } elseif ($hasMediaErrorHint) {
        $success = false;
        $errorType = 'media_error';
    } elseif ($hasGenericErrorHint) {
        $success = false;
        $errorType = 'provider_error';
    }

    return [
        'success' => $success,
        'provider_code' => $providerCode,
        'error_type' => $errorType,
    ];
}

function sendWhatsAppTemplateWithVariables($phoneNumber, $template, $variables) {
    if ($phoneNumber === '' || trim((string)$variables) === '') {
        return [
            'success' => false,
            'http_code' => 0,
            'response' => 'Missing phone number or template variables.',
            'request_url' => '',
            'provider_code' => null,
            'error_type' => 'validation_error',
        ];
    }

    $sendResult = sendWhatsAppTemplateRequest(
        preg_replace('/\D+/', '', $phoneNumber),
        $template,
        (string)$variables
    );

    if (!empty($sendResult['curl_error'])) {
        return [
            'success' => false,
            'http_code' => (int)($sendResult['http_code'] ?? 0),
            'response' => (string)($sendResult['curl_error'] ?? ''),
            'request_url' => (string)($sendResult['request_url'] ?? ''),
            'provider_code' => null,
            'error_type' => 'network_error',
        ];
    }

    $httpCode = (int)($sendResult['http_code'] ?? 0);
    $responseText = (string)($sendResult['response'] ?? '');
    $interpreted = interpretWhatsAppApiResponse($httpCode, $responseText);

    return [
        'success' => (bool)$interpreted['success'],
        'http_code' => $httpCode,
        'response' => $responseText,
        'request_url' => (string)($sendResult['request_url'] ?? ''),
        'provider_code' => $interpreted['provider_code'],
        'error_type' => $interpreted['error_type'],
    ];
}

function logCli($message) {
    global $cronLogFile;
    $timestamp = date('Y-m-d H:i:s');
    $line = '[' . $timestamp . '] ' . $message . "\n";
    echo $line;
    @file_put_contents($cronLogFile, $line, FILE_APPEND | LOCK_EX);
}

logCli('Starting unsent feedback sender');

$feedbackDelayHours = defined('FEEDBACK_SEND_DELAY_HOURS') ? max(0, (int)FEEDBACK_SEND_DELAY_HOURS) : 24;
logCli('Feedback send delay hours set to ' . $feedbackDelayHours);

$feedbackStartDate = '';
if (defined('FEEDBACK_SEND_FROM_DATE') && trim((string)FEEDBACK_SEND_FROM_DATE) !== '') {
    $feedbackStartDate = trim((string)FEEDBACK_SEND_FROM_DATE);
    $parsedDate = DateTime::createFromFormat('Y-m-d', $feedbackStartDate);
    if (!$parsedDate) {
        logCli('Invalid FEEDBACK_SEND_FROM_DATE format; expected YYYY-MM-DD.');
        exit(1);
    }
    $feedbackStartDate = $parsedDate->format('Y-m-d') . ' 00:00:00';
    logCli('Feedback eligible from date set to ' . $feedbackStartDate);
}

try {
    $stmt = $pdo->query("SELECT 1 FROM tickets LIMIT 1");
} catch (Exception $e) {
    logCli('Database connection failed: ' . $e->getMessage());
    exit(1);
}

$delayCondition = '';
if ($feedbackDelayHours > 0) {
    $delayCondition = ' AND t.arrival_timestamp < (NOW() - INTERVAL ' . $feedbackDelayHours . ' HOUR)';
}

$startDateCondition = '';
$executeParams = [];
if ($feedbackStartDate !== '') {
    $startDateCondition = ' AND t.arrival_timestamp >= :feedback_start_date';
    $executeParams[':feedback_start_date'] = $feedbackStartDate;
}

$groups = executeAndFetch($pdo,
    "SELECT p.patient_id, p.patient_name, p.country_code, p.mobile, p.care_country_code, p.care_mobile,
            DATE(t.arrival_timestamp) AS visit_date, MAX(t.ticket_id) AS latest_ticket_id
     FROM tickets t
     INNER JOIN patients p ON p.patient_id = t.patient_id
     WHERE t.current_status <> 'Canceled'" . $delayCondition . $startDateCondition . "
     GROUP BY p.patient_id, p.patient_name, p.country_code, p.mobile, p.care_country_code, p.care_mobile, visit_date
     ORDER BY visit_date DESC, p.patient_name",
    $executeParams
);

// Get latest ticket per patient-day (feedback is per patient-day, not per ticket)
$ticketIds = array_values(array_filter(array_map(fn($row) => (int)($row['latest_ticket_id'] ?? 0), $groups), fn($id) => $id > 0));
$feedbackMap = [];
if (!empty($ticketIds)) {
    $placeholders = implode(',', array_fill(0, count($ticketIds), '?'));
    
    // Ensure records exist for latest tickets (initialize with feedback_sent = 0 if not present)
    try {
        foreach ($ticketIds as $tid) {
            executeUpdate($pdo,
                "INSERT IGNORE INTO feedback_tickets (ticket_id, feedback_sent)
                 VALUES (?, 0)",
                [$tid]
            );
        }
    } catch (Exception $e) {
        // Silent fail - proceed with query anyway
    }
    
    
    $fsResults = executeAndFetch($pdo,
        "SELECT ticket_id, feedback_sent FROM feedback_tickets WHERE ticket_id IN ($placeholders)",
        $ticketIds
    );
    foreach ($fsResults as $fsRow) {
        $ticketId = (int)($fsRow['ticket_id'] ?? 0);
        if ($ticketId > 0) {
            $feedbackMap[$ticketId] = ['feedback_sent' => (int)($fsRow['feedback_sent'] ?? 0)];
        }
    }
}

$sentCount = 0;
$failCount = 0;
$skipCount = 0;

foreach ($groups as $group) {
    $patientId = (int)($group['patient_id'] ?? 0);
    $ticketId = (int)($group['latest_ticket_id'] ?? 0);
    if ($ticketId <= 0) {
        $skipCount++;
        continue;
    }

    $feedbackStatus = $feedbackMap[$ticketId] ?? ['feedback_sent' => 0];
    if ((int)$feedbackStatus['feedback_sent'] === 1) {
        $skipCount++;
        continue;
    }

    $countryCode = $group['care_country_code'] ?: ($group['country_code'] ?: '+961');
    $mobile = $group['care_mobile'] ?: $group['mobile'];
    $phone = formatWhatsAppNumber($mobile, $countryCode);
    if ($phone === '') {
        $skipCount++;
        continue;
    }

    $feedbackLink = FEEDBACK_TALLY_FORM_URL;
    $sendResult = sendWhatsAppTemplateWithVariables($phone, 'feedback', $feedbackLink);

    // The provider sometimes returns HTTP 2xx while the body parser can't extract a definitive “success” code.
    // To avoid false negatives, treat HTTP 2xx as success for marking feedback as sent.
    $httpOk = !empty($sendResult['http_code']) && (int)$sendResult['http_code'] >= 200 && (int)$sendResult['http_code'] < 300;
    $isSuccess = $httpOk || !empty($sendResult['success']);

    executeUpdate($pdo,
        "INSERT INTO feedback_tickets (ticket_id, feedback_sent)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE feedback_sent = VALUES(feedback_sent)",
        [$ticketId, $isSuccess ? 1 : 0]
    );

    $logAction = $isSuccess ? 'Feedback WhatsApp Sent' : 'Feedback WhatsApp Failed';

    $rawResponse = trim((string)($sendResult['response'] ?? ''));
    $curlError = trim((string)($sendResult['curl_error'] ?? ''));
    $logNotes = 'scheduled=1 | Template=feedback | link=' . $feedbackLink;
    $logNotes .= ' | phone=' . $phone;
    $logNotes .= ' | http_code=' . (string)($sendResult['http_code'] ?? '');
    $logNotes .= ' | provider_success_flag=' . (!empty($sendResult['success']) ? '1' : '0');
    if ($curlError !== '') {
        $logNotes .= ' | curl_error=' . $curlError;
    }
    if ($rawResponse !== '') {
        $logNotes .= ' | response=' . $rawResponse;
    }

    if (!$isSuccess) {
        $logNotes .= ' | error_type=' . trim((string)($sendResult['error_type'] ?? 'send_error'));
    }

    executeUpdate($pdo,
        "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, ?, NULL, NULL, ?, ?)",
        [$ticketId, $logAction, authCurrentUserId() ?: null, $logNotes]
    );

    logCli(sprintf(
        'Ticket %d patient %d: %s (phone=%s, http_code=%s, result=%s)',
        $ticketId,
        $patientId,
        $logAction,
        $phone,
        (string)($sendResult['http_code'] ?? ''),
        $rawResponse
    ));


    if ($isSuccess) {
        $sentCount++;
    } else {
        $failCount++;
    }
}

logCli("Finished sending feedback. Sent={$sentCount}, Failed={$failCount}, Skipped={$skipCount}.");
exit(0);

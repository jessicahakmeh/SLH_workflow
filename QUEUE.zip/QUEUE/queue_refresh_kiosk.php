<?php
// Minimal kiosk-only endpoint returning a safe JSON array for TVs
// Usage: /queue_refresh_kiosk.php?department=imaging&machine=1&limit=10

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Keep output minimal and stable for old browsers
require_once 'config.php';

try {
    $department = isset($_GET['department']) ? trim($_GET['department']) : 'all';
    $machine = isset($_GET['machine']) ? trim($_GET['machine']) : 'all';
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
    if ($limit <= 0) $limit = 10;

    // Base query: only what TVs need
    $query = "SELECT t.ticket_id AS id, t.queue_number, t.current_status AS status FROM tickets t WHERE t.closing_timestamp IS NULL AND t.arrival_timestamp >= CURDATE() AND t.arrival_timestamp < (CURDATE() + INTERVAL 1 DAY)";
    $params = [];

    // Department-specific narrow filters to keep payload small
    if ($department === 'lab') {
        $query .= " AND t.lab = 1 AND t.current_status IN ('Called','Recalled')";
    } elseif ($department === 'imaging') {
        if ($machine !== 'all' && $machine !== '') {
            $query .= " AND t.imaging_machine = ?";
            $params[] = $machine;
        }
        $query .= " AND t.img = 1 AND t.current_status IN ('Called','Recalled')";
    } else {
        // Generic: all Called/Recalled
        $query .= " AND t.current_status IN ('Called','Recalled')";
    }

    $query .= " ORDER BY t.arrival_timestamp ASC LIMIT ?";
    $params[] = $limit;

    $rows = [];
    try {
        $rows = executeAndFetch($pdo, $query, $params);
    } catch (Exception $e) {
        error_log('queue_refresh_kiosk query failed: ' . $e->getMessage());
        $rows = [];
    }

    // Return a minimal stable array (no extra debug info)
    echo json_encode($rows);
} catch (Exception $e) {
    error_log('queue_refresh_kiosk error: ' . $e->getMessage());
    echo json_encode([]);
}

exit;

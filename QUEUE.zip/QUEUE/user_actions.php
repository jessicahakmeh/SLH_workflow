<?php
require_once 'config.php';
session_start();
authRequireRoles([], ['message' => 'You must be logged in to view action logs.']);

function userActionDecodeDetails($detailsText) {
    $decoded = json_decode((string)$detailsText, true);
    return is_array($decoded) ? $decoded : null;
}

function userActionTicketLabel($detailsText) {
    $details = userActionDecodeDetails($detailsText);
    if (!$details) {
        return '';
    }

    $parts = [];
    if (!empty($details['queue_number'])) {
        $parts[] = 'Q ' . (string)$details['queue_number'];
    } elseif (!empty($details['ticket_id'])) {
        $parts[] = 'Ticket #' . (string)$details['ticket_id'];
    }
    if (!empty($details['patient_name'])) {
        $parts[] = (string)$details['patient_name'];
    }
    return implode(' | ', $parts);
}

function userActionChangeLabel($detailsText) {
    $details = userActionDecodeDetails($detailsText);
    if (!$details) {
        return '';
    }
    $fromStatus = trim((string)($details['from_status'] ?? ''));
    $toStatus = trim((string)($details['to_status'] ?? ''));
    if ($fromStatus !== '' || $toStatus !== '') {
        return $fromStatus !== '' ? $fromStatus . ' -> ' . ($toStatus !== '' ? $toStatus : '?') : $toStatus;
    }
    if (!empty($details['ticket_action'])) {
        return (string)$details['ticket_action'];
    }
    return '';
}

function userActionRenderDetails($detailsText) {
    $details = userActionDecodeDetails($detailsText);
    if (!$details) {
        return (string)$detailsText;
    }

    $skipKeys = [
        'ticket_id', 'queue_number', 'patient_name', 'from_status', 'to_status',
    ];
    $labelMap = [
        'ticket_action' => 'Action',
        'department' => 'Department',
        'status' => 'Current Status',
        'service_type' => 'Service Type',
        'imaging_machine' => 'Machine',
        'clinic' => 'Clinic',
        'requested_by' => 'Requested By',
        'assigned_butler' => 'Assigned Butler',
        'machine' => 'Machine',
        'notes' => 'Notes',
        'message' => 'Message',
        'query' => 'Query',
        'method' => 'Method',
        'action' => 'Submitted Action',
        'post_keys' => 'POST Keys',
        'roles' => 'Roles',
        'mode' => 'Mode',
        'target_username' => 'Target User',
        'target_user_id' => 'Target User ID',
        'auth_source' => 'Auth Source',
        'required_roles' => 'Required Roles',
    ];

    $lines = [];
    foreach ($details as $key => $value) {
        if (in_array($key, $skipKeys, true) || $value === null || $value === '') {
            continue;
        }
        $label = $labelMap[$key] ?? ucwords(str_replace('_', ' ', (string)$key));
        if (is_array($value)) {
            $value = implode(', ', array_map('strval', $value));
        }
        $lines[] = $label . ': ' . (string)$value;
    }

    return !empty($lines) ? implode("\n", $lines) : (string)$detailsText;
}

$user = authCurrentUser();
$isPrivileged = authHasAnyRole(['admin', 'quality']);

$rawUserId = $_GET['user_id'] ?? null;
$showAll = $isPrivileged && ($rawUserId === 'all');
if (!$showAll) {
    $selectedUserId = $isPrivileged ? (int)($rawUserId ?? (int)$user['id']) : (int)$user['id'];
    $selectedUserId = $selectedUserId > 0 ? $selectedUserId : (int)$user['id'];
} else {
    $selectedUserId = 0;
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = $page > 0 ? $page : 1;
$perPage = 50;
$offset = ($page - 1) * $perPage;

$users = executeAndFetch($pdo, "SELECT id, username, full_name FROM users WHERE is_active = 1 ORDER BY full_name ASC, username ASC", []);

if ($showAll) {
    $countStmt = $pdo->query("SELECT COUNT(*) FROM user_action_logs");
    $totalLogs = (int)$countStmt->fetchColumn();

    $logs = executeAndFetch($pdo,
        "SELECT l.user_id, l.username, l.action_key, l.page_name, l.details, l.ip_address, l.created_at, u.full_name
         FROM user_action_logs l
         LEFT JOIN users u ON u.id = l.user_id
         ORDER BY l.created_at DESC
         LIMIT ? OFFSET ?",
        [$perPage, $offset]
    );
} else {
    $totalLogs = (int)executeAndFetchOne($pdo, "SELECT COUNT(*) FROM user_action_logs WHERE user_id = ?", [$selectedUserId]);

    $logs = executeAndFetch($pdo,
        "SELECT l.user_id, l.username, l.action_key, l.page_name, l.details, l.ip_address, l.created_at, u.full_name
         FROM user_action_logs l
         LEFT JOIN users u ON u.id = l.user_id
         WHERE l.user_id = ?
         ORDER BY l.created_at DESC
         LIMIT ? OFFSET ?",
        [$selectedUserId, $perPage, $offset]
    );
}

$totalPages = max(1, (int)ceil($totalLogs / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
}

function userActionsPageUrl($page, $rawUserId, $showAll) {
    $params = [];
    if ($showAll) {
        $params['user_id'] = 'all';
    } elseif ($rawUserId !== null && $rawUserId !== '') {
        $params['user_id'] = (string)$rawUserId;
    }
    $params['page'] = (int)$page;
    return 'user_actions.php?' . http_build_query($params);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Actions</title>
    <style>
        body{margin:0;font-family:Segoe UI,Tahoma,sans-serif;background:#f3f6fb;color:#17212f}.wrap{max-width:1180px;margin:30px auto;padding:0 20px}.card{background:#fff;border-radius:16px;padding:20px 22px;box-shadow:0 18px 48px rgba(23,33,47,.10)}
        table{width:100%;border-collapse:collapse;margin-top:18px}th,td{text-align:left;padding:12px 10px;border-bottom:1px solid #e6edf7;vertical-align:top}th{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:#607086}select{padding:10px 12px;border:1px solid #c9d3e1;border-radius:10px}a{color:#0b66c3;text-decoration:none}.meta{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:12px}
        .pill{display:inline-block;background:#eef5ff;color:#0b66c3;border-radius:999px;padding:4px 8px;font-size:12px;font-weight:700}.details{white-space:pre-wrap;word-break:break-word;color:#455468}.empty{padding:28px 0;color:#607086}
        .pager-link{padding:6px 10px;border:1px solid #d5dfec;border-radius:8px;background:#fff}
        .pager-link.active{background:#0b66c3;color:#fff;border-color:#0b66c3;font-weight:700}
    </style>
</head>
<body>
    <?php authRenderUserMenu(); ?>
<div class="wrap">
    <div class="card">
        <div class="meta">
            <a href="<?php echo htmlspecialchars(authDefaultLandingPage(), ENT_QUOTES, 'UTF-8'); ?>">Back</a>
            <?php if (!(defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED)): ?><a href="change_password.php">Change Password</a><?php endif; ?>
            <?php if (authHasAnyRole(['admin'])): ?><a href="user_management.php">User Management</a><?php endif; ?>
            <a href="logout.php">Logout</a>
        </div>
        <h1>User Action Logs</h1>
        <p class="pill"><?php echo htmlspecialchars((string)($user['full_name'] ?: $user['username']), ENT_QUOTES, 'UTF-8'); ?></p>
        <p style="margin:8px 0 12px; color:#607086;">Showing <?php echo htmlspecialchars((string)count($logs), ENT_QUOTES, 'UTF-8'); ?> of <?php echo htmlspecialchars((string)$totalLogs, ENT_QUOTES, 'UTF-8'); ?> logs | Page <?php echo htmlspecialchars((string)$page, ENT_QUOTES, 'UTF-8'); ?> of <?php echo htmlspecialchars((string)$totalPages, ENT_QUOTES, 'UTF-8'); ?></p>
        <form method="get" action="user_actions.php">
            <label for="user_id">User</label>
            <select id="user_id" name="user_id" <?php echo $isPrivileged ? '' : 'disabled'; ?> onchange="this.form.submit()">
                <?php if ($isPrivileged): ?>
                    <option value="all" <?php echo $showAll ? 'selected' : ''; ?>>All Users</option>
                <?php endif; ?>
                <?php foreach ($users as $option): ?>
                    <?php if (!$isPrivileged && (int)$option['id'] !== (int)$user['id']) { continue; } ?>
                    <option value="<?php echo (int)$option['id']; ?>" <?php echo (!$showAll && (int)$option['id'] === $selectedUserId) ? 'selected' : ''; ?>><?php echo htmlspecialchars(trim((string)($option['full_name'] ?: $option['username'])), ENT_QUOTES, 'UTF-8'); ?></option>
                <?php endforeach; ?>
            </select>
        </form>
        <?php if (empty($logs)): ?>
            <div class="empty">No actions logged yet for this user.</div>
        <?php else: ?>
            <table>
                <thead>
                    <tr><th>Time</th><th>Handled By</th><th>Action</th><th>Ticket</th><th>Change</th><th>Page</th><th>IP</th><th>Details</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <?php $actorLabel = trim((string)($log['full_name'] ?? '')) !== '' ? (string)$log['full_name'] : (string)($log['username'] ?? ''); ?>
                        <tr>
                            <td><?php echo htmlspecialchars((string)$log['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($actorLabel !== '' ? $actorLabel : 'System', ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars((string)$log['action_key'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars(userActionTicketLabel((string)($log['details'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars(userActionChangeLabel((string)($log['details'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars((string)($log['page_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars((string)($log['ip_address'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="details"><?php echo htmlspecialchars(userActionRenderDetails((string)($log['details'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php if ($totalPages > 1): ?>
                <div style="display:flex; gap:8px; align-items:center; justify-content:center; margin-top:16px; flex-wrap:wrap;">
                    <?php if ($page > 1): ?>
                        <a class="pager-link" href="<?php echo htmlspecialchars(userActionsPageUrl($page - 1, $rawUserId, $showAll), ENT_QUOTES, 'UTF-8'); ?>">Previous</a>
                    <?php endif; ?>

                    <?php
                        $window = 2;
                        $startPage = max(1, $page - $window);
                        $endPage = min($totalPages, $page + $window);

                        if ($startPage > 1) {
                            echo '<a class="pager-link" href="' . htmlspecialchars(userActionsPageUrl(1, $rawUserId, $showAll), ENT_QUOTES, 'UTF-8') . '">1</a>';
                            if ($startPage > 2) {
                                echo '<span style="color:#607086;">...</span>';
                            }
                        }

                        for ($i = $startPage; $i <= $endPage; $i++) {
                            $activeClass = $i === $page ? ' active' : '';
                            echo '<a class="pager-link' . $activeClass . '" href="' . htmlspecialchars(userActionsPageUrl($i, $rawUserId, $showAll), ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars((string)$i, ENT_QUOTES, 'UTF-8') . '</a>';
                        }

                        if ($endPage < $totalPages) {
                            if ($endPage < $totalPages - 1) {
                                echo '<span style="color:#607086;">...</span>';
                            }
                            echo '<a class="pager-link" href="' . htmlspecialchars(userActionsPageUrl($totalPages, $rawUserId, $showAll), ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars((string)$totalPages, ENT_QUOTES, 'UTF-8') . '</a>';
                        }
                    ?>

                    <?php if ($page < $totalPages): ?>
                        <a class="pager-link" href="<?php echo htmlspecialchars(userActionsPageUrl($page + 1, $rawUserId, $showAll), ENT_QUOTES, 'UTF-8'); ?>">Next</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
</body>
</html>

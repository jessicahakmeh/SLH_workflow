<?php

function authIsEnabled() {
    return defined('AUTH_ENABLED') && AUTH_ENABLED;
}

function authUpdateSessionActivity() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION['auth_last_activity'] = time();
    }
}

function authCheckSessionInactivity() {
    if (!authIsEnabled()) {
        return false;
    }
    
    if (!isset($_SESSION['auth_user']) || !is_array($_SESSION['auth_user'])) {
        return false;
    }

    if (!isset($_SESSION['auth_last_activity'])) {
        $_SESSION['auth_last_activity'] = time();
        return false;
    }

    $timeoutSeconds = defined('AUTH_SESSION_TIMEOUT_SECONDS') ? (int)AUTH_SESSION_TIMEOUT_SECONDS : 86400;
    $lastActivity = (int)$_SESSION['auth_last_activity'];
    $currentTime = time();
    $inactiveSeconds = $currentTime - $lastActivity;

    if ($inactiveSeconds > $timeoutSeconds) {
        authLogoutUser();
        return true; // Session has been terminated due to inactivity
    }

    // Update activity timestamp on this request
    $_SESSION['auth_last_activity'] = $currentTime;
    return false;
}

function authIsAjaxRequest() {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string)$_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        return true;
    }
    if (!empty($_SERVER['HTTP_ACCEPT']) && stripos((string)$_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
        return true;
    }
    return false;
}

function authAllRoles() {
    return ['admin', 'billing', 'butler', 'imaging', 'laboratory', 'quality'];
}

function authCurrentUser() {
    if (!authIsEnabled()) {
        return [
            'id' => 0,
            'username' => 'auth-disabled',
            'full_name' => 'Authentication Disabled',
            'roles' => authAllRoles(),
        ];
    }
    return isset($_SESSION['auth_user']) && is_array($_SESSION['auth_user']) ? $_SESSION['auth_user'] : null;
}

function authCurrentUserId() {
    $user = authCurrentUser();
    return (int)($user['id'] ?? 0);
}

function authCurrentUsername() {
    $user = authCurrentUser();
    return (string)($user['username'] ?? '');
}

function authCurrentRoles() {
    $user = authCurrentUser();
    return isset($user['roles']) && is_array($user['roles']) ? array_values($user['roles']) : [];
}

function authHasAnyRole($roles) {
    if (!authIsEnabled()) {
        return true;
    }
    $required = is_array($roles) ? $roles : [$roles];
    if (empty($required)) {
        return authCurrentUser() !== null;
    }
    $current = authCurrentRoles();
    foreach ($required as $role) {
        if (in_array((string)$role, $current, true)) {
            return true;
        }
    }
    return false;
}

function authPageName() {
    return basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
}

function authClientIp() {
    $candidates = ['HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($candidates as $key) {
        if (!empty($_SERVER[$key])) {
            $value = trim((string)$_SERVER[$key]);
            if ($key === 'HTTP_X_FORWARDED_FOR') {
                $parts = explode(',', $value);
                return trim((string)$parts[0]);
            }
            return $value;
        }
    }
    return '';
}

function authLogThrottleSeconds($kind) {
    $kind = strtolower(trim((string)$kind));
    if ($kind === 'submit') {
        return defined('AUTH_SUBMIT_LOG_TTL_SECONDS') ? max(0, (int)AUTH_SUBMIT_LOG_TTL_SECONDS) : 1;
    }
    return defined('AUTH_VIEW_LOG_TTL_SECONDS') ? max(0, (int)AUTH_VIEW_LOG_TTL_SECONDS) : 20;
}

function authShouldLogBySessionThrottle($kind, $fingerprint) {
    $ttl = authLogThrottleSeconds($kind);
    if ($ttl <= 0) {
        return true;
    }

    if (!isset($_SESSION) || !is_array($_SESSION)) {
        return true;
    }

    if (!isset($_SESSION['auth_log_throttle']) || !is_array($_SESSION['auth_log_throttle'])) {
        $_SESSION['auth_log_throttle'] = [];
    }

    $now = time();
    $bucketKey = strtolower(trim((string)$kind)) . ':' . md5((string)$fingerprint);
    $lastTs = isset($_SESSION['auth_log_throttle'][$bucketKey]) ? (int)$_SESSION['auth_log_throttle'][$bucketKey] : 0;

    if ($lastTs > 0 && ($now - $lastTs) < $ttl) {
        return false;
    }

    $_SESSION['auth_log_throttle'][$bucketKey] = $now;

    // Keep the session bucket bounded.
    if (count($_SESSION['auth_log_throttle']) > 150) {
        asort($_SESSION['auth_log_throttle']);
        $_SESSION['auth_log_throttle'] = array_slice($_SESSION['auth_log_throttle'], -100, null, true);
    }

    return true;
}

function authGetPatientLogContext($patientId) {
    global $pdo;
    $patientId = (int)$patientId;
    if ($patientId <= 0 || !isset($pdo) || !$pdo instanceof PDO) {
        return null;
    }

    try {
        return executeAndFetchOne($pdo, "SELECT patient_id, mrn, patient_name, country_code, mobile FROM patients WHERE patient_id = ? LIMIT 1", [$patientId]);
    } catch (Exception $e) {
        return null;
    }
}

function authBuildSubmitRequestDetails($requestMethod, $actionName, $postKeys) {
    $details = [
        'method' => (string)$requestMethod,
        'action' => (string)$actionName,
        'post_keys' => is_array($postKeys) ? array_values($postKeys) : [],
    ];

    $interestingFields = [
        'selected_patient_id',
        'existing_patient_id',
        'patient_id',
        'ticket_id',
        'mrn',
        'patient_name',
        'service_type',
        'queue_number',
        'selected_patient_name',
    ];

    $requestFields = [];
    foreach ($interestingFields as $field) {
        if (!isset($_POST[$field]) || is_array($_POST[$field])) {
            continue;
        }
        $value = trim((string)$_POST[$field]);
        if ($value === '') {
            continue;
        }
        $requestFields[$field] = mb_substr($value, 0, 120);
    }
    if (!empty($requestFields)) {
        $details['request_fields'] = $requestFields;
    }

    $patientId = 0;
    foreach (['selected_patient_id', 'existing_patient_id', 'patient_id'] as $patientKey) {
        if (!empty($_POST[$patientKey])) {
            $patientId = (int)$_POST[$patientKey];
            if ($patientId > 0) {
                break;
            }
        }
    }

    if ($patientId > 0) {
        $patientContext = authGetPatientLogContext($patientId);
        if ($patientContext) {
            $details['patient_context'] = [
                'patient_id' => (int)($patientContext['patient_id'] ?? $patientId),
                'mrn' => (string)($patientContext['mrn'] ?? ''),
                'patient_name' => (string)($patientContext['patient_name'] ?? ''),
                'mobile' => (string)($patientContext['country_code'] ?? '') . (string)($patientContext['mobile'] ?? ''),
            ];
        } else {
            $details['patient_context'] = ['patient_id' => $patientId];
        }
    }

    // For scan_docs POST, include pending patient context from session to identify the request owner.
    if (authPageName() === 'scan_docs.php' && isset($_SESSION['pending_patient_data']) && is_array($_SESSION['pending_patient_data'])) {
        $pending = $_SESSION['pending_patient_data'];
        $details['pending_patient'] = [
            'existing_patient_id' => (int)($pending['existing_patient_id'] ?? 0),
            'patient_name' => mb_substr((string)($pending['patient_name'] ?? ''), 0, 120),
            'service_type' => (string)($pending['service_type'] ?? ''),
        ];
    }

    return $details;
}

function authLogAction($actionKey, $details = [], $pageName = null, $userId = null, $username = null) {
    global $pdo;
    if (!isset($pdo) || !$pdo instanceof PDO) {
        return;
    }

    if ($userId === null) {
        $userId = authCurrentUserId();
    }
    if ($username === null || $username === '') {
        $username = authCurrentUsername();
    }

    $detailText = '';
    if (is_array($details)) {
        $detailText = json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    } elseif ($details !== null) {
        $detailText = (string)$details;
    }

    try {
        executeUpdate($pdo, "INSERT INTO user_action_logs (user_id, username, action_key, page_name, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)", [
            $userId > 0 ? $userId : null,
            $username !== '' ? $username : null,
            (string)$actionKey,
            $pageName !== null ? (string)$pageName : authPageName(),
            $detailText !== '' ? $detailText : null,
            authClientIp(),
            substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        ]);
    } catch (Exception $e) {
    }
}

function authGetTicketLogContext($ticketId) {
    global $pdo;
    $ticketId = (int)$ticketId;
    if ($ticketId <= 0 || !isset($pdo) || !$pdo instanceof PDO) {
        return null;
    }

    try {
        return executeAndFetchOne($pdo, "SELECT t.ticket_id, t.queue_number, t.current_status, t.service_type, t.imaging_machine, t.Clinic, p.patient_name FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ? LIMIT 1", [$ticketId]);
    } catch (Exception $e) {
        return null;
    }
}

function authLogTicketAction($actionKey, $ticketId, $details = [], $pageName = null, $userId = null, $username = null) {
    $ticketId = (int)$ticketId;
    if ($ticketId <= 0) {
        authLogAction($actionKey, $details, $pageName, $userId, $username);
        return;
    }

    $context = authGetTicketLogContext($ticketId);
    $payload = is_array($details) ? $details : ['message' => (string)$details];
    if ($context) {
        $payload = array_merge([
            'ticket_id' => (int)($context['ticket_id'] ?? $ticketId),
            'queue_number' => (string)($context['queue_number'] ?? ''),
            'patient_name' => (string)($context['patient_name'] ?? ''),
            'status' => (string)($context['current_status'] ?? ''),
            'service_type' => (string)($context['service_type'] ?? ''),
            'imaging_machine' => (string)($context['imaging_machine'] ?? ''),
            'clinic' => (string)($context['Clinic'] ?? ''),
        ], $payload);
    } else {
        $payload = array_merge(['ticket_id' => $ticketId], $payload);
    }

    authLogAction($actionKey, $payload, $pageName, $userId, $username);
}

function authDenyAccess($message, $httpCode = 403) {
    http_response_code($httpCode);
    if (authIsAjaxRequest()) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Access Denied</title><style>body{font-family:Arial,sans-serif;background:#f5f7fb;color:#17212f;padding:40px}.card{max-width:560px;margin:40px auto;background:#fff;border-radius:14px;padding:28px;box-shadow:0 12px 40px rgba(23,33,47,.12)}a{color:#0b66c3;text-decoration:none}.actions{margin-top:18px;display:flex;gap:12px;flex-wrap:wrap}</style></head><body><div class="card"><h1>Access Denied</h1><p>' . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</p><div class="actions"><a href="login.php">Go to Login</a><a href="stream.php">Open Stream</a></div></div></body></html>';
    exit;
}

function authRequireRoles($roles = [], $options = []) {
    if (!authIsEnabled()) {
        return;
    }

    // Check for session inactivity timeout
    if (authCheckSessionInactivity()) {
        // Session was terminated due to inactivity
        if (authIsAjaxRequest()) {
            authDenyAccess('Your session has expired due to inactivity. Please log in again.', 401);
        }
        $returnTo = authPageName();
        $query = $_SERVER['QUERY_STRING'] ?? '';
        if ($query !== '') {
            $returnTo .= '?' . $query;
        }
        session_write_close(); // Ensure session is written before redirect
        header('Location: login.php?return_to=' . urlencode($returnTo));
        exit;
    }

    $roles = is_array($roles) ? $roles : [$roles];
    $logView = array_key_exists('log_view', $options) ? (bool)$options['log_view'] : true;
    $customMessage = isset($options['message']) ? (string)$options['message'] : 'You do not have access to this page.';

    $user = authCurrentUser();
    if ($user === null) {
        if (authIsAjaxRequest()) {
            authDenyAccess('Authentication required.', 401);
        }
        $returnTo = authPageName();
        $query = $_SERVER['QUERY_STRING'] ?? '';
        if ($query !== '') {
            $returnTo .= '?' . $query;
        }
        session_write_close(); // Ensure session is written before redirect
        header('Location: login.php?return_to=' . urlencode($returnTo));
        exit;
    }

    if (!empty($roles) && !authHasAnyRole($roles)) {
        authLogAction('access_denied', ['required_roles' => array_values($roles)], authPageName());
        authDenyAccess($customMessage, 403);
    }

    $requestMethod = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if ($logView && $requestMethod === 'GET' && !authIsAjaxRequest()) {
        $query = trim((string)($_SERVER['QUERY_STRING'] ?? ''));
        $viewFingerprint = authPageName() . '|' . $query;
        if (authShouldLogBySessionThrottle('view', $viewFingerprint)) {
            authLogAction('view_page', ['query' => $query], authPageName());
        }
    } elseif ($requestMethod !== 'GET') {
        $postKeys = [];
        if (isset($_POST) && is_array($_POST)) {
            $postKeys = array_values(array_map('strval', array_keys($_POST)));
        }
        $actionName = '';
        if (!empty($_POST['action'])) {
            $actionName = (string)$_POST['action'];
        } elseif (!empty($_GET['action'])) {
            $actionName = (string)$_GET['action'];
        }
        $submitFingerprint = authPageName() . '|' . $requestMethod . '|' . $actionName . '|' . implode(',', $postKeys);
        if (authShouldLogBySessionThrottle('submit', $submitFingerprint)) {
            $submitDetails = authBuildSubmitRequestDetails($requestMethod, $actionName, $postKeys);
            authLogAction('submit_request', $submitDetails, authPageName());
        }
    }
}

function authGetUserByUsername($username) {
    global $pdo;
    return executeAndFetchOne($pdo, "SELECT * FROM users WHERE username = ? AND is_active = 1 LIMIT 1", [trim((string)$username)]);
}

function authNormalizeLoginName($username) {
    $username = trim((string)$username);
    if ($username === '') {
        return '';
    }
    if (strpos($username, '\\') !== false) {
        $parts = explode('\\', $username);
        $username = end($parts);
    }
    if (strpos($username, '@') !== false) {
        $parts = explode('@', $username, 2);
        $username = $parts[0];
    }
    return strtolower(trim((string)$username));
}

function authBuildAdBindUsername($username) {
    $username = trim((string)$username);
    if ($username === '') {
        return '';
    }
    if (strpos($username, '\\') !== false || strpos($username, '@') !== false) {
        return $username;
    }
    if (defined('AUTH_AD_NETBIOS') && trim((string)AUTH_AD_NETBIOS) !== '') {
        return trim((string)AUTH_AD_NETBIOS) . '\\' . $username;
    }
    if (defined('AUTH_AD_DOMAIN') && trim((string)AUTH_AD_DOMAIN) !== '') {
        return $username . '@' . trim((string)AUTH_AD_DOMAIN);
    }
    return $username;
}

function authLdapEscapeValue($value) {
    $value = (string)$value;
    if (function_exists('ldap_escape')) {
        return ldap_escape($value, '', LDAP_ESCAPE_FILTER);
    }
    $map = [
        '\\' => '\\5c',
        '*' => '\\2a',
        '(' => '\\28',
        ')' => '\\29',
        chr(0) => '\\00',
    ];
    return strtr($value, $map);
}

function authAdCreateConnection(&$error = '') {
    $error = '';
    if (!function_exists('ldap_connect')) {
        $error = 'PHP LDAP extension is not enabled.';
        return null;
    }

    $primaryServer = defined('AUTH_AD_SERVER') ? trim((string)AUTH_AD_SERVER) : '';
    $fallbackServer = defined('AUTH_AD_FALLBACK_SERVER') ? trim((string)AUTH_AD_FALLBACK_SERVER) : '';
    $port = defined('AUTH_AD_PORT') ? (int)AUTH_AD_PORT : 389;
    $port = $port > 0 ? $port : 389;

    if ($primaryServer === '') {
        $error = 'AUTH_AD_SERVER is empty.';
        return null;
    }

    $servers = array_filter(array_unique([$primaryServer, $fallbackServer]), static function ($s) { return $s !== ''; });
    foreach ($servers as $server) {
        $connection = @ldap_connect($server, $port);
        if ($connection === false) {
            continue;
        }
        @ldap_set_option($connection, LDAP_OPT_PROTOCOL_VERSION, 3);
        @ldap_set_option($connection, LDAP_OPT_REFERRALS, 0);
        if (defined('AUTH_AD_USE_TLS') && AUTH_AD_USE_TLS) {
            @ldap_start_tls($connection);
        }
        // Test the connection is actually reachable with a quick anonymous read
        $testRead = @ldap_read($connection, '', '(objectClass=*)', ['supportedCapabilities'], 0, 0, 2);
        if ($testRead !== false) {
            return $connection;
        }
        @ldap_unbind($connection);
    }

    $error = 'Could not reach any LDAP server (' . implode(', ', $servers) . ').';
    return null;
}

function authAdBindForSearch($connection, &$error = '') {
    $error = '';
    $bindUser = defined('AUTH_AD_SEARCH_BIND_USER') ? trim((string)AUTH_AD_SEARCH_BIND_USER) : '';
    $bindPass = defined('AUTH_AD_SEARCH_BIND_PASS') ? (string)AUTH_AD_SEARCH_BIND_PASS : '';

    if ($bindUser !== '') {
        $candidates = [$bindUser];
        $netbios = defined('AUTH_AD_NETBIOS') ? trim((string)AUTH_AD_NETBIOS) : '';
        $domain = defined('AUTH_AD_DOMAIN') ? trim((string)AUTH_AD_DOMAIN) : '';
        if (strpos($bindUser, '\\') === false && strpos($bindUser, '@') === false) {
            if ($netbios !== '') {
                $candidates[] = $netbios . '\\' . $bindUser;
            }
            if ($domain !== '') {
                $candidates[] = $bindUser . '@' . $domain;
            }
        }
        $candidates = array_values(array_unique(array_filter(array_map('trim', $candidates), static function ($value) {
            return $value !== '';
        })));

        foreach ($candidates as $candidateUser) {
            $ok = @ldap_bind($connection, $candidateUser, $bindPass);
            if ($ok === true) {
                return true;
            }
        }

        $lastError = authAdLastLdapError($connection);
        $error = 'AD search bind failed for configured service account. Tried: ' . implode(', ', $candidates) . '.' . ($lastError !== '' ? ' ' . $lastError : '');
        return false;
    }

    $ok = @ldap_bind($connection);
    if ($ok !== true) {
        $lastError = authAdLastLdapError($connection);
        $error = 'Anonymous AD search bind failed. Configure AUTH_AD_SEARCH_BIND_USER and AUTH_AD_SEARCH_BIND_PASS.' . ($lastError !== '' ? ' ' . $lastError : '');
        return false;
    }

    return true;
}

function authAdReadDefaultNamingContext($connection) {
    $search = @ldap_read($connection, '', '(objectClass=*)', ['defaultNamingContext']);
    if ($search === false) {
        return '';
    }
    $entries = @ldap_get_entries($connection, $search);
    if (!is_array($entries) || !isset($entries['count']) || (int)$entries['count'] < 1) {
        return '';
    }
    if (!isset($entries[0]['defaultnamingcontext'][0])) {
        return '';
    }
    return trim((string)$entries[0]['defaultnamingcontext'][0]);
}

function authAdLastLdapError($connection) {
    if (!is_resource($connection) && !(is_object($connection) && get_class($connection) === 'LDAP\\Connection')) {
        return '';
    }
    $message = function_exists('ldap_error') ? trim((string)@ldap_error($connection)) : '';
    $errno = function_exists('ldap_errno') ? (int)@ldap_errno($connection) : 0;
    if ($errno > 0 && $message !== '') {
        return 'LDAP error ' . $errno . ': ' . $message;
    }
    if ($message !== '') {
        return 'LDAP error: ' . $message;
    }
    return '';
}

function authSearchActiveDirectoryUsers($query, $limit = 15, &$error = '') {
    $error = '';
    $query = trim((string)$query);
    if ($query === '') {
        return [];
    }

    if (!authIsEnabled() || !defined('AUTH_AD_ENABLED') || !AUTH_AD_ENABLED) {
        $error = 'Active Directory authentication is not enabled.';
        return [];
    }

    $conn = authAdCreateConnection($connectError);
    if (!$conn) {
        $error = $connectError;
        return [];
    }

    if (!authAdBindForSearch($conn, $bindError)) {
        @ldap_unbind($conn);
        $error = $bindError;
        return [];
    }

    $baseDn = defined('AUTH_AD_BASE_DN') ? trim((string)AUTH_AD_BASE_DN) : '';
    if ($baseDn === '') {
        $baseDn = authAdReadDefaultNamingContext($conn);
    }
    if ($baseDn === '') {
        @ldap_unbind($conn);
        $error = 'AUTH_AD_BASE_DN is empty and defaultNamingContext could not be discovered.';
        return [];
    }

    $safe = authLdapEscapeValue($query);
    $limit = max(1, min(50, (int)$limit));
    $filter = '(&(objectCategory=person)(objectClass=user)(!(userAccountControl:1.2.840.113556.1.4.803:=2))(|(sAMAccountName=*' . $safe . '*)(displayName=*' . $safe . '*)(userPrincipalName=*' . $safe . '*)(mail=*' . $safe . '*)))';
    $attributes = ['samaccountname', 'displayname', 'userprincipalname', 'mail', 'distinguishedname'];

    $search = @ldap_search($conn, $baseDn, $filter, $attributes, 0, $limit);
    if ($search === false) {
        $ldapError = authAdLastLdapError($conn);
        // Fallback once in case AUTH_AD_BASE_DN points to the wrong tree.
        $fallbackBase = authAdReadDefaultNamingContext($conn);
        if ($fallbackBase !== '' && strcasecmp($fallbackBase, $baseDn) !== 0) {
            $search = @ldap_search($conn, $fallbackBase, $filter, $attributes, 0, $limit);
            if ($search !== false) {
                $baseDn = $fallbackBase;
            }
        }
    }
    if ($search === false) {
        $ldapError = isset($ldapError) && $ldapError !== '' ? $ldapError : authAdLastLdapError($conn);
        $bindUser = defined('AUTH_AD_SEARCH_BIND_USER') ? trim((string)AUTH_AD_SEARCH_BIND_USER) : '';
        $hint = '';
        if ($ldapError !== '' && stripos($ldapError, 'LDAP error 1:') !== false) {
            if ($bindUser === '') {
                $hint = ' Configure AUTH_AD_SEARCH_BIND_USER and AUTH_AD_SEARCH_BIND_PASS (service account) in config.php.';
            } else {
                $hint = ' Verify bind account permissions and AUTH_AD_USE_TLS/LDAPS policy on the domain controller.';
            }
        }
        @ldap_unbind($conn);
        $error = 'AD search query failed for base DN "' . $baseDn . '".' . ($ldapError !== '' ? ' ' . $ldapError : '') . $hint;
        return [];
    }

    $entries = @ldap_get_entries($conn, $search);
    @ldap_unbind($conn);
    if (!is_array($entries) || !isset($entries['count'])) {
        return [];
    }

    $results = [];
    for ($i = 0; $i < (int)$entries['count']; $i++) {
        $row = $entries[$i];
        $sam = isset($row['samaccountname'][0]) ? trim((string)$row['samaccountname'][0]) : '';
        $display = isset($row['displayname'][0]) ? trim((string)$row['displayname'][0]) : '';
        $upn = isset($row['userprincipalname'][0]) ? trim((string)$row['userprincipalname'][0]) : '';
        $mail = isset($row['mail'][0]) ? trim((string)$row['mail'][0]) : '';
        $dn = isset($row['distinguishedname'][0]) ? trim((string)$row['distinguishedname'][0]) : '';
        if ($sam === '') {
            continue;
        }
        $results[] = [
            'username' => $sam,
            'full_name' => $display,
            'upn' => $upn,
            'email' => $mail,
            'dn' => $dn,
            'ad_username' => $upn !== '' ? $upn : $sam,
        ];
    }

    return $results;
}

function authFindUserForAdLogin($username) {
    global $pdo;
    $username = trim((string)$username);
    $normalized = authNormalizeLoginName($username);
    $bindUser = authBuildAdBindUsername($username);
    return executeAndFetchOne($pdo,
        "SELECT *
         FROM users
         WHERE is_active = 1
           AND (
                LOWER(username) = ?
                                OR LOWER(username) = ?
                                OR LOWER(username) = ?
                OR LOWER(COALESCE(ad_username, '')) = ?
                OR LOWER(COALESCE(ad_username, '')) = ?
                OR LOWER(COALESCE(ad_username, '')) = ?
           )
         ORDER BY id ASC
         LIMIT 1",
        [
            strtolower($username),
                    strtolower($normalized),
                    strtolower($bindUser),
            strtolower($username),
            strtolower($normalized),
            strtolower($bindUser),
        ]
    );
}

function authFindUserByLoginInput($username) {
    global $pdo;
    $username = trim((string)$username);
    $normalized = authNormalizeLoginName($username);
    return executeAndFetchOne($pdo,
        "SELECT *
         FROM users
         WHERE is_active = 1
           AND (LOWER(username) = ? OR LOWER(username) = ?)
         ORDER BY id ASC
         LIMIT 1",
        [
            strtolower($username),
            strtolower($normalized),
        ]
    );
}

function authUserHasRole($userId, $roleKey) {
    global $pdo;
    $result = executeAndFetchOne($pdo, "SELECT 1 FROM user_roles WHERE user_id = ? AND role_key = ? LIMIT 1", [(int)$userId, (string)$roleKey]);
    return (bool)$result;
}

function authGetUserRoles($userId) {
    global $pdo;
    $results = executeAndFetch($pdo, "SELECT role_key FROM user_roles WHERE user_id = ? ORDER BY role_key ASC", [(int)$userId]);
    return array_column($results ?? [], 'role_key') ?: [];
}

function authVerifyLocalPassword($userRow, $password) {
    $password = (string)$password;
    $stored = (string)($userRow['password_value'] ?? '');
    if ($stored !== '') {
        $decoded = base64_decode($stored, true);
        $isBase64 = ($decoded !== false) && (base64_encode($decoded) === $stored);
        if ($isBase64 && hash_equals($decoded, $password)) {
            return true;
        }
        // Backward compatibility for any legacy plain values not yet migrated.
        if (!$isBase64 && hash_equals($stored, $password)) {
            return true;
        }
    }
    $hash = (string)($userRow['password_hash'] ?? '');
    if ($hash !== '' && password_verify($password, $hash)) {
        return true;
    }
    return false;
}

function authTryActiveDirectoryLogin($username, $password) {
    if (!authIsEnabled() || !defined('AUTH_AD_ENABLED') || !AUTH_AD_ENABLED) {
        return false;
    }
    if (!function_exists('ldap_connect')) {
        return false;
    }

    $username = trim((string)$username);
    $password = (string)$password;
    if ($username === '' || $password === '') {
        return false;
    }

    $connection = @ldap_connect(AUTH_AD_SERVER, defined('AUTH_AD_PORT') ? AUTH_AD_PORT : 389);
    if ($connection === false) {
        return false;
    }

    @ldap_set_option($connection, LDAP_OPT_PROTOCOL_VERSION, 3);
    @ldap_set_option($connection, LDAP_OPT_REFERRALS, 0);
    if (defined('AUTH_AD_USE_TLS') && AUTH_AD_USE_TLS) {
        @ldap_start_tls($connection);
    }

    $bindUser = authBuildAdBindUsername($username);

    $bindOk = @ldap_bind($connection, $bindUser, $password);
    @ldap_unbind($connection);
    return $bindOk === true;
}

function authGetAdDiagnostics($username = '', $password = '') {
    $missing = [];
    $checks = [];

    $checks['auth_enabled'] = authIsEnabled();
    $checks['ad_enabled'] = (defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED);

    $hasLdap = function_exists('ldap_connect');
    $checks['ldap_extension'] = $hasLdap;
    if (!$hasLdap) {
        $missing[] = 'PHP LDAP extension is not enabled.';
    }

    $server = defined('AUTH_AD_SERVER') ? trim((string)AUTH_AD_SERVER) : '';
    $port = defined('AUTH_AD_PORT') ? (int)AUTH_AD_PORT : 0;
    $domain = defined('AUTH_AD_DOMAIN') ? trim((string)AUTH_AD_DOMAIN) : '';
    $netbios = defined('AUTH_AD_NETBIOS') ? trim((string)AUTH_AD_NETBIOS) : '';
    $baseDn = defined('AUTH_AD_BASE_DN') ? trim((string)AUTH_AD_BASE_DN) : '';

    $checks['ad_server_configured'] = ($server !== '');
    if ($server === '') {
        $missing[] = 'AUTH_AD_SERVER is empty.';
    }

    $checks['ad_port_configured'] = ($port > 0);
    if ($port <= 0) {
        $missing[] = 'AUTH_AD_PORT is invalid.';
    }

    $checks['ad_domain_configured'] = ($domain !== '');
    if ($domain === '') {
        $missing[] = 'AUTH_AD_DOMAIN is empty.';
    }

    $checks['ad_netbios_configured'] = ($netbios !== '');
    if ($netbios === '') {
        $missing[] = 'AUTH_AD_NETBIOS is empty.';
    }

    $checks['ad_base_dn_configured'] = ($baseDn !== '');
    if ($baseDn === '') {
        $missing[] = 'AUTH_AD_BASE_DN is empty.';
    }

    $connectOk = false;
    $connectError = '';
    if ($hasLdap && $server !== '' && $port > 0) {
        $conn = @ldap_connect($server, $port);
        if ($conn !== false) {
            @ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
            @ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);
            if (defined('AUTH_AD_USE_TLS') && AUTH_AD_USE_TLS) {
                @ldap_start_tls($conn);
            }
            $connectOk = true;
            @ldap_unbind($conn);
        } else {
            $connectError = 'Could not create LDAP connection to server.';
            $missing[] = 'Cannot connect to AD server/port from this host.';
        }
    }
    $checks['ad_server_reachable'] = $connectOk;

    $bindTest = null;
    $username = trim((string)$username);
    if ($username !== '' || $password !== '') {
        $bindUser = authBuildAdBindUsername($username);
        $bindOk = authTryActiveDirectoryLogin($username, (string)$password);
        $bindTest = [
            'attempted' => true,
            'input_username' => $username,
            'bind_username' => $bindUser,
            'success' => $bindOk,
            'message' => $bindOk ? 'AD bind succeeded.' : 'AD bind failed (invalid credentials or AD policy/reachability issue).',
        ];
        if (!$bindOk) {
            $missing[] = 'AD bind failed for entered credentials.';
        }
    }

    return [
        'ok' => empty($missing),
        'checks' => $checks,
        'missing' => array_values(array_unique($missing)),
        'connect_error' => $connectError,
        'bind_test' => $bindTest,
    ];
}

function authBuildSessionUser($userRow) {
    $roles = authGetUserRoles((int)$userRow['id']);
    return [
        'id' => (int)$userRow['id'],
        'username' => (string)$userRow['username'],
        'full_name' => (string)($userRow['full_name'] ?? ''),
        'roles' => $roles,
        'auth_source' => (string)($userRow['auth_source'] ?? 'local'),
    ];
}

function authExtractLoginMode($username) {
    $username = trim((string)$username);
    $isLocalOverride = false;
    if (strpos($username, '.\\') === 0) {
        $isLocalOverride = true;
        $username = substr($username, 2);
    }

    return [
        'username' => trim((string)$username),
        'local_override' => $isLocalOverride,
    ];
}

function authRefreshCurrentSessionUser($userId = null) {
    global $pdo;
    $userId = $userId === null ? authCurrentUserId() : (int)$userId;
    if ($userId <= 0 || !isset($pdo) || !$pdo instanceof PDO) {
        return;
    }
    $userRow = executeAndFetchOne($pdo, "SELECT * FROM users WHERE id = ? LIMIT 1", [$userId]);
    if ($userRow) {
        $_SESSION['auth_user'] = authBuildSessionUser($userRow);
    }
}

function authLoginUser($username, $password, &$error = '') {
    global $pdo;
    $error = '';
    $loginInput = authExtractLoginMode($username);
    $username = (string)$loginInput['username'];
    $isLocalOverride = !empty($loginInput['local_override']);
    $password = (string)$password;

    if (!authIsEnabled()) {
        return true;
    }
    if ($username === '' || $password === '') {
        $error = 'Username and password are required.';
        return false;
    }

    if (defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED) {
        if ($isLocalOverride) {
            $localUser = authFindUserByLoginInput($username);
            if (!$localUser || !authVerifyLocalPassword($localUser, $password)) {
                $error = 'Invalid local username or password.';
                return false;
            }

            $sessionUser = authBuildSessionUser($localUser);
            $_SESSION['auth_user'] = $sessionUser;
            $_SESSION['auth_last_activity'] = time();
            executeUpdate($pdo, "UPDATE users SET last_login_at = NOW(), auth_source = 'local', updated_at = NOW() WHERE id = ?", [(int)$localUser['id']]);
            authLogAction('login_success', ['roles' => $sessionUser['roles'], 'mode' => 'local_override'], authPageName(), (int)$localUser['id'], (string)$localUser['username']);
            return true;
        }

        if (!authTryActiveDirectoryLogin($username, $password)) {
            // Fallback to local credentials when AD auth fails.
            $fallbackUser = authFindUserByLoginInput($username);
            if (!$fallbackUser || !authVerifyLocalPassword($fallbackUser, $password)) {
                $error = 'Invalid username or password.';
                return false;
            }

            $sessionUser = authBuildSessionUser($fallbackUser);
            if (empty($sessionUser['roles'])) {
                $error = 'You do not have a role in this system.';
                return false;
            }

            $_SESSION['auth_user'] = $sessionUser;
            $_SESSION['auth_last_activity'] = time();
            executeUpdate($pdo, "UPDATE users SET last_login_at = NOW(), auth_source = 'local', updated_at = NOW() WHERE id = ?", [(int)$fallbackUser['id']]);
            authLogAction('login_success', ['roles' => $sessionUser['roles'], 'mode' => 'local_fallback'], authPageName(), (int)$fallbackUser['id'], (string)$fallbackUser['username']);
            return true;
        }

        $userRow = authFindUserForAdLogin($username);
        if (!$userRow) {
            $error = 'You do not have a role in this system.';
            return false;
        }

        $sessionUser = authBuildSessionUser($userRow);
        if (empty($sessionUser['roles'])) {
            $error = 'You do not have a role in this system.';
            return false;
        }

        $_SESSION['auth_user'] = $sessionUser;

        $_SESSION['auth_last_activity'] = time();
        executeUpdate($pdo, "UPDATE users SET last_login_at = NOW(), auth_source = 'ad', updated_at = NOW() WHERE id = ?", [(int)$userRow['id']]);

        authLogAction('login_success', ['roles' => $sessionUser['roles'], 'mode' => 'ad'], authPageName(), (int)$userRow['id'], (string)$userRow['username']);
        return true;
    }

    $userRow = authGetUserByUsername($username);
    if (!$userRow) {
        $error = 'Invalid username or password.';
        return false;
    }

    $authSource = strtolower((string)($userRow['auth_source'] ?? 'local'));
    $isValid = false;
    if ($authSource === 'ad') {
        $bindUser = trim((string)($userRow['ad_username'] ?? ''));
        $isValid = authTryActiveDirectoryLogin($bindUser !== '' ? $bindUser : $username, $password);
    } else {
        $isValid = authVerifyLocalPassword($userRow, $password);
        if (!$isValid && defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED) {
            $bindUser = trim((string)($userRow['ad_username'] ?? ''));
            if ($bindUser !== '') {
                $isValid = authTryActiveDirectoryLogin($bindUser, $password);
            }
        }
    }

    if (!$isValid) {
        $error = 'Invalid username or password.';
        return false;
    }

    $sessionUser = authBuildSessionUser($userRow);
    $_SESSION['auth_user'] = $sessionUser;
    $_SESSION['auth_last_activity'] = time();

    executeUpdate($pdo, "UPDATE users SET last_login_at = NOW() WHERE id = ?", [(int)$userRow['id']]);

    authLogAction('login_success', ['roles' => $sessionUser['roles']], authPageName(), (int)$userRow['id'], (string)$userRow['username']);
    return true;
}

function authLogoutUser() {
    if (authIsEnabled()) {
        authLogAction('logout', [], authPageName());
    }
    unset($_SESSION['auth_user']);
}

function authChangePassword($userId, $newPassword, &$error = '') {
    global $pdo;
    $error = '';
    $userId = (int)$userId;
    $newPassword = trim((string)$newPassword);
    if (defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED) {
        $error = 'Password changes are disabled while Active Directory authentication is enabled.';
        return false;
    }
    if ($userId <= 0) {
        $error = 'Invalid user.';
        return false;
    }
    if ($newPassword === '') {
        $error = 'Password cannot be empty.';
        return false;
    }

    $ok = executeUpdate($pdo, "UPDATE users SET password_value = ?, password_hash = NULL, auth_source = 'local', updated_at = NOW() WHERE id = ?", [base64_encode($newPassword), $userId]);
    if ($ok) {
        authLogAction('password_changed', [], authPageName(), $userId, authCurrentUsername());
        return true;
    }

    $error = 'Failed to update password.';
    return false;
}

function authDefaultLandingPage($roles = null) {
    $roles = is_array($roles) ? $roles : authCurrentRoles();
    $priority = [
        'admin' => 'administration.php',
        'quality' => 'statistics.php',
        'billing' => 'billing.php',
        'butler' => 'butler.php',
        'imaging' => 'imaging.php',
        'laboratory' => 'laboratory.php',
    ];
    foreach ($priority as $role => $page) {
        if (in_array($role, $roles, true)) {
            return $page;
        }
    }
    return 'stream.php';
}

function authUserNavigationPages($roles = null) {
    $roles = is_array($roles) ? $roles : authCurrentRoles();
    $isAdmin = in_array('admin', $roles, true);
    $nonAdminRoles = array_values(array_diff(array_values(array_unique(array_map('strval', $roles))), ['admin']));
    $isBillingOnly = in_array('billing', $nonAdminRoles, true) && count($nonAdminRoles) === 1;

    if ($isBillingOnly && !$isAdmin) {
        return [
            ['label' => 'Billing', 'href' => 'billing.php'],
            ['label' => 'Clinics', 'href' => 'clinics.php'],
            ['label' => 'Action Logs', 'href' => 'user_actions.php'],
        ];
    }

    $pages = [
        ['label' => 'All Streams', 'href' => 'all_streams.php', 'roles' => ['butler', 'quality']],
        ['label' => 'Action Logs', 'href' => 'user_actions.php', 'roles' => []],
        ['label' => 'Butler Queue', 'href' => 'butler.php', 'roles' => ['butler']],
        ['label' => 'Patient Selection', 'href' => 'patient_selection.php', 'roles' => ['butler', 'billing']],
        ['label' => 'New Ticket', 'href' => 'new_ticket.php', 'roles' => ['butler', 'billing']],
        ['label' => 'Billing', 'href' => 'billing.php', 'roles' => ['billing']],
        ['label' => 'Clinics', 'href' => 'clinics.php', 'roles' => ['billing']],
        ['label' => 'Imaging', 'href' => 'imaging.php', 'roles' => ['imaging']],
        ['label' => 'Laboratory', 'href' => 'laboratory.php', 'roles' => ['laboratory']],
        ['label' => 'Statistics', 'href' => 'statistics.php', 'roles' => ['quality']],
        ['label' => 'Administration', 'href' => 'administration.php', 'roles' => ['quality']],
        ['label' => 'User Management', 'href' => 'user_management.php', 'roles' => ['admin']],
    ];

    $result = [];
    foreach ($pages as $page) {
        $requiredRoles = isset($page['roles']) && is_array($page['roles']) ? $page['roles'] : [];
        $allowed = empty($requiredRoles) || $isAdmin;
        if (!$allowed) {
            foreach ($requiredRoles as $role) {
                if (in_array((string)$role, $roles, true)) {
                    $allowed = true;
                    break;
                }
            }
        }
        if ($allowed) {
            $result[] = [
                'label' => (string)$page['label'],
                'href' => (string)$page['href'],
            ];
        }
    }

    return $result;
}

function authSanitizeReturnTo($returnTo) {
    $returnTo = trim((string)$returnTo);
    if ($returnTo === '') {
        return '';
    }
    if (preg_match('/^[a-z][a-z0-9+\-.]*:/i', $returnTo) === 1) {
        return '';
    }
    if (strpos($returnTo, '//') === 0) {
        return '';
    }
    return ltrim($returnTo, '/\\');
}

function authRenderUserMenu() {
    static $rendered = false;
    if ($rendered) {
        return;
    }
    $rendered = true;

    $user = authCurrentUser();
    if (!$user || !is_array($user)) {
        return;
    }

    $displayName = trim((string)($user['full_name'] ?? ''));
    if ($displayName === '') {
        $displayName = trim((string)($user['username'] ?? 'User'));
    }
    $username = trim((string)($user['username'] ?? ''));
    $roles = isset($user['roles']) && is_array($user['roles']) ? $user['roles'] : [];
    $roleText = !empty($roles) ? implode(', ', array_map('ucfirst', $roles)) : 'No roles';
    $navigationPages = authUserNavigationPages($roles);

    echo '<style>
        .auth-user-menu{position:fixed;top:14px;right:16px;z-index:5000;font-family:Segoe UI,Tahoma,sans-serif}
        .auth-user-menu details{position:relative}
        .auth-user-menu summary{list-style:none;display:flex;align-items:center;justify-content:center;gap:6px;padding:6px 8px;border-radius:999px;background:rgba(255,255,255,.94);border:1px solid rgba(12,102,195,.14);box-shadow:0 10px 22px rgba(23,33,47,.14);cursor:pointer;backdrop-filter:blur(10px)}
        .auth-user-menu summary::-webkit-details-marker{display:none}
        .auth-user-menu .avatar{width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#0b66c3;color:#fff;font-weight:700;font-size:11px;flex:0 0 auto}
        .auth-user-menu .info{display:flex;flex-direction:column;min-width:0;flex:1}
        .auth-user-menu .name{font-size:13px;font-weight:700;color:#17212f;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .auth-user-menu .meta{font-size:11px;color:#607086;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .auth-user-menu .chevron{font-size:11px;color:#607086;flex:0 0 auto}
        .auth-user-menu .panel{position:absolute;top:calc(100% + 8px);right:0;width:280px;padding:12px;border-radius:14px;background:#fff;border:1px solid #dde6f0;box-shadow:0 20px 44px rgba(23,33,47,.18)}
        .auth-user-menu .panel-header{padding:4px 6px 10px;border-bottom:1px solid #edf2f7;margin-bottom:8px}
        .auth-user-menu .panel-name{font-size:14px;font-weight:700;color:#17212f}
        .auth-user-menu .panel-user{font-size:12px;color:#607086;margin-top:2px}
        .auth-user-menu .panel-roles{font-size:12px;color:#455468;margin-top:6px;line-height:1.4}
        .auth-user-menu .links{display:flex;flex-direction:column;gap:4px}
        .auth-user-menu .links a{display:block;padding:9px 10px;border-radius:10px;text-decoration:none;color:#17212f;font-size:13px}
        .auth-user-menu .links a:hover{background:#eef5ff;color:#0b66c3}
        .auth-user-menu .nav-group{margin:2px 0}
        .auth-user-menu .nav-group > summary{display:flex;justify-content:space-between;align-items:center;padding:9px 10px;border-radius:10px;background:#f7fafd;border:1px solid #e7eef7;box-shadow:none}
        .auth-user-menu .nav-group > summary:hover{background:#eef5ff}
        .auth-user-menu .nav-label{font-size:13px;color:#17212f;font-weight:600}
        .auth-user-menu .nav-arrow{font-size:11px;color:#607086}
        .auth-user-menu .nav-group[open] .nav-arrow{transform:rotate(90deg)}
        .auth-user-menu .sub-links{display:flex;flex-direction:column;gap:3px;margin-top:4px;padding-left:4px}
        .auth-user-menu .sub-links a{padding:8px 10px;font-size:12px}
        @media (max-width:700px){.auth-user-menu{top:10px;right:10px}.auth-user-menu summary{padding:6px 8px}.auth-user-menu .avatar{width:22px;height:22px;font-size:10px}.auth-user-menu .meta{display:none}.auth-user-menu .panel{width:250px}}
    </style>';

    echo '<div class="auth-user-menu">';
    echo '<details>';
    echo '<summary>';
    echo '<span class="avatar">' . htmlspecialchars(strtoupper(substr($displayName, 0, 1)), ENT_QUOTES, 'UTF-8') . '</span>';
    echo '<span class="chevron">&#9662;</span>';
    echo '</summary>';
    echo '<div class="panel">';
    echo '<div class="panel-header">';
    echo '<div class="panel-name">' . htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8') . '</div>';
    if ($username !== '') {
        echo '<div class="panel-user">' . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . '</div>';
    }
    echo '<div class="panel-roles">Roles: ' . htmlspecialchars($roleText, ENT_QUOTES, 'UTF-8') . '</div>';
    echo '</div>';
    echo '<div class="links">';
    echo '<details class="nav-group">';
    echo '<summary><span class="nav-label">Navigation</span><span class="nav-arrow">&#9654;</span></summary>';
    echo '<div class="sub-links">';
    foreach ($navigationPages as $navPage) {
        echo '<a href="' . htmlspecialchars($navPage['href'], ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($navPage['label'], ENT_QUOTES, 'UTF-8') . '</a>';
    }
    echo '</div>';
    echo '</details>';
    if (!(defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED)) {
        echo '<a href="change_password.php">Change Password</a>';
    }
    echo '<a href="logout.php">Logout</a>';
    echo '</div>';
    echo '</div>';
    echo '</details>';
    echo '</div>';
}

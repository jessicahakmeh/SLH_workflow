<?php
require_once 'config.php';
session_start();
authRequireRoles(['butler', 'billing', 'admin'], ['log_view' => false]);

// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Remember where we came from (billing, butler, clinics)
$from_page = isset($_GET['from']) ? trim($_GET['from']) : '';
$return_clinic = isset($_GET['clinic']) ? trim($_GET['clinic']) : '';
$is_retake = in_array($from_page, ['billing', 'butler', 'clinics']);

// ENFORCE: When from=clinics, service type must be "Clinics" - override any existing data
if ($from_page === 'clinics') {
    if (isset($_SESSION['pending_patient_data'])) {
        $_SESSION['pending_patient_data']['service_type'] = 'Clinics';
    }
}

// Check if this is a pending patient (coming from new_ticket.php after form submission)
$is_pending = isset($_GET['pending']) && $_GET['pending'] === 'true';

// Also check if session has pending data (fallback if GET parameter is lost)
if (!$is_pending && isset($_SESSION['pending_patient_data'])) {
    $is_pending = true;
}

// Get patient ID from URL parameter or session
$patient_id = isset($_GET['patient_id']) ? trim($_GET['patient_id']) : null;

// If it's a pending patient, check session has the data and use a temporary ID for temp storage
if ($is_pending) {
    if (!isset($_SESSION['pending_patient_data'])) {
        die('Error: No patient data found. Please create a ticket first.');
    }
    // Use a temporary identifier for the temp directory (will be updated after patient creation)
    $temp_patient_id = 'pending_' . time();
} else if (!$patient_id) {
    die('Error: Patient ID not provided. Please create a ticket first.');
} else {
    // Use the provided patient ID
    $temp_patient_id = $patient_id;
}

// Function to authenticate and access network share
function accessNetworkShare($path) {
    // For Windows, we need to authenticate with the network share
    require_once __DIR__ . '/lib/exec_helpers.php';
    $netUse = 'net use ' . escapeshellarg($path) . ' /user:' . escapeshellarg(NETWORK_USERNAME) . ' ' . escapeshellarg(NETWORK_PASSWORD) . ' 2>&1';
    $res = run_process($netUse, null, 10);
    $output = preg_split('/\r?\n/', trim($res['stdout']));
    $returnVar = $res['exit'];
    
    if ($returnVar !== 0) {
        error_log("Network share connection failed: " . implode("\n", $output));
        return false;
    }
    return true;
}

// Function to disconnect network share
function disconnectNetworkShare($path) {
    require_once __DIR__ . '/lib/exec_helpers.php';
    $netUse = 'net use ' . escapeshellarg($path) . ' /delete 2>&1';
    run_process($netUse, null, 5);
}

// Ensure network share is accessible by mapping the root share (e.g. \\server\share)
function connectNetworkShareIfNeeded($basePath) {
    // If readable already, we're good
    if (@is_readable($basePath)) return true;

    // Normalize and extract server\share
    $p = preg_replace('#^\\+#', '', $basePath);
    $parts = explode('\\', $p);
    if (count($parts) < 2) {
        error_log('connectNetworkShareIfNeeded: invalid basePath=' . $basePath);
        return false;
    }
    $server = $parts[0];
    $share = $parts[1];
    $root = "\\\\{$server}\\{$share}";

    $user = NETWORK_USERNAME;
    $pass = NETWORK_PASSWORD;
    require_once __DIR__ . '/lib/monitoring.php';
    $cmd = 'net use ' . escapeshellarg($root) . ' /user:' . escapeshellarg($user) . ' ' . escapeshellarg($pass) . ' 2>&1';
    require_once __DIR__ . '/lib/exec_helpers.php';
    $res = run_process($cmd, null, 10);
    $output = preg_split('/\r?\n/', trim($res['stdout']));
    $ret = $res['exit'];
    if ($ret === 0) {
        error_log('connectNetworkShareIfNeeded: net use succeeded for ' . $root);
        return true;
    }
    error_log('connectNetworkShareIfNeeded: net use failed for ' . $root . ' output: ' . implode('\n', $output));
    return false;
}

// Robust copy with retries to handle intermittent network/locking issues
function safe_copy_with_retries($src, $dst, $retries = 3, $sleepSeconds = 1) {
    // Normalize destination directory
    $dir = dirname($dst);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }

    for ($attempt = 1; $attempt <= $retries; $attempt++) {
        clearstatcache(true, $src);
        if (!file_exists($src)) {
            error_log("safe_copy: source missing: $src");
            return false;
        }
        if (@copy($src, $dst)) {
            return true;
        }
        $lastErr = error_get_last();
        error_log("safe_copy attempt $attempt failed for $dst: " . json_encode($lastErr));
        if ($attempt < $retries) {
            sleep($sleepSeconds);
            // try to (re)connect network share before retrying
            connectNetworkShareIfNeeded($dir . '\\');
        }
    }
    return false;
}

// Function to format phone number with country code
function formatInternationalNumber($phone_number, $country_code) {
    $phone_number = preg_replace('/[^0-9]/', '', $phone_number);
    $country_code_digits = preg_replace('/[^0-9]/', '', $country_code);
    
    if (strpos($phone_number, $country_code_digits) === 0) {
        $phone_number = substr($phone_number, strlen($country_code_digits));
    }
    
    return $country_code_digits . $phone_number;
}

// Function to send WhatsApp message
function sendWhatsAppMessage($phone_number, $template, $variables = []) {
    try {
        if (empty($phone_number)) {
            error_log("WhatsApp API: No phone number provided");
            return false;
        }
        $phone_number = preg_replace('/[^0-9]/', '', $phone_number);
        
        if (strlen($phone_number) <= 9) {
            $phone_number = '961' . $phone_number;
        }

        $sendResult = sendWhatsAppTemplateRequest($phone_number, $template, $variables);
        $full_url = (string)($sendResult['request_url'] ?? '');
        
        error_log("WhatsApp API Request: " . $full_url);

        $response = (string)($sendResult['response'] ?? '');
        $http_code = (int)($sendResult['http_code'] ?? 0);
        $curl_error = (string)($sendResult['curl_error'] ?? '');
        
        error_log("WhatsApp API Response (HTTP $http_code): " . $response);
        
        if ($curl_error) {
            error_log("WhatsApp API cURL Error: " . $curl_error);
            return false;
        }
        
        if ($http_code >= 200 && $http_code < 300) {
            error_log("WhatsApp message sent successfully to $phone_number with template: $template");
            return true;
        } else {
            error_log("WhatsApp API returned HTTP $http_code for $phone_number");
            return false;
        }
        
    } catch (Exception $e) {
        error_log("WhatsApp API Exception: " . $e->getMessage());
        return false;
    }
}

// Function to generate next available queue number for a service type
function generateNextQueueNumber($service_type) {
    global $pdo;
    
    $prefixes = [
        'Appointment' => 'A',
        'Private' => 'P',
        'Guarantor' => 'G',
        'Clinics' => 'C'
    ];
    
    if (!isset($prefixes[$service_type])) {
        throw new Exception("Invalid service type");
    }
    
    $prefix = $prefixes[$service_type];
    
    // Count existing tickets with this prefix today
    $count = executeAndFetchOne($pdo, "SELECT COUNT(*) FROM tickets WHERE queue_number LIKE ? AND DATE(arrival_timestamp) = CURDATE()", [$prefix . '%'])['COUNT(*)'];
    
    return $prefix . ($count + 1);
}

// Function to create patient record in database
function createPatientRecord($is_pending, $existing_patient_id = null, $pre_generated_queue = null) {
    global $pdo, $from_page;

    $currentUser = authCurrentUser();
    $registeredByUserId = authCurrentUserId();
    $registeredByUsername = '';
    if (is_array($currentUser)) {
        $registeredByUsername = trim((string)($currentUser['full_name'] ?? ''));
        if ($registeredByUsername === '') {
            $registeredByUsername = trim((string)($currentUser['username'] ?? ''));
        }
    }
    if ($registeredByUsername === '') {
        $registeredByUsername = authCurrentUsername();
    }
    $registeredByUsername = trim((string)$registeredByUsername);

    $assignedButlerUserId = null;
    $assignedButlerUsername = null;
    if (authHasAnyRole(['butler'])) {
        $assignedButlerUserId = $registeredByUserId > 0 ? $registeredByUserId : null;
        $assignedButlerUsername = $registeredByUsername !== '' ? $registeredByUsername : null;
    }
    
    if ($is_pending) {
        // Get data from session
        if (!isset($_SESSION['pending_patient_data'])) {
            throw new Exception("No patient data in session");
        }
        
        $data = $_SESSION['pending_patient_data'];
        $service_type = $data['service_type']; // Already enforced to 'Clinics' if from=clinics
        
        // Use pre-generated queue number if provided, otherwise generate one
        if ($pre_generated_queue !== null) {
            $queue_number = $pre_generated_queue;
        } else {
            $queue_number = generateNextQueueNumber($service_type);
        }
        
        // Mobile must be provided
        if (empty($data['mobile'])) {
            throw new Exception('Contact mobile number is required');
        }
        // If care_mobile is empty, use mobile as fallback
        $care_mobile = $data['care_mobile'] ?? '';
        if (empty($care_mobile)) {
            $care_mobile = $data['mobile'];
        }
        // If care_country_code is empty, use main country_code as fallback
        $care_country_code = $data['care_country_code'] ?? '';
        if (empty($care_country_code)) {
            $care_country_code = $data['country_code'];
        }
        
        // Insert patient into database
        $initial_status = ($service_type === 'Clinics') ? 'Waiting' : 'Arrived';
        $initial_cl = ($service_type === 'Clinics') ? 1 : 0;
        $selected_patient_id = isset($data['existing_patient_id']) ? (int)$data['existing_patient_id'] : 0;

        $mrn = isset($data['mrn']) && trim($data['mrn']) !== '' ? trim($data['mrn']) : null;

        if ($selected_patient_id > 0) {
            // Reuse existing demographics row and refresh it with submitted values.
            if (!executeAndFetchOne($pdo, "SELECT patient_id FROM patients WHERE patient_id = ?", [$selected_patient_id])) {
                throw new Exception('Selected existing patient was not found');
            }

            // IMPORTANT: Capture the ORIGINAL patient data BEFORE updating, so we can detect changes
            $original_snapshot_row = executeAndFetchOne($pdo, "SELECT mrn, patient_name, mobile, country_code, care_mobile, care_country_code, email, address
                                                    FROM patients
                                                    WHERE patient_id = ?", [$selected_patient_id]) ?: [];
            
            $dem_update_sql = "UPDATE patients
                               SET patient_name = ?,
                                   mobile = ?,
                                   country_code = ?,
                                   care_mobile = ?,
                                   care_country_code = ?,
                                   email = ?,
                                   address = ?
                               WHERE patient_id = ?";
            executeUpdate($pdo, $dem_update_sql, [
                $data['patient_name'],
                $data['mobile'],
                $data['country_code'],
                $care_mobile,
                $care_country_code,
                $data['email'],
                $data['address'],
                $selected_patient_id
            ]);

            // Keep existing MRN if already present; only set when currently empty.
            if ($mrn !== null && $mrn !== '') {
                executeUpdate($pdo, "UPDATE patients SET mrn = ? WHERE patient_id = ? AND (mrn IS NULL OR TRIM(mrn) = '')", [$mrn, $selected_patient_id]);
            }

            $new_patient_id = $selected_patient_id;
            
            // Use the ORIGINAL snapshot (before updates) for baseline comparison
            $snapshot_row = $original_snapshot_row;
        } else {
            // Create a new demographics row when no existing patient was selected.
            $dem_sql = "INSERT INTO patients (mrn, patient_name, mobile, country_code, care_mobile, care_country_code, email, address)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            executeUpdate($pdo, $dem_sql, [
                $mrn,
                $data['patient_name'],
                $data['mobile'],
                $data['country_code'],
                $care_mobile,
                $care_country_code,
                $data['email'],
                $data['address']
            ]);
            $new_patient_id = $pdo->lastInsertId();
        }

        // Build baseline demographics snapshot for this ticket.
        // For existing patients being edited, we already captured the original snapshot above
        // For new patients, we fetch the newly created patient row
        if ($selected_patient_id <= 0) {
            // New patient: fetch the newly created patient data
            $snapshot_row = executeAndFetchOne($pdo, "SELECT mrn, patient_name, mobile, country_code, care_mobile, care_country_code, email, address
                                           FROM patients
                                           WHERE patient_id = ?", [$new_patient_id]) ?: [];
        }
        // else: for existing patients, snapshot_row was already set above before the UPDATE
        $demographics_snapshot = json_encode($snapshot_row, JSON_UNESCAPED_UNICODE);
        if ($demographics_snapshot === false) {
            $demographics_snapshot = null;
        }

        $is_existing_patient = $selected_patient_id > 0 ? 1 : 0;
        
        // For existing patients being edited, check if demographics actually changed
        $demographics_edited = 0;
        $demographics_changed_fields = NULL;
        if ($is_existing_patient) {
            $current_data = executeAndFetchOne($pdo, "SELECT mrn, patient_name, mobile, country_code, care_mobile, care_country_code, email, address
                                          FROM patients
                                          WHERE patient_id = ?", [$new_patient_id]) ?: [];
            
            $fieldsToCheck = ['mrn', 'patient_name', 'mobile', 'country_code', 'care_mobile', 'care_country_code', 'email', 'address'];
            $changedFields = [];
            
            foreach ($fieldsToCheck as $field) {
                $snapshotVal = trim((string)($snapshot_row[$field] ?? ''));
                $currentVal = trim((string)($current_data[$field] ?? ''));
                if ($snapshotVal !== $currentVal) {
                    $changedFields[] = $field;
                }
            }
            
            if (!empty($changedFields)) {
                $demographics_edited = 1;
                $demographics_changed_fields = json_encode($changedFields, JSON_UNESCAPED_UNICODE);
            }
        }

        // Step 2: Insert queue entry into tickets table
        $tkt_sql = "INSERT INTO tickets
                    (patient_id, queue_number, service_type, current_status, cl, arrival_timestamp, registered_by_username, assigned_butler_username, is_existing_patient, demographics_snapshot, demographics_edited, demographics_changed_fields)
                    VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?)";
        executeUpdate($pdo, $tkt_sql, [
            $new_patient_id,
            $queue_number,
            $service_type,
            $initial_status,
            $initial_cl,
            $registeredByUsername !== '' ? $registeredByUsername : null,
            $assignedButlerUsername,
            $is_existing_patient,
            $demographics_snapshot,
            $demographics_edited,
            $demographics_changed_fields
        ]);

        $ticket_id = $pdo->lastInsertId();
        
        $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Created', NULL, ?, ?, ?)";
        executeUpdate($pdo, $log_sql, [$ticket_id, $initial_status, authCurrentUserId() ?: null, "Ticket created after document upload"]);
        
        // Send WhatsApp message with queue ticket template
        if (!empty($data['mobile']) && !empty($data['country_code'])) {
            $formatted_phone = formatInternationalNumber($data['mobile'], $data['country_code']);
            sendWhatsAppMessage($formatted_phone, 'ticket_queue', [$queue_number, $queue_number]);
        }
        
        // Clear session data
        unset($_SESSION['pending_patient_data']);
        
        return [
            'patient_id' => $new_patient_id,
            'ticket_id' => $ticket_id,
            'queue_number' => $queue_number
        ];
    } else {
        if ($from_page === 'clinics') {
            executeUpdate($pdo, "UPDATE tickets SET service_type = 'Clinics' WHERE ticket_id = ? AND service_type != 'Clinics'", [$existing_patient_id]);
        }
        
        return [
            'patient_id' => $existing_patient_id,
            'queue_number' => null
        ];
    }
}

// Check if we have POST data for image
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Start output buffer to prevent accidental output breaking JSON responses
    ob_start();
    // Suppress displaying PHP errors to the client during AJAX handling
    ini_set('display_errors', '0');
    
    // convert all PHP errors to exceptions so our try/catch block can handle them
    set_error_handler(function($errno, $errstr, $errfile, $errline) {
        throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
    });

    // catch fatal errors as well and make sure we still return valid JSON
    register_shutdown_function(function() {
        $err = error_get_last();
        if ($err) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Fatal error',
                'details' => [sprintf("%s in %s on line %d", $err['message'], $err['file'], $err['line'])]
            ]);
        }
    });

try {
        // Check if FPDF exists
        if (!file_exists('FPDF/fpdf.php')) {
            if (ob_get_length()) ob_end_clean();
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'error' => 'FPDF library not found. Please install FPDF in the FPDF folder.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        // Check for FPDI in current folder or parent directory for PDF merging
        $fpdi_available = false;
        $fpdi_path = '';

        // Try to find and load FPDI - prioritize the autoload.php for proper namespace setup
        $candidates = [
            'FPDI/vendor/autoload.php',           // Composer installation
            'FPDI/src/autoload.php',              // Direct src autoload
            '../FPDI/vendor/autoload.php',
            '../FPDI/src/autoload.php'
        ];

        foreach ($candidates as $cand) {
            if (file_exists($cand)) {
                require_once($cand);
                $fpdi_path = $cand;
                $fpdi_available = true;
                error_log('FPDI autoloader loaded from: ' . $fpdi_path);
                break;
            }
        }

        if (!$fpdi_available) {
            error_log('FPDI library not found; PDF merging will be skipped');
        }
    
    require('FPDF/fpdf.php');
    
    // Parse FormData (new method) or JSON (legacy method)
    $images = [];
    $uploaded_pdfs = [];
    
    if (!empty($_POST['images_json'])) {
        // New FormData method
        $images = json_decode($_POST['images_json'], true);
        
        // Get uploaded PDF files
        foreach ($_FILES as $key => $file) {
            if (strpos($key, 'pdf_') === 0) {
                if ($file['error'] === UPLOAD_ERR_OK) {
                    $uploaded_pdfs[] = $file['tmp_name'];
                    error_log("Uploaded PDF file: " . $file['name']);
                }
            }
        }
    } else {
        // Legacy JSON method (backward compatibility)
        $images = json_decode(file_get_contents('php://input'), true);
    }

    // Prescription is mandatory for new patients, optional for retakes and clinics
    global $is_retake, $from_page;
    $prescription_optional = $is_retake || $from_page === 'clinics';
    if (!$prescription_optional && (!isset($images['prescription']) || !is_array($images['prescription']) || count($images['prescription']) == 0)) {
        http_response_code(400);
        echo json_encode(['error' => 'At least one prescription photo or PDF is required for new patients']);
        exit;
    }
    
    // If ID Front is captured, ID Back must also be captured
    if ((!empty($images['id-front']) && empty($images['id-back'])) || 
        (empty($images['id-front']) && !empty($images['id-back']))) {
        http_response_code(400);
        echo json_encode(['error' => 'If ID is photographed, both front and back must be captured']);
        exit;
    }

    // Create patient-specific temp directory
    $patient_temp_dir = 'temp/' . $temp_patient_id . '/';
    if (!file_exists($patient_temp_dir)) {
        mkdir($patient_temp_dir, 0777, true);
    }

    // Function to save the base64 image to a file
    function saveBase64Image($base64_string, $output_file) {
        // Detect data URL prefix and mime type
        if (preg_match('#^data:(image/[a-z0-9+.-]+);base64,#i', $base64_string, $m)) {
            $mime = strtolower($m[1]);
            // Strip the data URL part
            $base64_string = preg_replace('#^data:[^;]+;base64,#i', '', $base64_string);
        } else {
            $mime = 'image/jpeg';
        }

        $image_data = base64_decode($base64_string);
        if ($image_data === false) {
            error_log("Failed to decode base64 image for: " . $output_file);
            return false;
        }

        // Convert PNG data to JPEG so our fixed .jpg filenames remain valid and FPDF handles it
        if ($mime === 'image/png') {
            $img = @imagecreatefromstring($image_data);
            if ($img !== false) {
                if (imagejpeg($img, $output_file, 90)) {
                    imagedestroy($img);
                    error_log("Converted PNG to JPEG & saved: " . $output_file);
                    return true;
                } else {
                    error_log("Failed to convert PNG to JPEG for: " . $output_file);
                    imagedestroy($img);
                    return false;
                }
            } else {
                error_log("GD could not parse PNG data for: " . $output_file);
                // fall through and write raw data as fallback
            }
        }

        // If input is HEIC/HEIF, attempt conversion to JPEG for FPDF embedding
        if (in_array($mime, ['image/heic', 'image/heif'])) {
            // Save original HEIC temporarily
            $heic_temp = preg_replace('/\.[a-z0-9]+$/i', '.heic', $output_file);
            if (file_put_contents($heic_temp, $image_data) === false) {
                error_log("Failed to write HEIC temp file: " . $heic_temp);
                return false;
            }

            // Try Imagick first
            if (class_exists('Imagick')) {
                try {
                    $im = new Imagick();
                    $im->readImageBlob(file_get_contents($heic_temp));
                    $im->setImageFormat('jpeg');
                    $im->setImageCompressionQuality(90);
                    if ($im->writeImage($output_file)) {
                        $im->clear(); $im->destroy();
                        @unlink($heic_temp);
                        error_log("Converted HEIC to JPEG: " . $output_file);
                        return true;
                    }
                } catch (Exception $e) {
                    error_log('Imagick conversion failed: ' . $e->getMessage());
                }
            }

            // Fallback to ImageMagick CLI if available
            $magickCmd = null;
            // Check for 'magick' (newer) or 'convert' (older)
                require_once __DIR__ . '/lib/monitoring.php';
                require_once __DIR__ . '/lib/exec_helpers.php';
                $r1 = run_process('where magick 2>NUL', null, 2);
                $r2 = run_process('where convert 2>NUL', null, 2);
                $whichMagick = trim($r1['stdout']) ?: trim($r2['stdout']);
            if ($whichMagick) {
                // prefer 'magick' command if present
                if (stripos($whichMagick, 'magick') !== false) $magickCmd = 'magick';
                else $magickCmd = 'convert';
            }

                if ($magickCmd) {
                $escapedIn = escapeshellarg($heic_temp);
                $escapedOut = escapeshellarg($output_file);
                $cmd = "$magickCmd $escapedIn $escapedOut";
                $r = run_process($cmd . ' 2>&1', null, 30);
                $output = preg_split('/\r?\n/', trim($r['stdout']));
                $ret = $r['exit'];
                if ($ret === 0 && file_exists($output_file) && filesize($output_file) > 0) {
                    @unlink($heic_temp);
                    error_log("Converted HEIC to JPEG via CLI: " . $output_file);
                    return true;
                } else {
                    error_log("ImageMagick CLI conversion failed: " . implode('\n', $output));
                }
            }

            // If conversion failed, keep the HEIC file but signal failure to embed
            error_log("HEIC conversion not available on server for: " . $heic_temp);
            return false;
        }

        // For other image types, write directly (ensure output directory exists)
        if (file_put_contents($output_file, $image_data) === false) {
            error_log("Failed to write image to: " . $output_file);
            return false;
        }
        error_log("Successfully saved image to: " . $output_file . " (" . filesize($output_file) . " bytes)");
        return true;
    }

    // Save the images from base64 to temporary files
    $temp_files = [];
    $save_success = true;
    $temp_prescription_files = [];
    
    $image_mapping = [
        'id-front' => $patient_temp_dir . 'id_front.jpg',
        'id-back' => $patient_temp_dir . 'id_back.jpg',
        'insurance-front' => $patient_temp_dir . 'insurance_front.jpg',
        'insurance-back' => $patient_temp_dir . 'insurance_back.jpg'
    ];
    
    foreach ($image_mapping as $key => $path) {
        // Only save images that are not null/empty
        if (!isset($images[$key]) || empty($images[$key])) {
            error_log("Skipping $key - no image data");
            continue;
        }
        
        error_log("Saving $key to: $path");
        if (!saveBase64Image($images[$key], $path)) {
            $save_success = false;
            error_log("Failed to save $key");
            break;
        }
        $temp_files[] = $path;
    }
    
    // Handle prescription images and PDFs (array)
    if ($save_success && isset($images['prescription']) && is_array($images['prescription'])) {
        foreach ($images['prescription'] as $index => $prescription_item) {
            // Handle both old format (just string) and new format (object with type)
            if (is_string($prescription_item)) {
                // Legacy format - base64 encoded image
                $prescription_path = $patient_temp_dir . 'prescription_' . ($index + 1) . '.jpg';
                error_log("Saving prescription image " . ($index + 1) . " to: $prescription_path");
                if (!saveBase64Image($prescription_item, $prescription_path)) {
                    $save_success = false;
                    error_log("Failed to save prescription image " . ($index + 1));
                    break;
                }
                $temp_files[] = $prescription_path;
                $temp_prescription_files[] = $prescription_path;
            } else if (is_array($prescription_item)) {
                // New format - could be image or PDF
                if ($prescription_item['type'] === 'image') {
                    // Base64 encoded image
                    $prescription_path = $patient_temp_dir . 'prescription_' . ($index + 1) . '.jpg';
                    error_log("Saving prescription image " . ($index + 1) . " to: $prescription_path");
                    if (!saveBase64Image($prescription_item['data'], $prescription_path)) {
                        $save_success = false;
                        error_log("Failed to save prescription image " . ($index + 1));
                        break;
                    }
                    $temp_files[] = $prescription_path;
                    $temp_prescription_files[] = $prescription_path;
                } else if ($prescription_item['type'] === 'pdf') {
                    // Uploaded PDF file
                    $pdf_index = $prescription_item['index'];
                    if (isset($uploaded_pdfs[$pdf_index])) {
                        $prescription_path = $patient_temp_dir . 'prescription_' . ($index + 1) . '.pdf';
                        error_log("Copying uploaded PDF " . ($index + 1) . " from: " . $uploaded_pdfs[$pdf_index]);
                        if (!safe_copy_with_retries($uploaded_pdfs[$pdf_index], $prescription_path, 3, 1)) {
                            $save_success = false;
                            error_log("Failed to copy uploaded PDF " . ($index + 1) . " (after retries)");
                            break;
                        }
                        $temp_files[] = $prescription_path;
                        $temp_prescription_files[] = $prescription_path;
                    }
                }
            }
        }
    }
    
    if (!$save_success) {
        // Clean up any partial files
        foreach ($temp_files as $file) {
            if (file_exists($file)) unlink($file);
        }
        http_response_code(500);
        echo json_encode(['error' => 'Failed to save temporary images']);
        exit;
    }

    // Helper function to add image with proper sizing
    function addImageToPDF($pdf, $image_path, $y_position) {
        error_log("Adding image to PDF from: " . $image_path);
        
        if (file_exists($image_path) && filesize($image_path) > 0) {
            error_log("Image exists, size: " . filesize($image_path) . " bytes");
            
            // Get original image dimensions
            list($orig_width, $orig_height) = getimagesize($image_path);
            error_log("Image dimensions: " . $orig_width . "x" . $orig_height);

            // Attempt to embed image close to original quality: compute physical size from pixels
            // Assume scanning at 300 DPI (common for good quality). If images are lower/higher DPI,
            // this will still preserve image pixel dimensions as much as possible while fitting page.
            $dpi = 300;
            $width_mm = ($orig_width / $dpi) * 25.4; // convert inches to mm
            $height_mm = ($orig_height / $dpi) * 25.4;

            // Available width on A4 with small margins
            $available_width = 190; // mm
            if ($width_mm > $available_width) {
                $scale = $available_width / $width_mm;
                $width_mm = $available_width;
                $height_mm = $height_mm * $scale;
            }

            // Center horizontally
            $pageWidth = $pdf->GetPageWidth();
            $x = ($pageWidth - $width_mm) / 2;

            $pdf->Image($image_path, $x, $y_position, $width_mm, $height_mm);
            error_log("Image added at position: x=$x, y=$y_position, width={$width_mm}, height={$height_mm}");

            // Return the height used for next image positioning
            return $height_mm;
        } else {
            error_log("Image NOT found: " . $image_path);
            // Draw a placeholder box
            $pdf->SetFillColor(240, 240, 240);
            $pdf->Rect(15, $y_position, 180, 60, 'F');
            $pdf->SetFont('Arial', '', 12);
            $pdf->SetTextColor(100, 100, 100);
            $pdf->Text(70, $y_position + 30, "No image");
            return 60; // Placeholder height
        }
    }

    // Detect network and output variables early, before any potential merge notifications
    $network_success = true;
    $network_messages = [];
    $network_locations = [];

    // Track which PDFs to create
    $pdf_files = [];
    $has_id = !empty($images['id-front']) && !empty($images['id-back']);
    $has_insurance = !empty($images['insurance-front']) || !empty($images['insurance-back']);
    
    // ==================== FIRST PDF: {patient_id}_ID.pdf (if ID exists) ====================
    if ($has_id) {
        $pdf1 = new FPDF('P', 'mm', 'A4');
        $pdf1->SetAutoPageBreak(false);
        $pdf1->SetMargins(0, 0, 0);
        
        $pdf1->AddPage();
        
        // Position for ID Front (top)
        $y_position = 20;
        $height1 = addImageToPDF($pdf1, $patient_temp_dir . 'id_front.jpg', $y_position);
        
        // Position for ID Back (below ID Front with 15mm gap)
        $y_position += $height1 + 15;
        addImageToPDF($pdf1, $patient_temp_dir . 'id_back.jpg', $y_position);
        
        // Save ID.pdf locally
        $id_pdf_name = $patient_temp_dir . $temp_patient_id . '_ID.pdf';
        $pdf1->Output('F', $id_pdf_name);
        $pdf_files['id'] = $id_pdf_name;
        error_log("Created ID PDF: " . $id_pdf_name);
    }

    // ==================== SECOND PDF: {patient_id}_Insurance_Prescription.pdf ====================
    // only create insurance/prescription PDF if there are new images or insurance scans
    $create_insurance_pdf = $has_insurance || count($temp_prescription_files) > 0;
    if ($create_insurance_pdf) {
        $pdf2 = new FPDF('P', 'mm', 'A4');
        $pdf2->SetAutoPageBreak(false);
        $pdf2->SetMargins(0, 0, 0);
        
        // PAGE 1: Insurance Front and Back (if exists)
        if ($has_insurance) {
            $pdf2->AddPage();
            
            // Position for Insurance Front (top)
            $y_position = 15;
            $height1 = addImageToPDF($pdf2, $patient_temp_dir . 'insurance_front.jpg', $y_position);
            
            // Position for Insurance Back
            $y_position += $height1 + 12;
            addImageToPDF($pdf2, $patient_temp_dir . 'insurance_back.jpg', $y_position);
        }
        
        // Always add prescription pages for image files (skip PDF files here — they'll be merged later)
        foreach ($temp_prescription_files as $prescription_file) {
            $ext = strtolower(pathinfo($prescription_file, PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png'])) {
                $pdf2->AddPage();

                // Position for Prescription (top with margin)
                $y_position = 20;
                addImageToPDF($pdf2, $prescription_file, $y_position);
            } else {
                // PDF files will be merged after creating this PDF
                error_log("Skipping prescription PDF for image embedding: " . $prescription_file);
            }
        }
        
        // Save Insurance_Prescription.pdf locally
        $insurance_pdf_name = $patient_temp_dir . $temp_patient_id . '_Insurance_Prescription.pdf';
        $pdf2->Output('F', $insurance_pdf_name);
        $pdf_files['insurance'] = $insurance_pdf_name;
        error_log("Created Insurance PDF: " . $insurance_pdf_name);
    }

    // Only attempt merge if we actually created an insurance/prescription PDF earlier
    if (!empty($create_insurance_pdf)) {
        // If there are any prescription PDF files, merge them with the generated insurance PDF into one final PDF
        $prescription_pdfs = [];
    foreach ($temp_prescription_files as $f) {
        if (strtolower(pathinfo($f, PATHINFO_EXTENSION)) === 'pdf') {
            $prescription_pdfs[] = $f;
        }
    }

    if (!empty($prescription_pdfs)) {
        if (!empty($fpdi_available)) {
            // Check if Fpdi class is actually available
            if (!class_exists('\setasign\Fpdi\Fpdi')) {
                error_log('FPDI was found but class setasign\Fpdi\Fpdi could not be loaded. Paths checked: FPDI/src/autoload.php, etc.');
                $network_messages[] = 'Warning: FPDI library incomplete; proceeding without PDF merging';
                // Don't attempt merge
            } else {
                try {
                    // We'll build a merged PDF that preserves the original prescription order:
                    // - insurance_pdf_name contains (optionally) an insurance page followed by generated prescription image pages
                    // - $temp_prescription_files contains the prescription items in original order (images or pdfs)
                    // We'll import the insurance pdf pages as needed and insert uploaded PDFs in place of pdf items.

                    $merged_name = $patient_temp_dir . $temp_patient_id . '_Insurance_Prescription_Merged.pdf';
                    $fpdi = new \setasign\Fpdi\Fpdi();

                // Open the generated insurance PDF as source
                if (!file_exists($insurance_pdf_name)) {
                    throw new Exception('Generated insurance PDF missing for merge');
                }
                $insurancePageCount = $fpdi->setSourceFile($insurance_pdf_name);

                // Determine starting page for generated prescription pages
                // If there was an insurance page present (has_insurance true), that was created as the first page
                $generated_page_index = 1; // 1-based index in insurance PDF
                // If insurance page exists, keep it as first page
                if ($has_insurance) {
                    $tpl = $fpdi->importPage($generated_page_index);
                    $size = $fpdi->getTemplateSize($tpl);
                    $orientation = ($size['width'] > $size['height']) ? 'L' : 'P';
                    $fpdi->AddPage($orientation, [$size['width'], $size['height']]);
                    $fpdi->useTemplate($tpl);
                    $generated_page_index++;
                }

                // Now iterate over the temp_prescription_files in order, inserting either a generated page (for images)
                // or the full uploaded PDF pages (for pdf items).
                foreach ($temp_prescription_files as $pres_item) {
                    $ext = strtolower(pathinfo($pres_item, PATHINFO_EXTENSION));
                    if ($ext === 'pdf') {
                        // Insert all pages from this uploaded PDF
                        if (!file_exists($pres_item)) {
                            error_log('Uploaded prescription PDF missing during merge: ' . $pres_item);
                            continue;
                        }
                        $count = $fpdi->setSourceFile($pres_item);
                        for ($pp = 1; $pp <= $count; $pp++) {
                            $tpl = $fpdi->importPage($pp);
                            $size = $fpdi->getTemplateSize($tpl);
                            $orientation = ($size['width'] > $size['height']) ? 'L' : 'P';
                            $fpdi->AddPage($orientation, [$size['width'], $size['height']]);
                            $fpdi->useTemplate($tpl);
                        }
                    } else {
                        // Use next generated page from the insurance PDF (these are the pages we created for prescription images)
                        if ($generated_page_index <= $insurancePageCount) {
                            $tpl = $fpdi->importPage($generated_page_index);
                            $size = $fpdi->getTemplateSize($tpl);
                            $orientation = ($size['width'] > $size['height']) ? 'L' : 'P';
                            $fpdi->AddPage($orientation, [$size['width'], $size['height']]);
                            $fpdi->useTemplate($tpl);
                            $generated_page_index++;
                        } else {
                            error_log('No generated page available to insert for prescription image');
                        }
                    }
                }

                // If there are any remaining generated pages (unlikely), append them
                while ($generated_page_index <= $insurancePageCount) {
                    $tpl = $fpdi->importPage($generated_page_index);
                    $size = $fpdi->getTemplateSize($tpl);
                    $orientation = ($size['width'] > $size['height']) ? 'L' : 'P';
                    $fpdi->AddPage($orientation, [$size['width'], $size['height']]);
                    $fpdi->useTemplate($tpl);
                    $generated_page_index++;
                }

                $fpdi->Output('F', $merged_name);
                // Replace insurance PDF with merged PDF for network copy
                $pdf_files['insurance'] = $merged_name;
                $network_messages[] = 'Merged uploaded prescription PDFs into Insurance PDF (preserving order)';
                error_log("Created merged Insurance PDF: " . $merged_name);
            } catch (Exception $e) {
                error_log('FPDI merge failed: ' . $e->getMessage());
                $network_messages[] = 'Warning: Failed to merge uploaded PDFs - proceeding with generated PDF only';
            }
            }
        } else {
            $network_messages[] = 'Warning: Uploaded PDFs present but FPDI not available; PDFs were saved separately';
            error_log('FPDI not available - skipping PDF merge');
        }
    }
    // end create_insurance_pdf check

    }

    // Verify local PDFs were created (skip for clinics with no images)
    $is_clinics = isset($_GET['from']) && $_GET['from'] === 'clinics';
    
    if (isset($pdf_files['id']) && (!file_exists($pdf_files['id']) || filesize($pdf_files['id']) == 0)) {
        if (!$is_clinics) {
            error_log("ID PDF verification failed: " . $pdf_files['id']);
            http_response_code(500);
            echo json_encode(['error' => 'Failed to create ID PDF locally']);
            exit;
        } else {
            error_log("ID PDF not created for clinics (no images uploaded) - this is OK");
        }
    }
    
    if (isset($pdf_files['insurance'])) {
        if (!file_exists($pdf_files['insurance']) || filesize($pdf_files['insurance']) == 0) {
            if (!$is_clinics) {
                error_log("Insurance PDF verification failed: " . $pdf_files['insurance']);
                http_response_code(500);
                echo json_encode(['error' => 'Failed to create Insurance_Prescription PDF locally']);
                exit;
            } else {
                error_log("Insurance PDF not created for clinics (no images uploaded) - this is OK");
            }
        }
    }

    // For pending patients, generate the queue_number FIRST (before network save) to use as filename
    // This does NOT create a database record yet - just reserves a queue number
    $pre_generated_queue = null;
    
    if ($is_pending) {
        try {
            if (!isset($_SESSION['pending_patient_data'])) {
                throw new Exception("No patient data in session");
            }
            $service_type = $_SESSION['pending_patient_data']['service_type']; // Already enforced to 'Clinics' if from=clinics
            $pre_generated_queue = generateNextQueueNumber($service_type);
            error_log("Pre-generated queue number for pending patient: " . $pre_generated_queue);
        } catch (Exception $e) {
            error_log("Error pre-generating queue number: " . $e->getMessage());
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => 'Failed to generate queue number: ' . $e->getMessage()
            ]);
            exit;
        }
    }

    // Determine filename base - prefer MRN over queue number so PDFs are always named {mrn}.pdf
    $filenameBase = $pre_generated_queue;

    // For existing patient re-admissions (pending new ticket), look up their MRN from the DB
    // and use it so the new PDF overwrites the old one rather than being saved under the queue number.
    if ($is_pending && isset($_SESSION['pending_patient_data'])) {
        $existingPidForMrn = isset($_SESSION['pending_patient_data']['existing_patient_id'])
            ? (int)$_SESSION['pending_patient_data']['existing_patient_id']
            : 0;
        if ($existingPidForMrn > 0) {
            $mrnLookupRow = executeAndFetchOne($pdo, "SELECT mrn FROM patients WHERE patient_id = ?", [$existingPidForMrn]);
            if (!empty($mrnLookupRow['mrn'])) {
                $filenameBase = $mrnLookupRow['mrn'];
            }
        }
    }

    if (!$is_pending && !$filenameBase) {
        // Retake / edit path: use the ticket's MRN, falling back to queue number then ticket id
        $infoRow = executeAndFetchOne($pdo, "SELECT p.mrn, t.queue_number FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
        if ($infoRow) {
            if (!empty($infoRow['mrn'])) {
                $filenameBase = $infoRow['mrn'];
            } elseif (!empty($infoRow['queue_number'])) {
                $filenameBase = $infoRow['queue_number'];
            } else {
                $filenameBase = $patient_id;
            }
        }
    }
    
    // Fallback to patient_id if no filename determined
    if (!$filenameBase) {
        $filenameBase = $patient_id;
    }
 
        // Ensure network share is accessible before copying PDFs
        if (!connectNetworkShareIfNeeded(ID_SAVE_PATH)) {
            $network_success = false;
            $network_messages[] = 'Failed to connect to ID network share';
            error_log('scan_docs: connectNetworkShareIfNeeded failed for ID_SAVE_PATH: ' . ID_SAVE_PATH);
        }

        // Save ID.pdf to the ID folder (if it exists)
        if (isset($pdf_files['id']) && file_exists($pdf_files['id'])) {
            $id_filename = $filenameBase . '.pdf';
            $id_network_path = ID_SAVE_PATH . $id_filename;
            error_log("Copying ID PDF to network: " . $id_network_path);
            
            if (safe_copy_with_retries($pdf_files['id'], $id_network_path, 3, 1)) {
                $network_messages[] = 'ID PDF saved successfully to network';
                $network_locations['id_pdf'] = $id_network_path;
                error_log("ID PDF copied successfully");
            } else {
                $network_success = false;
                $network_messages[] = 'Failed to save ID PDF to network location';
                error_log("Failed to copy ID PDF to network");
            }
        }

        // Save Insurance_Prescription.pdf to the out folder (if it exists)
        // Use same filename base (already determined above)
        if (isset($pdf_files['insurance']) && file_exists($pdf_files['insurance'])) {
            $insurance_filename = $filenameBase . '.pdf';
            $insurance_network_path = INSURANCE_SAVE_PATH . $insurance_filename;
            error_log("Copying Insurance PDF to network: " . $insurance_network_path);
            
            if (safe_copy_with_retries($pdf_files['insurance'], $insurance_network_path, 3, 1)) {
                $network_messages[] = 'Insurance/Prescription PDF saved successfully to network';
                $network_locations['insurance_pdf'] = $insurance_network_path;
                error_log("Insurance PDF copied successfully");
            } else {
                $network_success = false;
                $network_messages[] = 'Failed to save Insurance/Prescription PDF to network location';
                error_log("Failed to copy Insurance PDF to network");
            }
        } else {
            // No PDFs were created (valid for clinics with no images)
            $network_messages[] = 'No documents to save (prescription optional for clinics)';
            error_log("No PDFs created - skipping network save");
        }

    // NOW create the patient database record ONLY if network save was successful
    $actual_patient_id = $patient_id;
    $actual_ticket_id = null;
    $queue_number = null;
    
    if ($network_success && $is_pending) {
        try {
            $patient_created = createPatientRecord($is_pending, null, $pre_generated_queue);
            $actual_patient_id = $patient_created['patient_id'];
            $actual_ticket_id = $patient_created['ticket_id'] ?? null;
            $queue_number = $patient_created['queue_number'];
            error_log("Patient record created with ID: " . $actual_patient_id . " Queue: " . $queue_number . " Ticket: " . $actual_ticket_id);
        } catch (Exception $e) {
            error_log("Error creating patient record: " . $e->getMessage());
            $network_success = false;
            $network_messages[] = 'Failed to create patient record: ' . $e->getMessage();
        }
    } else if (!$is_pending) {
        // For existing patients, $actual_patient_id is already set from $patient_id
        $actual_patient_id = $patient_id;
    } else if (!$network_success && $is_pending) {
        // Network save failed, don't create the record
        error_log("Network save failed, skipping patient record creation");
    }

    // Clean up temporary files
    foreach ($temp_files as $file) {
        if (file_exists($file)) {
            unlink($file);
            error_log("Deleted temp file: " . $file);
        }
    }
    foreach ($pdf_files as $pdf_file) {
        if (file_exists($pdf_file)) {
            unlink($pdf_file);
            error_log("Deleted PDF file: " . $pdf_file);
        }
    }
    
    // Remove patient's temp directory if empty
    if (file_exists($patient_temp_dir) && count(glob($patient_temp_dir . '*')) === 0) {
        rmdir($patient_temp_dir);
        error_log("Removed temp directory: " . $patient_temp_dir);
    }

    // Return response to the frontend
    header('Content-Type: application/json');
    ob_clean(); // Clear any buffered output
    
    if ($network_success) {
        $response = [
            'success' => true,
            'message' => 'Patient record created and PDFs saved successfully',
            'details' => $network_messages,
            'locations' => $network_locations,
            'patient_id' => $actual_patient_id,
            'queue_number' => $queue_number
        ];
        if ($actual_ticket_id !== null) {
            $response['ticket_id'] = $actual_ticket_id;
        }

        echo json_encode($response);
        exit;
    } else {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Failed to save to network locations',
            'details' => $network_messages
        ]);
        exit;
    }

} catch (Exception $e) {

    error_log("Exception in scan_docs.php: " . $e->getMessage());

    http_response_code(500);

    echo json_encode(['success' => false, 'error' => 'Internal server error']);

    exit;

}

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document Scanner - Patient PDF Creator</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
            font-size: 2.5em;
        }

        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 1.1em;
        }

        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            border: 2px solid #e0e0e0;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background-color: #fff;
            position: relative;
            overflow: hidden;
        }

        .card:hover {
            border-color: #667eea;
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.2);
        }

        .card.captured {
            border-color: #4CAF50;
            background-color: #f0fff0;
        }

        .card-icon {
            font-size: 3em;
            margin-bottom: 10px;
        }

        .card h3 {
            color: #333;
            margin-bottom: 10px;
            font-size: 1.2em;
        }

        .card-preview {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }

        .card-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: #4CAF50;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            display: none;
        }

        .card.captured .card-badge {
            display: block;
        }

        /* Camera Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 20px;
            max-width: 800px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }

        .modal-header h2 {
            color: #333;
        }

        .close-btn {
            background: none;
            border: none;
            font-size: 1.5em;
            cursor: pointer;
            color: #666;
        }

        .close-btn:hover {
            color: #333;
        }

        #camera-feed {
            width: 100%;
            max-height: 400px;
            object-fit: cover;
            border-radius: 10px;
            background: #000;
            margin-bottom: 15px;
        }

        .camera-controls {
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
        }

        .btn-primary {
            background: #4CAF50;
            color: white;
        }

        .btn-primary:hover {
            background: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(76, 175, 80, 0.3);
        }

        .btn-secondary {
            background: #f44336;
            color: white;
        }

        .btn-secondary:hover {
            background: #da190b;
            transform: translateY(-2px);
        }

        .btn-capture {
            background: #667eea;
            color: white;
            font-size: 1.2em;
            padding: 15px 40px;
        }

        .btn-capture:hover {
            background: #5a67d8;
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .prescription-gallery {
            position: relative;
            width: 100%;
        }

        .prescription-photo-container {
            position: relative;
            width: 100%;
            height: 150px;
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
            margin-bottom: 8px;
        }

        .prescription-photo-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .prescription-delete-btn {
            position: absolute;
            top: 5px;
            right: 5px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            cursor: pointer;
            font-size: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        .prescription-delete-btn:hover {
            background: #da190b;
            transform: scale(1.1);
            box-shadow: 0 3px 8px rgba(0,0,0,0.3);
        }

        .prescription-count {
            text-align: center;
            font-size: 0.9em;
            color: #4CAF50;
            margin-top: 8px;
        }

        .btn-save {
            background: #667eea;
            color: white;
            width: 100%;
            font-size: 1.3em;
            padding: 15px;
        }

        .btn-save:hover:not(:disabled) {
            background: #5a67d8;
            transform: translateY(-2px);
        }

        .btn-save:disabled {
            background: #ccc;
            cursor: not-allowed;
        }

        .status-bar {
            background: #f5f5f5;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .capture-progress {
            color: #666;
        }

        .progress-dot {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin: 0 3px;
            background: #ddd;
        }

        .progress-dot.captured {
            background: #4CAF50;
        }

        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
            text-align: center;
        }

        .success-message {
            background: #e8f5e8;
            color: #2e7d32;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
            text-align: center;
        }

        .camera-hint {
            background: #e1f5fe;
            color: #0277bd;
            padding: 5px 10px;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 0.9em;
            text-align: center;
        }

        @media (max-width: 600px) {
            .container {
                padding: 15px;
            }
            
            .card-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .btn-capture {
                padding: 12px 20px;
                font-size: 1em;
            }
        }

        /* File upload input styling */
        #fallbackFileInput {
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            width: 100%;
            cursor: pointer;
            font-size: 1em;
            transition: all 0.3s;
        }

        #fallbackFileInput:hover {
            border-color: #667eea;
            background-color: #f9f9f9;
        }

        #fallbackFileInput:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
    </style>
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <div class="container">
        <h1>📄 Patient Document Scanner<?php echo $is_retake ? ' - Retake' : ''; ?></h1>
        <div class="subtitle"><?php echo $is_retake ? 'Retake patient documents. Prescription is optional.' : 'Click on any card to take a photo.'; ?></div>
        
        <div class="card-grid" id="cardGrid">
            <!-- ID Front -->
            <div class="card" data-card="id-front">
                <div class="card-icon">🆔</div>
                <h3>ID Front</h3>
                <img class="card-preview" id="preview-id-front" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='150'%3E%3Crect width='200' height='150' fill='%23f0f0f0'/%3E%3Ctext x='50' y='75' font-family='Arial' font-size='14' fill='%23999'%3ENo Image%3C/text%3E%3C/svg%3E" alt="ID Front Preview">
                <div class="card-badge">✓ Captured</div>
            </div>

            <!-- ID Back -->
            <div class="card" data-card="id-back">
                <div class="card-icon">🆔↩️</div>
                <h3>ID Back</h3>
                <img class="card-preview" id="preview-id-back" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='150'%3E%3Crect width='200' height='150' fill='%23f0f0f0'/%3E%3Ctext x='50' y='75' font-family='Arial' font-size='14' fill='%23999'%3ENo Image%3C/text%3E%3C/svg%3E" alt="ID Back Preview">
                <div class="card-badge">✓ Captured</div>
            </div>

            <!-- Insurance Front -->
            <div class="card" data-card="insurance-front">
                <div class="card-icon">📇</div>
                <h3>Insurance Front</h3>
                <img class="card-preview" id="preview-insurance-front" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='150'%3E%3Crect width='200' height='150' fill='%23f0f0f0'/%3E%3Ctext x='30' y='75' font-family='Arial' font-size='14' fill='%23999'%3ENo Image%3C/text%3E%3C/svg%3E" alt="Insurance Front Preview">
                <div class="card-badge">✓ Captured</div>
            </div>

            <!-- Insurance Back -->
            <div class="card" data-card="insurance-back">
                <div class="card-icon">📇↩️</div>
                <h3>Insurance Back</h3>
                <img class="card-preview" id="preview-insurance-back" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='150'%3E%3Crect width='200' height='150' fill='%23f0f0f0'/%3E%3Ctext x='30' y='75' font-family='Arial' font-size='14' fill='%23999'%3ENo Image%3C/text%3E%3C/svg%3E" alt="Insurance Back Preview">
                <div class="card-badge">✓ Captured</div>
            </div>

            <!-- Prescription -->
            <div class="card" data-card="prescription">
                <div class="card-icon">📋</div>
                <h3>Prescription<?php echo $is_retake ? ' <small style="color: #666; font-weight: normal;">(Optional)</small>' : ''; ?></h3>
                <div id="prescription-gallery" class="prescription-gallery">
                    <img class="card-preview" id="preview-prescription-default" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='150'%3E%3Crect width='200' height='150' fill='%23f0f0f0'/%3E%3Ctext x='35' y='75' font-family='Arial' font-size='14' fill='%23999'%3ENo Image%3C/text%3E%3C/svg%3E" alt="Prescription Preview">
                </div>
                <div id="prescription-count" class="prescription-count" style="display: none; margin-top: 8px; text-align: center; font-size: 0.9em; color: #4CAF50;">0 photos</div>
                <div class="card-badge">✓ Captured</div>
            </div>
        </div>

        <!-- Status Bar -->
        <div class="status-bar">
            <div class="capture-progress">
                <span id="captureCount">No documents captured</span>
                <span id="progressDots">
                    <span class="progress-dot"></span>
                    <span class="progress-dot"></span>
                    <span class="progress-dot"></span>
                </span>
            </div>
            <button class="btn btn-primary" onclick="saveImages()" id="saveBtn" disabled>💾 <?php echo $is_retake ? 'Update PDFs' : 'Save PDFs to Network'; ?></button>
        </div>

        <!-- Message Display -->
        <div id="messageDisplay"></div>

        <!-- Camera Modal -->
        <div class="modal" id="cameraModal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 id="modalTitle">Take Photo</h2>
                    <button class="close-btn" onclick="closeModal()">&times;</button>
                </div>
                <video id="camera-feed" autoplay playsinline></video>
                <div id="cameraError" class="error-message" style="display: none;"></div>
                <div class="camera-hint" id="cameraHint">📱 Using back camera (environment)</div>
                <div class="camera-controls">
                    <button class="btn btn-capture" onclick="captureImage()">📸 Take Photo</button>
                    <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                </div>
                <div class="camera-controls" style="margin-top: 10px;">
                    <button class="btn" onclick="switchCamera()" id="switchCameraBtn" style="background: #9c27b0; color: white;">🔄 Switch Camera</button>
                </div>
                <div style="margin-top: 20px; text-align: center; border-top: 1px solid #ddd; padding-top: 20px;">
                    <p style="color: #666; margin-bottom: 10px;">Or upload an image or PDF from your device:</p>
                    <input type="file" id="fallbackFileInput" accept="image/*,.pdf" onchange="handleFileUpload(event)" style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; width: 100%; cursor: pointer;">
                </div>
            </div>
        </div>
    </div>

    <script>
        // Image storage
        let images = {
            'id-front': null,
            'id-back': null,
            'insurance-front': null,
            'insurance-back': null,
            'prescription': [] // Array for multiple prescription images/files
        };
        
        // Store uploaded PDF files separately (not as base64)
        let uploadedPdfs = [];

        let currentCard = null;
        let mediaStream = null;
        let currentFacingMode = 'environment';

        // Get elements
        const modal = document.getElementById('cameraModal');
        const video = document.getElementById('camera-feed');
        const modalTitle = document.getElementById('modalTitle');
        const saveBtn = document.getElementById('saveBtn');
        const cameraError = document.getElementById('cameraError');
        const cameraHint = document.getElementById('cameraHint');
        const messageDisplay = document.getElementById('messageDisplay');
        const switchCameraBtn = document.getElementById('switchCameraBtn');

        // Check if MediaDevices API is supported
        function isMediaDevicesSupported() {
            return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
        }

        // Check if we're on a mobile device
        function isMobileDevice() {
            return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        }

        // Switch between front and back camera
        async function switchCamera() {
            if (!mediaStream) return;
            
            try {
                // Stop the current stream first
                mediaStream.getTracks().forEach(track => track.stop());
                mediaStream = null;
                video.srcObject = null;
                
                // Toggle the facing mode
                const nextFacingMode = currentFacingMode === 'environment' ? 'user' : 'environment';
                
                // Update UI before requesting new stream
                cameraHint.textContent = nextFacingMode === 'environment' ? '📱 Using back camera (environment)' : '📱 Using front camera (user)';
                console.log('Attempting to switch to:', nextFacingMode);
                
                let newStream = null;
                
                // Try with exact constraint first (stricter enforcement)
                try {
                    const strictConstraints = {
                        video: {
                            facingMode: { exact: nextFacingMode },
                            width: { ideal: 1920 },
                            height: { ideal: 1080 }
                        }
                    };
                    newStream = await navigator.mediaDevices.getUserMedia(strictConstraints);
                    console.log('Camera switched successfully using exact constraint:', nextFacingMode);
                    currentFacingMode = nextFacingMode;
                } catch (strictError) {
                    console.warn('Exact facingMode constraint failed, trying with ideal:', strictError);
                    
                    // Fallback to ideal constraint
                    try {
                        const idealConstraints = {
                            video: {
                                facingMode: { ideal: nextFacingMode },
                                width: { ideal: 1920 },
                                height: { ideal: 1080 }
                            }
                        };
                        newStream = await navigator.mediaDevices.getUserMedia(idealConstraints);
                        console.log('Camera switched successfully using ideal constraint:', nextFacingMode);
                        currentFacingMode = nextFacingMode;
                    } catch (idealError) {
                        console.error('Both exact and ideal constraints failed:', idealError);
                        throw idealError;
                    }
                }
                
                // Apply new stream
                mediaStream = newStream;
                video.srcObject = mediaStream;
                cameraError.style.display = 'none';
                
                // Ensure video is playing
                if (video.paused) {
                    await video.play().catch(e => console.warn('Video play warning:', e));
                }
                
            } catch (error) {
                console.error('Camera switch error:', error);
                cameraError.textContent = 'Failed to switch camera. Your device may only have one camera, or the camera is in use by another application.';
                cameraError.style.display = 'block';
                
                // Try to restore original camera (any available)
                try {
                    mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
                    video.srcObject = mediaStream;
                    console.log('Restored to any available camera');
                } catch (restoreError) {
                    console.error('Failed to restore camera:', restoreError);
                }
            }
        }

        // Card click handlers
        document.querySelectorAll('.card').forEach(card => {
            card.addEventListener('click', function() {
                const cardType = this.dataset.card;
                openCamera(cardType);
            });
        });

        // Open camera for specific card
        async function openCamera(cardType) {
            currentCard = cardType;
            modalTitle.textContent = `Take Photo - ${getCardTitle(cardType)}`;
            
            cameraError.style.display = 'none';
            
            if (!isMediaDevicesSupported()) {
                cameraError.textContent = 'Your browser does not support direct camera access. You can still upload an image using the file picker below.';
                cameraError.style.display = 'block';
                video.style.display = 'none';
                switchCameraBtn.style.display = 'none';
                cameraHint.style.display = 'none';
                modal.classList.add('active');
                return;
            }

            try {
                if (mediaStream) {
                    mediaStream.getTracks().forEach(track => track.stop());
                }

                // Reset to environment camera on open
                currentFacingMode = 'environment';
                cameraHint.textContent = '📱 Using back camera (environment)';

                // Try with exact constraint first (stricter enforcement)
                try {
                    const strictConstraints = {
                        video: {
                            facingMode: { exact: 'environment' },
                            width: { ideal: 1920 },
                            height: { ideal: 1080 }
                        }
                    };
                    mediaStream = await navigator.mediaDevices.getUserMedia(strictConstraints);
                    console.log('Camera opened using exact environment constraint');
                } catch (e) {
                    console.warn('Exact environment constraint failed, trying ideal:', e);
                    
                    // Fallback to ideal constraint for environment
                    try {
                        const idealConstraints = {
                            video: {
                                facingMode: { ideal: 'environment' },
                                width: { ideal: 1920 },
                                height: { ideal: 1080 }
                            }
                        };
                        mediaStream = await navigator.mediaDevices.getUserMedia(idealConstraints);
                        console.log('Camera opened using ideal environment constraint');
                    } catch (fallbackError) {
                        console.log('Environment camera failed, trying any camera:', fallbackError);
                        mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
                        currentFacingMode = 'unknown';
                        cameraHint.textContent = '📱 Using available camera';
                    }
                }
                
                video.srcObject = mediaStream;
                video.style.display = 'block';
                await video.play();
                modal.classList.add('active');
                
                const devices = await navigator.mediaDevices.enumerateDevices();
                const videoDevices = devices.filter(device => device.kind === 'videoinput');
                switchCameraBtn.style.display = videoDevices.length > 1 ? 'inline-block' : 'none';
                
            } catch (error) {
                console.error('Camera error:', error);
                
                let errorMessage = 'Unable to access camera. ';
                
                if (error.name === 'NotAllowedError' || error.message.includes('permission')) {
                    errorMessage += 'Please allow camera access in your browser settings.';
                } else if (error.name === 'NotFoundError' || error.message.includes('NotReadable')) {
                    errorMessage += 'No camera found on this device.';
                } else {
                    errorMessage += 'Please check your camera connection.';
                }
                
                errorMessage += ' You can still upload an image using the file picker below.';
                
                cameraError.textContent = errorMessage;
                cameraError.style.display = 'block';
                video.style.display = 'none';
                switchCameraBtn.style.display = 'none';
                cameraHint.style.display = 'none';
                modal.classList.add('active');
            }
        }

        // Handle file upload fallback
        function handleFileUpload(event) {
            const file = event.target.files[0];
            if (!file) return;
            
            const isPDF = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
            
            if (isPDF) {
                // Handle PDF files
                if (currentCard === 'prescription') {
                    // For prescription, store PDF file object and add reference
                    uploadedPdfs.push(file);
                    images[currentCard].push({
                        type: 'pdf',
                        fileName: file.name,
                        index: uploadedPdfs.length - 1
                    });
                    addPrescriptionPhotoToGallery({
                        type: 'pdf',
                        fileName: file.name,
                        index: uploadedPdfs.length - 1
                    });
                } else {
                    alert('PDF uploads are only supported for prescriptions');
                    return;
                }
            } else {
                // Handle image files (existing logic)
                const reader = new FileReader();
                reader.onload = function(e) {
                    if (currentCard === 'prescription') {
                        // For prescription, add to array
                        images[currentCard].push({
                            type: 'image',
                            data: e.target.result
                        });
                        addPrescriptionPhotoToGallery({
                            type: 'image',
                            data: e.target.result
                        });
                    } else {
                        // For other cards, replace single image
                        images[currentCard] = e.target.result;
                        const previewId = `preview-${currentCard}`;
                        const previewImg = document.getElementById(previewId);
                        if (previewImg) {
                            previewImg.src = e.target.result;
                        }
                        const card = document.querySelector(`[data-card="${currentCard}"]`);
                        if (card) {
                            card.classList.add('captured');
                        }
                    }
                    updateProgress();
                    closeModal();
                };
                reader.readAsDataURL(file);
            }
            updateProgress();
            closeModal();
        }

        // Add prescription photo to gallery display
        function addPrescriptionPhotoToGallery(fileData) {
            const gallery = document.getElementById('prescription-gallery');
            const defaultPreview = document.getElementById('preview-prescription-default');
            
            // Hide default preview if first image
            if (images['prescription'].length === 1 && defaultPreview) {
                defaultPreview.style.display = 'none';
            }
            
            const container = document.createElement('div');
            container.className = 'prescription-photo-container';
            container.id = `prescription-photo-${images['prescription'].length - 1}`;
            
            if (typeof fileData === 'string') {
                // Legacy base64 image string
                const img = document.createElement('img');
                img.src = fileData;
                container.appendChild(img);
            } else if (fileData.type === 'pdf') {
                // Display PDF icon for PDFs
                const pdfLabel = document.createElement('div');
                pdfLabel.style.cssText = 'display: flex; align-items: center; justify-content: center; height: 150px; background: #f5f5f5; border-radius: 8px; flex-direction: column; gap: 10px;';
                
                const icon = document.createElement('div');
                icon.style.cssText = 'font-size: 3em;';
                icon.textContent = '📄';
                
                const label = document.createElement('div');
                label.style.cssText = 'font-size: 0.9em; text-align: center; word-break: break-word; padding: 0 5px;';
                label.textContent = fileData.fileName;
                
                pdfLabel.appendChild(icon);
                pdfLabel.appendChild(label);
                container.appendChild(pdfLabel);
            } else {
                // Display image (object with data)
                const img = document.createElement('img');
                img.src = fileData.data || '';
                container.appendChild(img);
            }
            
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'prescription-delete-btn';
            deleteBtn.textContent = '✕';
            deleteBtn.onclick = function(e) {
                e.stopPropagation();
                deletePrescriptionPhoto(images['prescription'].length - 1);
            };
            container.appendChild(deleteBtn);
            
            gallery.appendChild(container);
            updatePrescriptionCount();
        }

        // Delete a prescription photo
        function deletePrescriptionPhoto(index) {
            images['prescription'].splice(index, 1);
            
            const container = document.getElementById(`prescription-photo-${index}`);
            if (container) {
                container.remove();
            }
            
            // Re-index remaining photos
            const containers = document.querySelectorAll('.prescription-photo-container');
            containers.forEach((cont, newIndex) => {
                cont.id = `prescription-photo-${newIndex}`;
                const deleteBtn = cont.querySelector('.prescription-delete-btn');
                if (deleteBtn) {
                    deleteBtn.onclick = function(e) {
                        e.stopPropagation();
                        deletePrescriptionPhoto(newIndex);
                    };
                }
            });
            
            // Show default preview if no images
            if (images['prescription'].length === 0) {
                const defaultPreview = document.getElementById('preview-prescription-default');
                if (defaultPreview) {
                    defaultPreview.style.display = 'block';
                }
            }
            
            updatePrescriptionCount();
            updateProgress();
        }

        // Update prescription photo count display
        function updatePrescriptionCount() {
            const count = images['prescription'].length;
            const countDisplay = document.getElementById('prescription-count');
            if (countDisplay) {
                if (count > 0) {
                    countDisplay.textContent = count + ' photo' + (count > 1 ? 's' : '');
                    countDisplay.style.display = 'block';
                } else {
                    countDisplay.style.display = 'none';
                }
            }
        }

        // Capture image from video feed
        function captureImage() {
            if (!video.videoWidth) {
                alert('Camera not ready. Please wait...');
                return;
            }

            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            
            context.drawImage(video, 0, 0, canvas.width, canvas.height);
            
            const imageData = canvas.toDataURL('image/jpeg', 0.9);
            
            if (currentCard === 'prescription') {
                // For prescription, add to array
                images[currentCard].push(imageData);
                addPrescriptionPhotoToGallery(imageData);
                const card = document.querySelector(`[data-card="${currentCard}"]`);
                if (card) {
                    card.classList.add('captured');
                }
            } else {
                // For other cards, replace single image
                images[currentCard] = imageData;
                const previewId = `preview-${currentCard}`;
                const previewImg = document.getElementById(previewId);
                if (previewImg) {
                    previewImg.src = imageData;
                }
                const card = document.querySelector(`[data-card="${currentCard}"]`);
                if (card) {
                    card.classList.add('captured');
                }
            }
            
            updateProgress();
            closeModal();
        }

        // Close camera modal
        function closeModal() {
            modal.classList.remove('active');
            if (mediaStream) {
                mediaStream.getTracks().forEach(track => track.stop());
                mediaStream = null;
            }
            video.srcObject = null;
            video.style.display = 'block';
            cameraError.style.display = 'none';
            switchCameraBtn.style.display = 'inline-block';
            cameraHint.style.display = 'block';
        }

        // Update capture progress
        function updateProgress() {
            const hasIdFront = images['id-front'] !== null;
            const hasIdBack = images['id-back'] !== null;
            const hasInsuranceFront = images['insurance-front'] !== null;
            const hasInsuranceBack = images['insurance-back'] !== null;
            const hasPrescription = images['prescription'].length > 0;
            
            let statusParts = [];
            if (hasPrescription) statusParts.push('📋 Prescription (' + images['prescription'].length + ')');
            
            if (hasIdFront && hasIdBack) {
                statusParts.push('🆔 ID (both sides)');
            } else if (hasIdFront || hasIdBack) {
                statusParts.push('⚠️ ID (incomplete)');
            }
            
            if (hasInsuranceFront || hasInsuranceBack) {
                statusParts.push('📇 Insurance');
            }
            
            if (statusParts.length == 0) {
                document.getElementById('captureCount').textContent = 'No documents captured';
            } else {
                document.getElementById('captureCount').textContent = statusParts.join(' • ');
            }
            
            const dots = document.querySelectorAll('.progress-dot');
            if (dots[0]) dots[0].classList.toggle('captured', <?php echo $is_retake ? 'true' : 'hasPrescription'; ?>);
            if (dots[1]) dots[1].classList.toggle('captured', hasIdFront && hasIdBack);
            if (dots[2]) dots[2].classList.toggle('captured', hasInsuranceFront || hasInsuranceBack);
            
            saveBtn.disabled = <?php echo $is_retake ? 'false' : '!hasPrescription'; ?>;
        }

        // Get human-readable card title
        function getCardTitle(cardType) {
            const titles = {
                'id-front': 'ID Front',
                'id-back': 'ID Back',
                'insurance-front': 'Insurance Front',
                'insurance-back': 'Insurance Back',
                'prescription': 'Prescription'
            };
            return titles[cardType] || cardType;
        }

        // Save images and generate PDFs to network
        async function saveImages() {
            const hasIdFront = images['id-front'] !== null;
            const hasIdBack = images['id-back'] !== null;
            const hasPrescription = images['prescription'].length > 0;
            
            <?php if (!$is_retake): ?>
            if (!hasPrescription) {
                alert('Prescription is required for new patients! Please add at least one prescription photo or PDF.');
                return;
            }
            <?php endif; ?>
            
            if ((hasIdFront || hasIdBack) && !(hasIdFront && hasIdBack)) {
                alert('If ID is photographed, both front and back must be captured!');
                return;
            }

            saveBtn.disabled = true;
            saveBtn.textContent = 'Saving to network...';
            
            messageDisplay.innerHTML = '';

            try {
                // Use FormData instead of JSON to handle both base64 and PDF files
                const formData = new FormData();
                formData.append('images_json', JSON.stringify(images));
                
                // Add uploaded PDF files
                uploadedPdfs.forEach((pdfFile, index) => {
                    formData.append('pdf_' + index, pdfFile);
                });
                
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                });

                const text = (await response.text()).replace(/^\uFEFF/, '').trim();
                let result;
                try {
                    result = JSON.parse(text);
                } catch (e) {
                    throw new Error('Invalid JSON from server: ' + text);
                }

                if (response.ok && result.success) {
                    let filesList = '';
                    if (result.locations.id_pdf) {
                        filesList += `<br><strong>ID PDF:</strong> ${result.locations.id_pdf}`;
                    }
                    if (result.locations.insurance_pdf) {
                        filesList += `<br><strong>Insurance/Prescription PDF:</strong> ${result.locations.insurance_pdf}`;
                    }
                    
                    // Include queue number in success message if available
                    let queueMsg = '';
                    if (result.queue_number) {
                        queueMsg = `<br><strong style="color: #4CAF50; font-size: 1.2em;">Queue Number: ${result.queue_number}</strong>`;
                    }
                    
                    messageDisplay.innerHTML = `
                        <div class="success-message">
                            ✅ Patient record created successfully!${queueMsg}${filesList}
                        </div>
                    `;
                    
                    // Redirect after 2 seconds (back to originating workflow)
                    setTimeout(function() {
                        var redirectTarget = 'butler.php';
                        <?php if ($from_page === 'clinics'): ?>
                        redirectTarget = 'clinics.php';
                        <?php if ($return_clinic !== ''): ?>
                        redirectTarget += '?clinic=<?php echo rawurlencode($return_clinic); ?>';
                        <?php endif; ?>
                        <?php elseif ($from_page === 'billing'): ?>
                        redirectTarget = 'billing.php';
                        <?php elseif ($from_page === 'butler'): ?>
                        redirectTarget = 'butler.php';
                        <?php endif; ?>
                        window.location.href = redirectTarget;
                    }, 2000);
                } else {
                    messageDisplay.innerHTML = `
                        <div class="error-message">
                            ❌ Failed to save PDFs:<br>
                            ${result.error || 'Unknown error'}<br>
                            ${result.details ? result.details.join('<br>') : ''}
                        </div>
                    `;
                }
            } catch (error) {
                console.error('Error:', error);
                messageDisplay.innerHTML = `
                    <div class="error-message">
                        ❌ Network error: ${error.message}
                    </div>
                `;
            } finally {
                saveBtn.disabled = false;
                saveBtn.textContent = '💾 Save';
            }
        }

        // Reset all images
        function resetAll() {
            if (confirm('Reset all captured images?')) {
                images = {
                    'id-front': null,
                    'id-back': null,
                    'insurance-front': null,
                    'insurance-back': null,
                    'prescription': []
                };
                
                // Reset regular card previews
                document.querySelectorAll('.card-preview').forEach(preview => {
                    preview.src = 'data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\'%3E%3Crect width=\'200\' height=\'150\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'50\' y=\'75\' font-family=\'Arial\' font-size=\'14\' fill=\'%23999\'%3ENo Image%3C/text%3E%3C/svg%3E';
                });
                
                // Reset prescription gallery
                const prescriptionGallery = document.getElementById('prescription-gallery');
                if (prescriptionGallery) {
                    prescriptionGallery.innerHTML = '<img class="card-preview" id="preview-prescription-default" src="data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'200\' height=\'150\'%3E%3Crect width=\'200\' height=\'150\' fill=\'%23f0f0f0\'/%3E%3Ctext x=\'35\' y=\'75\' font-family=\'Arial\' font-size=\'14\' fill=\'%23999\'%3ENo Image%3C/text%3E%3C/svg%3E">';
                }
                
                // Hide prescription count
                const prescriptionCount = document.getElementById('prescription-count');
                if (prescriptionCount) {
                    prescriptionCount.style.display = 'none';
                }
                
                document.querySelectorAll('.card').forEach(card => {
                    card.classList.remove('captured');
                });
                
                updateProgress();
                messageDisplay.innerHTML = '';
            }
        }

        // Add reset button
        const statusBar = document.querySelector('.status-bar');
        const resetButton = document.createElement('button');
        resetButton.className = 'btn btn-secondary';
        resetButton.textContent = '↻ Reset All';
        resetButton.onclick = resetAll;
        resetButton.style.marginLeft = '10px';
        statusBar.appendChild(resetButton);

        // Add browser info for debugging
        const browserInfo = document.createElement('div');
        browserInfo.className = 'fallback-note';
        browserInfo.innerHTML = `📱 Device: ${isMobileDevice() ? 'Mobile' : 'Desktop'} | Camera API: ${isMediaDevicesSupported() ? '✅ Supported' : '❌ Not Supported'}`;
        document.querySelector('.status-bar').after(browserInfo);

        // Initial progress update
        updateProgress();

        // Clean up on page unload
        window.addEventListener('beforeunload', function() {
            if (mediaStream) {
                mediaStream.getTracks().forEach(track => track.stop());
            }
        });
    </script>
</body>
</html>
<?php
// patient_actions.php - Unified Patient Actions Handler
// Handles actions for both Lab and Imaging departments
require_once 'config.php';
session_start();
authRequireRoles(['butler', 'billing', 'imaging', 'laboratory', 'admin'], ['log_view' => false]);

$action = $_POST['action'] ?? '';
$ticket_id = intval($_POST['patient_id'] ?? $_POST['ticket_id'] ?? 0);
$patient_id = $ticket_id; // alias kept for undo session compatibility
$department = $_POST['department'] ?? '';
$machine = $_POST['machine'] ?? ''; // For imaging only

// Check if this is an AJAX request or form submission
$is_ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

$response = ['success' => false, 'message' => ''];
$whatsapp_urls = []; // Track all WhatsApp API calls for debugging

/**
 * Save undo state in session using the shared undo.php contract.
 */
function saveUndoState($pdo, $ticket_id, $previous_status, $new_status, $action_label, $department) {
    $state = executeAndFetchOne($pdo, "SELECT img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$ticket_id], PDO::FETCH_ASSOC) ?: [];

    $_SESSION['last_action'] = [
        'patient_id' => $ticket_id,
        'previous_status' => $previous_status,
        'current_status' => $new_status,
        'action' => $action_label,
        'department' => $department,
        'img' => $state['img'] ?? 0,
        'lab' => $state['lab'] ?? 0,
        'dp2' => $state['dp2'] ?? 0,
        'imaging_machine' => $state['imaging_machine'] ?? null,
        'timestamp' => time()
    ];
}

function patientActionAudit($actionKey, $ticketId, $department, $fromStatus, $toStatus = null, $extra = []) {
    $details = array_merge([
        'ticket_action' => ucwords(str_replace('_', ' ', (string)$actionKey)),
        'department' => (string)$department,
        'from_status' => (string)$fromStatus,
        'to_status' => $toStatus !== null ? (string)$toStatus : null,
    ], $extra);
    authLogTicketAction($actionKey, $ticketId, $details, 'patient_actions.php');
}

// ====================
// PHONE NUMBER FORMATTING HELPER
// ====================
/**
 * Format phone number with country code
 * @param string $phone_number - The local phone number (without country code)
 * @param string $country_code - The country code (e.g., '+961', '+1')
 * @return string - The formatted international phone number
 */
function formatInternationalNumber($phone_number, $country_code) {
    // Remove all non-numeric characters from phone number
    $phone_number = preg_replace('/[^0-9]/', '', $phone_number);
    
    // Remove country code from both for processing
    $country_code_digits = preg_replace('/[^0-9]/', '', $country_code);
    
    // Remove country code if it already exists in the phone number
    if (strpos($phone_number, $country_code_digits) === 0) {
        $phone_number = substr($phone_number, strlen($country_code_digits));
    }
    
    // Combine and return
    return $country_code_digits . $phone_number;
}

// ====================
// WHATSAPP MESSAGING FUNCTIONS
// ====================
/**
 * Send WhatsApp message via API
 * @param string $phone_number - Destination phone number (should already be formatted with country code)
 * @param string $template - Template name (call_queue, skip_queue, ticket_queue)
 * @param array $variables - Optional template variables (e.g., ['queue_number' => '1001'])
 */
function sendWhatsAppMessage($phone_number, $template, $variables = []) {
    global $whatsapp_urls;
    try {
        if (empty($phone_number)) {
            error_log("WhatsApp API: No phone number provided");
            return false; // Skip if no phone number
        }
        $phone_number = preg_replace('/[^0-9]/', '', $phone_number);

        if (strlen($phone_number) <= 9) {
            $phone_number = '961' . $phone_number;
        }

        $sendResult = sendWhatsAppTemplateRequest($phone_number, $template, $variables);
        $full_url = (string)($sendResult['request_url'] ?? '');
        
        // Track this URL for debugging
        $whatsapp_urls[] = [
            'template' => $template,
            'phone' => $phone_number,
            'url' => $full_url
        ];
        
        // Log the request for debugging (server log)
        error_log("WhatsApp API Request: " . $full_url);

        $response = (string)($sendResult['response'] ?? '');
        $http_code = (int)($sendResult['http_code'] ?? 0);
        $curl_error = (string)($sendResult['curl_error'] ?? '');
        
        // Log the response for debugging
        error_log("WhatsApp API Response (HTTP $http_code): " . $response);
        
        if ($curl_error) {
            error_log("WhatsApp API cURL Error: " . $curl_error);
            return false;
        }
        
        // Check if response indicates success
        if ($http_code >= 200 && $http_code < 300) {
            error_log("WhatsApp message sent successfully to $phone_number with template: $template");
            return true;
        } else {
            error_log("WhatsApp API returned HTTP $http_code for $phone_number");
            return false;
        }
        
    } catch (Exception $e) {
        error_log("WhatsApp API Exception: " . $e->getMessage());
        return false;
    }
}

try {
    // Validate department
    if (!in_array($department, ['lab', 'imaging', 'clinics'])) {
        throw new Exception('Invalid department');
    }

    // Get current status and patient info
    $patient = executeAndFetchOne($pdo, "SELECT t.current_status, t.img FROM tickets t WHERE t.ticket_id = ?", [$ticket_id]);
    
    if (!$patient) {
        throw new Exception('Patient not found');
    }
    
    $current_status = $patient['current_status'];

    // Define department-specific messages and context
    $dept_context = [
        'lab' => [
            'name' => 'Laboratory',
            'skip_msg' => 'Patient skipped in Laboratory',
            'recall_msg' => 'Patient recalled in Laboratory',
            'send_back_msg' => 'Sent back to waiting queue from Lab',
            'session_key' => 'lab_message'
        ],
        'imaging' => [
            'name' => 'Imaging',
            'skip_msg' => 'Patient skipped in Imaging',
            'recall_msg' => 'Patient recalled in Imaging',
            'send_back_msg' => 'Sent back to waiting queue',
            'session_key' => 'imaging_message'
        ],
        'clinics' => [
            'name' => 'Clinics',
            'skip_msg' => 'Patient skipped in Clinics',
            'recall_msg' => 'Patient recalled in Clinics',
            'send_back_msg' => 'Sent back to waiting queue from Clinics',
            'session_key' => 'clinics_message'
        ]
    ];

    $context = $dept_context[$department];

    // Handle butler stream confirmation (mark as In Process)
    if ($action === 'mark_in_process') {
        $stream = $_POST['stream'] ?? 'lab';
        executeUpdate($pdo, "UPDATE tickets SET current_status = 'In Process', lab = 0, img = 0, dp2 = 0, approval_timestamp = NOW() WHERE ticket_id = ?", [$ticket_id]);

        $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Reception Confirmed', 'Called', 'In Process', ?, ?)";
        executeUpdate($pdo, $log_sql, [$ticket_id, "Patient confirmed reception at {$stream}", authCurrentUserId() ?: null]);
        patientActionAudit('ticket_mark_in_process', $ticket_id, $stream, $current_status, 'In Process', [
            'notes' => "Patient confirmed reception at {$stream}",
        ]);

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Patient status updated']);
        exit;
    }

    switch ($action) {
        case 'call_patient':
            executeUpdate($pdo, "UPDATE tickets SET current_status = 'Called' WHERE ticket_id = ?", [$ticket_id]);

            if ($department === 'clinics') {
                saveUndoState($pdo, $ticket_id, $current_status, 'Called', 'Called in Clinics', 'clinics');
            }

            if ($department === 'lab') {
                executeUpdate($pdo, "UPDATE tickets SET lab_call_time = NOW() WHERE ticket_id = ?", [$ticket_id]);
            } elseif ($department === 'imaging') {
                executeUpdate($pdo, "UPDATE tickets SET imaging_call_time = NOW() WHERE ticket_id = ?", [$ticket_id]);
            } else {
                executeUpdate($pdo, "UPDATE tickets SET clinics_call_time = NOW() WHERE ticket_id = ?", [$ticket_id]);
            }

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Called', ?, 'Called', ?, ?, ?)";
            executeUpdate($pdo, $log_sql, [$ticket_id, $current_status, $machine ?: null, authCurrentUserId() ?: null, "Patient called to {$context['name']}"]);
            patientActionAudit('ticket_called', $ticket_id, $department, $current_status, 'Called', [
                'machine' => $machine,
                'notes' => "Patient called to {$context['name']}",
            ]);

            $phoneResult = executeAndFetchOne($pdo, "SELECT p.mobile, p.country_code FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$ticket_id]);
            if ($phoneResult && !empty($phoneResult['mobile'])) {
                $international_phone = formatInternationalNumber($phoneResult['mobile'], $phoneResult['country_code'] ?? '+961');
                $dept_name = ($department === 'lab') ? 'Laboratory' : 'Imaging';
                $dept_name_ar = ($department === 'lab') ? 'المختبر' : 'الأشعة';
                sendWhatsAppMessage($international_phone, 'call_queue', ['dept_en' => $dept_name, 'dept_ar' => $dept_name_ar]);
            }

            $_SESSION[$context['session_key']] = "Patient called to {$context['name']}";
            $response['success'] = true;
            $response['message'] = 'Patient called successfully';
            break;

        case 'mark_in_process':
            executeUpdate($pdo, "UPDATE tickets SET current_status = 'In Process', cl = 0, img = 0, lab = 0, dp2 = 0, approval_timestamp = NOW() WHERE ticket_id = ?", [$ticket_id]);

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Marked In Process', ?, 'In Process', ?, ?)";
            executeUpdate($pdo, $log_sql, [$ticket_id, $current_status, authCurrentUserId() ?: null, "Marked as In Process in {$context['name']}"]);
            patientActionAudit('ticket_mark_in_process', $ticket_id, $department, $current_status, 'In Process', [
                'notes' => "Marked as In Process in {$context['name']}",
            ]);

            $_SESSION[$context['session_key']] = 'Patient marked In Process';
            $response['success'] = true;
            $response['message'] = 'Patient marked In Process';
            break;

        case 'skip':
            executeUpdate($pdo, "UPDATE tickets SET current_status = 'Skipped' WHERE ticket_id = ?", [$ticket_id]);

            if ($department === 'clinics') {
                saveUndoState($pdo, $ticket_id, $current_status, 'Skipped', 'Skipped in Clinics', 'clinics');
            }

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Skipped', ?, 'Skipped', ?, ?, ?)";
            executeUpdate($pdo, $log_sql, [$ticket_id, $current_status, $machine ?: null, authCurrentUserId() ?: null, $context['skip_msg']]);
            patientActionAudit('ticket_skipped', $ticket_id, $department, $current_status, 'Skipped', [
                'machine' => $machine,
                'notes' => $context['skip_msg'],
            ]);

            $phoneResult = executeAndFetchOne($pdo, "SELECT p.mobile, p.country_code FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$ticket_id]);
            if ($phoneResult && !empty($phoneResult['mobile'])) {
                $international_phone = formatInternationalNumber($phoneResult['mobile'], $phoneResult['country_code'] ?? '+961');
                $dept_name = ($department === 'lab') ? 'Laboratory' : 'Imaging';
                $dept_name_ar = ($department === 'lab') ? 'المختبر' : 'الأشعة';
                sendWhatsAppMessage($international_phone, 'skip_queue', ['dept_en' => $dept_name, 'dept_ar' => $dept_name_ar]);
            }

            $_SESSION[$context['session_key']] = 'Patient skipped';
            $response['success'] = true;
            $response['message'] = 'Patient skipped successfully';
            break;

        case 'recall':
            executeUpdate($pdo, "UPDATE tickets SET current_status = 'Recalled' WHERE ticket_id = ?", [$ticket_id]);

            if ($department === 'clinics') {
                saveUndoState($pdo, $ticket_id, $current_status, 'Recalled', 'Recalled in Clinics', 'clinics');
            }

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Recalled', ?, 'Recalled', ?, ?, ?)";
            executeUpdate($pdo, $log_sql, [$ticket_id, $current_status, $machine ?: null, authCurrentUserId() ?: null, $context['recall_msg']]);
            patientActionAudit('ticket_recalled', $ticket_id, $department, $current_status, 'Recalled', [
                'machine' => $machine,
                'notes' => $context['recall_msg'],
            ]);

            $phoneResult = executeAndFetchOne($pdo, "SELECT p.mobile, p.country_code FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$ticket_id]);
            if ($phoneResult && !empty($phoneResult['mobile'])) {
                $international_phone = formatInternationalNumber($phoneResult['mobile'], $phoneResult['country_code'] ?? '+961');
                $dept_name = ($department === 'lab') ? 'Laboratory' : 'Imaging';
                $dept_name_ar = ($department === 'lab') ? 'المختبر' : 'الأشعة';
                sendWhatsAppMessage($international_phone, 'call_queue', ['dept_en' => $dept_name, 'dept_ar' => $dept_name_ar]);
            }

            $_SESSION[$context['session_key']] = 'Patient recalled';
            $response['success'] = true;
            $response['message'] = 'Patient recalled successfully';
            break;

        case 'send_back':
            executeUpdate($pdo, "UPDATE tickets SET current_status = 'On Hold' WHERE ticket_id = ?", [$ticket_id]);

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Sent back to Queue', ?, 'On Hold', ?, ?, ?)";
            executeUpdate($pdo, $log_sql, [$ticket_id, $current_status, $machine ?: null, authCurrentUserId() ?: null, $context['send_back_msg']]);
            patientActionAudit('ticket_sent_back', $ticket_id, $department, $current_status, 'On Hold', [
                'machine' => $machine,
                'notes' => $context['send_back_msg'],
            ]);

            $_SESSION[$context['session_key']] = 'Patient sent back to waiting queue';
            $response['success'] = true;
            $response['message'] = 'Patient sent back to waiting queue';
            break;

        case 'start_procedure':
            if (!in_array($department, ['lab', 'imaging', 'clinics'])) {
                throw new Exception('Invalid action for this department');
            }

            executeUpdate($pdo, "UPDATE tickets SET current_status = 'Served' WHERE ticket_id = ?", [$ticket_id]);

            $procedure_name = $department === 'lab' ? 'lab procedure' : 'imaging procedure';
            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Started Procedure', ?, 'Served', ?, ?, ?)";
            executeUpdate($pdo, $log_sql, [$ticket_id, $current_status, $machine ?: null, authCurrentUserId() ?: null, "Started $procedure_name"]);
            patientActionAudit('ticket_served', $ticket_id, $department, $current_status, 'Served', [
                'machine' => $machine,
                'notes' => "Started $procedure_name",
            ]);

            $_SESSION[$context['session_key']] = 'Procedure started';
            $response['success'] = true;
            $response['message'] = 'Procedure started';
            break;

        case 'close':
            if ($department !== 'lab') {
                throw new Exception('Invalid action for this department');
            }

            if ($patient['img'] == 1) {
                $mrnResult = executeAndFetchOne($pdo, "SELECT p.mrn FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$ticket_id]);
                $mrn = $mrnResult['mrn'] ?? null;

                executeUpdate($pdo, "
                    UPDATE tickets
                    SET current_status = 'Waiting',
                        lab = 0,
                        dp2 = 1
                    WHERE ticket_id = ?
                ", [$ticket_id]);

                if ($mrn !== null) {
                    executeUpdate($pdo, "UPDATE patients SET mrn = ? WHERE patient_id = (SELECT patient_id FROM tickets WHERE ticket_id = ?)", [$mrn, $ticket_id]);
                }

                $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Completed Lab & Sent to Imaging', 'Served', 'Waiting', ?, 'Lab completed, sent to imaging queue')";
                $_SESSION[$context['session_key']] = 'Patient completed and sent to Imaging queue!';
            } else {
                executeUpdate($pdo, "
                    UPDATE tickets
                    SET current_status = 'Completed',
                        closing_timestamp = NOW()
                    WHERE ticket_id = ?
                ", [$ticket_id]);

                $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Completed Lab', 'Served', 'Completed', ?, 'Laboratory tests completed')";
                $_SESSION[$context['session_key']] = 'Patient completed successfully!';
            }

            executeUpdate($pdo, $log_sql, [$ticket_id, authCurrentUserId() ?: null]);
            patientActionAudit('ticket_closed', $ticket_id, $department, $current_status, $patient['img'] == 1 ? 'Waiting' : 'Completed', [
                'notes' => $patient['img'] == 1 ? 'Lab completed, sent to imaging queue' : 'Department workflow completed',
            ]);

            $response['success'] = true;
            $response['message'] = 'Ticket closed successfully';
            break;

        case 'call_next':
            $servedPatient = executeAndFetchOne($pdo, "
                SELECT t.ticket_id AS id, t.img FROM tickets t
                WHERE t.current_status = 'Served'
                AND " . ($department === 'lab' ? 't.lab = 1 AND t.dp2 = 0' : 't.img = 1 AND t.imaging_machine IS NOT NULL') . "
                LIMIT 1
            ", []);

            if ($servedPatient) {
                if ($department === 'lab' && $servedPatient['img'] == 1) {
                    executeUpdate($pdo, "
                        UPDATE tickets
                        SET current_status = 'Waiting',
                            lab = 0,
                            dp2 = 1
                        WHERE ticket_id = ?
                    ", [$servedPatient['id']]);
                    $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Completed Lab & Sent to Imaging', 'Served', 'Waiting', ?, 'Auto-completed when calling next patient')";
                    $completedToStatus = 'Waiting';
                } else {
                    executeUpdate($pdo, "
                        UPDATE tickets
                        SET current_status = 'Completed',
                            closing_timestamp = NOW()
                        WHERE ticket_id = ?
                    ", [$servedPatient['id']]);
                    $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Completed via Call Next', 'Served', 'Completed', ?, 'Auto-completed when calling next patient')";
                    $completedToStatus = 'Completed';
                }

                executeUpdate($pdo, $log_sql, [$servedPatient['id'], authCurrentUserId() ?: null]);
                patientActionAudit('ticket_auto_completed', (int)$servedPatient['id'], $department, 'Served', $completedToStatus, [
                    'notes' => 'Auto-completed when calling next patient',
                ]);
            }

            if ($department === 'lab') {
                $nextPatient = executeAndFetchOne($pdo, "
                    SELECT t.ticket_id AS id FROM tickets t
                    WHERE t.current_status = 'Waiting'
                    AND t.lab = 1
                    AND t.dp2 = 0
                    ORDER BY
                        FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
                        t.arrival_timestamp ASC
                    LIMIT 1
                ", []);
            } else {
                $nextPatient = executeAndFetchOne($pdo, "
                    SELECT t.ticket_id AS id FROM tickets t
                    WHERE t.current_status = 'Waiting'
                    AND t.img = 1
                    AND (t.lab = 0 OR t.dp2 = 1)
                    AND t.imaging_machine = ?
                    ORDER BY
                        FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
                        t.arrival_timestamp ASC
                    LIMIT 1
                ", [$machine]);
            }

            if ($nextPatient) {
                executeUpdate($pdo, "UPDATE tickets SET current_status = 'Called' WHERE ticket_id = ?", [$nextPatient['id']]);

                if ($department === 'lab') {
                    executeUpdate($pdo, "UPDATE tickets SET lab_call_time = NOW() WHERE ticket_id = ?", [$nextPatient['id']]);
                } else {
                    executeUpdate($pdo, "UPDATE tickets SET imaging_call_time = NOW() WHERE ticket_id = ?", [$nextPatient['id']]);
                }

                $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Called Next', 'Waiting', 'Called', ?, ?, 'Called as next patient via Call Next button')";
                executeUpdate($pdo, $log_sql, [$nextPatient['id'], $machine ?: null, authCurrentUserId() ?: null]);
                patientActionAudit('ticket_called_next', (int)$nextPatient['id'], $department, 'Waiting', 'Called', [
                    'machine' => $machine,
                    'notes' => 'Called as next patient via Call Next button',
                ]);

                $phoneResult = executeAndFetchOne($pdo, "SELECT p.mobile, p.country_code FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$nextPatient['id']]);
                if ($phoneResult && !empty($phoneResult['mobile'])) {
                    $international_phone = formatInternationalNumber($phoneResult['mobile'], $phoneResult['country_code'] ?? '+961');
                    $dept_name = ($department === 'lab') ? 'Laboratory' : 'Imaging';
                    $dept_name_ar = ($department === 'lab') ? 'المختبر' : 'الأشعة';
                    sendWhatsAppMessage($international_phone, 'call_queue', ['dept_en' => $dept_name, 'dept_ar' => $dept_name_ar]);
                }

                $_SESSION[$context['session_key']] = 'Next patient called successfully!';
            } else {
                $_SESSION[$context['session_key']] = 'No more patients waiting';
            }

            $response['success'] = true;
            $response['message'] = 'Call next processed';
            break;

        case 'wrong_info':
            $previousStatus = $current_status;
            executeUpdate($pdo, "UPDATE tickets SET current_status = 'Wrong Info', lab = 0, img = 0, dp2 = 0, imaging_machine = NULL WHERE ticket_id = ?", [$ticket_id]);

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Wrong Information', ?, 'Wrong Info', ?, ?, 'Patient has wrong information and returned to billing')";
            executeUpdate($pdo, $log_sql, [$ticket_id, $previousStatus, $machine ?: null, authCurrentUserId() ?: null]);
            patientActionAudit('ticket_wrong_info', $ticket_id, $department, $previousStatus, 'Wrong Info', [
                'machine' => $machine,
                'notes' => 'Patient has wrong information and returned to billing',
            ]);

            $phoneResult = executeAndFetchOne($pdo, "SELECT p.mobile, p.country_code FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$ticket_id]);
            if ($phoneResult && !empty($phoneResult['mobile'])) {
                $international_phone = formatInternationalNumber($phoneResult['mobile'], $phoneResult['country_code'] ?? '+961');
                sendWhatsAppMessage($international_phone, 'ticket_queue', ['status' => 'Wrong Information']);
            }

            $_SESSION[$context['session_key']] = 'Patient marked as wrong information and sent to billing';
            $response['success'] = true;
            $response['message'] = 'Patient marked as wrong information';
            break;

        case 'release_patient':
            $previousStatus = $current_status;
            executeUpdate($pdo, "UPDATE tickets SET current_status = 'Waiting' WHERE ticket_id = ?", [$ticket_id]);

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Released from Wrong Info', 'Wrong Info', 'Waiting', ?, 'Patient information corrected and released to waiting queue')";
            executeUpdate($pdo, $log_sql, [$ticket_id, authCurrentUserId() ?: null]);
            patientActionAudit('ticket_release_wrong_info', $ticket_id, $department, $previousStatus, 'Waiting', [
                'notes' => 'Patient information corrected and released to waiting queue',
            ]);

            $phoneResult = executeAndFetchOne($pdo, "SELECT p.mobile, p.country_code FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$ticket_id]);
            if ($phoneResult && !empty($phoneResult['mobile'])) {
                $international_phone = formatInternationalNumber($phoneResult['mobile'], $phoneResult['country_code'] ?? '+961');
                sendWhatsAppMessage($international_phone, 'ticket_queue', ['status' => 'Information Corrected']);
            }

            $_SESSION[$context['session_key']] = 'Patient released from wrong information status';
            $response['success'] = true;
            $response['message'] = 'Patient released successfully';
            break;

        default:
            $response['message'] = 'Invalid action';
    }
} catch (Exception $e) {
    $error_msg = 'Error: ' . $e->getMessage();
    $session_key = isset($context) ? $context['session_key'] : 'error_message';
    $_SESSION[$session_key] = $error_msg;
    $response['success'] = false;
    $response['message'] = $error_msg;
}

// If it's an AJAX request, return JSON
if ($is_ajax) {
    header('Content-Type: application/json');
    // Add console-visible debugging info with all WhatsApp URLs called
    $response['_debug_whatsapp_urls'] = $whatsapp_urls;
    echo json_encode($response);
    exit();
} else {
    // If it's a form submission, redirect back
    if ($department === 'imaging' && $machine) {
        header('Location: imaging.php?machine=' . urlencode($machine));
    } elseif ($department === 'clinics') {
        $clinic_param = isset($_POST['clinic']) ? urlencode($_POST['clinic']) : '';
        header('Location: clinics.php' . ($clinic_param ? '?clinic=' . $clinic_param : ''));
    } else {
        header('Location: ' . ($department === 'imaging' ? 'imaging.php' : 'laboratory.php'));
    }
    exit();
}

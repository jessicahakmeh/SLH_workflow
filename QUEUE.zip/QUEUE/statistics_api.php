<?php
// statistics_api.php - API endpoint for statistics dashboard
require_once 'config.php';
session_start();
authRequireRoles(['quality', 'admin'], ['log_view' => false]);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$input = file_get_contents('php://input');
if (empty($input)) {
    echo json_encode(['success' => false, 'message' => 'Empty request body']);
    exit;
}

$data = json_decode($input, true);
if ($data === null) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON format']);
    exit;
}

$action = $data['action'] ?? '';
if (empty($action)) {
    echo json_encode(['success' => false, 'message' => 'Action not specified']);
    exit;
}

try {
    switch ($action) {
        case 'get_patient_timeline':
            // Get patient info
                // Support both numeric ticket-id lookups and fallbacks by queue_number+mrn+arrival
                $patient_id_raw = $data['patient_id'] ?? null;

                $patient = false;
                $queue_number = trim((string)($data['queue_number'] ?? ''));
                $mrn = trim((string)($data['mrn'] ?? ''));
                $arrival_ts = trim((string)($data['arrival_ts'] ?? ''));

                if (!empty($patient_id_raw) && is_numeric($patient_id_raw) && intval($patient_id_raw) > 0) {
                    $patient_id = intval($patient_id_raw);
                    $patient = executeAndFetchOne($pdo, "SELECT t.ticket_id AS id, t.queue_number, p.patient_name, p.mrn, t.arrival_timestamp, t.approval_timestamp, t.closing_timestamp, t.current_status, t.service_type FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
                } else {
                    if (!empty($queue_number) && !empty($mrn)) {
                        if (!empty($arrival_ts)) {
                            $patient = executeAndFetchOne($pdo, "SELECT t.ticket_id AS id, t.queue_number, p.patient_name, p.mrn, t.arrival_timestamp, t.approval_timestamp, t.closing_timestamp, t.current_status, t.service_type FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.queue_number = ? AND p.mrn = ? AND DATE(t.arrival_timestamp) = DATE(?) LIMIT 1", [$queue_number, $mrn, $arrival_ts]);
                        }
                        if (!$patient) {
                            $patient = executeAndFetchOne($pdo, "SELECT t.ticket_id AS id, t.queue_number, p.patient_name, p.mrn, t.arrival_timestamp, t.approval_timestamp, t.closing_timestamp, t.current_status, t.service_type FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.queue_number = ? AND p.mrn = ? ORDER BY t.arrival_timestamp DESC LIMIT 1", [$queue_number, $mrn]);
                        }
                    } elseif (!empty($queue_number)) {
                        // Fallback for flows where MRN is not set yet.
                        if (!empty($arrival_ts)) {
                            $patient = executeAndFetchOne($pdo, "SELECT t.ticket_id AS id, t.queue_number, p.patient_name, p.mrn, t.arrival_timestamp, t.approval_timestamp, t.closing_timestamp, t.current_status, t.service_type FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.queue_number = ? AND DATE(t.arrival_timestamp) = DATE(?) ORDER BY t.arrival_timestamp DESC LIMIT 1", [$queue_number, $arrival_ts]);
                        }
                        if (!$patient) {
                            $patient = executeAndFetchOne($pdo, "SELECT t.ticket_id AS id, t.queue_number, p.patient_name, p.mrn, t.arrival_timestamp, t.approval_timestamp, t.closing_timestamp, t.current_status, t.service_type FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.queue_number = ? ORDER BY t.arrival_timestamp DESC LIMIT 1", [$queue_number]);
                        }
                    }
                }

                if (!$patient) {
                    throw new Exception('Patient not found for the provided timeline identifiers');
                }

                // Get all logs for this patient
                $logs = executeAndFetch($pdo, "
                    SELECT tl.id, tl.action, tl.from_status, tl.to_status, tl.notes, tl.created_at, tl.machine_type, tl.performed_by,
                            u.username AS performed_by_username,
                            u.full_name AS performed_by_full_name,
                            COALESCE(NULLIF(u.full_name, ''), NULLIF(u.username, ''), '') AS performed_by_label
                     FROM ticket_logs tl
                     LEFT JOIN users u ON u.id = tl.performed_by
                     WHERE tl.ticket_id = ?
                     ORDER BY tl.created_at ASC
                ", [$patient['id']]);

                // Get billing info (guard against negative durations)
                $billingInfo = executeAndFetchOne($pdo, "SELECT approval_timestamp, closing_timestamp, CASE WHEN approval_timestamp IS NOT NULL AND closing_timestamp IS NOT NULL AND closing_timestamp >= approval_timestamp THEN TIMESTAMPDIFF(MINUTE, approval_timestamp, closing_timestamp) ELSE NULL END as billing_time_minutes FROM tickets WHERE ticket_id = ?", [$patient['id']]);

                // Compute stage timings
                $stage_timings = [];
                $in_process_start = null;
                $in_process_end = null;
                $waiting_start = null;
                $first_served_call = null;
                $arrival_ts = strtotime($patient['arrival_timestamp']);

                foreach ($logs as $log) {
                    $ts = strtotime($log['created_at']);
                    $to_status = trim($log['to_status'] ?? '');
                    $from_status = trim($log['from_status'] ?? '');
                    $action = strtolower($log['action'] ?? '');
                    $notes = strtolower($log['notes'] ?? '');

                    if (!$in_process_start && strcasecmp($to_status, 'In Process') === 0) {
                        $in_process_start = $ts;
                    }
                    if ($in_process_start && !$in_process_end && strcasecmp($from_status, 'In Process') === 0) {
                        $in_process_end = $ts;
                    }
                    if (!$waiting_start && strcasecmp($to_status, 'Waiting') === 0) {
                        $waiting_start = $ts;
                    }
                    if (!$first_served_call && (strpos($action, 'call') !== false || strpos($notes, 'called') !== false)) {
                        $first_served_call = $ts;
                    }
                }

                if ($in_process_start) {
                    $stage_timings['arrival_to_billing_wait'] = max(0, round(($in_process_start - $arrival_ts) / 60, 1));
                }
                if ($in_process_start && $in_process_end) {
                    $stage_timings['in_process_duration'] = max(0, round(($in_process_end - $in_process_start) / 60, 1));
                }
                if ($in_process_end && $waiting_start) {
                    $stage_timings['billing_to_waiting_wait'] = max(0, round(($waiting_start - $in_process_end) / 60, 1));
                }
                if ($waiting_start && $first_served_call) {
                    $stage_timings['waiting_to_served_duration'] = max(0, round(($first_served_call - $waiting_start) / 60, 1));
                }

                echo json_encode([
                    'success' => true,
                    'patient' => $patient,
                    'logs' => $logs,
                    'billing_info' => $billingInfo,
                    'stage_timings' => $stage_timings
                ]);
                break;
        
        case 'get_skip_cancel_tickets':
            // Get all skipped and canceled tickets in a date range
            $start_date = $data['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $data['end_date'] ?? date('Y-m-d');
            $filter_type = $data['filter_type'] ?? 'skip'; // 'skip', 'cancel', or 'both'
            $end_date_inclusive = date('Y-m-d', strtotime($end_date . ' +1 day'));
            
            // Determine which statuses to include based on filterType ('skip', 'cancel', or 'both')
            $status_filter = $filter_type === 'both' ? "'Skipped','Canceled'" : 
                           ($filter_type === 'cancel' ? "'Canceled'" : "'Skipped'");
            
            // Use $status_filter in both the LEFT JOIN and WHERE clauses
            $records = executeAndFetch($pdo, "
                SELECT 
                    t.ticket_id AS id,
                    t.queue_number,
                    p.patient_name,
                    p.mrn,
                    p.mobile,
                    t.service_type,
                    t.current_status,
                    t.arrival_timestamp,
                    t.closing_timestamp,
                    TIMESTAMPDIFF(MINUTE, t.arrival_timestamp, NOW()) as wait_time,
                    tl.action,
                    tl.created_at as action_time,
                    tl.notes
                FROM tickets t
                JOIN patients p ON t.patient_id = p.patient_id
                LEFT JOIN ticket_logs tl ON t.ticket_id = tl.ticket_id AND tl.action IN ($status_filter)
                WHERE t.arrival_timestamp >= ? AND t.arrival_timestamp < ?
                AND t.current_status IN ($status_filter)
                ORDER BY t.arrival_timestamp DESC
            ", [$start_date . ' 00:00:00', $end_date_inclusive . ' 00:00:00']);
            
            echo json_encode([
                'success' => true,
                'data' => $records,
                'count' => count($records)
            ]);
            break;
        
        case 'get_billing_stats':
            // Get billing processing time statistics
            $start_date = $data['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $data['end_date'] ?? date('Y-m-d');
            $end_date_inclusive = date('Y-m-d', strtotime($end_date . ' +1 day'));
            
            $billingStats = executeAndFetchOne($pdo, "
                SELECT 
                    COUNT(*) as total_billing,
                    COUNT(CASE WHEN current_status IN ('Completed', 'Served') THEN 1 END) as completed,
                    COUNT(CASE WHEN current_status = 'Canceled' THEN 1 END) as canceled,
                    AVG(CASE 
                        WHEN approval_timestamp IS NOT NULL AND closing_timestamp IS NOT NULL AND closing_timestamp >= approval_timestamp
                        THEN TIMESTAMPDIFF(MINUTE, approval_timestamp, closing_timestamp)
                        ELSE NULL
                    END) as avg_processing_time,
                    MIN(CASE 
                        WHEN approval_timestamp IS NOT NULL AND closing_timestamp IS NOT NULL AND closing_timestamp >= approval_timestamp
                        THEN TIMESTAMPDIFF(MINUTE, approval_timestamp, closing_timestamp)
                        ELSE NULL
                    END) as min_processing_time,
                    MAX(CASE 
                        WHEN approval_timestamp IS NOT NULL AND closing_timestamp IS NOT NULL AND closing_timestamp >= approval_timestamp
                        THEN TIMESTAMPDIFF(MINUTE, approval_timestamp, closing_timestamp)
                        ELSE NULL
                    END) as max_processing_time
                FROM tickets
                WHERE approval_timestamp IS NOT NULL
                AND arrival_timestamp >= ? AND arrival_timestamp < ?
            ", [$start_date . ' 00:00:00', $end_date_inclusive . ' 00:00:00']);
            
            echo json_encode([
                'success' => true,
                'data' => $billingStats
            ]);
            break;
        
        default:
            throw new Exception('Unknown action: ' . $action);
        
        case 'export_excel':
            header('Content-Type: application/json');
            // Export MERGED patient records (1 logical patient = 1 row) with stage timings
            $start_date = $data['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $data['end_date'] ?? date('Y-m-d');
            $end_date_inclusive = date('Y-m-d', strtotime($end_date . ' +1 day'));
            
            // Grouped query to fetch logical patients
            $groupQuery = "SELECT t.queue_number, p.mrn, MIN(t.arrival_timestamp) as arrival_ts, MAX(t.closing_timestamp) as last_closing, MIN(t.approval_timestamp) as first_approval, GROUP_CONCAT(DISTINCT p.patient_name SEPARATOR '; ') as patient_names, GROUP_CONCAT(DISTINCT t.service_type SEPARATOR '; ') as service_types, GROUP_CONCAT(DISTINCT t.current_status SEPARATOR '; ') as statuses, GROUP_CONCAT(DISTINCT p.mobile SEPARATOR '; ') as mobiles, GROUP_CONCAT(DISTINCT p.email SEPARATOR '; ') as emails, MIN(COALESCE(t.lab_call_time, t.imaging_call_time)) as first_call_time, COUNT(*) as ticket_count FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.arrival_timestamp >= ? AND t.arrival_timestamp < ? GROUP BY t.queue_number, DATE(t.arrival_timestamp), p.mrn ORDER BY t.arrival_timestamp DESC";
            
            $mergedRecords = executeAndFetch($pdo, $groupQuery, [$start_date . ' 00:00:00', $end_date_inclusive . ' 00:00:00']);
            
            $exportData = [];
            
            foreach ($mergedRecords as $record) {
                $allTickets = executeAndFetch($pdo, "SELECT t.ticket_id AS id FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.queue_number = ? AND DATE(t.arrival_timestamp) = ? AND p.mrn = ? ORDER BY t.arrival_timestamp ASC", [$record['queue_number'], date('Y-m-d', strtotime($record['arrival_ts'])), $record['mrn']]);
                
                $stage_arrivals_to_billing = [];
                $stage_in_process = [];
                $stage_billing_to_waiting = [];
                $stage_waiting_to_served = [];
                
                $arrival_ts = strtotime($record['arrival_ts']);
                
                foreach ($allTickets as $ticket) {
                    $logs = executeAndFetch($pdo, "SELECT created_at, action, from_status, to_status, notes FROM ticket_logs WHERE ticket_id = ? ORDER BY created_at ASC", [$ticket['id']]);
                    
                    $in_process_start = null;
                    $in_process_end = null;
                    $waiting_start = null;
                    $first_served_call = null;
                    
                    foreach ($logs as $log) {
                        $ts = strtotime($log['created_at']);
                        if (!$in_process_start && strcasecmp(trim($log['to_status'] ?? ''), 'In Process') === 0) {
                            $in_process_start = $ts;
                        }
                        if ($in_process_start && !$in_process_end && strcasecmp(trim($log['from_status'] ?? ''), 'In Process') === 0) {
                            $in_process_end = $ts;
                        }
                        if (!$waiting_start && strcasecmp(trim($log['to_status'] ?? ''), 'Waiting') === 0) {
                            $waiting_start = $ts;
                        }
                        // Check for first served call (action contains 'call' OR notes contains 'called')
                        if (!$first_served_call) {
                            $action = strtolower($log['action'] ?? '');
                            $notes = strtolower($log['notes'] ?? '');
                            if (strpos($action, 'call') !== false || strpos($notes, 'called') !== false) {
                                $first_served_call = $ts;
                            }
                        }
                    }
                    
                    if ($in_process_start) $stage_arrivals_to_billing[] = max(0, round(($in_process_start - $arrival_ts) / 60, 1));
                    if ($in_process_start && $in_process_end) $stage_in_process[] = max(0, round(($in_process_end - $in_process_start) / 60, 1));
                    if ($waiting_start && $first_served_call) $stage_waiting_to_served[] = max(0, round(($first_served_call - $waiting_start) / 60, 1));
                }
                
                // Calculate wait time (arrival to first call)
                $wait_time_mins = null;
                if ($record['arrival_ts'] && $record['first_call_time']) {
                    $wait_time_mins = round((strtotime($record['first_call_time']) - strtotime($record['arrival_ts'])) / 60, 2);
                }
                
                $exportData[] = [
                    'Queue' => $record['queue_number'],
                    'Patients' => $record['patient_names'],
                    'MRN' => $record['mrn'] ?? '',
                    'Mobiles' => $record['mobiles'] ?? '',
                    'Services' => $record['service_types'],
                    'Statuses' => $record['statuses'],
                    'Tickets' => $record['ticket_count'],
                    'Arrival' => $record['arrival_ts'],
                    'First Call' => $record['first_call_time'] ? date('Y-m-d H:i:s', strtotime($record['first_call_time'])) : 'N/A',
                    'Wait Time (min)' => $wait_time_mins ?? '-',
                    'Billing Start' => $record['first_approval'] ?? 'N/A',
                    'Closed' => $record['last_closing'] ?? 'Pending',
                    'Arrival to Processing (min)' => count($stage_arrivals_to_billing) > 0 ? round(array_sum($stage_arrivals_to_billing) / count($stage_arrivals_to_billing), 2) : '-',
                    'In-Process Time (min)' => count($stage_in_process) > 0 ? round(array_sum($stage_in_process) / count($stage_in_process), 2) : '-',
                    'Waiting to Served (min)' => count($stage_waiting_to_served) > 0 ? round(array_sum($stage_waiting_to_served) / count($stage_waiting_to_served), 2) : '-'
                ];
            }
            
            echo json_encode([
                'success' => true,
                'data' => $exportData,
                'filename' => 'patient-records-merged-' . $start_date . '-to-' . $end_date . '.xlsx'
            ]);
            exit;

        case 'get_offender_detail':
            $queue_number = $data['queue_number'] ?? '';
            $mrn = $data['mrn'] ?? '';
            $start_date = $data['start_date'] ?? '';
            $end_date = $data['end_date'] ?? '';
            
            if (empty($queue_number) || empty($mrn)) {
                throw new Exception('Queue number and MRN are required');
            }
            
            // Parse dates
            $startTs = strtotime($start_date . ' 00:00:00');
            $endTs = strtotime($end_date . ' 23:59:59');
            
            // Get all tickets for this logical patient group
            $tickets = executeAndFetch($pdo, "
                                SELECT t.ticket_id AS id, t.queue_number, p.mrn, t.arrival_timestamp, t.imaging_call_time, 
                                             t.lab_call_time, t.closing_timestamp, t.imaging_machine, t.current_status
                                FROM tickets t
                                JOIN patients p ON t.patient_id = p.patient_id
                                WHERE t.queue_number = ? 
                                    AND p.mrn = ?
                                    AND DATE(t.arrival_timestamp) BETWEEN DATE(?) AND DATE(?)
                                ORDER BY t.arrival_timestamp ASC
            ", [$queue_number, $mrn, $start_date, $end_date]);
            
            if (!$tickets) {
                throw new Exception('No tickets found for this patient');
            }
            
            // Build inter-test wait breakdown
            $inter_test_waits = [];
            for ($i = 0; $i < count($tickets) - 1; $i++) {
                $current_ticket = $tickets[$i];
                $next_ticket = $tickets[$i + 1];
                
                // Get call time for current ticket (prefer imaging > lab > null)
                $current_call = $current_ticket['imaging_call_time'] ?? $current_ticket['lab_call_time'];
                $next_call = $next_ticket['imaging_call_time'] ?? $next_ticket['lab_call_time'];
                
                if ($current_ticket['closing_timestamp'] && $next_call) {
                    $closing_time = strtotime($current_ticket['closing_timestamp']);
                    $next_call_time = strtotime($next_call);
                    $wait_seconds = max(0, $next_call_time - $closing_time);
                    $wait_minutes = round($wait_seconds / 60, 1);
                    
                    $inter_test_waits[] = [
                        'from_machine' => $current_ticket['imaging_machine'] ?? 'Lab',
                        'to_machine' => $next_ticket['imaging_machine'] ?? 'Lab',
                        'wait_minutes' => $wait_minutes
                    ];
                }
            }
            
            echo json_encode([
                'success' => true,
                'data' => [
                    'queue_number' => $queue_number,
                    'mrn' => $mrn,
                    'tickets' => $tickets,
                    'inter_test_waits' => $inter_test_waits
                ]
            ]);
            exit;
        
        case 'get_billing_extremes':
            // Get records with max or min processing time
            $start_date = $data['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $data['end_date'] ?? date('Y-m-d');
            $extreme_type = $data['type'] ?? 'max'; // 'max' or 'min'
            $end_date_inclusive = date('Y-m-d', strtotime($end_date . ' +1 day'));
            
            $order_dir = ($extreme_type === 'max') ? 'DESC' : 'ASC';
            
            $records = executeAndFetch($pdo, "
                SELECT 
                    t.ticket_id AS id,
                    t.queue_number,
                    p.patient_name,
                    p.mrn,
                    t.approval_timestamp,
                    t.closing_timestamp,
                    TIMESTAMPDIFF(MINUTE, t.approval_timestamp, t.closing_timestamp) as processing_time_minutes,
                    t.current_status
                FROM tickets t
                JOIN patients p ON t.patient_id = p.patient_id
                WHERE t.approval_timestamp IS NOT NULL 
                AND t.closing_timestamp IS NOT NULL 
                AND t.closing_timestamp >= t.approval_timestamp
                AND t.arrival_timestamp >= ? AND t.arrival_timestamp < ?
                ORDER BY processing_time_minutes $order_dir
                LIMIT 20
            ", [$start_date . ' 00:00:00', $end_date_inclusive . ' 00:00:00']);
            
            echo json_encode([
                'success' => true,
                'data' => $records,
                'type' => $extreme_type
            ]);
            exit;
        
        // Find tickets by MRN (simple helper for timeline selection)
        case 'find_tickets':
            $mrn = $data['mrn'] ?? '';
            if (empty($mrn)) {
                throw new Exception('MRN required');
            }

            $tickets = executeAndFetch($pdo, "SELECT t.ticket_id AS id, t.queue_number, p.mrn, t.arrival_timestamp FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE p.mrn = ? ORDER BY t.arrival_timestamp DESC LIMIT 50", [$mrn]);

            echo json_encode(['success' => true, 'tickets' => $tickets]);
            exit;

        case 'get_patient_by_mrn':
            $mrn = $data['mrn'] ?? '';
            $start_date = $data['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $end_date = $data['end_date'] ?? date('Y-m-d');
            
            if (empty($mrn)) {
                throw new Exception('MRN required');
            }

            // Add one day to end_date to include the entire end date
            $end_date_inclusive = date('Y-m-d', strtotime($end_date . ' +1 day'));

            // Get patient info
            $patient = executeAndFetchOne($pdo, "SELECT patient_id, mrn, patient_name FROM patients WHERE mrn = ?", [$mrn]);
            
            if (!$patient) {
                throw new Exception('Patient not found');
            }

            // Get all tickets for this patient in the date range
            $tickets = executeAndFetch($pdo, "
                SELECT 
                    ticket_id AS id,
                    queue_number,
                    service_type,
                    arrival_timestamp,
                    first_call_timestamp,
                    closing_timestamp,
                    current_status AS status,
                    (SELECT GROUP_CONCAT(DISTINCT department_name ORDER BY department_name SEPARATOR ', ') 
                     FROM ticket_machines tm 
                     JOIN machines m ON tm.machine_id = m.machine_id 
                     WHERE tm.ticket_id = t.ticket_id) AS department,
                    TIMESTAMPDIFF(MINUTE, arrival_timestamp, COALESCE(first_call_timestamp, closing_timestamp)) AS wait_minutes
                FROM tickets t
                WHERE patient_id = ? 
                    AND arrival_timestamp >= ?
                    AND arrival_timestamp < ?
                ORDER BY arrival_timestamp DESC
            ", [$patient['patient_id'], $start_date, $end_date_inclusive]);

            // Ensure $tickets is always an array
            if (!is_array($tickets)) {
                $tickets = [];
            }

            echo json_encode([
                'success' => true,
                'data' => [
                    'patient_name' => $patient['patient_name'],
                    'mrn' => $patient['mrn'],
                    'tickets' => $tickets
                ]
            ]);
            exit;
    }
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>

<?php
// imaging_stats.php
require_once 'config.php';
session_start();
authRequireRoles(['imaging', 'admin'], ['log_view' => false]);

$machine = $_GET['machine'] ?? "";

// Get counts for this machine
$query = "
    SELECT 
        COUNT(CASE WHEN current_status = 'TO IMAGING' THEN 1 END) as waiting,
        COUNT(CASE WHEN current_status IN ('Called', 'Recalled') THEN 1 END) as called,
        COUNT(CASE WHEN current_status = 'In Process' THEN 1 END) as in_process,
        COUNT(CASE WHEN current_status = 'Skipped' THEN 1 END) as skipped,
        COUNT(*) as total
    FROM patients
    WHERE imaging_machine = ?
    AND closing_timestamp IS NULL
    AND DATE(arrival_timestamp) = CURDATE()
";

$stats = executeAndFetchOne($pdo, $query, [$machine]);
?>

<div class="stat-card" style="border-top-color: #3498db;">
    <div class="stat-number"><?php echo $stats['total']; ?></div>
    <div class="stat-label">Total</div>
</div>

<div class="stat-card" style="border-top-color: #27ae60;">
    <div class="stat-number"><?php echo $stats['waiting']; ?></div>
    <div class="stat-label">Waiting</div>
</div>

<div class="stat-card" style="border-top-color: #f39c12;">
    <div class="stat-number"><?php echo $stats['called']; ?></div>
    <div class="stat-label">Called</div>
</div>

<div class="stat-card" style="border-top-color: #9b59b6;">
    <div class="stat-number"><?php echo $stats['in_process']; ?></div>
    <div class="stat-label">In Process</div>
</div>
<?php
require_once 'config.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (!authIsEnabled()) {
    header('Location: stream.php');
    exit;
}

if (authCurrentUser()) {
    session_write_close();
    header('Location: ' . authDefaultLandingPage());
    exit;
}

$error = '';
$returnTo = authSanitizeReturnTo($_GET['return_to'] ?? $_POST['return_to'] ?? '');
$adEnabled = defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED;
$adNetbios = $adEnabled && defined('AUTH_AD_NETBIOS') ? trim((string)AUTH_AD_NETBIOS) : '';
$adPrefix = $adNetbios !== '' ? $adNetbios . '\\' : '';
$usernameInputValue = $adPrefix;
$adDiagnostics = $adEnabled ? authGetAdDiagnostics() : null;
$showConnectionTools = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $usernameInputValue = $username;
    $password = (string)($_POST['password'] ?? '');

    if ($adEnabled && isset($_POST['ad_debug_test'])) {
        $adDiagnostics = authGetAdDiagnostics($username, $password);
        $showConnectionTools = true;
    } else {
        if (authLoginUser($username, $password, $error)) {
            $target = $returnTo !== '' ? $returnTo : authDefaultLandingPage();
            session_write_close();
            header('Location: ' . $target);
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body{margin:0;font-family:Segoe UI,Tahoma,sans-serif;background:linear-gradient(135deg,#e7eef7,#f8fafc);color:#17212f}
        .wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
        .card{width:min(420px,100%);background:#fff;border-radius:18px;padding:28px;box-shadow:0 24px 64px rgba(23,33,47,.14)}
        h1{margin:0 0 8px;font-size:28px}
        .muted{color:#607086;margin:0 0 20px}
        .error{background:#fde7e7;color:#a12626;padding:12px 14px;border-radius:10px;margin-bottom:16px}
        label{display:block;font-weight:600;margin:14px 0 6px}
        input{width:100%;box-sizing:border-box;padding:12px 14px;border:1px solid #c9d3e1;border-radius:10px;font-size:15px}
        button{width:100%;margin-top:18px;border:0;border-radius:10px;background:#0b66c3;color:#fff;padding:12px 14px;font-size:15px;font-weight:700;cursor:pointer}
        .hint{margin-top:16px;font-size:13px;color:#607086}
        .pill{display:inline-block;padding:4px 8px;background:#eef5ff;color:#0b66c3;border-radius:999px;font-size:12px;font-weight:700}
        .conn-tools{margin-top:14px;border:1px solid #dbe4ef;border-radius:10px;background:#fbfcfe}
        .conn-tools summary{list-style:none;cursor:pointer;padding:8px 10px;font-size:12px;font-weight:700;color:#455468;display:flex;align-items:center;justify-content:space-between}
        .conn-tools summary::-webkit-details-marker{display:none}
        .conn-tools summary::after{content:'>';font-size:11px;color:#607086;transition:transform .15s ease}
        .conn-tools[open] summary::after{transform:rotate(90deg)}
        .conn-tools-body{padding:0 10px 10px}
        .ad-debug-card{margin-top:8px;padding:10px;border:1px solid #d5e7db;background:#f7fcf9;border-radius:10px}
        .ad-debug-title{font-size:13px;font-weight:700;color:#1f6f43;margin-bottom:8px}
        .ad-debug-status{font-size:12px;color:#455468;margin:6px 0}
        .ad-debug-list{margin:8px 0 0 16px;padding:0;font-size:12px;color:#a12626}
        .ad-debug-list li{margin:3px 0}
        .btn-debug{background:#1f6f43;margin-top:8px;padding:9px 12px;font-size:13px;border-radius:8px}
        .ok{color:#1f6f43;font-weight:700}
        .warn{color:#a12626;font-weight:700}
    </style>
</head>
<body>
<div class="wrap">
    <form class="card" method="post" action="login.php">
        <div>
            <span class="pill">Queue System</span>
        </div>
        <h1>Sign In</h1>
        <p class="muted"><?php echo $adEnabled ? 'Use stlouis\\username for AD login, or .\\username to force local login.' : 'Use your local app account.'; ?></p>
        <?php if ($error !== ''): ?>
            <div class="error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
        <input type="hidden" name="return_to" value="<?php echo htmlspecialchars($returnTo, ENT_QUOTES, 'UTF-8'); ?>">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" autocomplete="username" value="<?php echo htmlspecialchars((string)$usernameInputValue, ENT_QUOTES, 'UTF-8'); ?>" placeholder="<?php echo $adEnabled ? 'stlouis\\username or .\\username' : 'username'; ?>" required>
        <label for="password">Password</label>
        <input type="password" id="password" name="password" autocomplete="current-password" placeholder="<?php echo $adEnabled ? 'Active Directory password' : ''; ?>" required>
        <button type="submit">Login</button>
        <?php if ($adEnabled): ?>
            <details class="conn-tools"<?php echo $showConnectionTools ? ' open' : ''; ?>>
                <summary>Connection Test</summary>
                <div class="conn-tools-body">
                    <button type="submit" name="ad_debug_test" value="1" class="btn-debug">Test AD Connection</button>
                    <div class="ad-debug-card">
                        <div class="ad-debug-title">Active Directory Diagnostics</div>
                        <div class="ad-debug-status">Overall: <span class="<?php echo !empty($adDiagnostics['ok']) ? 'ok' : 'warn'; ?>"><?php echo !empty($adDiagnostics['ok']) ? 'OK' : 'Missing/Failing Checks'; ?></span></div>
                        <div class="ad-debug-status">LDAP extension: <span class="<?php echo !empty($adDiagnostics['checks']['ldap_extension']) ? 'ok' : 'warn'; ?>"><?php echo !empty($adDiagnostics['checks']['ldap_extension']) ? 'Loaded' : 'Missing'; ?></span></div>
                        <div class="ad-debug-status">AD server config: <span class="<?php echo !empty($adDiagnostics['checks']['ad_server_configured']) ? 'ok' : 'warn'; ?>"><?php echo !empty($adDiagnostics['checks']['ad_server_configured']) ? 'Configured' : 'Missing'; ?></span></div>
                        <div class="ad-debug-status">AD server reachable: <span class="<?php echo !empty($adDiagnostics['checks']['ad_server_reachable']) ? 'ok' : 'warn'; ?>"><?php echo !empty($adDiagnostics['checks']['ad_server_reachable']) ? 'Yes' : 'No'; ?></span></div>
                        <?php if (!empty($adDiagnostics['bind_test']['attempted'])): ?>
                            <div class="ad-debug-status">Credential bind test (<strong><?php echo htmlspecialchars((string)($adDiagnostics['bind_test']['bind_username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></strong>):
                                <span class="<?php echo !empty($adDiagnostics['bind_test']['success']) ? 'ok' : 'warn'; ?>"><?php echo !empty($adDiagnostics['bind_test']['success']) ? 'Success' : 'Failed'; ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($adDiagnostics['missing']) && is_array($adDiagnostics['missing'])): ?>
                            <ul class="ad-debug-list">
                                <?php foreach ($adDiagnostics['missing'] as $item): ?>
                                    <li><?php echo htmlspecialchars((string)$item, ENT_QUOTES, 'UTF-8'); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </details>
        <?php endif; ?>
        <div class="hint"><?php echo $adEnabled ? 'If AD auth fails, the system also checks local credentials for active users with assigned roles.' : 'Use your configured local account.'; ?></div>
    </form>
</div>
<?php if ($adEnabled && $adPrefix !== ''): ?>
<script>
(function () {
    const usernameInput = document.getElementById('username');
    const prefix = <?php echo json_encode($adPrefix); ?>;
    if (!usernameInput || !prefix) {
        return;
    }

    function applyPrefixIfNeeded() {
        const current = usernameInput.value || '';
        if (current === '') {
            usernameInput.value = prefix;
            return;
        }
        if (current.indexOf('\\') === -1 && current.indexOf('@') === -1) {
            usernameInput.value = prefix + current;
        }
    }

    usernameInput.addEventListener('blur', applyPrefixIfNeeded);
    if ((usernameInput.value || '') === '') {
        usernameInput.value = prefix;
    }
})();
</script>
<?php endif; ?>
</body>
</html>

<?php
// undo_button.php - Reusable undo button component
?>

<!-- Undo Button UI (initially hidden) -->
<div class="undo-toast" id="undoToast" style="display: none;">
    <div class="undo-toast-content">
        <span class="undo-message">
            <i class="fas fa-undo"></i>
            <span id="undoMessage">Action undone</span>
        </span>
        <div class="undo-actions">
            <button class="undo-btn" id="undoButton">
                <i class="fas fa-undo-alt"></i> Undo
            </button>
            <span class="undo-timer" id="undoTimer">10s</span>
            <button class="undo-dismiss" id="undoDismiss" title="Dismiss">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
</div>

<style>
    .undo-toast {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: white;
        border-left: 4px solid #3498db;
        border-radius: 6px;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        padding: 15px 20px;
        z-index: 9999;
        animation: slideInUp 0.3s ease;
        max-width: 450px;
    }

    @keyframes slideInUp {
        from {
            transform: translateY(100px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .undo-toast-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 15px;
    }

    .undo-message {
        display: flex;
        align-items: center;
        gap: 10px;
        color: #2c3e50;
        font-weight: 500;
        font-size: 14px;
    }

    .undo-message i {
        color: #3498db;
        font-size: 16px;
    }

    .undo-actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .undo-btn {
        background: #3498db;
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 600;
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 5px;
        white-space: nowrap;
    }

    .undo-btn:hover {
        background: #2980b9;
        transform: translateY(-2px);
        box-shadow: 0 3px 10px rgba(52, 152, 219, 0.3);
    }

    .undo-timer {
        color: #7f8c8d;
        font-size: 13px;
        font-weight: 600;
        min-width: 25px;
        text-align: center;
    }

    .undo-dismiss {
        background: none;
        border: none;
        color: #95a5a6;
        cursor: pointer;
        font-size: 16px;
        padding: 0;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.3s;
    }

    .undo-dismiss:hover {
        color: #e74c3c;
    }

    @media (max-width: 768px) {
        .undo-toast {
            bottom: 10px;
            right: 10px;
            left: 10px;
            max-width: none;
        }

        .undo-toast-content {
            flex-wrap: wrap;
        }

        .undo-message {
            flex: 1;
            min-width: 200px;
        }

        .undo-actions {
            width: 100%;
        }

        .undo-btn {
            flex: 1;
        }
    }
</style>

<script>
    // Store undo state
    let undoTimeout = null;
    let undoCountdown = null;

    /**
     * Show undo button for 10 seconds
     * @param {string} actionDescription - What action was performed
     * @param {string} previousStatus - Previous status for display
     */
    function showUndoButton(actionDescription = 'Last action') {
        const undoToast = document.getElementById('undoToast');
        const undoMessage = document.getElementById('undoMessage');
        const undoTimer = document.getElementById('undoTimer');
        const undoButton = document.getElementById('undoButton');
        const undoDismiss = document.getElementById('undoDismiss');

        // Update message
        undoMessage.textContent = actionDescription;

        // Show toast
        undoToast.style.display = 'block';

        // Clear previous timeout
        if (undoTimeout) clearTimeout(undoTimeout);
        if (undoCountdown) clearInterval(undoCountdown);

        // Set countdown timer
        let secondsLeft = 10;
        undoTimer.textContent = secondsLeft + 's';

        undoCountdown = setInterval(() => {
            secondsLeft--;
            undoTimer.textContent = secondsLeft + 's';

            if (secondsLeft <= 0) {
                clearInterval(undoCountdown);
                hideUndoButton();
            }
        }, 1000);

        // Auto-hide after 10 seconds
        undoTimeout = setTimeout(() => {
            hideUndoButton();
        }, 10000);

        // Handle undo button click
        undoButton.onclick = performUndo;

        // Handle dismiss button click
        undoDismiss.onclick = hideUndoButton;
    }

    /**
     * Hide the undo button
     */
    function hideUndoButton() {
        const undoToast = document.getElementById('undoToast');
        undoToast.style.display = 'none';

        if (undoTimeout) clearTimeout(undoTimeout);
        if (undoCountdown) clearInterval(undoCountdown);
    }

    /**
     * Perform the undo action via AJAX
     */
    function performUndo() {
        const undoButton = document.getElementById('undoButton');
        const originalText = undoButton.innerHTML;

        // Disable button and show loading state
        undoButton.disabled = true;
        undoButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Undoing...';

        fetch('undo.php', {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                undoButton.innerHTML = '<i class="fas fa-check"></i> Undone!';
                undoButton.style.background = '#27ae60';

                // Refresh the page after 1.5 seconds (prefer smartReload)
                setTimeout(() => {
                    if (window.smartReload) window.smartReload(0); else window.location.reload();
                }, 1500);
            } else {
                alert('Error: ' + data.message);
                undoButton.innerHTML = originalText;
                undoButton.disabled = false;
            }
        })
        .catch(error => {
            console.error('Undo error:', error);
            alert('Error undoing action');
            undoButton.innerHTML = originalText;
            undoButton.disabled = false;
        });
    }
</script>

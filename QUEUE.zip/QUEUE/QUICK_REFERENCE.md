# Connection Pooling Quick Reference

## One-Page Migration Guide

### The Problem
```
Connection failed: SQLSTATE[08004] [1040] Too many connections
```
**Root Cause:** Prepared statements never closed, connections accumulate.

---

## Solution: Use Wrapper Functions

### Pattern 1: SELECT Multiple Rows
```php
// ❌ OLD - Connection leak
$stmt = $pdo->prepare("SELECT * FROM tickets WHERE status = ?");
$stmt->execute(['Waiting']);
$tickets = $stmt->fetchAll();

// ✅ NEW - Auto cleanup
$tickets = executeAndFetch($pdo, "SELECT * FROM tickets WHERE status = ?", ['Waiting']);
```

### Pattern 2: SELECT Single Row
```php
// ❌ OLD - Connection leak
$stmt = $pdo->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->execute([$id]);
$patient = $stmt->fetch();

// ✅ NEW - Auto cleanup
$patient = executeAndFetchOne($pdo, "SELECT * FROM patients WHERE id = ?", [$id]);
```

### Pattern 3: INSERT/UPDATE/DELETE
```php
// ❌ OLD - Connection leak
$stmt = $pdo->prepare("INSERT INTO tickets (patient_id, queue_number) VALUES (?, ?)");
$stmt->execute([$patientId, $queueNum]);

// ✅ NEW - Auto cleanup
$success = executeUpdate($pdo, 
    "INSERT INTO tickets (patient_id, queue_number) VALUES (?, ?)", 
    [$patientId, $queueNum]
);
```

### Pattern 4: If You Need Direct Control
```php
// ✅ ACCEPTABLE - Manual cleanup
$stmt = $pdo->prepare("SELECT * FROM patients");
$stmt->execute();
$patients = $stmt->fetchAll();
closeStatement($stmt);  // IMPORTANT: Always clean up!
$stmt = null;
```

---

## Usage Reference Table

| Operation | Function | Example |
|-----------|----------|---------|
| **SELECT All** | `executeAndFetch()` | `executeAndFetch($pdo, "SELECT * FROM t WHERE x = ?", [1])` |
| **SELECT One** | `executeAndFetchOne()` | `executeAndFetchOne($pdo, "SELECT * FROM t WHERE id = ?", [1])` |
| **INSERT** | `executeUpdate()` | `executeUpdate($pdo, "INSERT INTO t (a,b) VALUES (?,?)", [1,2])` |
| **UPDATE** | `executeUpdate()` | `executeUpdate($pdo, "UPDATE t SET a = ? WHERE id = ?", [1,2])` |
| **DELETE** | `executeUpdate()` | `executeUpdate($pdo, "DELETE FROM t WHERE id = ?", [1])` |
| **Manual Cleanup** | `closeStatement()` | `closeStatement($stmt); $stmt = null;` |

---

## Before/After Examples

### Real Example: Stream Update
```php
// ========== BEFORE (Connection Leak) ==========
function getStreamPatients($pdo, $stream) {
    $query = "SELECT t.ticket_id, p.patient_name, t.current_status 
              FROM tickets t JOIN patients p ON t.patient_id = p.patient_id 
              WHERE t.img = 1";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll();
    // ⚠️ Statement never closed! Connection held in pool.
}

// ========== AFTER (Proper Cleanup) ==========
function getStreamPatients($pdo, $stream) {
    return executeAndFetch(
        $pdo,
        "SELECT t.ticket_id, p.patient_name, t.current_status 
         FROM tickets t JOIN patients p ON t.patient_id = p.patient_id 
         WHERE t.img = 1"
    );
    // ✅ Statement auto-closed. Connection returned to pool.
}
```

### Real Example: Status Update
```php
// ========== BEFORE (Connection Leak) ==========
$stmt = $pdo->prepare("UPDATE tickets SET current_status = ? WHERE ticket_id = ?");
$stmt->execute(['Completed', $ticketId]);
// ⚠️ Connection held indefinitely

// ========== AFTER (Proper Cleanup) ==========
executeUpdate($pdo, 
    "UPDATE tickets SET current_status = ? WHERE ticket_id = ?", 
    ['Completed', $ticketId]
);
// ✅ Connection freed immediately
```

---

## Common Mistakes ❌

### Mistake 1: Forgetting to Close Statement
```php
// ❌ WRONG
$stmt = $pdo->prepare("SELECT * FROM table");
$stmt->execute();
return $stmt->fetchAll();
// Statement never closed! Use executeAndFetch() instead.

// ✅ RIGHT
return executeAndFetch($pdo, "SELECT * FROM table");
```

### Mistake 2: Using Direct Queries (no parameters)
```php
// ❌ STILL HAS ISSUES
$result = $pdo->query("SELECT * FROM table");
// Direct query, but statement not closed
foreach ($result as $row) { ... }

// ✅ BETTER
$rows = executeAndFetch($pdo, "SELECT * FROM table");
foreach ($rows as $row) { ... }
```

### Mistake 3: Multiple Statements Without Cleanup
```php
// ❌ WRONG - Connections accumulate
$s1 = $pdo->prepare("SELECT * FROM a");
$s1->execute();
$s2 = $pdo->prepare("SELECT * FROM b");
$s2->execute();
// Now 2 connections held!

// ✅ RIGHT
$a_data = executeAndFetch($pdo, "SELECT * FROM a");
$b_data = executeAndFetch($pdo, "SELECT * FROM b");
// Both cleaned up immediately
```

---

## File Update Priority

### CRITICAL (Do First!)
- `check_updates.php` - Called every 5 seconds
- `stream.php` - Real-time updates
- `statistics_api.php` - Dashboard polling

### HIGH (Do Next)
- `billing.php` - High volume operations
- `laboratory.php` - Lab workflow
- `imaging.php` - Imaging assignments

### MEDIUM (Then These)
- `clinics.php`, `scan_docs.php`, `new_ticket.php`, etc.

### LOW (Finally)
- `administration.php`, `user_management.php`, etc.

---

## Testing Your Changes

```php
// Quick test to verify wrapper functions work
$test = executeAndFetchOne($pdo, "SELECT 1 as test");
if ($test && $test['test'] == 1) {
    echo "✓ Wrapper functions working correctly";
} else {
    echo "✗ Error with wrapper functions";
}
```

---

## Monitoring Connection Pool

### In MySQL:
```sql
-- Check active connections
SHOW PROCESSLIST;

-- Count connections
SHOW STATUS LIKE 'Threads_connected';

-- View max allowed
SHOW VARIABLES LIKE 'max_connections';
```

### In PHP:
```php
$result = $pdo->query("SHOW PROCESSLIST");
$count = count($result->fetchAll());
echo "Current connections: $count";
```

---

## FAQs

**Q: Can I still use prepared statements directly?**
A: Yes, but manually call `closeStatement($stmt)` after use. Wrapper functions are preferred.

**Q: Will this break existing code?**
A: No, wrapper functions return the same data format. Results are identical.

**Q: What if I need advanced options like fetch mode?**
A: Wrapper functions use default fetch mode (PDO::FETCH_ASSOC). For custom modes, use:
```php
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$result = $stmt->fetchAll(PDO::FETCH_COLUMN); // Custom fetch mode
closeStatement($stmt);
```

**Q: How much improvement will this give?**
A: Expected reduction in "Too many connections" errors by 70-90% depending on usage patterns.

---

## Quick Checklist

- [ ] Updated config.php with new functions
- [ ] Read CONNECTION_POOLING_GUIDE.md
- [ ] Identified high-traffic files
- [ ] Migrated check_updates.php
- [ ] Migrated stream.php
- [ ] Tested with production-like load
- [ ] Verified MySQL connection count < 50
- [ ] Checked error logs for SQL issues
- [ ] Deployed to staging first
- [ ] Monitored production for 24 hours

---

**Last Updated:** 2026-08-22

<?php
// Lightweight monitoring endpoint
require_once __DIR__ . '/lib/monitoring.php';

// Basic auth optional - disable by default
if (defined('MONITOR_BASIC_USER') && defined('MONITOR_BASIC_PASS')) {
    if (!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER'] !== MONITOR_BASIC_USER || $_SERVER['PHP_AUTH_PW'] !== MONITOR_BASIC_PASS) {
        header('WWW-Authenticate: Basic realm="Monitoring"');
        header('HTTP/1.0 401 Unauthorized');
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
}

$metrics = get_monitoring_snapshot();

// Tail last 200 lines of monitor.log
$log = '';
$logfile = MONITOR_LOG;
if (file_exists($logfile)) {
    $lines = @file($logfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines !== false) {
        $last = array_slice($lines, -200);
        $log = implode("\n", $last);
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'metrics' => $metrics,
    'log_tail' => $log,
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

?>
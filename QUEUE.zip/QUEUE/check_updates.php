<?php
require_once 'config.php';
session_start();
authRequireRoles([], ['log_view' => false]);
session_write_close();

// Check for relevant changes in the last 5 seconds (reduced from 10 for better responsiveness)
$cutoff = date('Y-m-d H:i:s', time() - 5);

// Single efficient query to check for changes that affect billing/butler interfaces
$changeRecord = executeAndFetchOne($pdo, "
    SELECT 1 as has_changes
    FROM (
        -- Check for new patients arriving today
        SELECT 1 FROM tickets
        WHERE arrival_timestamp > ?
        AND arrival_timestamp >= CURDATE()
        AND arrival_timestamp < (CURDATE() + INTERVAL 1 DAY)

        UNION ALL

        -- Check for new ticket logs (status changes, etc.)
        SELECT 1 FROM ticket_logs
        WHERE created_at > ?
        AND action IN ('Status Changed', 'Sent to Lab', 'Sent to Imaging', 'Sent to Both', 'Canceled', 'Completed')
    ) changes
    LIMIT 1
", [$cutoff, $cutoff]);
$hasChanges = $changeRecord ? '1' : '0';

// Add cache headers to reduce server load
header('Cache-Control: no-cache, must-revalidate');
header('Expires: 0');

echo $hasChanges;
?>

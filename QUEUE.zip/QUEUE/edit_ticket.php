<?php
require_once 'config.php';
session_start();
authRequireRoles(['butler', 'billing', 'admin']);

function normalizeDemographicValue($value) {
    return trim((string)($value ?? ''));
}

function getCurrentTicketDemographics($pdo, $ticketId) {
    return executeAndFetchOne($pdo, "SELECT
            p.mrn,
            p.patient_name,
            p.mobile,
            p.country_code,
            p.care_mobile,
            p.care_country_code,
            p.email,
            p.address
        FROM tickets t
        JOIN patients p ON t.patient_id = p.patient_id
        WHERE t.ticket_id = ?", [$ticketId]);
}

function updateTicketDemographicsChangeFlags($pdo, $ticketId) {
    $ticketRow = executeAndFetchOne($pdo, "SELECT demographics_snapshot FROM tickets WHERE ticket_id = ?", [$ticketId]);
    if (!$ticketRow) {
        return;
    }

    $snapshot = [];
    if (!empty($ticketRow['demographics_snapshot'])) {
        $decoded = json_decode($ticketRow['demographics_snapshot'], true);
        if (is_array($decoded)) {
            $snapshot = $decoded;
        }
    }

    $current = getCurrentTicketDemographics($pdo, $ticketId);
    if (!$current) {
        return;
    }

    $fieldsToCheck = [
        'mrn',
        'patient_name',
        'mobile',
        'country_code',
        'care_mobile',
        'care_country_code',
        'email',
        'address'
    ];

    $changedFields = [];
    if (!empty($snapshot)) {
        foreach ($fieldsToCheck as $field) {
            // For legacy snapshots, only compare fields that exist in the snapshot.
            if (!array_key_exists($field, $snapshot)) {
                continue;
            }

            $snapshotValue = normalizeDemographicValue($snapshot[$field] ?? null);
            $currentValue = normalizeDemographicValue($current[$field] ?? null);
            if ($snapshotValue !== $currentValue) {
                $changedFields[] = $field;
            }
        }
    }

    $edited = !empty($changedFields) ? 1 : 0;
    $changedJson = $edited ? json_encode($changedFields, JSON_UNESCAPED_UNICODE) : null;

    executeUpdate($pdo, "UPDATE tickets SET demographics_edited = ?, demographics_changed_fields = ? WHERE ticket_id = ?", [$edited, $changedJson, $ticketId]);
}

// Accept either an individual id or a queue_number to edit multiple records
$patient_id = null;
$queue_number = null;
$message = '';
$message_type = '';

if (isset($_GET['id'])) {
    $patient_id = intval($_GET['id']);
}

if (isset($_GET['queue_number'])) {
    $queue_number = trim($_GET['queue_number']);
}

// Fetch patient data (by id if provided, otherwise fetch first record for queue_number)
if ($patient_id) {
    $patient = executeAndFetchOne($pdo, "
        SELECT t.ticket_id AS id, t.queue_number, t.service_type, t.arrival_timestamp, DATE(t.arrival_timestamp) as arrival_date, p.patient_name, p.mobile, p.care_mobile, p.country_code, p.care_country_code, p.email, p.address FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ? AND DATE(t.arrival_timestamp) = CURDATE()
    ", [$patient_id]);
    if (!$patient) {
        header('Location: butler.php');
        exit();
    }
} elseif ($queue_number) {
    $patient = executeAndFetchOne($pdo, "
        SELECT t.ticket_id AS id, t.queue_number, t.service_type, t.arrival_timestamp, DATE(t.arrival_timestamp) as arrival_date, p.patient_name, p.mobile, p.care_mobile, p.country_code, p.care_country_code, p.email, p.address FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.queue_number = ? AND DATE(t.arrival_timestamp) = CURDATE() LIMIT 1
    ", [$queue_number]);
    if (!$patient) {
        header('Location: butler.php');
        exit();
    }
    // set patient_id for form defaults
    $patient_id = $patient['id'];
} else {
    header('Location: butler.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    try {
        // Get address from text field
        $address = $_POST['address'] ?? '';
        
        /* OLD IMPLEMENTATION - when the dropdown fields were used to build the address not text input
        // Build address from dropdown fields
        $address = '';
        if (!empty($_POST['district'])) {
            $address = $_POST['district'];
            if (!empty($_POST['kaza'])) {
                $address .= ', ' . $_POST['kaza'];
                if (!empty($_POST['city'])) {
                    $address .= ', ' . $_POST['city'];
                }
            }
        }
        */
        
        // mobile must be provided
        if (empty($_POST['mobile'])) {
            throw new Exception('Contact mobile number is required');
        }
        // If care_mobile is empty, use mobile as fallback
        $care_mobile = $_POST['care_mobile'] ?? '';
        if (empty($care_mobile)) {
            $care_mobile = $_POST['mobile'];
        }
        // care country code fallback
        $care_country_code = $_POST['care_country_code'] ?? '';
        if (empty($care_country_code)) {
            $care_country_code = $_POST['country_code'];
        }
        
        // Update patient - if queue_number provided, apply to all records with that queue number for today
        if (!empty($_POST['queue_number']) || !empty($queue_number)) {
            $target_qn = !empty($_POST['queue_number']) ? $_POST['queue_number'] : $queue_number;
                $sql = "UPDATE patients p
                    JOIN tickets t ON t.patient_id = p.patient_id
                    SET p.patient_name = ?,
                    p.mobile = ?,
                    p.care_mobile = ?,
                    p.country_code = ?,
                    p.care_country_code = ?,
                    p.email = ?,
                    p.address = ?,
                    t.service_type = ?
                    WHERE t.queue_number = ? AND DATE(t.arrival_timestamp) = CURDATE()";
            executeUpdate($pdo, $sql, [
                $_POST['patient_name'],
                $_POST['mobile'],
                $care_mobile,
                $_POST['country_code'],
                $care_country_code,
                $_POST['email'],
                $address,
                $_POST['service_type'],
                $target_qn
            ]);

            // Recompute demographics flags for all tickets sharing this queue number.
            $ticketIds = executeAndFetch($pdo, "SELECT ticket_id FROM tickets WHERE queue_number = ? AND DATE(arrival_timestamp) = CURDATE()", [$target_qn]);
            foreach ($ticketIds as $ticketIdRecord) {
                updateTicketDemographicsChangeFlags($pdo, (int)$ticketIdRecord['ticket_id']);
            }

            // Log the update for queue_number (log first patient id)
            $log_target_id = $patient_id;
        } else {
                $sql = "UPDATE patients p
                    JOIN tickets t ON t.patient_id = p.patient_id
                    SET p.patient_name = ?,
                    p.mobile = ?,
                    p.care_mobile = ?,
                    p.country_code = ?,
                    p.care_country_code = ?,
                    p.email = ?,
                    p.address = ?,
                    t.service_type = ?
                    WHERE t.ticket_id = ?";
            executeUpdate($pdo, $sql, [
                $_POST['patient_name'],
                $_POST['mobile'],
                $care_mobile,
                $_POST['country_code'],
                $care_country_code,
                $_POST['email'],
                $address,
                $_POST['service_type'],
                $patient_id
            ]);

            updateTicketDemographicsChangeFlags($pdo, (int)$patient_id);

            $log_target_id = $patient_id;
        }
        
        // Log the update
        $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes) 
                   VALUES (?, 'Updated', NULL, NULL, ?)";
        executeUpdate($pdo, $log_sql, [$log_target_id, "Patient details updated by Butler"]);
        
        // Store success and patient_id in session for the success page
        $_SESSION['edit_success'] = true;
        $_SESSION['edited_patient_id'] = $patient_id;
        $_SESSION['edited_queue_number'] = $queue_number;
        header('Location: edit_ticket.php?' . ($queue_number ? 'queue_number=' . urlencode($queue_number) : 'id=' . $patient_id) . '&success=true');
        exit();
        
    } catch (Exception $e) {
        $message = "Error updating patient: " . $e->getMessage();
        $message_type = 'error';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Ticket - <?php echo htmlspecialchars($patient['queue_number']); ?></title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <div class="container">
        <?php
        // Check if this is a success redirect
        if (isset($_GET['success']) && $_GET['success'] === 'true' && isset($_SESSION['edit_success'])) {
            unset($_SESSION['edit_success']);
            $success_patient_id = $_SESSION['edited_patient_id'] ?? $patient_id;
            unset($_SESSION['edited_patient_id']);
            ?>
            <div style="text-align: center; padding: 40px 20px;">
                <div style="background: #f0fff0; border: 2px solid #4CAF50; border-radius: 10px; padding: 30px; margin-bottom: 20px;">
                    <i class="fas fa-check-circle" style="font-size: 48px; color: #4CAF50; margin-bottom: 10px;"></i>
                    <h2 style="color: #2d5016; margin: 10px 0;">Patient Information Updated Successfully!</h2>
                    <p style="color: #666; margin-bottom: 30px;">Queue #: <strong><?php echo htmlspecialchars($patient['queue_number']); ?></strong></p>
                    
                    <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                        <a href="butler.php" class="action-btn" style="background: #3498db; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
                            <i class="fas fa-arrow-left"></i> Back to Butler
                        </a>
                        <a href="scan_docs.php?patient_id=<?php echo $success_patient_id; ?>&from=butler" class="action-btn" style="background: #27ae60; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
                            <i class="fas fa-camera"></i> Retake Documents
                        </a>
                    </div>
                </div>
            </div>
            <?php
        } else {
            // Show the edit form
        ?>
        <?php
        // Include shared form with edit options
        $options = [
            'mode' => 'edit',
            'title' => 'Edit Patient Ticket - ' . $patient['queue_number'],
            'patient' => $patient,
            'button_text' => 'Update Ticket',
            'button_icon' => 'fa-save',
            'success_message' => 'Ticket Updated Successfully!'
        ];
        include 'shared_form.php';
        ?>
        <?php } ?>
    </div>
</body>
</html>
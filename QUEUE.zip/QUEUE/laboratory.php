﻿<?php
// laboratory.php - Full Width Laboratory Interface
require_once 'config.php';
session_start();
authRequireRoles(['laboratory', 'admin'], ['log_view' => false]);

// Helper function to save undo state
function saveUndoState($pdo, $patient_id, $previous_status, $new_status, $action, $department) {
    // Fetch department flags and imaging_machine from database
    $patient = executeAndFetchOne($pdo, "SELECT img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
    
    $_SESSION['last_action'] = [
        'patient_id' => $patient_id,
        'previous_status' => $previous_status,
        'current_status' => $new_status,
        'action' => $action,
        'department' => $department,
        'img' => $patient['img'] ?? 0,
        'lab' => $patient['lab'] ?? 0,
        'dp2' => $patient['dp2'] ?? 0,
        'imaging_machine' => $patient['imaging_machine'] ?? null,
        'timestamp' => time()
    ];
}

// Handle actions via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['call_patient'])) {
        try {
            $patient_id = (int)($_POST['patient_id'] ?? 0);
            if ($patient_id <= 0) {
                throw new Exception('Invalid patient ID');
            }

            // Get current status and department flags BEFORE update
            $current = executeAndFetchOne($pdo, "SELECT t.current_status, p.mobile, t.img, t.lab, t.dp2, t.imaging_machine FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
            
            if (!$current) {
                throw new Exception('Patient not found');
            }

        // Update patient status: Waiting â†’ Called
        executeUpdate($pdo, "
            UPDATE tickets SET current_status = 'Called',
                lab_call_time = NOW()
            WHERE ticket_id = ?
        ", [$patient_id]);

        // Log the action
        $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Called in Lab', 'Waiting', 'Called', ?, 'Patient called to Laboratory')";
        executeUpdate($pdo, $log_sql, [$patient_id, authCurrentUserId() ?: null]);

        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Called',
            'action' => 'Patient called',
            'department' => 'lab',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];

        // Send WhatsApp message
        error_log("Call Patient: Checking for mobile number. Mobile value: " . ($current['mobile'] ?? 'EMPTY'));
        if (!empty($current['mobile'])) {
            error_log("Call Patient: Mobile found, sending WhatsApp. Mobile: " . $current['mobile']);
            // Actually, we need to call it directly here
            $phone_number = preg_replace('/[^0-9]/', '', $current['mobile']);
            error_log("Call Patient: Phone number after cleanup: " . $phone_number);
            
            // Clean phone number - ensure Lebanon country code
            if (strlen($phone_number) == 8 && substr($phone_number, 0, 1) == '7') {
                $phone_number = '961' . $phone_number;
            } elseif (strlen($phone_number) == 9 && substr($phone_number, 0, 1) == '3') {
                $phone_number = '961' . $phone_number;
            } elseif (strpos($phone_number, '961') !== 0 && strlen($phone_number) < 11) {
                $phone_number = '961' . substr($phone_number, -9);
            }

            try {
                $sendResult = sendWhatsAppTemplateRequest($phone_number, 'call_queue', ['Laboratory', 'ط§ظ„ظ…ط®طھط¨ط±']);
                error_log("WhatsApp API Request: " . (string)($sendResult['request_url'] ?? ''));
                error_log("WhatsApp API Response (HTTP " . (int)($sendResult['http_code'] ?? 0) . "): " . (string)($sendResult['response'] ?? ''));
            } catch (Exception $whatsappError) {
                error_log("WhatsApp notification failed (non-fatal): " . $whatsappError->getMessage());
            }
        } else {
            error_log("Call Patient: No mobile number found for patient ID: " . $patient_id);
        }
            $_SESSION['lab_message'] = "Patient called successfully!";
            
            // Check if this is an AJAX request
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'message' => 'Patient called successfully']);
                exit();
            }
            
            header('Location: laboratory.php');
            exit();
        } catch (Exception $e) {
            error_log('call_patient error: ' . $e->getMessage());
            $_SESSION['lab_message'] = 'Error calling patient: ' . $e->getMessage();
            
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Error calling patient: ' . $e->getMessage()]);
                exit();
            }
            
            header('Location: laboratory.php');
            exit();
        }
        
    } elseif (isset($_POST['ok_patient'])) {
        try {
            $patient_id = (int)($_POST['patient_id'] ?? 0);
            if ($patient_id <= 0) {
                throw new Exception('Invalid patient ID');
            }

            // Get current status and department flags BEFORE update
            $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
            
            if (!$current) {
                throw new Exception('Patient not found');
            }

        // Update patient status: Called/Recalled â†’ Served
        executeUpdate($pdo, "
            UPDATE tickets SET current_status = 'Served'
            WHERE ticket_id = ?
        ", [$patient_id]);

        // Log the action
        $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes)
                VALUES (?, 'Served in Lab', ?, 'Served', ?, 'Patient served in Laboratory')";
        executeUpdate($pdo, $log_sql, [$patient_id, $current['current_status'], authCurrentUserId() ?: null]);

        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Served',
            'action' => 'Patient served',
            'department' => 'lab',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];

            $_SESSION['lab_message'] = "Patient served successfully! Status changed to 'Served'";
            header('Location: laboratory.php');
            exit();
        } catch (Exception $e) {
            error_log('ok_patient error: ' . $e->getMessage());
            $_SESSION['lab_message'] = 'Error serving patient: ' . $e->getMessage();
            
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Error serving patient: ' . $e->getMessage()]);
                exit();
            }
            
            header('Location: laboratory.php');
            exit();
        }

    } elseif (isset($_POST['complete_ticket'])) {
        try {
            $patient_id = (int)($_POST['patient_id'] ?? 0);
            if ($patient_id <= 0) {
                throw new Exception('Invalid patient ID');
            }

            // Lab numbers are optional now — removed mandatory check.
            
            // Get patient info BEFORE any updates for undo purposes
            $patient = executeAndFetchOne($pdo, "SELECT img, lab, dp2, current_status, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
            
            if (!$patient) {
                throw new Exception('Patient not found');
            }
        $original_img = $patient['img'];
        $original_lab = $patient['lab'];
        $original_dp2 = $patient['dp2'];
        $original_status = $patient['current_status'];
        
        if ($patient['img'] == 1) {
            // Patient needs imaging: set dp2=1, status=Waiting, lab=0
            executeUpdate($pdo, "
                UPDATE tickets SET current_status = 'Waiting',
                    lab = 0,
                    dp2 = 1
                WHERE ticket_id = ?
            ", [$patient_id]);

                // Log the action
                $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes)
                        VALUES (?, 'Completed Lab & Sent to Imaging', 'Served', 'Waiting', ?, 'Lab completed, sent to imaging queue')";
            $_SESSION['lab_message'] = "Patient completed and sent to Imaging queue!";
            
            // Save undo state with ORIGINAL values
            $_SESSION['last_action'] = [
                'patient_id' => $patient_id,
                'previous_status' => $original_status,
                'current_status' => 'Waiting',
                'action' => 'Completed Lab & Sent to Imaging',
                'department' => 'lab',
                'img' => $original_img,
                'lab' => $original_lab,
                'dp2' => $original_dp2,
                'imaging_machine' => $patient['imaging_machine'] ?? null,
                'timestamp' => time()
            ];
        } else {
            // Patient doesn't need imaging: complete the ticket
            executeUpdate($pdo, "
                UPDATE tickets SET current_status = 'Completed',
                    closing_timestamp = NOW()
                WHERE ticket_id = ?
            ", [$patient_id]);

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes)
                    VALUES (?, 'Completed Lab', 'Served', 'Completed', ?, 'Laboratory tests completed')";
            $_SESSION['lab_message'] = "Patient completed successfully!";
            
            // Save undo state with original values
            saveUndoState($pdo, $patient_id, $original_status, 'Completed', 'Completed Lab', 'lab');
        }

        executeUpdate($pdo, $log_sql, [$patient_id, authCurrentUserId() ?: null]);

            // Check if this is an AJAX request
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'message' => $_SESSION['lab_message']]);
                exit();
            }
            
            header('Location: laboratory.php');
            exit();
        } catch (Exception $e) {
            error_log('complete_ticket error: ' . $e->getMessage());
            $_SESSION['lab_message'] = 'Error completing ticket: ' . $e->getMessage();
            
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Error completing ticket: ' . $e->getMessage()]);
                exit();
            }
            
            header('Location: laboratory.php');
            exit();
        }
        
    } elseif (isset($_POST['send_back'])) {
        try {
            $patient_id = (int)($_POST['patient_id'] ?? 0);
            if ($patient_id <= 0) {
                throw new Exception('Invalid patient ID');
            }

            // Get current status and department flags BEFORE update
            $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
            
            if (!$current) {
                throw new Exception('Patient not found');
            }

        // Send back to waiting from Served status
        executeUpdate($pdo, "
            UPDATE tickets SET current_status = 'On Hold'
            WHERE ticket_id = ?
        ", [$patient_id]);

        // Log the action
        $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes)
                VALUES (?, 'Sent back to Waiting', 'Served', 'Waiting', ?, 'Sent back to waiting queue from Lab')";
        executeUpdate($pdo, $log_sql, [$patient_id, authCurrentUserId() ?: null]);
        
        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'On Hold',
            'action' => 'Sent back',
            'department' => 'lab',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];

            $_SESSION['lab_message'] = "Patient sent back to waiting queue!";
            header('Location: laboratory.php');
            exit();
        } catch (Exception $e) {
            error_log('send_back error: ' . $e->getMessage());
            $_SESSION['lab_message'] = 'Error sending back patient: ' . $e->getMessage();
            
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Error sending back patient: ' . $e->getMessage()]);
                exit();
            }
            
            header('Location: laboratory.php');
            exit();
        }

    } elseif (isset($_POST['call_next_patient'])) {
        // Call next patient logic
        $waitingPatient = executeAndFetchOne($pdo, "
            SELECT ticket_id AS id FROM tickets
            WHERE current_status = 'Waiting' 
            AND lab = 1
            AND dp2 = 0
            ORDER BY
                FIELD(service_type, 'Appointment', 'Private', 'Guarantor'),
                arrival_timestamp ASC
            LIMIT 1
        ", []);

        if ($waitingPatient) {
            executeUpdate($pdo, "
                UPDATE tickets SET current_status = 'Called',
                    lab_call_time = NOW()
                WHERE ticket_id = ?
            ", [$waitingPatient['id']]);

            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes)
                    VALUES (?, 'Called Next in Lab', 'Waiting', 'Called', ?, 'Called next patient in Laboratory')";
            executeUpdate($pdo, $log_sql, [$waitingPatient['id'], authCurrentUserId() ?: null]);
            
            $_SESSION['lab_message'] = "Called next patient successfully!";
        } else {
            $_SESSION['lab_message'] = "No waiting patients to call!";
        }
        
        header('Location: laboratory.php');
        exit();

    } elseif (isset($_POST['release_patient'])) {
        try {
            $patient_id = (int)($_POST['patient_id'] ?? 0);
            if ($patient_id <= 0) {
                throw new Exception('Invalid patient ID');
            }

            // Get current status before update
            $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
            
            if (!$current) {
                throw new Exception('Patient not found');
            }

        // Release patient from "Wrong Info" status back to "Waiting"
        executeUpdate($pdo, "
            UPDATE tickets SET current_status = 'Waiting'
            WHERE ticket_id = ?
        ", [$patient_id]);

        // Log the action
        $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes)
                VALUES (?, 'Released from Wrong Info', 'Wrong Info', 'Waiting', ?, 'Patient information corrected and released to waiting queue from Lab')";
        executeUpdate($pdo, $log_sql, [$patient_id, authCurrentUserId() ?: null]);
        
        // Build undo state
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Arrived',
            'action' => 'Released from Wrong Info',
            'department' => 'lab',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];

        $_SESSION['lab_message'] = "Patient released from wrong information status!";

            // Check if this is an AJAX request
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'message' => $_SESSION['lab_message']]);
                exit();
            }
            
            header('Location: laboratory.php');
            exit();
        } catch (Exception $e) {
            error_log('release_patient error: ' . $e->getMessage());
            $_SESSION['lab_message'] = 'Error releasing patient: ' . $e->getMessage();
            
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Error releasing patient: ' . $e->getMessage()]);
                exit();
            }
            
            header('Location: laboratory.php');
            exit();
        }
    }
}
// Get lab patients
$query = "
    SELECT
        t.ticket_id AS id,
        t.queue_number,
        p.mrn,
        p.patient_name,
        p.mobile,
        p.email,
        p.address,
        t.service_type as type,
        t.current_status as status,
        t.arrival_timestamp,
        t.approval_timestamp,
        t.lab_call_time,
        t.img,
        t.dp2
    FROM tickets t
    JOIN patients p ON t.patient_id = p.patient_id
    WHERE t.closing_timestamp IS NULL
    AND t.current_status IN ('Waiting', 'Called', 'On the Way', 'Skipped', 'Recalled', 'Served', 'On Hold')
    AND t.lab = 1
    AND t.dp2 = 0 -- Only show patients not yet sent to Imaging
    AND DATE(t.arrival_timestamp) = CURDATE()
    ORDER BY
        FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
        COALESCE(t.approval_timestamp, t.arrival_timestamp) ASC
";

$patients = executeAndFetch($pdo, $query, []);

// Count statistics
$waiting_count = 0;
$on_hold_count = 0;
$to_imaging_count = 0;
$skipped_recalled_count = 0;

foreach ($patients as $patient) {
    if ($patient['status'] == 'Waiting') $waiting_count++;
    if ($patient['status'] == 'On Hold') $on_hold_count++;
    if ($patient['img'] == 1) $to_imaging_count++;
    if (in_array($patient['status'], ['Skipped', 'Recalled'])) $skipped_recalled_count++;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratory Interface</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="browser-notifications.js"></script>
    <script src="refresh-manager.js"></script>
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <style>
        .lab-fullwidth-layout {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            height: auto;
        }
        .lab-fullwidth-layout .queues-panel {
            width: 100%;
            flex: 1;
        }
        .lab-fullwidth-layout .queue-table-container,
        .lab-fullwidth-layout .queue-table {
            width: 100%;
        }
    </style>

    <div class="imaging-container lab-fullwidth-layout" style="border-top: 6px solid #e74c3c;">
        <!-- Header -->
        <div class="imaging-header" style="background: #e74c3c; color: #fff;">
            <h1>
                <i class="fas fa-flask"></i> Laboratory Dashboard
            </h1>
        </div>
        
        <!-- Success Message -->
        <?php if (isset($_SESSION['lab_message'])): ?>
            <div class="success-message">
                <span><i class="fas fa-check-circle"></i> <?php echo $_SESSION['lab_message']; ?></span>
                <button class="close-message" onclick="this.parentElement.style.display='none'">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <?php unset($_SESSION['lab_message']); ?>
        <?php endif; ?>
        
        <!-- Statistics -->
        <div class="imaging-stats" id="labStats">
            <div class="stat-card" style="border-top-color: #e74c3c;">
                <div class="stat-number"><?php echo count($patients); ?></div>
                <div class="stat-label">Total in Queue</div>
            </div>
            <div class="stat-card" style="border-top-color: #3498db;">
                <div class="stat-number"><?php echo $waiting_count; ?></div>
                <div class="stat-label">Waiting</div>
            </div>
            <div class="stat-card" style="border-top-color: #27ae60;">
                <div class="stat-number"><?php echo $on_hold_count; ?></div>
                <div class="stat-label">On Hold</div>
            </div>
            <div class="stat-card" style="border-top-color: #9b59b6;">
                <div class="stat-number"><?php echo $to_imaging_count; ?></div>
                <div class="stat-label">To Imaging Next</div>
            </div>
        </div>
        
        <!-- Main Queue Section -->
        <div class="queues-panel">
            <div class="queues-header">
                <h2>
                    <i class="fas fa-flask"></i> Laboratory Queue
                    <span style="font-size: 16px; color: #7f8c8d; font-weight: normal;">
                        (<?php echo count($patients); ?> patients)
                    </span>
                </h2>
            </div>
            <!-- Queue Table -->
            <div class="queue-table-container" style="width: 100%;">
                <table class="queue-table" style="width: 100%;">
                    <thead>
                        <tr>
                            <th width="100">Queue #</th>
                            <th width="200">Patient Name</th>
                            <th width="100">Type</th>
                            <th width="100">Status</th>
                            <th width="200">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="labQueueBody">
                        <?php if (empty($patients)): ?>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <i class="fas fa-inbox"></i>
                                        <h3>No patients in lab queue</h3>
                                        <p>No patients waiting for laboratory tests</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($patients as $patient): 
                                // Calculate waiting time
                                $arrival_time = new DateTime($patient['approval_timestamp']);
                                $now = new DateTime();
                                $waiting_minutes = floor((strtotime($now->format('Y-m-d H:i:s')) - strtotime($patient['approval_timestamp'])) / 60);
                                
                                // Status badge class
                                $status_class = 'status-' . str_replace(' ', '-', strtolower($patient['status']));
                                
                                // Type badge class
                                $type_class = 'type-' . strtolower($patient['type']);
                                
                                // Format arrival time
                                $arrival_time_str = $arrival_time->format('H:i');
                            ?>
                                <tr id="lab-patient-<?php echo $patient['id']; ?>" 
                                    class="<?php echo $patient['type'] == 'Appointment' ? 'priority-highlight' : ''; ?>">
                                    <td style="font-weight: bold; color: #2c3e50;">
                                        <?php echo $patient['queue_number']; ?>
                                    </td>
                                    <td>
                                        <button class="view-pdf-btn" data-patient='<?php echo htmlspecialchars(json_encode([
                                            'id' => $patient['id'],
                                            'queue_number' => $patient['queue_number'],
                                            'patient_name' => $patient['patient_name'],
                                            'mrn' => $patient['mrn'] ?? ''
                                        ]), ENT_QUOTES, 'UTF-8'); ?>' style="background:none;border:none;padding:0;font-size:inherit;cursor:pointer;color:inherit;">
                                            <?php echo htmlspecialchars($patient['patient_name']); ?>
                                        </button>
                                        <?php if ($patient['img'] == 1): ?>
                                            <span class="dept-indicator imaging-indicator" title="Patient will go to Imaging next"> (&rarr; IMG)</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="type-badge <?php echo $type_class; ?>">
                                            <?php echo $patient['type']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge <?php echo $status_class; ?>">
                                            <?php echo $patient['status']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="lab-action-buttons">
                                            <?php if ($patient['status'] == 'Waiting'): ?>
                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                        <input type="hidden" name="department" value="lab">
                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                        <input type="hidden" name="action" value="call_patient">
                                                        <button type="submit" class="lab-action-btn" style="background: #27ae60; color: white; width: 100%; white-space: nowrap;">
                                                            <i class="fas fa-bullhorn"></i> Call
                                                        </button>
                                                    </form>
                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                        <input type="hidden" name="department" value="lab">
                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                        <input type="hidden" name="action" value="wrong_info">
                                                        <button type="submit" class="lab-action-btn" style="background: #e74c3c; color: white; width: 100%; white-space: nowrap;">
                                                            <i class="fas fa-exclamation-circle"></i> Wrong Info
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php elseif (in_array($patient['status'], ['Called', 'On the Way'], true)): ?>
                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                        <input type="hidden" name="department" value="lab">
                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                        <input type="hidden" name="action" value="start_procedure">
                                                        <button type="submit" class="lab-action-btn" style="background: #3498db; color: white; width: 100%; white-space: nowrap;">
                                                            <i class="fas fa-check"></i> OK
                                                        </button>
                                                    </form>
                                                    <button class="lab-action-btn" style="background: #f39c12; color: white; flex: 1; white-space: nowrap;"
                                                            onclick="skipPatient(<?php echo $patient['id']; ?>)">
                                                        <i class="fas fa-forward"></i> Skip
                                                    </button>
                                                </div>
                                            <?php elseif ($patient['status'] == 'Skipped'): ?>
                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                    <button class="lab-action-btn" style="background: #9b59b6; color: white; flex: 1; white-space: nowrap;"
                                                            onclick="recallPatient(<?php echo $patient['id']; ?>)">
                                                        <i class="fas fa-undo"></i> Recall
                                                    </button>
                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                        <input type="hidden" name="department" value="lab">
                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                        <input type="hidden" name="action" value="wrong_info">
                                                        <button type="submit" class="lab-action-btn" style="background: #e74c3c; color: white; width: 100%; white-space: nowrap;">
                                                            <i class="fas fa-exclamation-circle"></i> Wrong Info
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php elseif ($patient['status'] == 'Recalled'): ?>
                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                        <input type="hidden" name="department" value="lab">
                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                        <input type="hidden" name="action" value="start_procedure">
                                                        <button type="submit" class="lab-action-btn" style="background: #3498db; color: white; width: 100%; white-space: nowrap;">
                                                            <i class="fas fa-check"></i> OK
                                                        </button>
                                                    </form>
                                                    <button class="lab-action-btn" style="background: #f39c12; color: white; flex: 1; white-space: nowrap;"
                                                            onclick="skipPatient(<?php echo $patient['id']; ?>)">
                                                        <i class="fas fa-forward"></i> Skip
                                                    </button>
                                                </div>
                                            <?php elseif ($patient['status'] == 'Served'): ?>
                                                <!-- Served status buttons - Stay visible with Complete/Send Back options -->
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                    <input type="hidden" name="complete_ticket" value="1">
                                                    <button type="submit" class="lab-action-btn" style="background: #2ecc71; color: white;">
                                                        <i class="fas fa-check-circle"></i> Complete
                                                    </button>
                                                </form>
                                                <form method="POST" action="patient_actions.php" style="display: inline;">
                                                    <input type="hidden" name="department" value="lab">
                                                    <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                    <input type="hidden" name="action" value="send_back">
                                                    <button type="submit" class="lab-action-btn" style="background: #e74c3c; color: white;">
                                                        <i class="fas fa-arrow-left"></i> Send Back
                                                    </button>
                                                </form>
                                            <?php elseif ($patient['status'] == 'On Hold'): ?>
                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                    <button class="lab-action-btn" onclick="recallPatient(<?php echo $patient['id']; ?>)" style="background: #27ae60; color: white; flex: 1; white-space: nowrap;">
                                                        <i class="fas fa-bullhorn"></i> Call
                                                    </button>
                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                        <input type="hidden" name="department" value="lab">
                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                        <input type="hidden" name="action" value="wrong_info">
                                                        <button type="submit" class="lab-action-btn" style="background: #e74c3c; color: white; width: 100%; white-space: nowrap;">
                                                            <i class="fas fa-exclamation-circle"></i> Wrong Info
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    // ========== GLOBAL FUNCTIONS ==========
    const LAB_NOTIFICATION_PAGE = 'Laboratory';
    let labQueueRefreshInFlight = false;

    function collectCurrentLabTicketsFromDom() {
        const rows = document.querySelectorAll('#labQueueBody tr[id^="lab-patient-"]');
        return Array.from(rows).map(row => {
            const cells = row.querySelectorAll('td');
            return {
                id: row.id.replace('lab-patient-', ''),
                queueNumber: cells[0] ? cells[0].textContent.trim() : '',
                patientName: cells[1] ? cells[1].textContent.trim() : ''
            };
        });
    }

    function collectCurrentLabWrongInfoTicketsFromDom() {
        const rows = document.querySelectorAll('#labQueueBody tr[id^="lab-patient-"]');
        return Array.from(rows).map(row => {
            const statusBadge = row.querySelector('.status-badge');
            const statusText = statusBadge ? statusBadge.textContent.trim() : '';
            if (statusText !== 'Wrong Info') {
                return null;
            }

            const cells = row.querySelectorAll('td');
            return {
                id: row.id.replace('lab-patient-', ''),
                queueNumber: cells[0] ? cells[0].textContent.trim() : '',
                patientName: cells[1] ? cells[1].textContent.trim() : '',
                message: `${cells[0] ? cells[0].textContent.trim() : ''} - ${cells[1] ? cells[1].textContent.trim() : ''}`
            };
        }).filter(Boolean);
    }

    function notifyNewLabTickets(patients) {
        if (!window.QueueNotifications) {
            return;
        }

        QueueNotifications.notifyForNewTickets({
            pageKey: 'laboratory:main',
            items: (patients || []).map(patient => ({
                id: patient.id,
                queueNumber: patient.queue_number,
                patientName: patient.patient_name,
                message: `${patient.queue_number} - ${patient.patient_name}`
            })),
            title: 'New laboratory ticket',
            getBody: (item) => item.message || 'A new laboratory ticket is now visible.',
            onClick: () => window.focus()
        });

        QueueNotifications.notifyForNewTickets({
            pageKey: 'laboratory:wrong-info',
            items: (patients || [])
                .filter(patient => (patient.status || '').toLowerCase() === 'wrong info')
                .map(patient => ({
                    id: patient.id,
                    queueNumber: patient.queue_number,
                    patientName: patient.patient_name,
                    message: `${patient.queue_number} - ${patient.patient_name}`
                })),
            title: 'Wrong Info patient (Laboratory)',
            getBody: (item) => item.message || 'A Wrong Info patient is now visible in Laboratory.',
            onClick: () => window.focus()
        });
    }
    
    // Utility function to escape HTML
    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Skip patient (AJAX)
    function skipPatient(patientId) {
        if (confirm('Skip this patient? They will remain in queue.')) {
            fetch('patient_actions.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'action=skip&patient_id=' + patientId + '&department=lab'
            })
            .then(response => response.json())
            .then(data => {
                if (data._debug_whatsapp_urls && data._debug_whatsapp_urls.length > 0) {
                    console.log('ًں”— WhatsApp API URLs:');
                    data._debug_whatsapp_urls.forEach(call => {
                        console.log(`  Template: ${call.template}, Phone: ${call.phone}`);
                        console.log(`  URL: ${call.url}`);
                    });
                }
                if (data.success) {
                    alert('Patient skipped');
                    refreshLabQueue();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                alert('Error skipping patient');
                console.error('Error:', error);
            });
        }
    }
    
    // Recall patient (AJAX)
    function recallPatient(patientId) {
        if (confirm('Recall this patient?')) {
            fetch('patient_actions.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: 'action=recall&patient_id=' + patientId + '&department=lab'
            })
            .then(response => response.json())
            .then(data => {
                if (data._debug_whatsapp_urls && data._debug_whatsapp_urls.length > 0) {
                    console.log('ًں”— WhatsApp API URLs:');
                    data._debug_whatsapp_urls.forEach(call => {
                        console.log(`  Template: ${call.template}, Phone: ${call.phone}`);
                        console.log(`  URL: ${call.url}`);
                    });
                }
                if (data.success) {
                    alert('Patient recalled');
                    refreshLabQueue();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                alert('Error recalling patient');
                console.error('Error:', error);
            });
        }
    }
    
    // Call next patient (complete served if exists, then call next waiting)
    function callNextPatient() {
        // Step 1: Find and complete the served patient
        const rows = document.querySelectorAll('table tbody tr');
        let servedForm = null;
        
        for (let row of rows) {
            // Look for forms with complete_ticket input
            const form = row.querySelector('form input[name="complete_ticket"]')?.closest('form');
            if (form) {
                servedForm = form;
                break;
            }
        }
        
        console.log('Served form found:', !!servedForm);
        
        // If found a served patient, complete them first
        if (servedForm) {
            const formData = new FormData(servedForm);
            console.log('Form data patient_id:', formData.get('patient_id'));
            console.log('Form data complete_ticket:', formData.get('complete_ticket'));
            
            fetch('laboratory.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                console.log('Response status:', response.status);
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(text => {
                console.log('Patient completed, response:', text);
                // After completing the served patient, call the next waiting patient
                setTimeout(() => {
                    callWaitingPatient();
                }, 300);
            })
            .catch(error => {
                console.error('Error completing patient:', error);
                alert('Error completing patient: ' + error.message);
            });
            return;
        }
        
        console.log('No served patient found, calling waiting patient');
        // If no served patient, just call the next waiting patient
        callWaitingPatient();
    }
    
    function callWaitingPatient() {
        // Fetch the list of waiting patients ordered by approval_timestamp
        fetch('queue_refresh.php?department=lab')
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(patients => {
                // Find the oldest waiting patient
                const waitingPatients = patients.filter(p => p.status === 'waiting');
                
                if (waitingPatients.length === 0) {
                    console.log('No waiting patients');
                    // Reload to show the updated queue (prefer smartReload)
                    setTimeout(() => {
                        if (window.smartReload) window.smartReload(0); else window.location.reload();
                    }, 300);
                    return Promise.reject('No waiting patients');
                }
                
                // Sort by approval_timestamp and get the oldest
                waitingPatients.sort((a, b) => 
                    new Date(a.approval_timestamp) - new Date(b.approval_timestamp)
                );
                
                const nextPatient = waitingPatients[0];
                console.log('Calling next patient:', nextPatient.queue_number);
                
                // Call the next patient via AJAX - POST to laboratory.php with call_patient field
                const formData = new FormData();
                formData.append('call_patient', '1');
                formData.append('patient_id', nextPatient.id);
                
                return fetch('laboratory.php', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then(text => {
                console.log('Patient called successfully');
                // Reload to show the updated queue with the called patient (prefer smartReload)
                setTimeout(() => {
                    if (window.smartReload) window.smartReload(0); else window.location.reload();
                }, 300);
            })
            .catch(error => {
                console.error('Error calling next patient:', error);
                // Still reload to show current state
                setTimeout(() => {
                    if (window.smartReload) window.smartReload(0); else window.location.reload();
                }, 300);
            });
    }
    
    // Refresh lab queue via AJAX with state preservation
    function refreshLabQueue() {
        if (labQueueRefreshInFlight) {
            return;
        }

        labQueueRefreshInFlight = true;
        
        // Use RefreshManager if available
        if (window.refreshManager) {
            window.refreshManager.refreshSection('#labQueueBody', 'queue_refresh.php?department=lab')
                .then(() => {
                    labQueueRefreshInFlight = false;
                })
                .catch(error => {
                    console.error('Lab queue refresh error:', error);
                    labQueueRefreshInFlight = false;
                });
        } else {
            // Fallback to original method
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000);
            
            fetch('queue_refresh.php?department=lab', {
                signal: controller.signal,
                cache: 'no-store',
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
                .then(response => {
                    clearTimeout(timeoutId);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.text();
                })
                .then(html => {
                    const tableBody = document.getElementById('labQueueBody');
                    if (tableBody) {
                        tableBody.innerHTML = html;
                    }
                })
                .catch(error => {
                    clearTimeout(timeoutId);
                    if (error.name === 'AbortError') {
                        console.warn('Lab queue refresh timeout');
                    } else {
                        console.error('Network error refreshing lab queue:', error);
                        setTimeout(() => {
                            fetch('queue_refresh.php?department=lab', { cache: 'no-store' }).catch(err => console.error('Retry failed:', err));
                        }, 1000);
                    }
                })
                .finally(() => {
                    labQueueRefreshInFlight = false;
                });
        }
    }

    // PDF selector modal for Lab
    function showPdfSelector(patient) {
        // Ensure patient is parsed
        if (typeof patient === 'string') {
            try { patient = JSON.parse(patient); } catch(e) { console.error(e); return; }
        }
        // Create modal if not present
        let modal = document.getElementById('pdfSelectorModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'pdfSelectorModal';
            modal.className = 'patient-modal';
            modal.innerHTML = `
                <div class="patient-modal-content">
                    <div class="patient-modal-header">
                        <div class="patient-modal-title"><i class="fas fa-file-pdf"></i> Open Document</div>
                        <button class="patient-modal-close" id="pdfModalClose"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="patient-modal-body" id="pdfModalBody"></div>
                </div>`;
            document.body.appendChild(modal);
            modal.querySelector('#pdfModalClose').addEventListener('click', () => modal.classList.remove('active'));
        }

        const body = modal.querySelector('#pdfModalBody');
        body.innerHTML = `
            <div style="margin-bottom:12px;"><strong>${escapeHtml(patient.patient_name || '')}</strong></div>
            <div style="margin-bottom:12px; color:#2c3e50;"><strong>PID:</strong> ${escapeHtml(patient.mrn || 'N/A')}</div>
            <div style="display:flex; gap:8px;">
                <button id="openIdBtn" class="action-btn start"><i class="fas fa-id-card"></i> Open ID</button>
                <button id="openPrescBtn" class="action-btn whatsapp" style="background:#9b59b6; color:white;"><i class="fas fa-prescription"></i> Open Prescription</button>
            </div>
        `;

        modal.classList.add('active');
            // Attach observer now that modal exists
            setupPdfModalObserver();
        function openFile(type) {
            const filenameBase = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : patient.id;
            const url = 'download_pdf.php?type=' + encodeURIComponent(type) + '&file=' + encodeURIComponent(filenameBase + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
            window.open(url, '_blank', 'noopener');
        }

        modal.querySelector('#openIdBtn').onclick = () => openFile('id');
        modal.querySelector('#openPrescBtn').onclick = () => openFile('insurance');
    }

    // Delegate click for view-pdf-btn in lab
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.view-pdf-btn');
        if (btn) {
            e.preventDefault();
            const data = btn.getAttribute('data-patient');
            try { const patient = JSON.parse(data); showPdfSelector(patient); } catch(err) { console.error('Invalid patient data', err); }
        }
    });
    
    // Refresh button handler
    function refreshButtonClick() {
        refreshLabQueue();
    }
    
    // ========== EVENT LISTENERS ==========
    
    // Refresh lab queue automatically every 1 second (but not during user interaction)
    function startLabRefresh() {
        window.labRefreshInterval = setInterval(() => {
            // Don't refresh if page is hidden
            if (document.hidden) return;
            
            // Don't refresh if user is typing in an input or focused on a form element
            const activeElement = document.activeElement;
            if (activeElement && 
                (activeElement.tagName === 'INPUT' || 
                 activeElement.tagName === 'SELECT' || 
                 activeElement.tagName === 'TEXTAREA' ||
                 activeElement.classList.contains('editing'))) {
                return;
            }
            
            // Don't refresh if any modal is visible
            const hasOpenModal = document.querySelector('.modal:not(.hidden)') || 
                                document.querySelector('[role="dialog"]');
            if (hasOpenModal) return;
            
            refreshLabQueue();
        }, 1000);
    }
    
    // Start initial refresh
    startLabRefresh();
    
    // Setup observer for dynamically created PDF modal
    function setupPdfModalObserver() {
        const pdfModal = document.getElementById('pdfSelectorModal');
        if (pdfModal && !pdfModal.hasAttribute('data-observer-attached')) {
            pdfModal.setAttribute('data-observer-attached', 'true');
            const observer = new MutationObserver(() => {
                if (pdfModal.classList.contains('active')) {
                    // Modal opened - stop refresh
                    if (window.labRefreshInterval) {
                        clearInterval(window.labRefreshInterval);
                        window.labRefreshInterval = null;
                    }
                } else {
                    // Modal closed - resume refresh
                    if (!window.labRefreshInterval) {
                        startLabRefresh();
                    }
                }
            });
            observer.observe(pdfModal, { attributes: true, attributeFilter: ['class'] });
        }
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+R to refresh
        if (e.ctrlKey && e.key === 'r') {
            e.preventDefault();
            refreshLabQueue();
        }
        // Space to call next
        if (e.code === 'Space' && !e.ctrlKey && !e.altKey) {
            e.preventDefault();
            callNextPatient();
        }
        // F5 to refresh
        if (e.key === 'F5') {
            e.preventDefault();
            refreshLabQueue();
        }
    });
    
    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        if (window.QueueNotifications) {
            QueueNotifications.renderPermissionBanner({ pageName: LAB_NOTIFICATION_PAGE });
            QueueNotifications.syncTickets('laboratory:main', collectCurrentLabTicketsFromDom());
            QueueNotifications.syncTickets('laboratory:wrong-info', collectCurrentLabWrongInfoTicketsFromDom());
        }

        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                refreshLabQueue();
            }
        });

        window.addEventListener('focus', () => {
            refreshLabQueue();
        });

        // Add highlight animation to appointment rows
        setTimeout(() => {
            document.querySelectorAll('.priority-highlight').forEach(row => {
                row.style.backgroundColor = '#fff3cd';
                setTimeout(() => {
                    row.style.backgroundColor = '';
                }, 2000);
            });
        }, 1000);
    });
    </script>
    
    <!-- Show undo button if undo data exists and matches current department -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Check if there's undo data in session and it's for lab department
            <?php if (isset($_SESSION['last_action']) && $_SESSION['last_action']['department'] === 'lab' && ($_SESSION['last_action']['action'] ?? '') !== 'Mark On the Way'): ?>
                setTimeout(() => {
                    if (typeof showUndoButton !== 'undefined') {
                        const action = <?php echo json_encode($_SESSION['last_action']); ?>;
                        showUndoButton(action.action + ' - Click to undo');
                    }
                }, 500);
            <?php endif; ?>
        });
    </script>
</body>
<?php include 'undo_button.php'; ?>
</html>

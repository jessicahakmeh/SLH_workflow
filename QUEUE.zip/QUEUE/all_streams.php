<?php
// Stream Cards Container - Independent module
require_once 'config.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
authRequireRoles([], ['log_view' => false]);
?>
<title>Queue Streams</title>
<link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- Stream Cards - Horizontal at top -->
<div class="stream-cards-row">
    <!-- Lab Stream Card -->
    <div class="stream-card-compact lab-card">
        <div class="stream-card-compact-header lab">
            <span class="stream-card-label">Laboratory</span>
        </div>
        <div class="stream-card-compact-content" id="labStreamCompact">
            <!-- Content loaded via AJAX -->
        </div>
    </div>
    
    <!-- Imaging Stream Card -->
    <div class="stream-card-compact imaging-card">
        <div class="stream-card-compact-header imaging">
            <span class="stream-card-label">Imaging</span>
        </div>
        <div class="stream-card-compact-content" id="imgStreamCompact">
            <!-- Content loaded via AJAX -->
        </div>
    </div>
    
    <!-- Billing Stream Card -->
    <div class="stream-card-compact billing-card">
        <div class="stream-card-compact-header billing">
            <span class="stream-card-label">Billing</span>
        </div>
        <div class="stream-card-compact-content" id="billingStreamCompact">
            <!-- Content loaded via AJAX -->
        </div>
    </div>

    <!-- Clinics Stream Card -->
    <div class="stream-card-compact clinics-card">
        <div class="stream-card-compact-header clinics">
            <span class="stream-card-label">Clinics</span>
        </div>
        <div class="stream-card-compact-content" id="clinicsStreamCompact">
            <!-- Content loaded via AJAX -->
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="stream-confirmation-modal" id="streamConfirmationModal">
    <div class="stream-confirmation-modal-content">
        <div class="stream-confirmation-modal-header">
            <h3 id="confirmationTitle">Confirm Action</h3>
            <button class="stream-modal-close" id="confirmationCloseBtn" onclick="closeConfirmationModal(); return false;">&times;</button>
        </div>
        <div class="stream-confirmation-modal-body">
            <p id="confirmationMessage">Are you sure?</p>
            <p><small id="confirmationStatus">Status will be updated</small></p>
        </div>
        <div class="stream-confirmation-modal-footer">
            <button class="stream-modal-btn stream-modal-cancel" id="confirmationCancelBtn" onclick="closeConfirmationModal(); return false;">Cancel</button>
            <button class="stream-modal-btn stream-modal-confirm" id="confirmationConfirmBtn">Confirm</button>
        </div>
    </div>
</div>

<style>
/* Compact modal styles */
.stream-confirmation-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    z-index: 9999;
    justify-content: center;
    align-items: center;
    backdrop-filter: blur(3px);
}

.stream-confirmation-modal.active {
    display: flex;
    animation: modalFadeIn 0.25s ease;
}

@keyframes modalFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.stream-confirmation-modal-content {
    background: white;
    border-radius: 12px;
    width: 90%;
    max-width: 380px;
    overflow: hidden;
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
    animation: modalSlideIn 0.25s ease;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.stream-confirmation-modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 16px;
    background: linear-gradient(135deg, #3498db, #2980b9);
    color: white;
    border-bottom: 1px solid #2980b9;
}

.stream-confirmation-modal-header h3 {
    margin: 0;
    font-size: 1.1em;
    font-weight: 600;
}

.stream-modal-close {
    background: none;
    border: none;
    color: white;
    font-size: 20px;
    cursor: pointer;
    padding: 0;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: opacity 0.2s;
}

.stream-modal-close:hover {
    opacity: 0.8;
}

.stream-confirmation-modal-body {
    padding: 16px;
}

.stream-confirmation-modal-body p {
    margin: 0 0 8px 0;
    font-size: 14px;
    color: #2c3e50;
    line-height: 1.4;
}

.stream-confirmation-modal-body p:last-child {
    margin-bottom: 0;
}

.stream-confirmation-modal-body small {
    color: #7f8c8d;
    font-size: 12px;
}

.stream-confirmation-modal-footer {
    display: flex;
    justify-content: flex-end;
    padding: 12px 16px;
    gap: 10px;
    background: #f8f9fa;
    border-top: 1px solid #ecf0f1;
}

.stream-modal-btn {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    transition: all 0.2s;
    min-width: 80px;
}

.stream-modal-cancel {
    background: #e0e0e0;
    color: #555;
}

.stream-modal-cancel:hover {
    background: #d0d0d0;
    transform: translateY(-1px);
}

.stream-modal-confirm {
    background: linear-gradient(135deg, #27ae60, #219955);
    color: white;
}

.stream-modal-confirm:hover {
    background: linear-gradient(135deg, #219955, #1e8449);
    transform: translateY(-1px);
    box-shadow: 0 3px 10px rgba(39, 174, 96, 0.3);
}

.stream-modal-confirm:active {
    transform: translateY(0);
}
</style>

<script>
    // Configuration
    const streamConfigs = {
        lab: { id: 'labStreamCompact', action: 'mark_on_the_way', status: 'On the Way' },
        imaging: { id: 'imgStreamCompact', action: 'mark_on_the_way', status: 'On the Way' },
        billing: { id: 'billingStreamCompact', action: 'confirm_reception', status: 'In Process' },
        clinics: { id: 'clinicsStreamCompact', action: 'mark_served', status: 'Served' }
    };

    let currentConfirmation = null;

    function adjustCardSizing() {
        const cards = document.querySelectorAll('.stream-card-compact');
        let maxHeight = 0;
        
        // Find the tallest card
        cards.forEach(card => {
            const content = card.querySelector('.stream-card-compact-content');
            if (content) {
                const height = content.scrollHeight;
                if (height > maxHeight) maxHeight = height;
            }
        });
        
        // Set all cards to the same height
        if (maxHeight > 0) {
            cards.forEach(card => {
                card.style.minHeight = (maxHeight + 40) + 'px'; // Add padding
            });
        }
    }

    // Track refresh cycles to periodically update dashboard
    let streamRefreshCycles = 0;
    const DASHBOARD_REFRESH_EVERY_N_CYCLES = 5; // Refresh dashboard every 5 cycles (every 5 seconds at 1s interval)
    
    // Refresh stream data
    function refreshStreams() {
        streamRefreshCycles++;
        
        // Periodically update the main dashboard table as well
        if (streamRefreshCycles % DASHBOARD_REFRESH_EVERY_N_CYCLES === 0) {
            if (typeof window.refreshDashboard === 'function') {
                window.refreshDashboard();
            }
        }
        
        ['lab', 'imaging', 'billing', 'clinics'].forEach(stream => {
            fetch(`stream.php?mode=compact_content&stream=${stream}&t=${Date.now()}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status} - ${response.statusText}`);
                    }
                    return response.text();
                })
                .then(html => {
                    const container = document.getElementById(streamConfigs[stream].id);
                    if (container) {
                        container.innerHTML = html;
                        attachStreamHandlers(stream);
                        
                        // Add visual feedback
                        const card = container.closest('.stream-card-compact');
                        const hasPatient = container.querySelector('.ticket-number-compact') !== null;
                        
                        if (card) {
                            if (hasPatient) {
                                card.classList.add('has-patient');
                            } else {
                                card.classList.remove('has-patient');
                            }
                        }
                        
                        // Adjust card sizing
                        setTimeout(adjustCardSizing, 100);
                    }
                })
                .catch(error => {
                    console.error(`Error loading ${stream} stream:`, error);
                    // Show error message in card for debugging
                    const container = document.getElementById(streamConfigs[stream].id);
                    if (container) {
                        container.innerHTML = `<div style="color:red;padding:10px;font-size:12px;">Error: ${error.message}</div>`;
                    }
                });
        });
    }

    window.addEventListener('resize', adjustCardSizing);

    // Attach event handlers using event delegation on stream cards
    function attachStreamHandlers(stream) {
        // Event delegation is now handled at the parent level below
        // This function is called after each refresh but doesn't need to do anything
        // since click handlers are delegated to the card level
    }

    // Show confirmation modal
    function showConfirmationModal(stream, patientId, queueNumber) {
        const config = streamConfigs[stream];
        currentConfirmation = { stream, patientId, queueNumber, config };

        // Set flag BEFORE showing modal to prevent refresh race condition
        window.isStreamModalOpen = true;
        
        const modal = document.getElementById('streamConfirmationModal');
        document.getElementById('confirmationTitle').textContent = 
            stream === 'billing' ? 'Confirm Patient Reception' : 'Mark Patient On the Way';
        
        document.getElementById('confirmationMessage').textContent = 
            `Are you sure you want to ${stream === 'billing' ? 'confirm reception of' : 'mark on the way'} patient ${queueNumber}?`;
        
        document.getElementById('confirmationStatus').textContent = 
            `This will change status to "${config.status}"`;

        modal.classList.add('active');
        
        // Also pause main dashboard auto-refresh
        if (typeof window.stopAutoRefresh === 'function') {
            window.stopAutoRefresh();
        }
        if (window.refreshManager) {
            window.refreshManager.stopAutoRefresh();
        }
    }

    // Close confirmation modal
    function closeConfirmationModal() {
        const modal = document.getElementById('streamConfirmationModal');
        modal.classList.remove('active');
        currentConfirmation = null;
        
        // Clear flags to allow refresh to resume
        window.isStreamModalOpen = false;
        window.isModalOpen = false;
        
        // Do NOT call startAutoRefresh here - it causes cascade of refreshes
        // The stream polling (3-second interval) and dashboard refresh-manager are already running
        // Calling startAutoRefresh creates competing refresh cycles that cause flashing
        // Just let the normal polling handle updates when modal closes
    }

    // Handle confirmation
    document.getElementById('confirmationConfirmBtn').addEventListener('click', () => {
        if (!currentConfirmation) return;

        const { stream, patientId, config } = currentConfirmation;
        
        fetch(`stream.php?stream=${stream}&action=${config.action}&patient_id=${patientId}`)
            .then(response => response.json())
            .then(data => {
                console.log('Confirmation response:', data);
                if (data.success) {
                    closeConfirmationModal();
                    // Small delay to ensure server has processed
                    setTimeout(() => {
                        refreshStreams();
                        if (typeof refreshDashboard !== 'undefined') {
                            refreshDashboard();
                        }
                    }, 300);
                } else {
                    console.error('Action failed:', data.message);
                    closeConfirmationModal();
                    // Still refresh to show updated status
                    setTimeout(() => {
                        refreshStreams();
                        if (typeof refreshDashboard !== 'undefined') {
                            refreshDashboard();
                        }
                    }, 500);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                closeConfirmationModal();
                // Still refresh even on network error
                setTimeout(() => {
                    refreshStreams();
                    if (typeof refreshDashboard !== 'undefined') {
                        refreshDashboard();
                    }
                }, 500);
            });
    });

    // Modal close handlers - ensure buttons can be clicked
    function attachModalHandlers() {
        const cancelBtn = document.getElementById('confirmationCancelBtn');
        const closeBtn = document.getElementById('confirmationCloseBtn');
        const confirmModal = document.getElementById('streamConfirmationModal');
        
        // Use addEventListener for more reliable button handling
        if (cancelBtn) {
            // Remove any existing listeners first
            cancelBtn.removeEventListener('click', closeConfirmationModal);
            // Add new listener
            cancelBtn.addEventListener('click', closeConfirmationModal);
        }
        if (closeBtn) {
            closeBtn.removeEventListener('click', closeConfirmationModal);
            closeBtn.addEventListener('click', closeConfirmationModal);
        }
        
        // Also handle clicking outside the modal
        if (confirmModal) {
            confirmModal.removeEventListener('click', handleModalBackdropClick);
            confirmModal.addEventListener('click', handleModalBackdropClick);
        }
    }
    
    // Function to handle modal backdrop clicks
    function handleModalBackdropClick(e) {
        if (e.target.id === 'streamConfirmationModal') {
            closeConfirmationModal();
        }
    }
    
    // Attach handlers immediately and on page load
    attachModalHandlers();
    document.addEventListener('DOMContentLoaded', attachModalHandlers);

    // Initial load and polling
    refreshStreams();
    
    // Track if user is interacting with stream cards
    let isCardFocused = false;
    let cardFocusCooldownTimeout = null;
    
    // Attach focus tracking to the entire stream cards container
    // This uses event delegation to handle both existing and dynamically created cards
    const streamCardsContainer = document.querySelector('.stream-grid') || document.querySelector('[class*="stream"]');
    
    if (streamCardsContainer) {
        streamCardsContainer.addEventListener('mouseenter', (e) => {
            // Check if the event target or its parent is a stream card
            const card = e.target.closest('.stream-card-compact');
            if (card) {
                isCardFocused = true;
                // Clear any existing cooldown
                if (cardFocusCooldownTimeout) {
                    clearTimeout(cardFocusCooldownTimeout);
                }
                // Keep refresh paused for at least 5 seconds after user interacts
                cardFocusCooldownTimeout = setTimeout(() => {
                    isCardFocused = false;
                    cardFocusCooldownTimeout = null;
                }, 5000);
            }
        }, true); // Use capture phase
        
        streamCardsContainer.addEventListener('mouseleave', (e) => {
            const card = e.target.closest('.stream-card-compact');
            if (card) {
                isCardFocused = false;
                if (cardFocusCooldownTimeout) {
                    clearTimeout(cardFocusCooldownTimeout);
                    cardFocusCooldownTimeout = null;
                }
            }
        }, true); // Use capture phase
    }
    
    // Also attach listeners directly to initial stream cards as backup
    const streamCards = document.querySelectorAll('.stream-card-compact');
    
    streamCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            isCardFocused = true;
            if (cardFocusCooldownTimeout) {
                clearTimeout(cardFocusCooldownTimeout);
            }
            cardFocusCooldownTimeout = setTimeout(() => {
                isCardFocused = false;
                cardFocusCooldownTimeout = null;
            }, 5000);
        });
        card.addEventListener('mouseleave', () => {
            isCardFocused = false;
            if (cardFocusCooldownTimeout) {
                clearTimeout(cardFocusCooldownTimeout);
                cardFocusCooldownTimeout = null;
            }
        });
        
        // Use event delegation for ticket clicks
        card.addEventListener('click', (e) => {
            const ticket = e.target.closest('.ticket-number-compact');
            if (ticket) {
                e.preventDefault();
                e.stopPropagation();
                const patientId = ticket.dataset.patientId;
                const queueNumber = ticket.textContent.trim();
                
                // Determine which stream this card belongs to
                let stream = null;
                if (card.id === 'labStreamCompact' || card.classList.contains('lab-card')) {
                    stream = 'lab';
                } else if (card.id === 'imgStreamCompact' || card.classList.contains('imaging-card')) {
                    stream = 'imaging';
                } else if (card.id === 'billingStreamCompact' || card.classList.contains('billing-card')) {
                    stream = 'billing';
                } else if (card.id === 'clinicsStreamCompact' || card.classList.contains('clinics-card')) {
                    stream = 'clinics';
                }
                
                if (stream) {
                    showConfirmationModal(stream, patientId, queueNumber);
                }
            }
        }, true); // Use capture phase for better event handling
    });
    
    // Smart refresh guard function - checks all conditions before allowing refresh
    function shouldRefreshStreams() {
        // Never refresh if page is hidden
        if (document.hidden) return false;
        
        // Never refresh if stream modal is open
        if (window.isStreamModalOpen === true) return false;
        
        // Never refresh if main dashboard modal is open
        if (window.isModalOpen === true) return false;
        
        // Never refresh if card is focused/hovered
        if (isCardFocused) return false;
        
        // Never refresh if any menu/details is open
        if (document.querySelector('details[open]') !== null) return false;
        
        // Never refresh if confirmation modal has active class
        const modal = document.getElementById('streamConfirmationModal');
        if (modal && modal.classList.contains('active')) return false;
        
        return true;
    }
    
    // Single, well-managed polling interval
    // Increased to 3 seconds to give users time to click on stream cards
    // (butler.php auto-refresh is disabled to prevent conflicting refresh cycles)
    window.streamRefreshInterval = setInterval(() => {
        if (shouldRefreshStreams()) {
            refreshStreams();
        }
    }, 3000); // Check and refresh every 3 seconds if conditions allow

    // --- Server-Sent Events integration: prefer push updates over polling ---
    // Use SSE to reduce polling load. When SSE is active we stop the interval.
    (function setupSseForStreams() {
        if (!window.EventSource) return; // SSE not supported

        let sse = null;
        let sseReconnectTimer = null;

        function startSse() {
            try {
                sse = new EventSource('realtime_updates.php?stream=all');

                sse.addEventListener('status_update', (evt) => {
                    try {
                        const data = JSON.parse(evt.data);
                        // Decide which compact streams to refresh based on flags
                        if (data.lab) refreshSingleStream('lab');
                        if (data.img) refreshSingleStream('imaging');
                        if (data.cl) refreshSingleStream('clinics');
                        // Billing updates may come through other actions
                        if (data.action && data.action.toLowerCase().includes('billing')) refreshSingleStream('billing');
                    } catch (e) {
                        console.error('SSE status_update parse error:', e);
                        // fallback: refresh all streams
                        refreshStreams();
                    }
                });

                sse.addEventListener('machine_assignment', (evt) => {
                    try {
                        const data = JSON.parse(evt.data);
                        if (data.machine || data.imaging_machine) {
                            refreshSingleStream('imaging');
                        } else {
                            refreshStreams();
                        }
                    } catch (e) {
                        console.error('SSE machine_assignment parse error:', e);
                        refreshStreams();
                    }
                });

                sse.addEventListener('heartbeat', () => {
                    // no-op; keep connection alive
                });

                sse.onerror = function(err) {
                    console.error('SSE stream error:', err);
                    if (sse) {
                        try { sse.close(); } catch (e) {}
                        sse = null;
                    }
                    // restore polling fallback
                    if (!window.streamRefreshInterval) {
                        window.streamRefreshInterval = setInterval(() => {
                            if (shouldRefreshStreams()) refreshStreams();
                        }, 3000);
                    }
                    // try reconnect after delay
                    if (sseReconnectTimer) clearTimeout(sseReconnectTimer);
                    sseReconnectTimer = setTimeout(() => startSse(), 5000);
                };

                // SSE opened successfully: stop polling to avoid duplicate work
                sse.onopen = function() {
                    console.info('SSE for streams opened');
                    if (window.streamRefreshInterval) {
                        clearInterval(window.streamRefreshInterval);
                        window.streamRefreshInterval = null;
                    }
                };
            } catch (e) {
                console.error('Failed to start SSE for streams:', e);
                // ensure polling fallback
                if (!window.streamRefreshInterval) {
                    window.streamRefreshInterval = setInterval(() => {
                        if (shouldRefreshStreams()) refreshStreams();
                    }, 3000);
                }
            }
        }

        // Helper to refresh a single compact stream
        function refreshSingleStream(stream) {
            if (!streamConfigs[stream]) return;
            // Respect shouldRefreshStreams guard
            if (!shouldRefreshStreams()) return;

            fetch(`stream.php?mode=compact_content&stream=${stream}&t=${Date.now()}`)
                .then(response => {
                    if (!response.ok) throw new Error(`HTTP ${response.status}`);
                    return response.text();
                })
                .then(html => {
                    const container = document.getElementById(streamConfigs[stream].id);
                    if (container) {
                        container.innerHTML = html;
                        attachStreamHandlers(stream);
                        const card = container.closest('.stream-card-compact');
                        const hasPatient = container.querySelector('.ticket-number-compact') !== null;
                        if (card) {
                            if (hasPatient) card.classList.add('has-patient'); else card.classList.remove('has-patient');
                        }
                        setTimeout(adjustCardSizing, 100);
                    }
                })
                .catch(err => {
                    console.error(`Error refreshing single stream ${stream}:`, err);
                });
        }

        startSse();
    })();
    
    // Ensure polling continues when page becomes visible
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden && !window.streamRefreshInterval) {
            window.streamRefreshInterval = setInterval(() => {
                if (shouldRefreshStreams()) {
                    refreshStreams();
                }
            }, 3000);
        }
    });

</script>
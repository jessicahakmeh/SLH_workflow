<?php
// clinics.php - Clinics Dashboard (assignment + per-clinic queue with billing-style routing)
require_once 'config.php';
session_start();
require_once 'department_helpers.php';
authRequireRoles(['billing', 'admin'], ['log_view' => false]);

$clinics = ['Misc', 'ENT-URO', 'OBGYN', 'Cardio', 'OPS', 'PAU'];
$current_clinic = $_GET['clinic'] ?? '';

// =====================================================================
// POST HANDLERS
// =====================================================================

// --- Assign clinic to waiting patient ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_clinic'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinics_selected = isset($_POST['clinics'])
        ? array_values(array_filter($_POST['clinics'], fn($c) => !empty($c) && in_array($c, $clinics)))
        : [];

    if (!empty($clinics_selected)) {
        $originalPatient = executeAndFetchOne($pdo, "SELECT t.*, p.patient_id, p.patient_name, p.mrn, p.mobile, p.email, p.address FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);

        if ($originalPatient) {
            $queueNum = $originalPatient['queue_number'];
            $existingClinics = executeAndFetch($pdo, "
                SELECT DISTINCT Clinic FROM tickets
                WHERE queue_number = ? AND Clinic IS NOT NULL AND closing_timestamp IS NULL
            ", [$queueNum]);
            $existingClinics = array_map(fn($r) => $r['Clinic'], $existingClinics);

            $clinics_selected = array_values(array_filter($clinics_selected, fn($c) => !in_array($c, $existingClinics)));

            if (empty($clinics_selected)) {
                $_SESSION['clinics_message'] = "All selected clinics are already assigned to this patient's queue.";
                header('Location: clinics.php?clinic=' . urlencode($current_clinic));
                exit();
            }

            $firstClinic = $clinics_selected[0];
            executeUpdate($pdo, "UPDATE tickets SET Clinic = ?, service_type = 'Clinics', cl = 1 WHERE ticket_id = ?", [$firstClinic, $patient_id]);

            executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Assigned to Clinic', 'Waiting', 'Waiting', ?, ?)", [$patient_id, $firstClinic, "Patient assigned to $firstClinic"]);

            for ($i = 1; $i < count($clinics_selected); $i++) {
                $clinicName = $clinics_selected[$i];
                executeUpdate($pdo, "INSERT INTO tickets (
                    patient_id, queue_number, service_type, current_status, arrival_timestamp, approval_timestamp, cl, Clinic,
                    registered_by_username, assigned_butler_username,
                    last_need_request_by_username, last_need_request_at,
                    is_existing_patient, demographics_snapshot, demographics_edited, demographics_changed_fields
                ) VALUES (?, ?, 'Clinics', 'Waiting', ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
                    $originalPatient['patient_id'],
                    $originalPatient['queue_number'],
                    $originalPatient['arrival_timestamp'],
                    $originalPatient['approval_timestamp'],
                    $clinicName,
                    $originalPatient['registered_by_username'] ?? null,
                    $originalPatient['assigned_butler_username'] ?? null,
                    $originalPatient['last_need_request_by_username'] ?? null,
                    $originalPatient['last_need_request_at'] ?? null,
                    $originalPatient['is_existing_patient'] ?? 0,
                    $originalPatient['demographics_snapshot'] ?? null,
                    $originalPatient['demographics_edited'] ?? 0,
                    $originalPatient['demographics_changed_fields'] ?? null
                ]);
                
                $newId = $pdo->lastInsertId();
                executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Assigned to Clinic', 'Waiting', 'Waiting', ?, ?)", [$newId, $clinicName, "Duplicate ticket assigned to $clinicName"]);
            }
        }

        $_SESSION['clinics_message'] = "Patient assigned successfully!";
        header('Location: clinics.php?clinic=' . urlencode($current_clinic));
        exit();
    }

    $_SESSION['clinics_message'] = "Please select at least one valid clinic";
    header('Location: clinics.php?clinic=' . urlencode($current_clinic));
    exit();
}

// --- Transfer to Department: set In Process → redirect to scan_docs ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['transfer_to_department'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'In Process', approval_timestamp = NOW() WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'Waiting',
        'In Process',
        'Transferred to Department',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Transfer to Department', ?, 'In Process', ?, 'Transferred to department via scan docs')", [$patient_id, $current['current_status'] ?? 'Unknown', $current['Clinic']]);

    $redirectUrl = 'scan_docs.php?from=clinics&patient_id=' . $patient_id;
    if (!empty($clinic)) {
        $redirectUrl .= '&clinic=' . urlencode($clinic);
    }
    header('Location: ' . $redirectUrl);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['start_patient'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'Served' WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'Called',
        'Served',
        'Started Consultation',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Started Consultation', ?, 'Served', ?, 'Consultation started in clinics')", [$patient_id, $current['current_status'] ?? 'Called', $current['Clinic'] ?? $clinic]);

    $_SESSION['clinics_message'] = 'Consultation started successfully!';
    header('Location: clinics.php?clinic=' . urlencode($clinic));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['complete_patient'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'Completed', closing_timestamp = NOW() WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'Served',
        'Completed',
        'Completed in Clinics',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Completed in Clinics', ?, 'Completed', ?, 'Clinic consultation completed')", [$patient_id, $current['current_status'] ?? 'Served', $current['Clinic'] ?? $clinic]);

    $_SESSION['clinics_message'] = 'Patient completed successfully!';
    header('Location: clinics.php?clinic=' . urlencode($clinic));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_to_lab'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'Waiting', lab = 1, img = 0, dp2 = 0, cl = 0, imaging_machine = NULL WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'In Process',
        'Waiting',
        'Sent to Lab',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Sent to Lab', ?, 'Waiting', ?, 'Sent to Laboratory from clinics')", [$patient_id, $current['current_status'] ?? 'In Process', $current['Clinic'] ?? $clinic]);

    $_SESSION['clinics_message'] = 'Patient sent to Laboratory!';
    header('Location: clinics.php?clinic=' . urlencode($clinic));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_to_imaging'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'Waiting', img = 1, lab = 0, dp2 = 0, cl = 0, imaging_machine = NULL WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'In Process',
        'Waiting',
        'Sent to Imaging',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Sent to Imaging', ?, 'Waiting', ?, 'Sent to Imaging from clinics')", [$patient_id, $current['current_status'] ?? 'In Process', authCurrentUserId() ?: null]);

    $_SESSION['clinics_message'] = 'Patient sent to Imaging!';
    header('Location: clinics.php?clinic=' . urlencode($clinic));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_to_both'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'Waiting', lab = 1, img = 1, dp2 = 0, cl = 0, imaging_machine = NULL WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'In Process',
        'Waiting',
        'Sent to Both',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Sent to Both', ?, 'Waiting', ?, 'Sent to both Lab and Imaging from clinics')", [$patient_id, $current['current_status'] ?? 'In Process', $current['Clinic'] ?? $clinic]);

    $_SESSION['clinics_message'] = 'Patient sent to Lab and Imaging!';
    header('Location: clinics.php?clinic=' . urlencode($clinic));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_to_clinics'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'Waiting', service_type = 'Clinics', cl = 1, Clinic = NULL, lab = 0, img = 0, dp2 = 0, imaging_machine = NULL WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'In Process',
        'Waiting',
        'Sent to Clinics',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Sent to Clinics', ?, 'Waiting', ?, 'Returned to clinics assignment')", [$patient_id, $current['current_status'] ?? 'In Process', $current['Clinic'] ?? $clinic]);

    $_SESSION['clinics_message'] = 'Patient sent back to clinic assignments!';
    header('Location: clinics.php?clinic=' . urlencode($clinic));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancel_ticket'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'Canceled', closing_timestamp = NOW() WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'In Process',
        'Canceled',
        'Canceled in Clinics',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Canceled in Clinics', ?, 'Canceled', ?, 'Ticket canceled from clinics queue')", [$patient_id, $current['current_status'] ?? 'In Process', $current['Clinic'] ?? $clinic]);

    $_SESSION['clinics_message'] = 'Ticket canceled!';
    header('Location: clinics.php?clinic=' . urlencode($clinic));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['need_patient'])) {
    $patient_id = intval($_POST['patient_id']);

    $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

    $currentUser = authCurrentUser();
    $requestedByUserId = authCurrentUserId();
    $requestedByUsername = '';
    if (is_array($currentUser)) {
        $requestedByUsername = trim((string)($currentUser['full_name'] ?? ''));
        if ($requestedByUsername === '') {
            $requestedByUsername = trim((string)($currentUser['username'] ?? ''));
        }
    }
    if ($requestedByUsername === '') {
        $requestedByUsername = authCurrentUsername();
    }
    $requestedByUsername = trim((string)$requestedByUsername);

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic, assigned_butler_username, registered_by_username FROM tickets WHERE ticket_id = ?", [$patient_id]);

    $assignedButlerUsername = trim((string)($current['assigned_butler_username'] ?? ''));
    if ($assignedButlerUsername === '') {
        $assignedButlerUsername = null;
    }

    if ($assignedButlerUsername === null) {
        $fallbackName = trim((string)($current['registered_by_username'] ?? ''));
        $assignedButlerUsername = $fallbackName !== '' ? $fallbackName : null;
    }

    executeUpdate($pdo, "UPDATE tickets
                           SET current_status = 'Needed by Billing',
                               last_need_request_by_username = ?,
                               last_need_request_at = NOW(),
                               assigned_butler_username = ?
                           WHERE ticket_id = ?", [
        $requestedByUsername !== '' ? $requestedByUsername : null,
        $assignedButlerUsername,
        $patient_id
    ]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'In Process',
        'Needed by Billing',
        'Needed by Billing',
        'clinics'
    );

    $logRequester = $requestedByUsername !== '' ? $requestedByUsername : 'Unknown user';
    $logButler = $assignedButlerUsername !== null ? $assignedButlerUsername : 'Unassigned';
    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Needed by Billing', ?, 'Needed by Billing', ?, ?)", [$patient_id, $current['current_status'] ?? 'In Process', $current['Clinic'] ?? null, 'Patient requested at billing from clinics by ' . $logRequester . ' | Assigned butler: ' . $logButler]);

    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Patient marked as Needed by Billing']);
        exit();
    }

    $_SESSION['clinics_message'] = "Patient marked as 'Needed by Billing'!";
    header('Location: clinics.php?clinic=' . urlencode($current_clinic));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_return'])) {
    $patient_id = intval($_POST['patient_id']);
    $clinic = $_POST['clinic'] ?? $current_clinic;

    $current = executeAndFetchOne($pdo, "SELECT current_status, Clinic FROM tickets WHERE ticket_id = ?", [$patient_id]);

    executeUpdate($pdo, "UPDATE tickets SET current_status = 'In Process', lab = 0, img = 0, dp2 = 0 WHERE ticket_id = ?", [$patient_id]);

    saveUndoState(
        $pdo,
        $patient_id,
        $current['current_status'] ?? 'Needed by Billing',
        'In Process',
        'Patient Returned',
        'clinics'
    );

    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, Clinic, notes) VALUES (?, 'Patient Returned', ?, 'In Process', ?, 'Patient returned from billing to clinics')", [$patient_id, $current['current_status'] ?? 'Needed by Billing', $current['Clinic'] ?? $clinic]);

    $_SESSION['clinics_message'] = "Patient returned to 'In Process'!";
    header('Location: clinics.php?clinic=' . urlencode($clinic));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clinics Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="imaging_clinics.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="browser-notifications.js"></script>
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <div class="clinics-container">
        <!-- HEADER -->
        <div class="clinics-header">
            <h1>
                <i class="fas fa-clinic-medical"></i> Clinics Dashboard
            </h1>
            <a href="new_ticket.php?from=clinics">
                <i class="fas fa-plus-circle"></i> New Patient
            </a>
        </div>

        <!-- Success Message -->
        <?php if (isset($_SESSION['clinics_message'])): ?>
            <div class="success-message" id="successMessage">
                <span><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['clinics_message']); ?></span>
                <button class="close-message" onclick="this.parentElement.style.display='none'">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <?php unset($_SESSION['clinics_message']); ?>
        <?php endif; ?>

        <!-- MAIN WRAPPER (30/70 split) -->
        <div class="clinics-wrapper">

            <!-- LEFT PANEL: Clinic Assignments (30%) -->
            <div class="assignments-panel">
                <div class="assignments-panel-header">
                    <i class="fas fa-tasks"></i> Clinic Assignments
                </div>
                <div class="assignments-list" id="assignmentsList">
                    <?php
                    $unassigned = executeAndFetch($pdo, "
                        SELECT t.ticket_id AS id, t.queue_number, p.patient_name, p.mrn, t.Clinic
                        FROM tickets t
                        JOIN patients p ON t.patient_id = p.patient_id
                        WHERE t.current_status IN ('Waiting')
                            AND t.cl = 1
                            AND t.Clinic IS NULL
                            AND t.closing_timestamp IS NULL
                            AND DATE(t.arrival_timestamp) = CURDATE()
                        ORDER BY t.arrival_timestamp ASC
                    LIMIT 20
                    ", []);

                    if (empty($unassigned)):
                    ?>
                        <div class="empty-state">
                            <i class="fas fa-check-circle"></i>
                            <h3>All Assigned</h3>
                            <p>No patients awaiting clinic assignment</p>
                        </div>
                    <?php else:
                        foreach ($unassigned as $patient):
                    ?>
                        <div class="assignment-item">
                            <div class="assignment-item-header">
                                <div class="patient-name">
                                    <button class="view-pdf-btn" data-patient='<?php echo htmlspecialchars(json_encode([
                                        'id' => $patient['id'],
                                        'queue_number' => $patient['queue_number'],
                                        'patient_name' => $patient['patient_name'],
                                        'mrn' => $patient['mrn'] ?? ''
                                    ]), ENT_QUOTES, 'UTF-8'); ?>' style="background:none;border:none;padding:0;font-size:inherit;cursor:pointer;color:inherit;font-weight:inherit;text-align:left;">
                                        <?php echo htmlspecialchars($patient['patient_name']); ?>
                                    </button>
                                </div>
                                <div class="queue-number"><?php echo htmlspecialchars($patient['queue_number']); ?></div>
                            </div>
                            <form method="POST" class="assignment-form" data-patient-id="<?php echo $patient['id']; ?>">
                                <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                <div class="clinic-selections" style="display:flex;flex-direction:column;gap:12px;">
                                    <div class="clinic-select-group" style="display:flex;gap:12px;align-items:center;">
                                        <select name="clinics[]" class="clinic-select" required style="flex:1;">
                                            <option value="">Select clinic...</option>
                                            <?php foreach ($clinics as $c): ?>
                                                <option value="<?php echo $c; ?>"> <?php echo $c; ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button type="button" class="remove-clinic-btn" style="display:none;padding:8px 12px;border-radius:10px;background:linear-gradient(135deg,#e74c3c,#c0392b);color:white;border:none;cursor:pointer;">-</button>
                                    </div>
                                </div>
                                <div style="display:flex;gap:12px;margin-top:16px;">
                                    <input type="hidden" name="department" value="clinics">
                                    <input type="hidden" name="action" value="wrong_info">
                                    <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic ?? ''); ?>">
                                    <button type="button" class="add-clinic-btn" style="background:linear-gradient(135deg,#9b59b6,#8e44ad);color:white;border:none;padding:12px 16px;border-radius:10px;font-weight:700;">
                                        <i class="fas fa-plus"></i> Add
                                    </button>
                                    <button type="submit" name="assign_clinic" style="background:linear-gradient(135deg,#27ae60,#219653);color:white;border:none;padding:12px 16px;border-radius:10px;font-weight:700;">
                                        <i class="fas fa-check"></i> Assign Clinics
                                    </button>
                                    <button type="submit"
                                            formaction="patient_actions.php"
                                            formmethod="POST"
                                            formnovalidate
                                            name="wrong_info_from_assignment"
                                            title="Send back to Billing as Wrong Info"
                                            style="background:linear-gradient(135deg,#e74c3c,#c0392b);color:white;border:none;padding:12px 16px;border-radius:10px;font-weight:700;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </form>
                        </div>
                    <?php
                        endforeach;
                    endif;
                    ?>
                </div>
            </div>

            <!-- RIGHT PANEL: Clinic Queue (70%) -->
            <div class="queue-panel">
                <!-- Clinic Tabs with Icons -->
                <div class="clinic-tabs" id="clinicTabs">
                    <?php foreach ($clinics as $c): ?>
                        <button class="clinic-tab <?php echo $c === $current_clinic ? 'active' : ''; ?>"
                                onclick="window.location.href='clinics.php?clinic=<?php echo urlencode($c); ?>'"
                                title="<?php echo $c; ?> Queue">
                            <?php echo $c; ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <?php if ($current_clinic): ?>
                    <?php
                    // Stats
                    $stats = executeAndFetchOne($pdo, "
                        SELECT
                            COUNT(CASE WHEN t.current_status = 'Waiting' THEN 1 END)            AS waiting,
                            COUNT(CASE WHEN t.current_status IN ('Called','Recalled') THEN 1 END) AS called,
                            COUNT(CASE WHEN t.current_status IN ('Served','In Process') THEN 1 END) AS in_process,
                            COUNT(CASE WHEN t.current_status = 'Needed by Billing' THEN 1 END)  AS needed,
                            COUNT(*) as total
                        FROM tickets t
                        WHERE t.Clinic = ?
                            AND t.closing_timestamp IS NULL
                            AND t.cl = 1
                            AND DATE(t.arrival_timestamp) = CURDATE()
                    ", [$current_clinic]);

                    // Queue patients
                    $patients = executeAndFetch($pdo, "
                        SELECT t.ticket_id AS id, t.queue_number, p.patient_name, p.mrn, p.mobile,
                                     p.country_code, p.care_mobile, p.care_country_code, p.email, p.address,
                                     t.service_type, t.current_status, t.arrival_timestamp, t.approval_timestamp, t.Clinic,
                                     t.is_existing_patient, t.demographics_edited, t.demographics_changed_fields
                        FROM tickets t
                        JOIN patients p ON t.patient_id = p.patient_id
                        WHERE t.closing_timestamp IS NULL
                            AND DATE(t.arrival_timestamp) = CURDATE()
                            AND (
                                (
                                    t.Clinic = ?
                                    AND t.current_status IN ('Waiting','Called','Skipped','Recalled','On Hold','Served','In Process','Needed by Billing','Wrong Info')
                                    AND t.cl = 1
                                )
                                OR
                                (
                                    t.service_type = 'Billing'
                                    AND t.current_status = 'In Process'
                                )
                                OR
                                (
                                    t.service_type = 'Clinics'
                                    AND t.current_status = 'Wrong Info'
                                )
                            )
                        ORDER BY t.approval_timestamp ASC
                    ", [$current_clinic]);
                    ?>

                    <!-- Enhanced Stats Grid (Imaging-style) -->
                    <div class="clinic-stats">
                        <div class="stat-card" title="Total patients in <?php echo htmlspecialchars($current_clinic); ?>">
                            <div class="stat-number"><?php echo $stats['total']; ?></div>
                            <div class="stat-label"><i class="fas fa-users"></i> Total</div>
                        </div>
                        <div class="stat-card" title="Waiting to be called">
                            <div class="stat-number"><?php echo $stats['waiting']; ?></div>
                            <div class="stat-label"><i class="fas fa-clock"></i> Waiting</div>
                        </div>
                        <div class="stat-card" title="Called/Recalled patients">
                            <div class="stat-number"><?php echo $stats['called']; ?></div>
                            <div class="stat-label"><i class="fas fa-phone"></i> Called</div>
                        </div>
                        <div class="stat-card" title="In consultation">
                            <div class="stat-number"><?php echo $stats['in_process']; ?></div>
                            <div class="stat-label"><i class="fas fa-user-md"></i> In Progress</div>
                        </div>
                        <div class="stat-card" title="Needs billing intervention">
                            <div class="stat-number"><?php echo $stats['needed']; ?></div>
                            <div class="stat-label"><i class="fas fa-exclamation-triangle"></i> Needed</div>
                        </div>
                    </div>

                    <?php if (empty($patients)): ?>
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h3>No patients in <?php echo htmlspecialchars($current_clinic); ?> queue</h3>
                            <p>Assign patients from the left panel or wait for new arrivals</p>
                        </div>
                    <?php else: ?>
                        <div class="queue-table-container" id="clinicsQueueTable">
                            <table class="queue-table">
                                <thead>
                                    <tr>
                                        <th>Details</th>
                                        <th>Queue #</th>
                                        <th>Patient Name</th>
                                        <th>Type</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($patients as $patient):
                                        $status = $patient['current_status'];
                                        $pid    = $patient['id'];
                                        $sc     = 'status-' . strtolower(str_replace(' ', '-', $status));
                                        $type_class = 'type-' . strtolower($patient['service_type']);
                                    ?>
                                    <tr>
                                        <td>
                                            <button type="button" class="view-details-btn" data-patient='<?php echo htmlspecialchars(json_encode([
                                                'id' => $patient['id'],
                                                'queue_number' => $patient['queue_number'],
                                                'patient_name' => $patient['patient_name'],
                                                'mrn' => $patient['mrn'] ?? '',
                                                'mobile' => $patient['mobile'] ?? '',
                                                'country_code' => $patient['country_code'] ?? '',
                                                'care_mobile' => $patient['care_mobile'] ?? '',
                                                'care_country_code' => $patient['care_country_code'] ?? '',
                                                'email' => $patient['email'] ?? '',
                                                'address' => $patient['address'] ?? '',
                                                'is_existing_patient' => $patient['is_existing_patient'] ?? 0,
                                                'demographics_edited' => $patient['demographics_edited'] ?? 0,
                                                'demographics_changed_fields' => $patient['demographics_changed_fields'] ?? null,
                                                'type' => $patient['service_type'],
                                                'status' => $patient['current_status'],
                                                'arrival_timestamp' => $patient['arrival_timestamp'] ?? null,
                                                'approval_timestamp' => $patient['approval_timestamp'] ?? null
                                            ]), ENT_QUOTES, 'UTF-8'); ?>'>
                                                <i class="fas fa-eye"></i> Details
                                            </button>
                                        </td>
                                        <td class="queue-number-cell" style="font-weight:bold;color:#2c3e50;"><?php echo htmlspecialchars($patient['queue_number']); ?></td>
                                        <td class="patient-name-cell">
                                            <button class="view-pdf-btn" data-patient='<?php echo htmlspecialchars(json_encode([
                                                'id' => $patient['id'],
                                                'queue_number' => $patient['queue_number'],
                                                'patient_name' => $patient['patient_name'],
                                                'mrn' => $patient['mrn'] ?? ''
                                            ]), ENT_QUOTES, 'UTF-8'); ?>' style="background:none;border:none;padding:0;font-size:inherit;cursor:pointer;color:inherit;text-align:left;">
                                                <?php echo htmlspecialchars($patient['patient_name']); ?>
                                            </button>
                                        </td>
                                        <td>
                                            <span class="type-badge <?php echo $type_class; ?>">
                                                <?php echo htmlspecialchars($patient['service_type']); ?>
                                            </span>
                                        </td>
                                        <td><span class="status-badge <?php echo $sc; ?>"><?php echo htmlspecialchars($status); ?></span></td>
                                        <td>
                                            <?php if ($status === 'Waiting'): ?>
                                                <div class="action-buttons">
                                                <div class="action-grid">
                                                    <form method="POST" action="patient_actions.php" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="department" value="clinics">
                                                        <input type="hidden" name="action" value="call_patient">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button class="action-btn btn-call action-btn-full" title="Call patient to clinic"><i class="fas fa-phone"></i> Call</button>
                                                    </form>
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="transfer_to_department" class="action-btn btn-start action-btn-full" title="Transfer to department scan docs">
                                                            <i class="fas fa-paper-plane"></i> Transfer Dept
                                                        </button>
                                                    </form>
                                                </div>
                                                </div>
                                            <?php elseif (in_array($status, ['Called', 'Recalled'])): ?>
                                                <div class="action-buttons">
                                                <div class="action-grid">
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="start_patient" class="action-btn btn-start action-btn-full" title="Begin consultation"><i class="fas fa-play"></i> Start</button>
                                                    </form>
                                                    <form method="POST" action="patient_actions.php" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="department" value="clinics">
                                                        <input type="hidden" name="action" value="skip">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button class="action-btn btn-skip action-btn-full" title="Skip this patient"><i class="fas fa-step-forward"></i> Skip</button>
                                                    </form>
                                                </div>
                                                </div>
                                            <?php elseif (in_array($status, ['Skipped', 'On Hold'])): ?>
                                                <div class="action-buttons">
                                                <div class="action-grid">
                                                    <form method="POST" action="patient_actions.php" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="department" value="clinics">
                                                        <input type="hidden" name="action" value="recall">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button class="action-btn btn-call action-btn-full" title="Call patient again"><i class="fas fa-undo"></i> Recall</button>
                                                    </form>
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="transfer_to_department" class="action-btn btn-start action-btn-full" title="Transfer to department scan docs">
                                                            <i class="fas fa-paper-plane"></i> Transfer Dept
                                                        </button>
                                                    </form>
                                                </div>
                                                </div>
                                            <?php elseif ($status === 'Served'): ?>
                                                <div class="action-buttons">
                                                <div class="action-grid">
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="complete_patient" class="action-btn btn-start action-btn-full" title="Mark consultation complete"><i class="fas fa-check-circle"></i> Complete</button>
                                                    </form>
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="transfer_to_department" class="action-btn btn-start action-btn-full" title="Transfer to department scan docs">
                                                            <i class="fas fa-paper-plane"></i> Transfer Dept
                                                        </button>
                                                    </form>
                                                </div>
                                                </div>
                                            <?php elseif ($status === 'In Process' || $status === 'Wrong Info'): ?>
                                                <div class="action-buttons">
                                                <div class="action-grid">
                                                    <button type="button" class="action-btn btn-butler action-btn-full"
                                                            onclick="needButler(<?php echo $pid; ?>, '<?php echo htmlspecialchars($current_clinic); ?>')" title="Request billing assistance">
                                                        <i class="fas fa-user"></i> Need Butler
                                                    </button>
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="send_to_lab" class="action-btn btn-lab action-btn-full" title="Send to Laboratory"><i class="fas fa-flask"></i> Send to LAB</button>
                                                    </form>
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="send_to_imaging" class="action-btn btn-imaging action-btn-full" title="Send to Imaging"><i class="fas fa-x-ray"></i> Send to Imaging</button>
                                                    </form>
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="send_to_both" class="action-btn btn-both action-btn-full" title="Send to Lab + Imaging"><i class="fas fa-exchange-alt"></i> Send to BOTH</button>
                                                    </form>
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="send_to_clinics" class="action-btn btn-clinic action-btn-full" title="Back to clinics assignment"><i class="fas fa-clinic-medical"></i> Send to Clinics</button>
                                                    </form>
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="cancel_ticket" class="action-btn btn-cancel action-btn-full" title="Cancel ticket"
                                                                onclick="return confirm('Cancel this ticket?')">
                                                            <i class="fas fa-times"></i> Cancel
                                                        </button>
                                                    </form>
                                                </div>
                                                </div>
                                            <?php elseif ($status === 'Needed by Billing'): ?>
                                                <div class="action-buttons">
                                                <div class="action-grid">
                                                    <form method="POST" class="action-form">
                                                        <input type="hidden" name="patient_id" value="<?php echo $pid; ?>">
                                                        <input type="hidden" name="clinic" value="<?php echo htmlspecialchars($current_clinic); ?>">
                                                        <button type="submit" name="confirm_return" class="action-btn btn-start action-btn-full" title="Patient returned from billing"><i class="fas fa-check-circle"></i> Patient Released</button>
                                                    </form>
                                                </div>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-clinic-medical"></i>
                        <h3>Select a Clinic</h3>
                        <p>Click a clinic tab above to view/manage its patient queue</p>
                    </div>
                <?php endif; ?>

            </div><!-- /queue-panel -->
        </div><!-- /clinics-wrapper -->
    </div><!-- /clinics-container -->

        <!-- Patient Details Modal -->
        <div class="patient-modal" id="patientModal">
            <div class="patient-modal-content">
                <div class="patient-modal-header">
                    <div class="patient-modal-title">
                        <i class="fas fa-user"></i> Patient Details
                    </div>
                    <button class="patient-modal-close" onclick="closePatientModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="patient-modal-body" id="patientModalBody"></div>
            </div>
        </div>

    <script>
        const CLINICS_NOTIFICATION_PAGE = 'Clinics';

        function getClinicsNotificationKey() {
            const clinic = <?php echo json_encode($current_clinic); ?>;
            return `clinics:${clinic || 'all'}`;
        }

        function getClinicsWrongInfoNotificationKey() {
            const clinic = <?php echo json_encode($current_clinic); ?>;
            return `clinics:wrong-info:${clinic || 'all'}`;
        }

        function collectClinicsTicketsFromDom(doc = document) {
            const rows = doc.querySelectorAll('#clinicsQueueTable tbody tr');
            return Array.from(rows).map(row => {
                const patientInput = row.querySelector('input[name="patient_id"]');
                const queueCell = row.querySelector('.queue-number-cell');
                const patientCell = row.querySelector('.patient-name-cell');
                return {
                    id: patientInput ? patientInput.value : '',
                    queueNumber: queueCell ? queueCell.textContent.trim() : '',
                    patientName: patientCell ? patientCell.textContent.trim() : '',
                    message: `${queueCell ? queueCell.textContent.trim() : ''} - ${patientCell ? patientCell.textContent.trim() : ''}`
                };
            }).filter(item => item.id);
        }

        function collectClinicsWrongInfoTicketsFromDom(doc = document) {
            const rows = doc.querySelectorAll('#clinicsQueueTable tbody tr');
            return Array.from(rows).map(row => {
                const statusBadge = row.querySelector('.status-badge');
                const statusText = statusBadge ? statusBadge.textContent.trim() : '';
                if (statusText !== 'Wrong Info') {
                    return null;
                }

                const patientInput = row.querySelector('input[name="patient_id"]');
                const queueCell = row.querySelector('.queue-number-cell');
                const patientCell = row.querySelector('.patient-name-cell');

                return {
                    id: patientInput ? patientInput.value : '',
                    queueNumber: queueCell ? queueCell.textContent.trim() : '',
                    patientName: patientCell ? patientCell.textContent.trim() : '',
                    message: `${queueCell ? queueCell.textContent.trim() : ''} - ${patientCell ? patientCell.textContent.trim() : ''}`
                };
            }).filter(item => item && item.id);
        }

        function notifyNewClinicsTickets(doc = document) {
            if (!window.QueueNotifications || !<?php echo json_encode(!empty($current_clinic)); ?>) {
                return;
            }

            QueueNotifications.notifyForNewTickets({
                pageKey: getClinicsNotificationKey(),
                items: collectClinicsTicketsFromDom(doc),
                title: 'New clinics ticket',
                getBody: (item) => item.message || 'A new clinics ticket is now visible.',
                onClick: () => window.focus()
            });

            QueueNotifications.notifyForNewTickets({
                pageKey: getClinicsWrongInfoNotificationKey(),
                items: collectClinicsWrongInfoTicketsFromDom(doc),
                title: 'Wrong Info patient (Clinics)',
                getBody: (item) => item.message || 'A Wrong Info patient is now visible in Clinics.',
                onClick: () => window.focus()
            });
        }

        // ---- Need Butler via AJAX ----
        function needButler(patientId, clinic) {
            const formData = new FormData();
            formData.append('patient_id', patientId);
            formData.append('need_patient', '1');
            formData.append('clinic', clinic);

            fetch('clinics.php', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    if (window.smartReload) window.smartReload(0); else window.location.reload();
                } else {
                    alert('Could not update status. Refreshing...');
                    if (window.smartReload) window.smartReload(0); else window.location.reload();
                }
            })
            .catch(() => { if (window.smartReload) window.smartReload(0); else window.location.reload(); });
        }

        function saveMRN(patientId, mrn) {
            const formData = new FormData();
            formData.append('save_mrn', '1');
            formData.append('patient_id', patientId);
            formData.append('mrn', mrn);

            return fetch('billing.php', {
                method: 'POST',
                body: formData,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            }).then(r => r.json());
        }

        function showPatientDetails(patient) {
            if (typeof patient === 'string') {
                try {
                    patient = JSON.parse(patient);
                } catch (e) {
                    console.error('Error parsing patient:', e);
                    alert('Error loading patient data.');
                    return;
                }
            }

            const modalBody = document.getElementById('patientModalBody');
            if (!modalBody) {
                return;
            }

            let arrivalTimeStr = 'N/A';
            let approvalTimeStr = 'Not started yet';

            try {
                if (patient.arrival_timestamp) {
                    const arrivalTime = new Date(patient.arrival_timestamp);
                    arrivalTimeStr = arrivalTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                }
            } catch (e) {
                console.error('Error formatting arrival time:', e);
            }

            try {
                if (patient.approval_timestamp) {
                    const approvalTime = new Date(patient.approval_timestamp);
                    approvalTimeStr = approvalTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                }
            } catch (e) {
                console.error('Error formatting approval time:', e);
            }

            const changedFields = (() => {
                if (Array.isArray(patient.demographics_changed_fields)) return patient.demographics_changed_fields;
                if (typeof patient.demographics_changed_fields === 'string' && patient.demographics_changed_fields.trim() !== '') {
                    try {
                        const parsed = JSON.parse(patient.demographics_changed_fields);
                        return Array.isArray(parsed) ? parsed : [];
                    } catch (e) {
                        return [];
                    }
                }
                return [];
            })();

            const isExistingPatient = Number(patient.is_existing_patient) === 1;
            const hasDemographicsEdits = Number(patient.demographics_edited) === 1 || changedFields.length > 0;

            const changedFieldsBadge = hasDemographicsEdits
                ? `<div style="margin: 8px 0 14px 0;"><span style="display:inline-block;padding:6px 10px;border-radius:999px;background:#fdeaea;color:#c0392b;border:1px solid #f0b7b2;font-weight:700;font-size:12px;">Patient Details Edited</span></div>`
                : '';

            const existingPatientBadge = isExistingPatient
                ? `<span style="display:inline-block;padding:4px 8px;border-radius:999px;background:#fff0f0;color:#c0392b;border:1px solid #f0b7b2;font-weight:700;font-size:11px;margin-left:8px;">Existing Patient</span>`
                : '';

            const fieldHighlight = (fieldKey) => changedFields.includes(fieldKey)
                ? 'border-left:4px solid #e74c3c; background:#fff8f8; padding-left:10px;'
                : 'opacity:0.7;';

            const changedValueStyle = (fieldKey) => changedFields.includes(fieldKey)
                ? 'color:#c0392b;font-weight:700;'
                : 'color:#95a5a6;';

            modalBody.innerHTML = `
                <div class="patient-info-group">
                    <div class="patient-info-label">Queue Number</div>
                    <div class="patient-info-value" style="font-size: 24px; font-weight: bold; color: #3498db;">${patient.queue_number || 'N/A'}</div>
                </div>
                <div class="patient-info-group" style="${fieldHighlight('patient_name')}">
                    <div class="patient-info-label">Patient Name</div>
                    <div class="patient-info-value" style="${changedValueStyle('patient_name')}">${escapeHtml(patient.patient_name || '') || 'N/A'} ${existingPatientBadge}</div>
                </div>
                ${changedFieldsBadge}
                <div class="patient-info-group" style="${fieldHighlight('care_mobile') || fieldHighlight('care_country_code')}">
                    <div class="patient-info-label">Result & Care Mobile Number</div>
                    <div class="patient-info-value" style="${changedFields.includes('care_mobile') || changedFields.includes('care_country_code') ? 'color:#c0392b;font-weight:700;' : 'color:#95a5a6;'}">${patient.care_mobile ? escapeHtml((patient.care_country_code ? patient.care_country_code + ' ' : '') + patient.care_mobile) : 'N/A'}</div>
                </div>
                <div class="patient-info-group" style="${fieldHighlight('email')}">
                    <div class="patient-info-label">Email Address</div>
                    <div class="patient-info-value" style="${changedValueStyle('email')}">${patient.email ? escapeHtml(patient.email) : 'N/A'}</div>
                </div>
                <div class="patient-info-group" style="${fieldHighlight('address')}">
                    <div class="patient-info-label">Address</div>
                    <div class="patient-info-value" style="${changedValueStyle('address')}">${patient.address ? escapeHtml(patient.address) : 'N/A'}</div>
                </div>
                <div class="patient-info-group">
                    <div class="patient-info-label">Arrival Time</div>
                    <div class="patient-info-value" style="color:#95a5a6;">${arrivalTimeStr}</div>
                </div>
                <div class="patient-info-group">
                    <div class="patient-info-label">Start Time</div>
                    <div class="patient-info-value" style="color:#95a5a6;">${approvalTimeStr}</div>
                </div>
            `;

            const mrnValue = patient.mrn || '';
            const mrnStyle = isExistingPatient
                ? 'width:100%; padding:8px; font-size:14px; color:#c0392b; font-weight:700; border:2px solid #e74c3c; background:#fff7f7;'
                : 'width:100%; padding:8px; font-size:14px;';
            const mrnReadOnlyAttrs = isExistingPatient ? 'readonly aria-readonly="true"' : '';
            const saveButtonHtml = isExistingPatient
                ? '<button class="action-btn start action-btn-locked" id="saveMrnBtn" disabled>PID Locked</button>'
                : '<button class="action-btn start" id="saveMrnBtn">Save PID</button>';

            const detailsEl = document.createElement('div');
            detailsEl.innerHTML = `
                <div class="patient-info-group" style="${fieldHighlight('mrn')}">
                    <div class="patient-info-label">PID (Medical Record #)</div>
                    <div class="patient-info-value">
                        <input type="text" id="mrn_input" value="${escapeHtml(mrnValue)}" style="${mrnStyle}color:#c0392b;font-weight:700;" ${mrnReadOnlyAttrs} />
                        <div class="mrn-action-row">
                            ${saveButtonHtml}
                            <button class="action-btn action-btn-doc-id" id="openIdPdfBtn">Open ID PDF</button>
                            <button class="action-btn action-btn-doc-insurance" id="openInsurancePdfBtn">Open Prescription PDF</button>
                        </div>
                    </div>
                </div>
            `;
            modalBody.appendChild(detailsEl);

            const saveMrnBtn = document.getElementById('saveMrnBtn');
            if (saveMrnBtn && !isExistingPatient) {
                saveMrnBtn.addEventListener('click', function () {
                    const mrn = document.getElementById('mrn_input').value.trim();
                    if (!mrn) {
                        alert('MRN cannot be empty');
                        return;
                    }

                    saveMRN(patient.id, mrn).then(res => {
                        if (res && res.success) {
                            patient.mrn = mrn;
                            alert('MRN saved');
                        } else {
                            let msg = 'Failed to save MRN';
                            if (res && res.error) msg = res.error;
                            else if (res && res.messages && Array.isArray(res.messages)) msg = res.messages.join('\n');
                            alert(msg);
                        }
                    }).catch(err => {
                        console.error(err);
                        alert('Error saving MRN');
                    });
                });
            }

            document.getElementById('openIdPdfBtn').addEventListener('click', function () {
                const filename = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : (patient.queue_number || patient.id);
                const url = 'download_pdf.php?type=id&file=' + encodeURIComponent(filename + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
                window.open(url, '_blank', 'noopener');
            });

            document.getElementById('openInsurancePdfBtn').addEventListener('click', function () {
                const filename = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : (patient.queue_number || patient.id);
                const url = 'download_pdf.php?type=insurance&file=' + encodeURIComponent(filename + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
                window.open(url, '_blank', 'noopener');
            });

            document.getElementById('patientModal').classList.add('active');
        }

        function closePatientModal() {
            const modal = document.getElementById('patientModal');
            if (modal) {
                modal.classList.remove('active');
            }
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text || '';
            return div.innerHTML;
        }

        function showPdfSelectorClinics(patient) {
            if (typeof patient === 'string') {
                try {
                    patient = JSON.parse(patient);
                } catch (e) {
                    console.error(e);
                    return;
                }
            }

            let modal = document.getElementById('pdfSelectorModal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'pdfSelectorModal';
                modal.className = 'patient-modal';
                modal.innerHTML = `
                    <div class="patient-modal-content">
                        <div class="patient-modal-header">
                            <div class="patient-modal-title"><i class="fas fa-file-pdf"></i> Open Document</div>
                            <button class="patient-modal-close" id="pdfModalClose"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="patient-modal-body" id="pdfModalBody"></div>
                    </div>`;
                document.body.appendChild(modal);
                modal.querySelector('#pdfModalClose').addEventListener('click', () => modal.classList.remove('active'));
            }

            const body = modal.querySelector('#pdfModalBody');
            body.innerHTML = `
                <div style="margin-bottom:12px;"><strong>${escapeHtml(patient.patient_name || '')}</strong> - ${escapeHtml(patient.mrn || '')}</div>
                <div style="display:flex; gap:8px;">
                    <button id="openIdBtn" class="action-btn" style="background:#3498db; color:white;"><i class="fas fa-id-card"></i> Open ID</button>
                    <button id="openPrescBtn" class="action-btn" style="background:#9b59b6; color:white;"><i class="fas fa-prescription"></i> Open Prescription</button>
                </div>
            `;
            modal.classList.add('active');

            function openFile(type) {
                const filenameBase = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : patient.id;
                const url = 'download_pdf.php?type=' + encodeURIComponent(type) + '&file=' + encodeURIComponent(filenameBase + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
                window.open(url, '_blank', 'noopener');
            }

            modal.querySelector('#openIdBtn').onclick = () => openFile('id');
            modal.querySelector('#openPrescBtn').onclick = () => openFile('insurance');
        }

        document.addEventListener('click', function (e) {
            const detailsBtn = e.target.closest('.view-details-btn');
            if (detailsBtn) {
                e.preventDefault();
                e.stopPropagation();

                const patientData = detailsBtn.dataset.patient;
                if (!patientData) {
                    alert('Error: Patient data not available');
                    return;
                }

                try {
                    const patient = JSON.parse(patientData);
                    showPatientDetails(patient);
                } catch (error) {
                    console.error('Error parsing patient data:', error, 'Data was:', patientData);
                    alert('Error loading patient details.');
                }
                return;
            }

            const btn = e.target.closest('.view-pdf-btn');
            if (!btn) {
                return;
            }

            e.preventDefault();
            const data = btn.getAttribute('data-patient');
            try {
                const patient = JSON.parse(data);
                showPdfSelectorClinics(patient);
            } catch (err) {
                console.error('Invalid patient data', err);
            }
        });

        // ---- Auto-refresh every 2 seconds ----
        setInterval(function () {
            if (document.hidden) return;
            if (!<?php echo json_encode(!empty($current_clinic)); ?>) return;

            // Skip if interacting
            const activeElement = document.activeElement;
            if (activeElement && (activeElement.tagName === 'INPUT' || 
                                activeElement.tagName === 'SELECT' || 
                                activeElement.tagName === 'TEXTAREA')) {
                return;
            }

            const clinic = <?php echo json_encode($current_clinic); ?>;
            const url = 'clinics.php?clinic=' + encodeURIComponent(clinic);

            fetch(url)
                .then(r => r.text())
                .then(html => {
                    const parser = new DOMParser();
                    const newDoc = parser.parseFromString(html, 'text/html');

                    // Trigger browser notification for newly visible tickets.
                    notifyNewClinicsTickets(newDoc);

                    // Refresh assignments
                    const newAssignments = newDoc.getElementById('assignmentsList');
                    if (newAssignments) {
                        document.getElementById('assignmentsList').innerHTML = newAssignments.innerHTML;
                        attachAssignmentHandlers();
                    }

                    // Refresh queue table
                    const newQueue = newDoc.getElementById('clinicsQueueTable');
                    if (newQueue) document.getElementById('clinicsQueueTable').innerHTML = newQueue.innerHTML;
                });
        }, 2000);

        // ---- Assignment form dynamic handlers ----
        function attachAssignmentHandlers() {
            // Add clinic buttons
            document.querySelectorAll('.add-clinic-btn').forEach(btn => {
                btn.onclick = function() {
                    const form = this.closest('.assignment-form');
                    const container = form.querySelector('.clinic-selections');
                    const group = container.querySelector('.clinic-select-group').cloneNode(true);
                    
                    group.querySelector('select').value = '';
                    const removeBtn = group.querySelector('.remove-clinic-btn');
                    removeBtn.style.display = 'flex';
                    
                    removeBtn.onclick = () => {
                        if (container.children.length > 1) group.remove();
                    };
                    
                    container.appendChild(group);
                }
            });

            // Remove buttons
            document.querySelectorAll('.remove-clinic-btn').forEach(btn => {
                btn.onclick = function() {
                    const container = this.closest('.clinic-selections');
                    if (container.children.length > 1) {
                        this.closest('.clinic-select-group').remove();
                    }
                }
            });
        }

        document.addEventListener('DOMContentLoaded', function () {
            attachAssignmentHandlers();

            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') {
                    closePatientModal();
                }
            });

            const patientModal = document.getElementById('patientModal');
            if (patientModal) {
                patientModal.addEventListener('click', function (e) {
                    if (e.target === this) {
                        closePatientModal();
                    }
                });
            }

            if (window.QueueNotifications) {
                QueueNotifications.renderPermissionBanner({ pageName: CLINICS_NOTIFICATION_PAGE });
                QueueNotifications.syncTickets(
                    getClinicsNotificationKey(),
                    collectClinicsTicketsFromDom()
                );
                QueueNotifications.syncTickets(
                    getClinicsWrongInfoNotificationKey(),
                    collectClinicsWrongInfoTicketsFromDom()
                );
            }
        });
    </script>
    
    <!-- Undo button -->
    <?php include 'undo_button.php'; ?>
</body>
</html>

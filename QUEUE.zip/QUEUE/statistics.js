/* ======================================================================
   STATISTICS DASHBOARD - JAVASCRIPT
   ====================================================================== */

/**
 * Show timeline view for a specific patient
 * @param {number} patientId - The patient ID
 * @param {string} patientName - The patient name
 * @param {string} mrn - The patient MRN
 */
function showPatientTimeline(patientId, patientName, mrn, queueNum, arrivalTs) {
    // Create timeline modal
    const modal = document.createElement('div');
    modal.id = 'timelineModal';
    modal.className = 'timeline-container';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.right = '0';
    modal.style.bottom = '0';
    modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '10000';
    modal.style.margin = '0';
    modal.style.padding = '20px';
    modal.style.borderRadius = '0';
    modal.style.boxShadow = 'none';
    modal.style.background = 'rgba(0,0,0,0.5)';
    
    const contentWrapper = document.createElement('div');
    contentWrapper.style.background = 'white';
    contentWrapper.style.borderRadius = '12px';
    contentWrapper.style.maxWidth = '900px';
    contentWrapper.style.width = '100%';
    contentWrapper.style.maxHeight = '90vh';
    contentWrapper.style.overflowY = 'auto';
    contentWrapper.style.boxShadow = '0 20px 60px rgba(0,0,0,0.3)';
    contentWrapper.style.position = 'relative';
    
    // If no patient ID is provided, show search form first
    if (!patientId) {
        contentWrapper.innerHTML = `
            <div style="padding: 40px; text-align: center;">
                <h2 style="margin: 0 0 20px 0; color: #333;">
                    <i class="fas fa-search"></i> Patient Journey Search
                </h2>
                <p style="color: #666; margin-bottom: 30px;">Enter MRN to view patient timeline and stage timings</p>
                
                <div style="max-width: 400px; margin: 0 auto; text-align: left;">
                    <label style="font-size: 14px; color: #333; font-weight: 500; display: block; margin-bottom: 8px;">MRN</label>
                    <input id="searchMrn" type="text" placeholder="Enter MRN" style="width: 100%; padding: 12px; border: 2px solid #ddd; border-radius: 6px; font-size: 14px; box-sizing: border-box; margin-bottom: 20px;">
                    
                    <button id="searchMrnBtn" style="width: 100%; padding: 12px; background: #2d7ff9; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500;">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </div>
        `;
        modal.appendChild(contentWrapper);
        document.body.appendChild(modal);
        
        document.getElementById('searchMrnBtn').addEventListener('click', function() {
            const searchMrn = document.getElementById('searchMrn').value.trim();
            if (!searchMrn) {
                alert('Please enter an MRN');
                return;
            }
            
            contentWrapper.innerHTML = '<div style="padding: 40px; text-align: center;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';
            
            fetch('statistics_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'get_patient_timeline', mrn: searchMrn })
            })
            .then(r => r.json())
            .then(resp => {
                if (resp.success) {
                    renderTimeline(contentWrapper, resp.patient, resp.logs, resp.patient.patient_name || '', resp.patient.mrn || '', modal, resp.stage_timings);
                } else {
                    contentWrapper.innerHTML = `<div style="padding: 30px; text-align: center; color: #c0392b;"><i class="fas fa-exclamation-circle"></i><p>${resp.message || 'Patient not found'}</p></div>`;
                }
            })
            .catch(err => {
                contentWrapper.innerHTML = `<div style="padding: 30px; text-align: center; color: #c0392b;"><i class="fas fa-exclamation-circle"></i><p>Error: ${err.message}</p></div>`;
            });
        });

        // Auto-focus and allow Enter key
        setTimeout(() => {
            const mrnInput = document.getElementById('searchMrn');
            if (mrnInput) mrnInput.focus();
            mrnInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') document.getElementById('searchMrnBtn').click();
            });
        }, 100);
    } else {
        contentWrapper.innerHTML = '<div style="padding: 30px; animation: slideIn 0.3s ease;"></div>';
        modal.appendChild(contentWrapper);
        document.body.appendChild(modal);
        
        // Fetch patient timeline data
        const payload = { action: 'get_patient_timeline' };
        if (/^\d+$/.test(String(patientId))) {
            payload.patient_id = Number(patientId);
        } else {
            payload.queue_number = queueNum || '';
            payload.mrn = mrn || '';
            payload.arrival_ts = arrivalTs || '';
        }

        fetch('statistics_api.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                    renderTimeline(contentWrapper.querySelector('div'), data.patient, data.logs, patientName, mrn, modal, data.stage_timings);
            } else {
                contentWrapper.querySelector('div').innerHTML = `
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle"></i>
                        ${data.message || 'Failed to load timeline'}
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error fetching timeline:', error);
            contentWrapper.querySelector('div').innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i>
                    Error loading timeline data
                </div>
            `;
        });
    }
    
    // Close modal on background click
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.remove();
        }
    });
    
    // Close on Escape key
    document.addEventListener('keydown', function closeOnEsc(e) {
        if (e.key === 'Escape' && document.getElementById('timelineModal')) {
            document.getElementById('timelineModal').remove();
            document.removeEventListener('keydown', closeOnEsc);
        }
    });
}

/**
 * Get department badge HTML based on action
 */
function getDepartmentBadge(action, notes) {
    // Enhanced department detection
    let dept = null;
    let color = '#666';
    let bg = '#f0f0f0';
    let icon = 'fas fa-building';
    
    // Check action text for department hints
    if (action.includes('Lab') || notes?.includes('lab') || notes?.includes('Lab')) {
        dept = 'Lab';
        color = '#27ae60';
        bg = '#d5f4e6';
    } else if (action.includes('Imaging') || notes?.includes('imaging') || notes?.includes('Imaging')) {
        dept = 'Imaging';
        color = '#2980b9';
        bg = '#d5e8f7';
    } else if (action.includes('Billing') || notes?.includes('billing') || notes?.includes('Billing') || action.includes('Completed Lab & Sent')) {
        dept = 'Billing';
        color = '#3498db';
        bg = '#d4e9f2';
    }
    
    if (dept) {
        return `<div style="margin-top: 8px; display: inline-block; background: ${bg}; color: ${color}; padding: 4px 12px; border-radius: 4px; font-size: 12px; font-weight: 600;"><i class="${icon}" style="margin-right: 5px;"></i>${dept}</div>`;
    }
    return '';
}

/**
 * Render timeline content
 */
function renderTimeline(container, patient, logs, patientName, mrn, modal, stageTimings) {
    const formatTime = (dateString) => {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    };

    const calculateDuration = (startTime, endTime) => {
        if (!startTime || !endTime) return '-';
        const start = new Date(startTime);
        const end = new Date(endTime);
        const minutes = Math.floor((end - start) / 60000);
        
        if (minutes < 1) return '< 1 min';
        if (minutes < 60) return `${minutes} min`;
        
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return `${hours}h ${mins}m`;
    };

    let html = `
        <div class="timeline-header">
            <div>
                <h2>
                    <i class="fas fa-history"></i>
                    Complete Patient Journey
                </h2>
                <p style="margin: 10px 0 0 0; font-size: 14px; opacity: 0.9;">
                    ${patientName} - MRN: ${mrn || 'N/A'}
                </p>
            </div>
            <button class="timeline-close-btn" onclick="this.closest('.timeline-container').remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <div style="margin-top:12px; display:flex; gap:10px; align-items:center;">
            <div style="flex:1; max-width:420px;">
                <label style="font-size:12px; color:#666;">Lookup by Queue # / MRN</label>
                <div style="display:flex; gap:8px; margin-top:6px;">
                    <input id="timelineQueueInput" type="text" placeholder="Queue #" style="flex:1; padding:8px; border-radius:6px; border:1px solid #ddd;" value="${patient.queue_number || ''}">
                    <input id="timelineMrnInput" type="text" placeholder="MRN" style="flex:1; padding:8px; border-radius:6px; border:1px solid #ddd;" value="${mrn || patient.mrn || ''}">
                    <button id="timelineLookupBtn" style="padding:8px 12px; background:#2d7ff9; color:white; border:none; border-radius:6px; cursor:pointer;">Search</button>
                </div>
            </div>
        </div>

        <div class="patient-info-cards">
            <div class="info-card">
                <div class="info-card-label">Queue Number</div>
                <div class="info-card-value">${patient.queue_number}</div>
            </div>
            <div class="info-card">
                <div class="info-card-label">Arrival Time</div>
                <div class="info-card-value">${formatTime(patient.arrival_timestamp)}</div>
            </div>
            <div class="info-card">
                <div class="info-card-label">Service Type</div>
                <div class="info-card-value">${patient.service_type}</div>
            </div>
            <div class="info-card">
                <div class="info-card-label">Current Status</div>
                <div class="info-card-value">${patient.current_status}</div>
            </div>
        </div>
    `;

    const actorSet = new Set();
    if (logs && logs.length > 0) {
        logs.forEach((log) => {
            const actor = (log.performed_by_label || log.performed_by_full_name || log.performed_by_username || '').toString().trim();
            if (actor !== '') {
                actorSet.add(actor);
            }
        });
    }
    const actorsInvolved = Array.from(actorSet);
    if (actorsInvolved.length > 0) {
        html += `
            <div style="margin-bottom: 14px; padding: 12px; background: #f8f9fa; border: 1px solid #e2e8f0; border-radius: 8px;">
                <div style="font-size: 12px; color: #666; font-weight: 700; margin-bottom: 8px; text-transform: uppercase;">Users Involved</div>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    ${actorsInvolved.map((name) => `<span style="display:inline-block; background:#eef5ff; color:#0b66c3; border-radius:999px; padding:4px 10px; font-size:12px; font-weight:600;">${name}</span>`).join('')}
                </div>
            </div>
        `;
    }

    // Add stage timings if available
    if (stageTimings) {
        html += `
            <div style="margin-top: 20px; padding: 16px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #2d7ff9;">
                <h3 style="margin: 0 0 12px 0; font-size: 14px; font-weight: 600; color: #333;">
                    <i class="fas fa-chart-bar"></i> Stage Timings
                </h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div style="padding: 10px; background: white; border-radius: 6px;">
                        <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Arrival → Billing</div>
                        <div style="font-size: 18px; font-weight: 600; color: #2d7ff9;">${stageTimings.arrival_to_billing_wait || '-'} min</div>
                    </div>
                    <div style="padding: 10px; background: white; border-radius: 6px;">
                        <div style="font-size: 12px; color: #666; margin-bottom: 4px;">In-Process</div>
                        <div style="font-size: 18px; font-weight: 600; color: #27ae60;">${stageTimings.in_process_duration || '-'} min</div>
                    </div>
                    <div style="padding: 10px; background: white; border-radius: 6px;">
                        <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Billing → Waiting</div>
                        <div style="font-size: 18px; font-weight: 600; color: #f39c12;">${stageTimings.billing_to_waiting_wait || '-'} min</div>
                    </div>
                    <div style="padding: 10px; background: white; border-radius: 6px;">
                        <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Waiting → Served</div>
                        <div style="font-size: 18px; font-weight: 600; color: #e74c3c;">${stageTimings.waiting_to_served_duration || '-'} min</div>
                    </div>
                </div>
            </div>
        `;
    }

    if (logs && logs.length > 0) {
        let previousTime = patient.arrival_timestamp;
        
        html += '<div class="timeline-wrapper"><div class="timeline-content">';
        
        logs.forEach((log, index) => {
            const duration = calculateDuration(previousTime, log.created_at);
            const isUndoAction = log.action === 'Undo Action';
            const actionColor = isUndoAction ? '#e74c3c' : '#667eea';
            const actorName = (log.performed_by_label || log.performed_by_full_name || log.performed_by_username || '').toString().trim();
            
            html += `
                <div class="timeline-item">
                    <div class="timeline-marker">
                        <div class="timeline-dot" style="background: linear-gradient(135deg, ${actionColor} 0%, ${actionColor}88 100%);"></div>
                        <div class="timeline-line"></div>
                        <div class="timeline-time">${formatTime(log.created_at)}</div>
                    </div>
                    <div class="timeline-entry">
                        <div class="timeline-action">
                            <strong>${log.action}</strong>
                            ${log.action === 'Undo Action' ? ' <i class="fas fa-undo" style="color: #e74c3c;"></i>' : ''}
                        </div>
                        
                        <div class="timeline-status">
                            ${log.from_status ? `<span class="status-badge from">${log.from_status}</span>` : ''}
                            ${log.from_status && log.to_status ? '<i class="fas fa-arrow-right" style="color: #bdc3c7;"></i>' : ''}
                            ${log.to_status ? `<span class="status-badge to">${log.to_status}</span>` : ''}
                        </div>
                        
                        ${getDepartmentBadge(log.action, log.notes)}
                        
                        ${log.machine_type ? `
                            <div class="timeline-metadata">
                                <span><i class="fas fa-machine"></i> Machine: ${log.machine_type}</span>
                            </div>
                        ` : ''}
                        
                        ${log.notes ? `
                            <div class="timeline-notes">
                                <i class="fas fa-sticky-note"></i> ${log.notes}
                            </div>
                        ` : ''}

                        <div class="timeline-metadata">
                            <span><i class="fas fa-user"></i> Handled by: ${actorName !== '' ? actorName : 'System'}</span>
                        </div>
                        
                        <div class="timeline-metadata">
                            <span><i class="fas fa-hourglass-half"></i> Time since last action: ${duration}</span>
                        </div>
                    </div>
                </div>
            `;
            
            previousTime = log.created_at;
        });
        
        html += '</div></div>';
    } else {
        html += `
            <div class="no-data">
                <i class="fas fa-inbox"></i>
                <p>No timeline data available for this patient</p>
            </div>
        `;
    }
    
    container.innerHTML = html;

    // Attach lookup handler
    const lookupBtn = container.querySelector('#timelineLookupBtn');
    if (lookupBtn) {
        lookupBtn.addEventListener('click', function() {
            const q = (container.querySelector('#timelineQueueInput')?.value || '').trim();
            const m = (container.querySelector('#timelineMrnInput')?.value || '').trim();
            if (!q && !m) return;

            // show loading
            container.innerHTML = '<div style="padding: 40px; text-align:center;"><i class="fas fa-spinner fa-spin"></i> Looking up patient...</div>';

            fetch('statistics_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'get_patient_timeline', queue_number: q, mrn: m })
            })
            .then(r => r.json())
            .then(resp => {
                if (resp.success) {
                    renderTimeline(container, resp.patient, resp.logs, resp.patient.patient_name || '', resp.patient.mrn || '', modal, resp.stage_timings);
                } else {
                    container.innerHTML = `<div style="padding:30px; text-align:center; color:#c0392b;"><i class="fas fa-exclamation-circle"></i> ${resp.message || 'Patient not found'}</div>`;
                }
            })
            .catch(() => {
                container.innerHTML = `<div style="padding:30px; text-align:center; color:#c0392b;"><i class="fas fa-exclamation-circle"></i> Error during lookup</div>`;
            });
        });
    }

    // If MRN is available, fetch related tickets and render a ticket selector
    const mrnToUse = mrn || (patient && patient.mrn) || '';
    if (mrnToUse) {
        fetch('statistics_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'find_tickets', mrn: mrnToUse })
        })
        .then(r => r.json())
        .then(resp => {
            if (resp.success && resp.tickets && resp.tickets.length > 0) {
                const selectHtml = [`<div style="margin-top:14px; display:flex; gap:8px; align-items:center;"><label style="font-size:13px;color:#666;">Select Ticket</label><select id="timelineTicketSelect" style="padding:8px;border-radius:6px;border:1px solid #ddd;">`];
                resp.tickets.forEach(t => {
                    selectHtml.push(`<option value="${t.id}">${t.queue_number} — ${new Date(t.arrival_timestamp).toLocaleString()}</option>`);
                });
                selectHtml.push('</select><button id="timelineTicketOpen" style="padding:8px 10px;background:#27ae60;color:white;border:none;border-radius:6px;cursor:pointer;">Open</button></div>');

                container.querySelector('.timeline-header').insertAdjacentHTML('afterend', selectHtml.join(''));

                container.querySelector('#timelineTicketOpen').addEventListener('click', function() {
                    const pid = container.querySelector('#timelineTicketSelect').value;
                    if (pid) {
                        // open timeline for selected ticket id
                        showPatientTimeline(pid, '', '', '', '');
                    }
                });
            }
        })
        .catch(() => {});
    }
}

// Backward-compatible alias used by inline handlers in statistics.php.
function openPatientTimeline(patientId, queueNum, mrn, arrivalTs) {
    showPatientTimeline(patientId, '', mrn, queueNum, arrivalTs);
}

/**
 * Make table rows clickable to open timeline
 */
function makeTableRowsClickable() {
    // Target all table rows with data-patient-id attribute
    document.querySelectorAll('table tbody tr[data-patient-id]').forEach(row => {
        const queueNum = row.querySelector('td:nth-child(1)')?.textContent?.trim() || '';
        const patientName = row.querySelector('td:nth-child(3)')?.textContent?.trim() || '';
        const mrn = (row.getAttribute('data-mrn') || row.querySelector('td:nth-child(2)')?.textContent || '').trim();
        const arrivalTs = row.getAttribute('data-arrival') || '';
        const patientId = row.getAttribute('data-patient-id');
        
        if (patientId) {
            row.style.cursor = 'pointer';
            row.addEventListener('click', function(e) {
                if (e.target.tagName !== 'A' && e.target.tagName !== 'BUTTON') {
                    showPatientTimeline(patientId, patientName, mrn, queueNum, arrivalTs);
                }
            });
        }
    });
}

/**
 * Show stage breakdown modal with patient details for clicked stage card
 * @param {string} stageType - The stage type key (arrival_to_billing, in_process, billing_to_waiting, waiting_to_served)
 * @param {string} title - The card title
 * @param {string} description - The card description
 * @param {Array} details - Array of patient details for this stage
 */
function showStageBreakdown(stageType, title, description, details) {
    // Create modal element
    let modal = document.getElementById('stageBreakdownModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'stageBreakdownModal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000;
            padding: 20px;
            box-sizing: border-box;
            animation: fadeIn 0.2s ease-in-out;
        `;
        document.body.appendChild(modal);
    }

    // Color map for each stage
    const stageColors = {
        'arrival_to_billing': '#1976d2',
        'in_process': '#7b1fa2',
        'billing_to_waiting': '#c2185b',
        'waiting_to_served': '#00796b'
    };

    const stageColor = stageColors[stageType] || '#667eea';

    // Create modal content
    let html = `
        <div style="
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 900px;
            max-height: 80vh;
            display: flex;
            flex-direction: column;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            animation: slideUp 0.3s ease-out;
        ">
            <!-- Modal Header -->
            <div style="
                background: linear-gradient(135deg, ${stageColor}22 0%, ${stageColor}11 100%);
                border-bottom: 2px solid ${stageColor};
                padding: 20px;
                border-radius: 12px 12px 0 0;
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
            ">
                <div>
                    <h2 style="margin: 0 0 4px 0; color: ${stageColor}; font-size: 22px;">${title}</h2>
                    <p style="margin: 0; color: #666; font-size: 13px;">${description}</p>
                </div>
                <button onclick="document.getElementById('stageBreakdownModal').style.display='none';" style="
                    background: none;
                    border: none;
                    font-size: 24px;
                    color: #999;
                    cursor: pointer;
                    padding: 0;
                    width: 30px;
                    height: 30px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                ">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <!-- Modal Body -->
            <div style="
                flex: 1;
                overflow-y: auto;
                padding: 20px;
            ">
    `;

    if (!details || details.length === 0) {
        html += `
            <div style="
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 60px 20px;
                color: #999;
            ">
                <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 10px;"></i>
                <p style="margin: 0; font-size: 16px;">No patient data available for this stage</p>
            </div>
        `;
    } else {
        // Create table
        html += `
            <table style="
                width: 100%;
                border-collapse: collapse;
                font-size: 13px;
            ">
                <thead>
                    <tr style="background: #f5f5f5; border-bottom: 2px solid #ddd;">
                        <th style="padding: 12px; text-align: left; color: #333; font-weight: 600; border-right: 1px solid #eee;">Queue #</th>
                        <th style="padding: 12px; text-align: left; color: #333; font-weight: 600; border-right: 1px solid #eee;">Patient Name</th>
                        <th style="padding: 12px; text-align: left; color: #333; font-weight: 600; border-right: 1px solid #eee;">MRN</th>
                        <th style="padding: 12px; text-align: right; color: #333; font-weight: 600;">Duration (min)</th>
                    </tr>
                </thead>
                <tbody>
        `;

        // Sort details by value (descending)
        const sortedDetails = [...details].sort((a, b) => (b.value || 0) - (a.value || 0));

        sortedDetails.forEach((item, index) => {
            const rowBg = index % 2 === 0 ? '#ffffff' : '#f9f9f9';
            const valueColor = item.value > 0 ? stageColor : '#999';
            
            html += `
                <tr style="
                    background: ${rowBg};
                    border-bottom: 1px solid #eee;
                    transition: background 0.2s;
                    cursor: pointer;
                " onmouseover="this.style.background='${rowBg === '#ffffff' ? '#f0f0f0' : '#e8e8e8'}'" onmouseout="this.style.background='${rowBg}'">
                    <td style="padding: 12px; border-right: 1px solid #eee; color: #333; font-weight: 500;">${item.queue || 'N/A'}</td>
                    <td style="padding: 12px; border-right: 1px solid #eee; color: #333;">${item.patient || 'N/A'}</td>
                    <td style="padding: 12px; border-right: 1px solid #eee; color: #666; font-family: monospace;">${item.mrn || 'N/A'}</td>
                    <td style="padding: 12px; text-align: right; color: ${valueColor}; font-weight: 600;">${item.value !== null ? item.value.toFixed(2) : '-'}</td>
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>

            <!-- Statistics Summary -->
            <div style="
                margin-top: 20px;
                padding: 15px;
                background: #f9f9f9;
                border-radius: 6px;
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 15px;
            ">
                <div style="border-left: 3px solid ${stageColor}; padding-left: 10px;">
                    <div style="font-size: 12px; color: #666;">Total Records</div>
                    <div style="font-size: 18px; font-weight: 600; color: ${stageColor};">${details.length}</div>
                </div>
                <div style="border-left: 3px solid ${stageColor}; padding-left: 10px;">
                    <div style="font-size: 12px; color: #666;">Average Duration</div>
                    <div style="font-size: 18px; font-weight: 600; color: ${stageColor};">${(details.reduce((sum, d) => sum + (d.value || 0), 0) / details.length).toFixed(2)} min</div>
                </div>
                <div style="border-left: 3px solid ${stageColor}; padding-left: 10px;">
                    <div style="font-size: 12px; color: #666;">Maximum</div>
                    <div style="font-size: 18px; font-weight: 600; color: ${stageColor};">${Math.max(...details.map(d => d.value || 0)).toFixed(2)} min</div>
                </div>
                <div style="border-left: 3px solid ${stageColor}; padding-left: 10px;">
                    <div style="font-size: 12px; color: #666;">Minimum</div>
                    <div style="font-size: 18px; font-weight: 600; color: ${stageColor};">${Math.min(...details.map(d => d.value || 0)).toFixed(2)} min</div>
                </div>
            </div>
        `;
    }

    html += `
            </div>

            <!-- Modal Footer -->
            <div style="
                padding: 15px 20px;
                border-top: 1px solid #eee;
                text-align: right;
            ">
                <button onclick="document.getElementById('stageBreakdownModal').style.display='none';" style="
                    padding: 10px 20px;
                    background: #67899e;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: 600;
                ">
                    Close
                </button>
            </div>
        </div>
    `;

    modal.innerHTML = html;
    modal.style.display = 'flex';

    // Close modal on Escape key
    document.addEventListener('keydown', function closeOnEscape(e) {
        if (e.key === 'Escape') {
            modal.style.display = 'none';
            document.removeEventListener('keydown', closeOnEscape);
        }
    });

    // Close modal on background click
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
}

/**
 * Initialize dashboard interactions
 */
document.addEventListener('DOMContentLoaded', function() {
    makeTableRowsClickable();
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    `;
    document.head.appendChild(style);
});

/**
 * Filter table by search term
 */
function filterWaitingTimesTable(searchTerm) {
    const table = document.querySelector('.waiting-times-table');
    if (!table) return;
    
    const rows = table.querySelectorAll('tbody tr');
    searchTerm = searchTerm.toLowerCase();
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

/**
 * Sort table by column
 */
function sortTableByColumn(columnIndex) {
    const table = document.querySelector('.waiting-times-table');
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    const isNumeric = rows[0]?.children[columnIndex]?.textContent.match(/^\d+$/);
    
    rows.sort((a, b) => {
        const aValue = a.children[columnIndex]?.textContent.trim();
        const bValue = b.children[columnIndex]?.textContent.trim();
        
        if (isNumeric) {
            return parseInt(aValue) - parseInt(bValue);
        }
        return aValue.localeCompare(bValue);
    });
    
    rows.forEach(row => tbody.appendChild(row));
}

/**
 * Show skip/cancel tickets modal
 */
function showSkipCancelTickets(startDate, endDate, filterType = 'both') {
    const modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.right = '0';
    modal.style.bottom = '0';
    modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '10000';
    modal.style.padding = '20px';
    
    const contentWrapper = document.createElement('div');
    contentWrapper.style.background = 'white';
    contentWrapper.style.borderRadius = '12px';
    contentWrapper.style.maxWidth = '900px';
    contentWrapper.style.width = '100%';
    contentWrapper.style.maxHeight = '90vh';
    contentWrapper.style.overflowY = 'auto';
    contentWrapper.style.boxShadow = '0 20px 60px rgba(0,0,0,0.3)';
    
    contentWrapper.innerHTML = `
        <div style="padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;">
                    <i class="fas fa-${filterType === 'cancel' ? 'ban' : 'forward'}"></i>
                    ${filterType === 'cancel' ? 'Canceled' : filterType === 'skip' ? 'Skipped' : 'Skipped & Canceled'} Tickets
                </h2>
                <button onclick="this.closest('div').closest('div').parentElement.remove()" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div id="skipCancelContent" style="min-height: 200px;">
                <i class="fas fa-spinner fa-spin"></i> Loading...
            </div>
        </div>
    `;
    
    modal.appendChild(contentWrapper);
    document.body.appendChild(modal);
    
    // Fetch data
    fetch('statistics_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'get_skip_cancel_tickets',
            start_date: startDate,
            end_date: endDate,
            filter_type: filterType
        })
    })
    .then(r => r.json())
    .then(data => {
        const content = contentWrapper.querySelector('#skipCancelContent');
        if (data.success && data.data.length > 0) {
            let html = `<p style="color: #666; font-size: 14px; margin-bottom: 15px;">Total: <strong>${data.count}</strong> records</p>`;
            html += `<table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #f5f7fa; border-bottom: 2px solid #ddd;">
                        <th style="padding: 10px; text-align: left; font-weight: 600;">Queue #</th>
                        <th style="padding: 10px; text-align: left; font-weight: 600;">Patient Name</th>
                        <th style="padding: 10px; text-align: left; font-weight: 600;">Action</th>
                        <th style="padding: 10px; text-align: left; font-weight: 600;">Status</th>
                        <th style="padding: 10px; text-align: left; font-weight: 600;">Time</th>
                    </tr>
                </thead>
                <tbody>`;
            
            data.data.forEach(record => {
                const actionColor = record.current_status === 'Canceled' ? '#e74c3c' : '#f39c12';
                const actionIcon = record.current_status === 'Canceled' ? 'ban' : 'forward';
                html += `<tr style="border-bottom: 1px solid #eee; cursor: pointer;" onclick="showPatientTimeline(${record.id}, '${record.patient_name.replace(/'/g, "\\'")}', '${record.mrn || ''}')">
                    <td style="padding: 10px;">${record.queue_number}</td>
                    <td style="padding: 10px;"><strong>${record.patient_name}</strong></td>
                    <td style="padding: 10px;">
                        <span style="background: ${actionColor}20; color: ${actionColor}; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600;">
                            <i class="fas fa-${actionIcon}"></i> ${record.current_status}
                        </span>
                    </td>
                    <td style="padding: 10px;">${record.service_type}</td>
                    <td style="padding: 10px; font-size: 12px; color: #666;">${record.wait_time} min</td>
                </tr>`;
            });
            html += `</tbody></table>`;
            content.innerHTML = html;
        } else {
            content.innerHTML = `<div style="text-align: center; padding: 30px; color: #999;">
                <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 15px; display: block;"></i>
                <p>No ${filterType === 'cancel' ? 'canceled' : 'skipped'} tickets found</p>
            </div>`;
        }
    })
    .catch(err => {
        contentWrapper.querySelector('#skipCancelContent').innerHTML = `
            <div style="background: #ffe6e6; color: #c0392b; padding: 15px; border-radius: 6px;">
                <i class="fas fa-exclamation-circle"></i> Error loading records
            </div>
        `;
    });
    
    // Close on background click
    modal.addEventListener('click', function(e) {
        if (e.target === modal) modal.remove();
    });
}

<?php
// imaging_assignments.php - Handle assignments and provide AJAX refresh endpoint

// Set error handling to prevent output corruption
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Buffer output to catch any stray output
ob_start();

require_once 'config.php';
session_start();
authRequireRoles(['imaging', 'admin'], ['log_view' => false]);

// Check if this is an AJAX refresh request
$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
          strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

// Handle assignment via POST (for form submission)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_machine'])) {
    $patient_id = $_POST['patient_id']; // This is actually ticket_id
    $ticket_id = $patient_id; // Rename for clarity
    // Get machines array and filter out empty values
    $machines = isset($_POST['machines']) ? array_filter($_POST['machines'], function($m) { return !empty($m); }) : [];

    if (!empty($machines)) {
        // Get original ticket data for duplication
        $originalPatient = executeAndFetchOne($pdo, "SELECT t.*, p.patient_id FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$ticket_id]);

        if ($originalPatient) {
                    // Ensure MRN is included in the duplicate ticket record
                    $mrn = $originalPatient['mrn'];

            // Reindex array to get the first machine consistently
            $machines = array_values($machines);
            
            // Update the original ticket with the first machine
            executeUpdate($pdo, "
                UPDATE tickets
                SET imaging_machine = ?
                WHERE ticket_id = ?
            ", [$machines[0], $ticket_id]);

            // Log the assignment for the original patient
            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Assigned to Machine', 'Waiting', 'Waiting', ?, ?, 'Patient assigned to {$machines[0]}')";
            executeUpdate($pdo, $log_sql, [$ticket_id, $machines[0], authCurrentUserId() ?: null]);

            // Create duplicate tickets for additional machines
            for ($i = 1; $i < count($machines); $i++) {
                $machine = $machines[$i];

                // Insert duplicate ticket record (include MRN)
                $insert_sql = "INSERT INTO tickets (
                        patient_id, queue_number, service_type,
                        current_status, arrival_timestamp, approval_timestamp,
                        lab_call_time, imaging_call_time, imaging_machine,
                        lab, img, dp2
                    ) VALUES (
                        ?, ?, ?,
                        'Waiting', ?, NOW(),
                        NULL, NULL, ?,
                        ?, ?, ?
                    )";
                executeUpdate($pdo, $insert_sql, [
                    $originalPatient['patient_id'],
                    $originalPatient['queue_number'],
                    $originalPatient['service_type'],
                    $originalPatient['arrival_timestamp'],
                    $machine,
                    $originalPatient['lab'],
                    $originalPatient['img'],
                    $originalPatient['dp2']
                ]);

                $newTicketId = $pdo->lastInsertId();

                // Log the assignment for the duplicate ticket
                $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes) VALUES (?, 'Assigned to Machine', 'Waiting', 'Waiting', ?, ?, 'Duplicate ticket created and assigned to $machine')";
                executeUpdate($pdo, $log_sql, [$newTicketId, $machine, authCurrentUserId() ?: null]);
            }
            // close originalPatient if-block
        }

            $machine_list = implode(', ', $machines);
            
            if ($isAjax) {
                echo json_encode(['success' => true, 'message' => "Patient assigned to: $machine_list"]);
                exit();
            }
            
            echo "<script>alert('Patient assigned to: $machine_list');</script>";
            echo "<script>if (window.smartReload) window.smartReload(0); else window.location.reload();</script>";
            exit();
    } else {
        // No machines selected, show error
        if ($isAjax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Please select at least one machine']);
            exit();
        }
        echo "<script>alert('Please select at least one machine');</script>";
    }
}

// For AJAX requests, clean buffer and set proper headers
if ($isAjax) {
    ob_end_clean();
    header('Content-Type: text/html; charset=utf-8');
} else {
    ob_end_clean();
}
?>

<div class="assignments-header">
    <h2>
        <i class="fas fa-tasks"></i>
        Assignments
    </h2>
    <p style="color: #7f8c8d; font-size: 14px; margin: 5px 0 0 0;">
        Assign patients to imaging machines
    </p>
</div>

<div class="assignments-list" id="assignmentsList">
    <?php
    // Get patients waiting to be assigned
    $query = "
        SELECT 
            p.id,
            p.queue_number,
            p.mrn,
            p.patient_name,
            p.mobile,
            p.service_type,
            TIMESTAMPDIFF(MINUTE, p.approval_timestamp, NOW()) as wait_minutes
        FROM patients p
        WHERE p.closing_timestamp IS NULL 
        AND p.current_status IN ('Waiting', 'On Hold')
        AND p.img = 1
        AND (p.lab = 0 OR p.dp2 = 1)
        AND (p.imaging_machine IS NULL OR p.imaging_machine = '')
        AND DATE(p.arrival_timestamp) = CURDATE()
        ORDER BY 
            FIELD(p.service_type, 'Appointment', 'Private', 'Guarantor'),
            COALESCE(p.approval_timestamp, p.arrival_timestamp) ASC
    ";
    
    $assignments = executeAndFetch($pdo, $query, []);
    
    if (empty($assignments)): ?>
        <div class="empty-state">
            <i class="fas fa-clipboard-check"></i>
            <h3>No pending assignments</h3>
            <p>All patients have been assigned to machines</p>
        </div>
    <?php else: 
        foreach ($assignments as $patient): ?>
            <div class="assignment-item">
                    <div class="assignment-item-header view-pdf-btn" data-patient='<?php echo htmlspecialchars(json_encode([
                        'id' => $patient['id'],
                        'queue_number' => $patient['queue_number'],
                        'patient_name' => $patient['patient_name'],
                        'mrn' => $patient['mrn'] ?? ''
                    ]), ENT_QUOTES, 'UTF-8'); ?>' style="cursor:pointer;">
                        <div class="patient-name">
                            <?php echo htmlspecialchars($patient['patient_name']); ?>
                        </div>
                        <div class="queue-number">
                            <?php echo htmlspecialchars($patient['queue_number']); ?>
                        </div>
                    </div>
                
                <div style="font-size: 13px; color: #7f8c8d; margin-bottom: 15px;">
                    <span style="margin-right: 10px;">
                        <i class="fas fa-phone"></i> 
                        <?php echo $patient['mobile'] ? htmlspecialchars($patient['mobile']) : 'N/A'; ?>
                    </span>
                    <span>
                        <i class="fas fa-tag"></i> 
                        <?php echo htmlspecialchars($patient['service_type']); ?>
                    </span>
                                    <!-- wait time removed per user request -->
                </div>
                
                <form method="POST" class="assignment-form">
                    <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                    
                    <!-- Single machine dropdown -->
                    <div class="machine-selections">
                        <div class="machine-input-group">
                            <select name="machines[]" class="machine-select" required>
                                <option value="">Select Machine</option>
                                <?php
                                $machines = ['Xray', 'Fluoroscopy', 'Mammography', 'CT', 'UltraSound', 'MRI'];
                                foreach ($machines as $machine): ?>
                                    <option value="<?php echo $machine; ?>">
                                        <?php echo $machine; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <!-- Remove button is hidden for first dropdown -->
                            <button type="button" class="remove-machine-btn" title="Remove this machine" style="display: none;">
                                <i class="fas fa-minus"></i>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Buttons container - now positioned under the dropdown -->
                    <div class="assignment-buttons">
                        <button type="button" class="add-machine-btn" title="Add another machine">
                            <i class="fas fa-plus"></i>
                        </button>
                        <button type="submit" name="assign_machine" class="assign-btn">
                            <i class="fas fa-check"></i>
                        </button>
                    </div>
                </form>
            </div>
        <?php endforeach;
    endif; ?>
</div>

<style>
.assignment-item-header {
    padding: 12px 15px;
    background: #f8f9fa;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
    transition: all 0.2s ease;
}

.assignment-item-header:hover {
    background: #e8f4f8;
    border-color: #3498db;
    box-shadow: 0 2px 8px rgba(52, 152, 219, 0.2);
}

.assignment-item-header.view-pdf-btn {
    cursor: pointer;
}

.machine-selections {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 15px;
}

.machine-input-group {
    display: flex;
    gap: 8px;
    align-items: center;
}

.machine-input-group .machine-select {
    flex: 1;
    height: 40px;
    padding: 0 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    background-color: white;
}

.assignment-buttons {
    display: flex;
    gap: 8px;
    margin-top: 10px;
    align-items: center;
    padding: 8px 12px;
    background: #f5f5f5;
    border-radius: 6px;
    border: 1px solid #e0e0e0;
    cursor: pointer;
    transition: all 0.2s ease;
}

.assignment-buttons:hover {
    background: #ede7f6;
    border-color: #9b59b6;
}

.assignment-buttons .add-machine-btn {
    /* icon-only button */
    width: 40px;
    height: 40px;
    padding: 0;
    border: 2px solid #9b59b6;
    background-color: transparent;
    color: #9b59b6;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    transition: all 0.15s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.assignment-buttons .add-machine-btn:hover {
    background-color: #9b59b6;
    color: white;
}

.assignment-buttons .assign-btn {
    /* icon-only submit button */
    width: 40px;
    height: 40px;
    padding: 0;
    border: none;
    background-color: #27ae60;
    color: white;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    transition: all 0.15s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.assignment-buttons .assign-btn:hover {
    background-color: #229954;
}

.remove-machine-btn {
    flex-shrink: 0;
    width: 40px;
    height: 40px;
    padding: 0;
    border: 2px solid #e74c3c;
    background-color: transparent;
    color: #e74c3c;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.remove-machine-btn:hover {
    background-color: #e74c3c;
    color: white;
}

.patient-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.7);
    z-index: 1000;
    align-items: center;
    justify-content: center;
}

.patient-modal.active {
    display: flex;
}

.patient-modal-content {
    background-color: white;
    border-radius: 12px;
    width: 90%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

.patient-modal-header {
    background: #3498db;
    color: white;
    padding: 20px;
    border-radius: 12px 12px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.patient-modal-title {
    font-size: 20px;
    font-weight: 600;
}

.patient-modal-close {
    background: none;
    border: none;
    color: white;
    font-size: 24px;
    cursor: pointer;
    padding: 0;
    width: 30px;
    height: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.patient-modal-body {
    padding: 25px;
}

.patient-info-group {
    margin-bottom: 20px;
}

.patient-info-label {
    font-size: 12px;
    color: #7f8c8d;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 5px;
}

.patient-info-value {
    font-size: 16px;
    color: #2c3e50;
    font-weight: 500;
}

.action-btn {
    padding: 8px 15px;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.action-btn.start {
    background: #27ae60;
    color: white;
}

.action-btn.start:hover {
    background: #219653;
}
</style>

<script>
// Machine list template options
const machineOptions = [
    'Xray', 'Fluoroscopy', 'Mammography', 'CT', 'UltraSound', 'MRI'
];

// Utility function to escape HTML
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = String(text);
    return div.innerHTML;
}

// Show ID and prescription popup (for imaging assignments)
function showPdfSelectorImaging(patient) {
    // Ensure patient is parsed
    if (typeof patient === 'string') {
        try { patient = JSON.parse(patient); } catch(e) { console.error(e); return; }
    }
    
    // Create modal if not present
    let modal = document.getElementById('pdfSelectorModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'pdfSelectorModal';
        modal.className = 'patient-modal';
        modal.innerHTML = `
            <div class="patient-modal-content">
                <div class="patient-modal-header">
                    <div class="patient-modal-title"><i class="fas fa-file-pdf"></i> Open Document</div>
                    <button class="patient-modal-close" id="pdfModalClose"><i class="fas fa-times"></i></button>
                </div>
                <div class="patient-modal-body" id="pdfModalBody"></div>
            </div>`;
        document.body.appendChild(modal);
        modal.querySelector('#pdfModalClose').addEventListener('click', () => modal.classList.remove('active'));
        // Close on background click
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                this.classList.remove('active');
            }
        });
    }

    const body = modal.querySelector('#pdfModalBody');
    body.innerHTML = `
        <div style="margin-bottom:12px;"><strong>${escapeHtml(patient.patient_name || '')}</strong> — ${escapeHtml(patient.queue_number || '')}</div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
            <button id="openIdBtn" class="action-btn start"><i class="fas fa-id-card"></i> Open ID</button>
            <button id="openPrescBtn" class="action-btn" style="background:#9b59b6; color:white;"><i class="fas fa-prescription"></i> Open Prescription</button>
        </div>
    `;

    modal.classList.add('active');

    function openFile(type) {
        const filenameBase = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : patient.id;
        const url = 'download_pdf.php?type=' + encodeURIComponent(type) + '&file=' + encodeURIComponent(filenameBase + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
        window.open(url, '_blank', 'noopener');
    }

    modal.querySelector('#openIdBtn').onclick = () => openFile('id');
    modal.querySelector('#openPrescBtn').onclick = () => openFile('insurance');
}

// Handle clicks on entire patient name card to open ID and prescription popup
document.addEventListener('click', function(e) {
    if (!(e.target instanceof Element)) return;
    
    // Check if we clicked on the assignment-item-header with view-pdf-btn class
    const header = e.target.classList.contains('view-pdf-btn') ? 
        e.target : (e.target.closest ? e.target.closest('.view-pdf-btn.assignment-item-header') : null);
    
    if (header) {
        e.preventDefault();
        e.stopPropagation();
        const data = header.getAttribute('data-patient');
        try {
            const patient = JSON.parse(data);
            showPdfSelectorImaging(patient);
        } catch(err) {
            console.error('Invalid patient data', err);
        }
    }
});
</script>

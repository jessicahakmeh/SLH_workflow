-- MySQL Connection Monitoring SQL Script
-- Run periodically to check connection pool health
-- mysql -u root queue < monitor_connections.sql

-- Current active connections
SELECT 
    COUNT(*) as active_connections,
    USER,
    DATABASE
FROM information_schema.processlist
GROUP BY USER, DATABASE
ORDER BY active_connections DESC;

-- Connection pool status
SHOW PROCESSLIST;

-- Server variables
SELECT 
    variable_name,
    variable_value
FROM information_schema.global_variables
WHERE variable_name IN (
    'max_connections',
    'max_used_connections',
    'wait_timeout',
    'interactive_timeout',
    'net_read_timeout',
    'net_write_timeout',
    'max_allowed_packet'
)
ORDER BY variable_name;

-- Detailed connection info
SELECT 
    ID as connection_id,
    USER,
    HOST,
    DB as database_name,
    COMMAND,
    TIME as duration_seconds,
    STATE,
    INFO as query
FROM information_schema.processlist
WHERE COMMAND != 'Sleep'
ORDER BY TIME DESC;

// stream-handler.js - Handle stream interactions
class StreamHandler {
    constructor() {
        this.init();
    }
    
    init() {
        // Delegate click events
        document.addEventListener('click', this.handleClick.bind(this));
        
        // Handle modal actions
        document.addEventListener('click', (e) => {
            if (e.target.closest('.stream-modal-confirm')) {
                this.handleConfirmAction(e.target.closest('.stream-modal-confirm'));
            }
            if (e.target.closest('.stream-modal-cancel, .stream-modal-close')) {
                this.closeModal();
            }
        });
        
        // Handle escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal();
            }
        });
    }
    
    handleClick(e) {
        // Handle billing card clicks
        if (e.target.closest('.billing-patient-card')) {
            e.preventDefault();
            const card = e.target.closest('.billing-patient-card');
            const patientId = card.dataset.patientId;
            const stream = 'billing';
            
            if (patientId) {
                card.classList.remove('flashing');
                this.showConfirmationModal(stream, patientId);
            }
        }
        
        // Handle called display clicks
        if (e.target.closest('.called-display')) {
            e.preventDefault();
            const display = e.target.closest('.called-display');
            const patientId = display.dataset.patientId;
            const streamCard = display.closest('.stream-card');
            const stream = streamCard.classList.contains('lab-card') ? 'lab' : 'imaging';
            
            if (patientId) {
                this.showConfirmationModal(stream, patientId);
            }
        }
        
        // Close modal when clicking outside
        if (e.target.classList.contains('stream-modal')) {
            this.closeModal();
        }
    }
    
    async showConfirmationModal(stream, patientId) {
        try {
            // Set flag BEFORE opening modal to prevent refresh race condition
            window.isModalOpen = true;
            window.isStreamModalOpen = true;
            
            const response = await fetch(`stream.php?mode=modal&stream=${stream}&patient_id=${patientId}`);
            const modalHtml = await response.text();
            
            // Create modal container if it doesn't exist
            let modalContainer = document.getElementById('modalContainer');
            if (!modalContainer) {
                modalContainer = document.createElement('div');
                modalContainer.id = 'modalContainer';
                document.body.appendChild(modalContainer);
            }
            
            modalContainer.innerHTML = modalHtml;
            
            // Pause auto-refresh (works with RefreshManager and butler.php)
            if (window.refreshManager) {
                window.refreshManager.stopAutoRefresh();
            }
            if (window.stopAutoRefresh) {
                window.stopAutoRefresh();
            }
            
            // Add event listener for confirm button
            const confirmBtn = document.querySelector('.stream-modal-confirm');
            if (confirmBtn) {
                confirmBtn.addEventListener('click', () => {
                    this.handleConfirmAction(confirmBtn);
                });
            }
            
        } catch (error) {
            console.error('Error loading modal:', error);
            alert('Error loading confirmation dialog');
        }
    }
    
    async handleConfirmAction(button) {
        const stream = button.dataset.stream;
        const patientId = button.dataset.patientId;
        
        if (!stream || !patientId) return;
        
        const action = stream === 'billing' ? 'confirm_reception' : 'mark_on_the_way';
        
        try {
            const response = await fetch(`stream.php?stream=${stream}&action=${action}&patient_id=${patientId}`);
            const result = await response.json();
            
            if (result.success) {
                // Refresh the stream
                await this.refreshStream(stream);
                
                // Close modal
                this.closeModal();
                
                // Show success message
                this.showToast('Action completed successfully');
            }
        } catch (error) {
            console.error('Error performing action:', error);
            alert('Error performing action');
        }
    }
    
    async refreshStream(stream) {
        try {
            const response = await fetch(`stream.php?mode=cards&stream=${stream}`);
            const html = await response.text();
            
            const streamContainer = document.getElementById(`${stream}Stream`);
            if (streamContainer) {
                streamContainer.innerHTML = html;
            }
        } catch (error) {
            console.error(`Error refreshing ${stream} stream:`, error);
        }
    }
    
    closeModal() {
        const modal = document.getElementById('confirmationModal');
        if (modal) {
            modal.classList.remove('active');
            
            // Remove modal after animation
            setTimeout(() => {
                const modalContainer = document.getElementById('modalContainer');
                if (modalContainer) {
                    modalContainer.innerHTML = '';
                }
                
                // Clear both flags to allow refresh to resume
                window.isModalOpen = false;
                window.isStreamModalOpen = false;
                
                // Resume auto-refresh (works with RefreshManager and butler.php)
                if (window.refreshManager) {
                    window.refreshManager.startAutoRefresh();
                }
                if (window.startAutoRefresh) {
                    window.startAutoRefresh();
                }
            }, 300);
        }
    }
    
    showToast(message) {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = 'stream-toast';
        toast.textContent = message;
        document.body.appendChild(toast);
        
        // Show toast
        setTimeout(() => toast.classList.add('show'), 100);
        
        // Remove toast after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.streamHandler = new StreamHandler();
});
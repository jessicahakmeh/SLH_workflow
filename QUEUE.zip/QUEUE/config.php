<?php
// Configure session settings BEFORE session_start() is called anywhere
if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_NONE) {
    $sessionStoragePath = __DIR__ . '/temp/sessions';
    if (!is_dir($sessionStoragePath)) {
        @mkdir($sessionStoragePath, 0777, true);
    }
    if (is_dir($sessionStoragePath) && is_writable($sessionStoragePath)) {
        session_save_path($sessionStoragePath);
    }

    $scriptName = (string)($_SERVER['SCRIPT_NAME'] ?? '/');
    $cookiePath = str_replace('\\', '/', dirname($scriptName));
    if ($cookiePath === '.' || $cookiePath === '') {
        $cookiePath = '/';
    }
    if ($cookiePath[0] !== '/') {
        $cookiePath = '/' . $cookiePath;
    }

    // Detect HTTPS reliably across direct and proxy-fronted deployments.
    $httpsFlag = strtolower((string)($_SERVER['HTTPS'] ?? ''));
    $requestScheme = strtolower((string)($_SERVER['REQUEST_SCHEME'] ?? ''));
    $forwardedProto = strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''));
    $isSecure = ($httpsFlag !== '' && $httpsFlag !== 'off') || $requestScheme === 'https' || $forwardedProto === 'https';

    // Use an app-specific session cookie name to avoid collisions with other PHP apps on the same host.
    session_name('QUEUESESSID');

    if (!defined('AUTH_SESSION_TIMEOUT_SECONDS')) {
        define('AUTH_SESSION_TIMEOUT_SECONDS', 86400); // 24 hours
    }
    ini_set('session.gc_maxlifetime', (string)AUTH_SESSION_TIMEOUT_SECONDS);

    session_set_cookie_params([
        'lifetime' => 0, // Session cookie expires when browser closes
        'path' => $cookiePath,
        'secure' => $isSecure, // Only secure over HTTPS
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

if (!defined('APP_TIMEZONE')) {
    define('APP_TIMEZONE', 'Asia/Beirut');
}
date_default_timezone_set(APP_TIMEZONE);

// Database configuration
$host = 'localhost';
$dbname = 'queue';
$username = 'root';
$password = '';

        require_once __DIR__ . '/lib/monitoring.php';
        // If $pdo is null or not a PDO instance, attempt to (re)create it
if (!defined('DB_CONNECTION_TIMEOUT')) {
    define('DB_CONNECTION_TIMEOUT', 10); // seconds to wait for connection
}
if (!defined('DB_SOCKET_TIMEOUT')) {
    define('DB_SOCKET_TIMEOUT', 30); // seconds for socket operations
}
if (!defined('DB_MAX_CONNECTIONS')) {
    define('DB_MAX_CONNECTIONS', 100); // target MySQL max_connections setting
}

if (!defined('AUTH_ENABLED')) {
    define('AUTH_ENABLED', true);
}
if (!defined('AUTH_AD_ENABLED')) {
    define('AUTH_AD_ENABLED', true);
}
if (!defined('AUTH_AD_SERVER')) {
    define('AUTH_AD_SERVER', 'ldap://192.168.20.1');
}
if (!defined('AUTH_AD_FALLBACK_SERVER')) {
    define('AUTH_AD_FALLBACK_SERVER', 'ldap://192.168.20.100');
}
if (!defined('AUTH_AD_PORT')) {
    define('AUTH_AD_PORT', 389);
}
if (!defined('AUTH_AD_DOMAIN')) {
    define('AUTH_AD_DOMAIN', 'stlouis.com');
}
if (!defined('AUTH_AD_NETBIOS')) {
    define('AUTH_AD_NETBIOS', 'stlouis');
}
if (!defined('AUTH_AD_BASE_DN')) {
    define('AUTH_AD_BASE_DN', 'DC=stlouis,DC=com');
}
if (!defined('AUTH_AD_USE_TLS')) {
    define('AUTH_AD_USE_TLS', false);
}
if (!defined('AUTH_AD_SEARCH_BIND_USER')) {
    define('AUTH_AD_SEARCH_BIND_USER', 'svc-directus');
}
if (!defined('AUTH_AD_SEARCH_BIND_PASS')) {
    define('AUTH_AD_SEARCH_BIND_PASS', 'QxmXIgtaXiOR7EWrSXIb');
}

// Suppress output for AJAX/JSON requests
$suppress_output = isset($_GET['suppress_output']) || isset($_SERVER['HTTP_X_REQUESTED_WITH']);

// Start output buffering to prevent any accidental output in AJAX requests
if ($suppress_output) {
    ob_start();
}

//========== PDF creation for patient files ===========
// Network share credentials
define('NETWORK_USERNAME', 'stlouis\\appuser');  // Note: double backslash for Windows domain
define('NETWORK_PASSWORD', '$ecure@pp');
// Network paths
define('ID_SAVE_PATH', '\\\\192.168.20.3\\slh\\Internal\\Finance\\Accounting Department\\Admission & Billing\\Common\\Patients ID\\Queue_IDs\\');
define('INSURANCE_SAVE_PATH', '\\\\192.168.20.3\\slh\\Internal\\Finance\\Accounting Department\\Admission & Billing\\Common\\Patients ID\\Queue_presc&ins\\');

if (!defined('FEEDBACK_TALLY_FORM_URL')) {
    define('FEEDBACK_TALLY_FORM_URL', 'https://survey.slouishospital.com/feedback');
}
if (!defined('FEEDBACK_SEND_DELAY_HOURS')) {
    define('FEEDBACK_SEND_DELAY_HOURS', 24); // Set to 0 for same-day feedback sends
}
if (!defined('FEEDBACK_SEND_FROM_DATE')) {
    define('FEEDBACK_SEND_FROM_DATE', '2026-06-16'); // Set to YYYY-MM-DD to ignore older tickets, or leave empty to include all tickets
}
// Feedback token TTL kept for reference only (not used in DB-token mode).
if (!defined('FEEDBACK_BASE_URL')) {
    define('FEEDBACK_BASE_URL', '');
}
if (!defined('FEEDBACK_PUBLIC_ENTRY_URL')) {
    define('FEEDBACK_PUBLIC_ENTRY_URL', 'https://feedback.slouishospital.com/feedback/{token}');
}

if (!defined('WHATSAPP_API_URL')) {
    define('WHATSAPP_API_URL', 'https://www.bestsmsbulk.com/bestsmsbulkapi/common/sendSmsWpAPITemplate.php');
}
if (!defined('WHATSAPP_API_KEY')) {
    define('WHATSAPP_API_KEY', '02015ec21253fe7a773d9b31710e94d9b4e835373b0f3afadf9f2ee02c592804');
}
if (!defined('WHATSAPP_API_SECRET')) {
    define('WHATSAPP_API_SECRET', '17ac76331e6efae5ec80ae8a9abaef71c173017993fc37e811d6f33537c7e9d3');
}
if (!defined('WHATSAPP_SENDER_ID')) {
    define('WHATSAPP_SENDER_ID', '96176105260');
}
if (!defined('WHATSAPP_ROUTE')) {
    define('WHATSAPP_ROUTE', 'wp');
}
if (!defined('DB_SCHEMA_BOOTSTRAP_TTL_SECONDS')) {
    define('DB_SCHEMA_BOOTSTRAP_TTL_SECONDS', 21600);
}
if (!defined('WHATSAPP_HTTP_TIMEOUT_SECONDS')) {
    define('WHATSAPP_HTTP_TIMEOUT_SECONDS', 10);
}
if (!defined('WHATSAPP_CONNECT_TIMEOUT_SECONDS')) {
    define('WHATSAPP_CONNECT_TIMEOUT_SECONDS', 5);
}
if (!defined('WHATSAPP_LOG_API_CALLS')) {
    define('WHATSAPP_LOG_API_CALLS', true);
}

function shouldRunSchemaBootstrap($markerPath, $ttlSeconds) {
    $ttlSeconds = max(30, (int)$ttlSeconds);
    clearstatcache(true, $markerPath);
    if (!file_exists($markerPath)) {
        return true;
    }
    $age = time() - (int)@filemtime($markerPath);
    return $age >= $ttlSeconds;
}

function markSchemaBootstrapComplete($markerPath) {
    $dir = dirname($markerPath);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    @touch($markerPath);
}

function runSchemaBootstrapIfNeeded($pdo) {
    $markerPath = __DIR__ . '/temp/schema_bootstrap.ok';
    $lockPath = __DIR__ . '/temp/schema_bootstrap.lock';

    if (!shouldRunSchemaBootstrap($markerPath, DB_SCHEMA_BOOTSTRAP_TTL_SECONDS)) {
        return;
    }

    $lockHandle = @fopen($lockPath, 'c');
    if ($lockHandle === false) {
        createTablesIfNotExist($pdo);
        markSchemaBootstrapComplete($markerPath);
        return;
    }

    // Avoid request pileups: if another request is bootstrapping, skip this run.
    if (!@flock($lockHandle, LOCK_EX | LOCK_NB)) {
        fclose($lockHandle);
        return;
    }

    try {
        if (shouldRunSchemaBootstrap($markerPath, DB_SCHEMA_BOOTSTRAP_TTL_SECONDS)) {
            createTablesIfNotExist($pdo);
            markSchemaBootstrapComplete($markerPath);
        }
    } finally {
        @flock($lockHandle, LOCK_UN);
        fclose($lockHandle);
    }
}

// Create initial connection without database
try {
    // First connection: create database if needed
    $conn = new PDO(
        "mysql:host=$host;charset=utf8",
        $username,
        $password,
        [
            PDO::ATTR_TIMEOUT => DB_CONNECTION_TIMEOUT,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if database exists, create if not
    $stmt = $conn->query("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbname'");
    if ($stmt->rowCount() == 0) {
        $conn->exec("CREATE DATABASE $dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        if (!$suppress_output) echo "Database created successfully.<br>";
    }
    
    // Close this temporary connection to free resources
    $conn = null;
    
    // Now connect to the specific database with connection pooling and timeout settings
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_TIMEOUT => DB_CONNECTION_TIMEOUT,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_PERSISTENT => false, // Avoid persistent connections that don't pool well
        ]
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // Set session-level timeouts (connection timeout is already set via PDO::ATTR_TIMEOUT)
    // These help prevent "MySQL server has gone away" errors by closing idle connections
    $pdo->exec("SET SESSION wait_timeout = 600"); // 10 minutes - close idle connections
    $pdo->exec("SET SESSION interactive_timeout = 28800"); // 8 hours for interactive sessions
    $pdo->exec("SET SESSION net_read_timeout = 300"); // 5 minutes for long-running queries
    $pdo->exec("SET SESSION net_write_timeout = 300"); // 5 minutes for response writes
    
    // Run schema bootstrap only periodically to reduce per-request latency.
    runSchemaBootstrapIfNeeded($pdo);
    
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

/**
 * Check if database connection is alive and reconnect if needed
 * This helps prevent "MySQL server has gone away" errors in long-running scripts
 * especially for streaming connections like realtime_updates.php
 * 
 * @param PDO &$pdo - Reference to PDO connection object
 * @return bool - True if connection is healthy, false if reconnection failed
 */
function ensureDbConnectionAlive(&$pdo) {
    global $host, $dbname, $username, $password;
    
    try {
        // If $pdo is null or not a PDO instance, attempt to (re)create it
        if (!($pdo instanceof PDO)) {
            // Try to create a fresh connection
            $pdo = new PDO(
                "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
                $username,
                $password,
                [
                    PDO::ATTR_TIMEOUT => DB_CONNECTION_TIMEOUT,
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_PERSISTENT => false,
                ]
            );
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            // Re-set session-level timeouts
            try { $pdo->exec("SET SESSION wait_timeout = 600"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION interactive_timeout = 28800"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION net_read_timeout = 300"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION net_write_timeout = 300"); } catch (Throwable $__e) {}
            return true;
        }

        // Quick ping to test connection
        $pdo->query('SELECT 1');
        return true;
    } catch (PDOException $e) {
        // Connection is dead or unusable; attempt to reconnect safely
        error_log("Database connection lost: " . $e->getMessage() . ". Attempting reconnection...");

        try {
            // Close old connection
            $pdo = null;

            // Create new connection with same settings
            $pdo = new PDO(
                "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
                $username,
                $password,
                [
                    PDO::ATTR_TIMEOUT => DB_CONNECTION_TIMEOUT,
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_PERSISTENT => false,
                ]
            );

            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            // Re-set timeouts (best-effort)
            try { $pdo->exec("SET SESSION wait_timeout = 600"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION interactive_timeout = 28800"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION net_read_timeout = 300"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION net_write_timeout = 300"); } catch (Throwable $__e) {}

            error_log("Database reconnection successful");
            return true;

        } catch (Throwable $reconnectError) {
            error_log("Database reconnection failed: " . $reconnectError->getMessage());
            return false;
        }
    } catch (Throwable $t) {
        // Catch any non-PDO errors and attempt to reconnect
        error_log("Database check failed (non-PDO): " . $t->getMessage());
        try {
            $pdo = null;
            $pdo = new PDO(
                "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
                $username,
                $password,
                [
                    PDO::ATTR_TIMEOUT => DB_CONNECTION_TIMEOUT,
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_PERSISTENT => false,
                ]
            );
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            try { $pdo->exec("SET SESSION wait_timeout = 600"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION interactive_timeout = 28800"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION net_read_timeout = 300"); } catch (Throwable $__e) {}
            try { $pdo->exec("SET SESSION net_write_timeout = 300"); } catch (Throwable $__e) {}
            return true;
        } catch (Throwable $finalError) {
            error_log("Database reconnection failed after throwable: " . $finalError->getMessage());
            return false;
        }
    }
}

/**
 * Create all necessary tables if they don't exist
 */
function createTablesIfNotExist($pdo) {
    global $suppress_output;

    createAuthTablesIfNotExist($pdo, $suppress_output);
    
    // ─── 3a. patients (demographics) ─────────────────────────────────────────
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS patients (
            patient_id          INT           NOT NULL AUTO_INCREMENT,
            mrn                 VARCHAR(100)  DEFAULT NULL,
            patient_name        VARCHAR(255)  NOT NULL,
            country_code        VARCHAR(10)   NOT NULL DEFAULT '+961',
            mobile              VARCHAR(20)   NOT NULL DEFAULT '',
            care_country_code   VARCHAR(10)   DEFAULT '+961',
            care_mobile         VARCHAR(20)   DEFAULT NULL,
            email               VARCHAR(255)  DEFAULT NULL,
            address             TEXT          DEFAULT NULL,
            PRIMARY KEY (patient_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Ensure default care country code is Lebanon in existing databases as well.
    try {
        $pdo->exec("ALTER TABLE patients MODIFY COLUMN care_country_code VARCHAR(10) DEFAULT '+961'");
    } catch (Exception $e) {}

    // ─── 3b. tickets (queue / workflow entries) ───────────────────────────────
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tickets (
            ticket_id          INT  NOT NULL AUTO_INCREMENT,
            patient_id         INT  NOT NULL,
            queue_number       VARCHAR(20)   NOT NULL,
            service_type       ENUM('Appointment','Private','Guarantor','Clinics') NOT NULL,
            current_status     ENUM('Arrived','Waiting','In Process','Needed by Billing',
                                   'Called','On the Way','Skipped','Recalled','Served','On Hold',
                                   'Wrong Info','Completed','Canceled')
                               NOT NULL DEFAULT 'Arrived',
            arrival_timestamp  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            approval_timestamp DATETIME DEFAULT NULL,
            lab                TINYINT(1) NOT NULL DEFAULT 0,
            img                TINYINT(1) NOT NULL DEFAULT 0,
            dp2                TINYINT(1) NOT NULL DEFAULT 0,
            cl                 TINYINT(1) NOT NULL DEFAULT 0,
            lab_call_time      DATETIME DEFAULT NULL,
            imaging_call_time  DATETIME DEFAULT NULL,
            clinics_call_time  DATETIME DEFAULT NULL,
            closing_timestamp  DATETIME DEFAULT NULL,
            imaging_machine    ENUM('Xray','Fluoroscopy','Mammography','CT','UltraSound','MRI') DEFAULT NULL,
            Clinic             ENUM('Misc','ENT-URO','OBGYN','Cardio','OPS','PAU') DEFAULT NULL,
            registered_by_username VARCHAR(100) DEFAULT NULL,
            assigned_butler_username VARCHAR(100) DEFAULT NULL,
            last_need_request_by_username VARCHAR(100) DEFAULT NULL,
            last_need_request_at DATETIME DEFAULT NULL,
            is_existing_patient TINYINT(1) NOT NULL DEFAULT 0,
            demographics_snapshot LONGTEXT DEFAULT NULL,
            demographics_edited TINYINT(1) NOT NULL DEFAULT 0,
            demographics_changed_fields LONGTEXT DEFAULT NULL,
            PRIMARY KEY (ticket_id),
            FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE RESTRICT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // Remove legacy priority column if it exists in upgraded databases.
    try {
        $hasPriority = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'priority'")->rowCount() > 0;
        if ($hasPriority) {
            $pdo->exec("ALTER TABLE tickets DROP COLUMN priority");
        }
    } catch (Exception $e) {}

    // Ensure status enum includes the On the Way transitional state.
    try {
        $pdo->exec("ALTER TABLE tickets MODIFY COLUMN current_status ENUM('Arrived','Waiting','In Process','Needed by Billing','Called','On the Way','Skipped','Recalled','Served','On Hold','Wrong Info','Completed','Canceled') NOT NULL DEFAULT 'Arrived'");
    } catch (Exception $e) {}

    // Add tracking columns for existing-patient workflow and demographic edits.
    try {
        $hasExistingFlag = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'is_existing_patient'")->rowCount() > 0;
        if (!$hasExistingFlag) {
            $pdo->exec("ALTER TABLE tickets ADD COLUMN is_existing_patient TINYINT(1) NOT NULL DEFAULT 0");
        }
    } catch (Exception $e) {}

    try {
        $hasSnapshot = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'demographics_snapshot'")->rowCount() > 0;
        if (!$hasSnapshot) {
            $pdo->exec("ALTER TABLE tickets ADD COLUMN demographics_snapshot LONGTEXT DEFAULT NULL");
        }
    } catch (Exception $e) {}

    try {
        $hasEdited = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'demographics_edited'")->rowCount() > 0;
        if (!$hasEdited) {
            $pdo->exec("ALTER TABLE tickets ADD COLUMN demographics_edited TINYINT(1) NOT NULL DEFAULT 0");
        }
    } catch (Exception $e) {}

    try {
        $hasChangedFields = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'demographics_changed_fields'")->rowCount() > 0;
        if (!$hasChangedFields) {
            $pdo->exec("ALTER TABLE tickets ADD COLUMN demographics_changed_fields LONGTEXT DEFAULT NULL");
        }
    } catch (Exception $e) {}

    try {
        $hasRegisteredByUsername = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'registered_by_username'")->rowCount() > 0;
        if (!$hasRegisteredByUsername) {
            $pdo->exec("ALTER TABLE tickets ADD COLUMN registered_by_username VARCHAR(100) DEFAULT NULL");
        }
    } catch (Exception $e) {}

    try {
        $hasAssignedButlerUsername = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'assigned_butler_username'")->rowCount() > 0;
        if (!$hasAssignedButlerUsername) {
            $pdo->exec("ALTER TABLE tickets ADD COLUMN assigned_butler_username VARCHAR(100) DEFAULT NULL");
        }
    } catch (Exception $e) {}

    try {
        $hasLastNeedByUsername = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'last_need_request_by_username'")->rowCount() > 0;
        if (!$hasLastNeedByUsername) {
            $pdo->exec("ALTER TABLE tickets ADD COLUMN last_need_request_by_username VARCHAR(100) DEFAULT NULL");
        }
    } catch (Exception $e) {}

    try {
        $hasLastNeedAt = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'last_need_request_at'")->rowCount() > 0;
        if (!$hasLastNeedAt) {
            $pdo->exec("ALTER TABLE tickets ADD COLUMN last_need_request_at DATETIME DEFAULT NULL");
        }
    } catch (Exception $e) {}

    // Drop deprecated *_user_id ticket columns after username-based tracking replaced them.
    try {
        $hasRegisteredById = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'registered_by_user_id'")->rowCount() > 0;
        if ($hasRegisteredById) {
            $pdo->exec("ALTER TABLE tickets DROP COLUMN registered_by_user_id");
        }
    } catch (Exception $e) {}

    try {
        $hasAssignedButlerId = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'assigned_butler_user_id'")->rowCount() > 0;
        if ($hasAssignedButlerId) {
            $pdo->exec("ALTER TABLE tickets DROP COLUMN assigned_butler_user_id");
        }
    } catch (Exception $e) {}

    try {
        $hasLastNeedById = $pdo->query("SHOW COLUMNS FROM tickets LIKE 'last_need_request_by_user_id'")->rowCount() > 0;
        if ($hasLastNeedById) {
            $pdo->exec("ALTER TABLE tickets DROP COLUMN last_need_request_by_user_id");
        }
    } catch (Exception $e) {}



    $pdo->exec(" 
        CREATE TABLE IF NOT EXISTS feedback_tickets (
            ticket_id INT NOT NULL,
            feedback_sent TINYINT(1) NOT NULL DEFAULT 0,
            /* feedback_token VARCHAR(64) DEFAULT NULL,
            feedback_filled TINYINT(1) NOT NULL DEFAULT 0,
            fill_timestamp DATETIME DEFAULT NULL,
            tally_id VARCHAR(255) DEFAULT NULL, */
            PRIMARY KEY (ticket_id),
            CONSTRAINT fk_feedback_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");


    // ─── 4. ticket_logs ───────────────────────────────────────────────────────
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ticket_logs (
            id          INT PRIMARY KEY AUTO_INCREMENT,
            ticket_id   INT NOT NULL,
            action      VARCHAR(100) NOT NULL,
            from_status VARCHAR(50)  DEFAULT NULL,
            to_status   VARCHAR(50)  DEFAULT NULL,
            performed_by INT         DEFAULT NULL,
            machine_type ENUM('Xray','Fluoroscopy','Mammography','CT','UltraSound','MRI') DEFAULT NULL,
            Clinic       ENUM('Misc','ENT-URO','OBGYN','Cardio','OPS','PAU') DEFAULT NULL,
            notes        TEXT        DEFAULT NULL,
            created_at   DATETIME    DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
            FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    // ─── Indexes ──────────────────────────────────────────────────────────────
    try { $pdo->exec("CREATE INDEX idx_tickets_status   ON tickets(current_status)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_tickets_queue    ON tickets(queue_number)");   } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_tickets_arrival  ON tickets(arrival_timestamp)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_tickets_closing_arrival ON tickets(closing_timestamp, arrival_timestamp)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_tickets_patient  ON tickets(patient_id)");     } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_patients_name    ON patients(patient_name)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_patients_mobile  ON patients(mobile)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_patients_care_mobile ON patients(care_mobile)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_tl_ticket        ON ticket_logs(ticket_id)");  } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_tl_created       ON ticket_logs(created_at)"); } catch(Exception $e) {}
    // try { $pdo->exec("CREATE INDEX idx_feedback_filled  ON feedback_tickets(feedback_filled)"); } catch(Exception $e) {}
    // try { $pdo->exec("ALTER TABLE feedback_tickets ADD COLUMN feedback_token VARCHAR(64) DEFAULT NULL"); } catch(Exception $e) {}
    // try { $pdo->exec("CREATE UNIQUE INDEX idx_feedback_token ON feedback_tickets(feedback_token)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_ual_user_created ON user_action_logs(user_id, created_at)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_ual_created      ON user_action_logs(created_at)"); } catch(Exception $e) {}
    try { $pdo->exec("CREATE INDEX idx_tl_ticket_created ON ticket_logs(ticket_id, created_at)"); } catch(Exception $e) {}
}

function createAuthTablesIfNotExist($pdo, $suppressOutput = false) {
    $pdo->exec(" 
        CREATE TABLE IF NOT EXISTS roles (
            id INT PRIMARY KEY AUTO_INCREMENT,
            role_name VARCHAR(50) NOT NULL UNIQUE,
            description VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    try { $pdo->exec("ALTER TABLE roles MODIFY COLUMN role_name VARCHAR(50) NOT NULL"); } catch (Exception $e) {}
    try { $pdo->exec("CREATE UNIQUE INDEX uniq_roles_role_name ON roles(role_name)"); } catch (Exception $e) {}

    try { $pdo->exec("ALTER TABLE users ADD COLUMN password_value VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN auth_source VARCHAR(20) NOT NULL DEFAULT 'local'"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN ad_username VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE users ADD COLUMN last_login_at DATETIME DEFAULT NULL"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE users MODIFY COLUMN role_id INT NULL DEFAULT NULL"); } catch (Exception $e) {}

    $pdo->exec(" 
        CREATE TABLE IF NOT EXISTS users (
            id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) DEFAULT NULL,
            password_value VARCHAR(255) DEFAULT NULL,
            role_id INT DEFAULT NULL,
            full_name VARCHAR(255) DEFAULT NULL,
            is_active BOOLEAN DEFAULT TRUE,
            auth_source VARCHAR(20) NOT NULL DEFAULT 'local',
            ad_username VARCHAR(255) DEFAULT NULL,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_login_at DATETIME DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec(" 
        CREATE TABLE IF NOT EXISTS user_roles (
            user_id INT NOT NULL,
            role_key VARCHAR(50) NOT NULL,
            assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, role_key),
            CONSTRAINT fk_user_roles_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $pdo->exec(" 
        CREATE TABLE IF NOT EXISTS user_action_logs (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT DEFAULT NULL,
            username VARCHAR(100) DEFAULT NULL,
            action_key VARCHAR(100) NOT NULL,
            page_name VARCHAR(150) DEFAULT NULL,
            details LONGTEXT DEFAULT NULL,
            ip_address VARCHAR(64) DEFAULT NULL,
            user_agent VARCHAR(255) DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_user_action_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

    $roleSeeds = [
        'admin' => 'Full system access',
        'billing' => 'Billing and clinics access',
        'butler' => 'Front desk / butler access',
        'imaging' => 'Imaging access',
        'laboratory' => 'Laboratory access',
        'quality' => 'Statistics and administration access',
    ];
    foreach ($roleSeeds as $roleName => $roleDesc) {
        executeUpdate($pdo, "INSERT IGNORE INTO roles (role_name, description) VALUES (?, ?)", [$roleName, $roleDesc]);
    }

    $legacyRoleMap = [
        1 => 'butler',
        2 => 'billing',
        3 => 'laboratory',
        4 => 'imaging',
    ];
    try {
        $legacyRows = $pdo->query("SELECT id, role_id, password_hash, password_value FROM users")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($legacyRows as $legacyRow) {
            $userId = (int)($legacyRow['id'] ?? 0);
            $legacyRoleId = (int)($legacyRow['role_id'] ?? 0);
            if ($userId > 0 && isset($legacyRoleMap[$legacyRoleId])) {
                executeUpdate($pdo, "INSERT IGNORE INTO user_roles (user_id, role_key) VALUES (?, ?)", [$userId, $legacyRoleMap[$legacyRoleId]]);
            }
            if ($userId > 0 && empty($legacyRow['password_value']) && !empty($legacyRow['password_hash'])) {
                executeUpdate($pdo, "UPDATE users SET password_value = ? WHERE id = ? AND (password_value IS NULL OR password_value = '')", [base64_encode('butler123'), $userId]);
            }
        }
    } catch (Exception $e) {}

    // Migrate existing local plaintext password_value entries to Base64.
    try {
        $localPasswords = $pdo->query("SELECT id, password_value FROM users WHERE auth_source = 'local' AND password_value IS NOT NULL AND password_value <> ''")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($localPasswords as $row) {
            $userId = (int)($row['id'] ?? 0);
            $stored = (string)($row['password_value'] ?? '');
            if ($userId <= 0 || $stored === '') {
                continue;
            }
            $decoded = base64_decode($stored, true);
            $isAlreadyBase64 = ($decoded !== false) && (base64_encode($decoded) === $stored);
            if ($isAlreadyBase64) {
                continue;
            }
            executeUpdate($pdo, "UPDATE users SET password_value = ? WHERE id = ?", [base64_encode($stored), $userId]);
        }
    } catch (Exception $e) {}

    $userSeeds = [
        'admin' => ['password' => 'B@ckdoor4!T', 'full_name' => 'Default Admin User', 'roles' => ['admin']],
    ];

    // Remove legacy seeded non-admin local defaults.
    try {
        executeUpdate($pdo, "DELETE FROM users WHERE auth_source = 'local' AND username IN ('billing', 'butler', 'imaging', 'lab', 'quality') AND full_name IN ('Default Billing User', 'Default Butler User', 'Default Imaging User', 'Default Laboratory User', 'Default Quality User')", []);
    } catch (Exception $e) {}

    foreach ($userSeeds as $seedUsername => $seedData) {
        $existingUserRow = executeAndFetchOne($pdo, "SELECT id FROM users WHERE username = ? LIMIT 1", [$seedUsername]);
        $existingUserId = (int)($existingUserRow['id'] ?? 0);
        if ($existingUserId <= 0) {
            executeUpdate($pdo, "INSERT INTO users (username, password_value, full_name, is_active, auth_source) VALUES (?, ?, ?, 1, 'local')", [$seedUsername, base64_encode((string)$seedData['password']), $seedData['full_name']]);
            $existingUserId = (int)$pdo->lastInsertId();
        } else {
            executeUpdate($pdo, "UPDATE users SET password_value = ?, full_name = CASE WHEN full_name IS NULL OR full_name = '' THEN ? ELSE full_name END, is_active = 1, auth_source = 'local' WHERE id = ?", [base64_encode((string)$seedData['password']), $seedData['full_name'], $existingUserId]);
        }
        foreach ($seedData['roles'] as $seedRole) {
            executeUpdate($pdo, "INSERT IGNORE INTO user_roles (user_id, role_key) VALUES (?, ?)", [$existingUserId, $seedRole]);
        }
    }


}

require_once __DIR__ . '/auth.php';

// Clean up output buffer if it was started for AJAX requests
if ($suppress_output && ob_get_level() > 0) {
    ob_end_clean();
}

// Optional: Display connection success message (remove in production)
function displayConnectionInfo() {
    global $pdo;
    try {
        $stmt = $pdo->query("SELECT COUNT(*) as patient_count FROM patients");
        $patientCount = $stmt->fetch()['patient_count'];
        
        $stmt = $pdo->query("SELECT COUNT(*) as user_count FROM users");
        $userCount = $stmt->fetch()['user_count'];
        
        echo "<div style='background: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border-radius: 5px; border: 1px solid #c3e6cb;'>
                <strong>System Status:</strong> Database connected successfully. 
                Users: {$userCount}, Patients: {$patientCount}
              </div>";
    } catch (Exception $e) {
        // Silently fail - don't show errors in production
    }
}

// Call this function to display connection info (optional)
// displayConnectionInfo();

function updatePatientStatus($pdo, $patientId, $newStatus) {
    return executeUpdate($pdo, "UPDATE tickets SET current_status = ? WHERE ticket_id = ?", [$newStatus, $patientId]);
}

function logPatientAction($pdo, $patientId, $action, $userId = null) {
    if ($userId === null && function_exists('authCurrentUserId')) {
        $currentUserId = authCurrentUserId();
        $userId = $currentUserId > 0 ? $currentUserId : null;
    }
    return executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, performed_by) VALUES (?, ?, ?)", [$patientId, $action, $userId]);
}

function logApiCall($api_url, $response, $timestamp = null) {
    if ($timestamp === null) {
        $timestamp = (new DateTime('now', new DateTimeZone(APP_TIMEZONE)))->format('Y-m-d H:i:s');
    }
    $log_entry = "[$timestamp] API Call: $api_url\nResponse: $response\n\n";
    $log_file = __DIR__ . '/logs/api_calls.log';
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

function buildWhatsAppQueryString($params) {
    $query_parts = [];
    foreach ($params as $key => $value) {
        $encoded_value = rawurlencode((string)$value);
        if ($key === 'variables') {
            $encoded_value = str_replace('%2C', ',', $encoded_value);
        }
        $query_parts[] = $key . '=' . $encoded_value;
    }
    return implode('&', $query_parts);
}

function sendWhatsAppTemplateRequest($destination, $template, $variables = null, $extraParams = []) {
    $destination = preg_replace('/[^0-9]/', '', (string)$destination);
    $template = trim((string)$template);

    if ($destination === '' || $template === '') {
        return [
            'success' => false,
            'http_code' => 0,
            'response' => 'Missing destination or template.',
            'request_url' => '',
            'curl_error' => '',
        ];
    }

    if (is_array($variables)) {
        $variableValues = [];
        foreach ($variables as $value) {
            $variableValues[] = (string)$value;
        }
        $variables = implode(',', $variableValues);
    }

    $params = [
        'api_key' => WHATSAPP_API_KEY,
        'api_secret' => WHATSAPP_API_SECRET,
        'senderid' => WHATSAPP_SENDER_ID,
        'destination' => $destination,
        'route' => WHATSAPP_ROUTE,
        'template' => $template,
    ];

    if ($variables !== null && trim((string)$variables) !== '') {
        $params['variables'] = (string)$variables;
    }

    if (is_array($extraParams)) {
        foreach ($extraParams as $key => $value) {
            $key = trim((string)$key);
            if ($key === '') {
                continue;
            }
            $params[$key] = (string)$value;
        }
    }

    $fullUrl = WHATSAPP_API_URL . '?' . buildWhatsAppQueryString($params);
    $httpCode = 0;
    $responseText = '';
    $curlError = '';

    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $fullUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, WHATSAPP_HTTP_TIMEOUT_SECONDS);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, WHATSAPP_CONNECT_TIMEOUT_SECONDS);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = trim((string)curl_error($ch));
        curl_close($ch);

        if ($response !== false) {
            $responseText = (string)$response;
        } elseif ($curlError === '') {
            $curlError = 'cURL request failed.';
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => WHATSAPP_HTTP_TIMEOUT_SECONDS,
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
            ],
        ]);
        $response = @file_get_contents($fullUrl, false, $context);
        if ($response !== false) {
            $responseText = (string)$response;
        } else {
            $curlError = 'file_get_contents request failed.';
        }

        if (isset($http_response_header) && is_array($http_response_header)) {
            foreach ($http_response_header as $headerLine) {
                if (preg_match('/^HTTP\/\S+\s+(\d{3})\b/i', (string)$headerLine, $m) === 1) {
                    $httpCode = (int)$m[1];
                    break;
                }
            }
        }
    }

    if (WHATSAPP_LOG_API_CALLS) {
        logApiCall($fullUrl, $responseText !== '' ? $responseText : $curlError);
    }

    return [
        'success' => ($curlError === '' && $httpCode >= 200 && $httpCode < 300),
        'http_code' => $httpCode,
        'response' => $responseText,
        'request_url' => $fullUrl,
        'curl_error' => $curlError,
    ];
}

function normalizeDateYmd($value) {
    $value = trim((string)$value);
    if ($value === '') {
        return '';
    }

    // Fast path for ISO-like values such as 2026-04-11 or 2026-04-11T10:30:00.
    if (preg_match('/^\d{4}-\d{2}-\d{2}/', $value) === 1) {
        return substr($value, 0, 10);
    }

    $ts = strtotime($value);
    if ($ts === false) {
        return '';
    }

    return date('Y-m-d', $ts);
}

function buildAppBaseUrl() {
    if (defined('FEEDBACK_BASE_URL') && trim((string)FEEDBACK_BASE_URL) !== '') {
        return rtrim((string)FEEDBACK_BASE_URL, '/');
    }

    $https = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
    $scheme = $https ? 'https' : 'http';
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? 'localhost'));
    $scriptName = trim((string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $dir = str_replace('\\', '/', dirname($scriptName));
    if ($dir === '/' || $dir === '\\') {
        $dir = '';
    }

    return $scheme . '://' . $host . rtrim($dir, '/');
}

function generateAndStoreFeedbackToken($ticketId, $pdo) {
    // Token storage is currently disabled.
    // $ticketId = (int)$ticketId;
    // if ($ticketId <= 0) {
    //     return '';
    // }
    // $token = bin2hex(random_bytes(32));
    // $stmt = $pdo->prepare(
    //     "INSERT INTO feedback_tickets (ticket_id, feedback_token, feedback_sent, feedback_filled)
    //      VALUES (?, ?, 0, 0)
    //      ON DUPLICATE KEY UPDATE feedback_token = VALUES(feedback_token)"
    // );
    // $stmt->execute([$ticketId, $token]);
    // return $token;
    return '';
}

function validateFeedbackTokenFromDb($token, $pdo) {
    // Token validation is currently disabled.
    // $token = trim((string)$token);
    // if ($token === '') {
    //     return ['valid' => false, 'ticket_id' => 0, 'error' => 'missing_token'];
    // }
    // $stmt = $pdo->prepare(
    //     'SELECT ticket_id FROM feedback_tickets WHERE feedback_token = ? LIMIT 1'
    // );
    // $stmt->execute([$token]);
    // $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // if (!$row) {
    //     return ['valid' => false, 'ticket_id' => 0, 'error' => 'invalid_token'];
    // }
    // return ['valid' => true, 'ticket_id' => (int)$row['ticket_id'], 'error' => ''];
    return ['valid' => false, 'ticket_id' => 0, 'error' => 'token_disabled'];
}

function buildFeedbackAccessUrl($ticketId, $pdo) {
    // Tokenized feedback access is currently disabled.
    // $token = generateAndStoreFeedbackToken($ticketId, $pdo);
    // if ($token === '') {
    //     return '';
    // }

    // $entryUrl = '';
    // if (defined('FEEDBACK_PUBLIC_ENTRY_URL') && trim((string)FEEDBACK_PUBLIC_ENTRY_URL) !== '') {
    //     $entryUrl = trim((string)FEEDBACK_PUBLIC_ENTRY_URL);
    // } else {
    //     $entryUrl = buildAppBaseUrl() . '/feedback.php';
    // }

    // if (strpos($entryUrl, '{token}') !== false) {
    //     return str_replace('{token}', rawurlencode($token), $entryUrl);
    // }

    // $separator = strpos($entryUrl, '?') === false ? '?' : '&';
    // return rtrim($entryUrl, '&?') . $separator . 'token=' . rawurlencode($token);
    return FEEDBACK_TALLY_FORM_URL;
}

/**
 * Connection pooling and resource management helpers
 * These functions help prevent "Too many connections" errors
 */

/**
 * Close a prepared statement properly to free resources
 * @param PDOStatement $stmt - The statement to close
 */
function closeStatement(&$stmt) {
    if ($stmt instanceof PDOStatement) {
        $stmt = null;
    }
}

/**
 * Execute a query with automatic statement cleanup
 * Usage: $result = executeAndFetch($pdo, "SELECT * FROM table WHERE id = ?", [$id]);
 * @param PDO $pdo - Database connection
 * @param string $sql - SQL query
 * @param array $params - Query parameters
 * @param string $fetchMode - PDO fetch mode
 * @return array|false - Query results or false on error
 */
function executeAndFetch($pdo, $sql, $params = [], $fetchMode = PDO::FETCH_ASSOC) {
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetchAll($fetchMode);
        $stmt = null; // Explicit cleanup
        return $result;
    } catch (PDOException $e) {
        error_log("Database query error: " . $e->getMessage() . " - SQL: " . $sql);
        return false;
    }
}

/**
 * Execute a query and fetch a single row with automatic cleanup
 * @param PDO $pdo - Database connection
 * @param string $sql - SQL query
 * @param array $params - Query parameters
 * @param string $fetchMode - PDO fetch mode
 * @return array|false - Single row or false on error
 */
function executeAndFetchOne($pdo, $sql, $params = [], $fetchMode = PDO::FETCH_ASSOC) {
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $result = $stmt->fetch($fetchMode);
        $stmt = null; // Explicit cleanup
        return $result;
    } catch (PDOException $e) {
        error_log("Database query error: " . $e->getMessage() . " - SQL: " . $sql);
        return false;
    }
}

/**
 * Execute an insert/update/delete with automatic cleanup
 * @param PDO $pdo - Database connection
 * @param string $sql - SQL query
 * @param array $params - Query parameters
 * @return bool - Success status
 */
function executeUpdate($pdo, $sql, $params = []) {
    try {
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        $stmt = null; // Explicit cleanup
        return $result;
    } catch (PDOException $e) {
        error_log("Database query error: " . $e->getMessage() . " - SQL: " . $sql);
        return false;
    }
}

/**
 * Get the number of affected rows from the last statement
 * @param PDO $pdo - Database connection
 * @param PDOStatement $stmt - The last prepared statement
 * @return int - Number of affected rows
 */
function getAffectedRows($stmt) {
    if ($stmt instanceof PDOStatement) {
        return $stmt->rowCount();
    }
    return 0;
}

/**
 * Register a cleanup function to be called at script shutdown
 * This ensures all database resources are properly closed
 */
register_shutdown_function(function() {
    global $pdo;
    if ($pdo instanceof PDO) {
        $pdo = null; // Close the connection explicitly
    }
});

?>


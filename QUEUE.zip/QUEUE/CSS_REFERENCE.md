# CSS & Responsive Design - Quick Reference Card

## File Locations & Line Numbers

### Key Responsive Breakpoints in styles.css

```
Line ~2945  →  Tablet breakpoint (max-width: 1024px)
Line ~3000  →  Mobile Portrait (max-width: 767px)
Line ~3150  →  Small Mobile (max-width: 479px)
Line ~3280  →  Landscape optimization
```

---

## Screen Size Triggers

### Tablet Layout (768px - 1024px)
```css
@media (max-width: 1024px) {
    .dashboard-container {
        flex-direction: column;  /* Stack vertically */
        gap: 15px;
        padding: 15px;
    }
}
```
**Result**: Queue on top, streaming cards below in 2-column grid

### Mobile Layout (480px - 767px)
```css
@media (max-width: 767px) {
    .dashboard-container {
        flex-direction: column;  /* Stack vertically */
        gap: 10px;
        padding: 0;
    }
}
```
**Result**: Full-width vertical stack, touch-optimized

### Small Mobile (<480px)
```css
@media (max-width: 479px) {
    .dashboard-container {
        flex-direction: column;  /* Stack vertically */
        gap: 8px;
        padding: 0;
    }
}
```
**Result**: Compact spacing, minimal padding

### Landscape
```css
@media (orientation: landscape) and (max-height: 600px) {
    .streaming-section {
        flex-direction: row;  /* Side-by-side */
        gap: 10px;
    }
}
```
**Result**: Horizontal card arrangement

---

## Container Height Values

### Queue Section Heights
```
Desktop:  No constraint (uses full available)
Tablet:   max-height: 50vh   (50% of viewport)
Mobile:   max-height: 40vh   (40% of viewport)
Small:    max-height: 35vh   (35% of viewport)
```

### Dashboard Container
```
Desktop:  min-height: calc(100vh - 40px)  [Full screen minus padding]
Tablet:   min-height: auto                [Flexible]
Mobile:   min-height: auto                [Flexible]
```

---

## Font Size Scaling

### Large Numbers (Patient Queue Numbers)
```
Desktop:  font-size: 48px
Tablet:   font-size: 36px
Mobile:   font-size: 32px
Small:    font-size: 28px
```

### Labels & Headers
```
Desktop:  font-size: 16px
Tablet:   font-size: 14px
Mobile:   font-size: 12px
Small:    font-size: 10px
```

### Table Text
```
Desktop:  font-size: 14px
Tablet:   font-size: 12px
Mobile:   font-size: 11px
Small:    font-size: 10px
```

---

## Padding & Spacing

### Body Padding
```
Desktop:  padding: 20px
Tablet:   padding: 15px
Mobile:   padding: 10px
Small:    padding: 5px
```

### Card/Button Padding
```
Desktop:  padding: 20px / 16px
Tablet:   padding: 15px / 12px
Mobile:   padding: 12px / 8px
Small:    padding: 10px / 6px
```

### Gap Between Elements
```
Desktop:  gap: 20px
Tablet:   gap: 15px
Mobile:   gap: 10px
Small:    gap: 8px
```

---

## Flexbox Direction Changes

```
Device              Direction  Layout
─────────────────────────────────────────
Desktop (1025px+)   row        Side by side
Tablet              column     Stacked
Mobile              column     Stacked
Small Mobile        column     Stacked
Landscape           row        Side by side
```

### Code Reference
```css
/* Desktop */
.dashboard-container {
    flex-direction: row;  /* ← Left and right panels */
}

/* Tablet & Mobile */
@media (max-width: 1024px) {
    .dashboard-container {
        flex-direction: column;  /* ← Stacked */
    }
}

/* Landscape - Override to row */
@media (orientation: landscape) and (max-height: 600px) {
    .streaming-section {
        flex-direction: row;  /* ← Back to side-by-side */
    }
}
```

---

## Streaming Cards Grid

```
Desktop:          Tablet:           Mobile:
┌─────────┐       ┌───┬───┐        ┌─────┐
│ Card 1  │       │ 1 │ 2 │        │  1  │
├─────────┤       ├───┼───┤        ├─────┤
│ Card 2  │  →    │ 3 │   │   →    │  2  │
├─────────┤       └───┴───┘        ├─────┤
│ Card 3  │                        │  3  │
└─────────┘                        └─────┘

Flex value changes:
```

### Code
```css
/* Desktop: 1 column */
.streaming-section {
    flex-direction: column;
}

/* Tablet: 2 columns */
@media (max-width: 1024px) {
    .stream-card {
        flex: 1 1 calc(50% - 10px);
    }
}

/* Mobile: 1 column again */
@media (max-width: 767px) {
    .stream-card {
        flex: 1;
        min-width: 100%;
    }
}
```

---

## Button Sizing

### Desktop
```css
.action-btn {
    padding: 8px 15px;
    min-width: 90px;
    font-size: 13px;
}
```

### Tablet
```css
@media (max-width: 1024px) {
    .action-btn {
        padding: 8px 15px;
        min-width: 80px;
        font-size: 13px;
    }
}
```

### Mobile
```css
@media (max-width: 767px) {
    .action-btn {
        padding: 5px 8px;
        min-width: 60px;
        font-size: 11px;
    }
}
```

### Small Mobile
```css
@media (max-width: 479px) {
    .action-btn {
        padding: 4px 6px;
        min-width: 50px;
        font-size: 10px;
    }
}
```

---

## CSS Section Headers Format

### Before (Old)
```css
/* Form Styles */
```

### After (New)
```css
/* ======================================================================
   FORM STYLES - Inputs, Labels, Selects
   ====================================================================== */
```

### All Section Headers
1. GLOBAL STYLES
2. HEADER & LOGO STYLES
3. FORM STYLES
4. MODAL STYLES
5. RESPONSIVE DESIGN
6. DASHBOARD STYLES
7. STREAMING CARDS
8. TABLE STYLES
9. STATUS & TYPE BADGES
10. BILLING INTERFACE STYLES
11. IMAGING INTERFACE STYLES
12. LABORATORY INTERFACE STYLES
13. BUTLER INTERFACE RESPONSIVE STYLES

---

## Common Customizations

### Make Queue Shorter on Mobile
```css
/* In @media (max-width: 767px) */
.queue-section {
    max-height: 35vh;  /* was 40vh */
}
```

### Make Queue Taller on Mobile
```css
/* In @media (max-width: 767px) */
.queue-section {
    max-height: 50vh;  /* was 40vh */
}
```

### Increase Gap Between Cards
```css
.streaming-section {
    gap: 20px;  /* was 15px */
}
```

### Make Buttons Bigger
```css
@media (max-width: 767px) {
    .action-btn {
        padding: 8px 12px;  /* was 5px 8px */
        min-width: 70px;    /* was 60px */
    }
}
```

### Adjust Breakpoint
```css
/* Change from 1024px to 1200px */
@media (max-width: 1200px) {  /* ← This value */
    .dashboard-container {
        flex-direction: column;
    }
}
```

---

## Debugging Tips

### See Which Breakpoint Active
```css
/* Add temporarily to body */
body::after {
    content: 'Desktop';
}

@media (max-width: 1024px) {
    body::after {
        content: 'Tablet';
    }
}

@media (max-width: 767px) {
    body::after {
        content: 'Mobile';
    }
}
```

### Check Computed Styles
In DevTools:
1. Right-click element
2. "Inspect" 
3. See applied CSS rules
4. Check media query matches

### Test Different Sizes
DevTools Responsive Mode:
- Desktop: 1920x1080
- Tablet: 768x1024
- Mobile: 375x667
- Landscape: 812x375

---

## CSS Properties Reference

### Flexbox Direction
```css
flex-direction: row;     /* Side by side */
flex-direction: column;  /* Stacked */
```

### Sizing
```css
min-height: X;   /* Minimum height */
max-height: X;   /* Maximum height */
flex: 1;         /* Take equal space */
```

### Viewport Units
```css
vh  = viewport height   (1vh = 1% of screen height)
vw  = viewport width    (1vw = 1% of screen width)
vmin = smaller dimension
vmax = larger dimension
```

### Calc Function
```css
calc(100vh - 40px)      /* Viewport height minus padding */
calc(50% - 10px)        /* Half width minus gap */
```

---

## Testing Device Sizes

| Device | Width | Height | Browser Action |
|--------|-------|--------|----------------|
| Desktop | 1920 | 1080 | Normal view |
| iPad | 768 | 1024 | DevTools: iPad |
| iPhone 14 | 390 | 844 | DevTools: iPhone 14 |
| iPhone SE | 375 | 667 | DevTools: Custom 375x667 |
| Landscape Phone | 812 | 375 | DevTools: Rotate device |
| Galaxy Tab | 600 | 800 | DevTools: Custom 600x800 |

---

## Performance Checklist

✅ Single CSS file (no extra requests)
✅ No JavaScript for responsiveness
✅ CSS-only media queries
✅ Efficient selectors
✅ No layout reflows
✅ Viewport meta tag present
✅ Smooth transitions (no jumpy layouts)

---

## Browser Compatibility

✅ Chrome 88+
✅ Firefox 87+
✅ Safari 14+
✅ Edge 88+
✅ Mobile browsers (all modern)

---

## Quick Links to Media Queries in styles.css

```
:1039    BILLING INTERFACE
:2509    IMAGING INTERFACE
:2752    LABORATORY INTERFACE
:2945    Tablet breakpoint (1024px)
:3000    Mobile breakpoint (767px)
:3150    Small Mobile breakpoint (479px)
:3280    Landscape optimization
```

---

**Breakpoints Added:**

| Breakpoint | Device | Layout |
|-----------|--------|--------|
| 1024px ↓ | Tablets | Vertical stack |
| 767px ↓ | Mobile | Full-width vertical |
| 479px ↓ | Small Mobile | Compact vertical |
| Landscape | Any device | Horizontal optimized |

### 3. Container Height Management ✅

**Problem:** Dashboard didn't fill screen properly on different devices

**Solution:** 
- Desktop: `min-height: calc(100vh - 40px)`
- Tablet: `max-height: 50vh` for queue section
- Mobile: `max-height: 40vh` for queue section  
- Small Mobile: `max-height: 35vh` for queue section

Result: Containers now intelligently scale to fill available space without unnecessary scrolling

### 4. Responsive Streaming Cards ✅

**Behaviors:**
- Desktop: 3 cards in vertical column on right (25% width)
- Tablet: 2x1 grid layout
- Mobile: Full-width vertical stack
- Landscape: Horizontal row layout

### 5. Touch-Friendly Mobile Interface ✅

- Minimum button size: 50px width
- Adequate padding between touch targets
- Readable font sizes on all devices
- Proper spacing for finger navigation

---

## Key Features

### ✅ Full-Height Responsive Layout
```css
.dashboard-container {
    min-height: calc(100vh - 40px);
    display: flex;
    flex-direction: row;
}

@media (max-width: 1024px) {
    .dashboard-container {
        flex-direction: column;
        min-height: auto;
    }
}
```

### ✅ Scalable Typography
Font sizes automatically adjust:
- Desktop: 48px for large numbers
- Tablet: 36px
- Mobile: 32px
- Small Mobile: 28px

### ✅ Viewport-Based Sizing
Using `vh` (viewport height) units for intelligent scaling:
- Maintains readability
- Prevents excessive scrolling
- Works on all screen orientations

### ✅ Flexible Grid Layouts
Streaming cards adapt automatically:
```css
@media (max-width: 1024px) {
    .stream-card {
        flex: 1 1 calc(50% - 10px);  /* 2-column on tablets */
    }
}

@media (max-width: 767px) {
    .stream-card {
        flex: 1;  /* Full-width on mobile */
        min-width: 100%;
    }
}
```
## Key Files

```
styles.css                          3,300 lines (Main styling)
butler.php                          No changes needed
IMPLEMENTATION_COMPLETE.md          This implementation
RESPONSIVE_DESIGN_GUIDE.md          Detailed reference
STYLES_IMPROVEMENTS.md              Technical documentation
```

---

*For detailed information, see the full documentation files.*
*For quick answers, see this reference card.*

## Screen Sizes & Layouts

### Desktop (1025px+)
- **Layout**: 2-column horizontal
  - Left: Queue section (larger)
  - Right: 3 streaming cards (vertical stack)
- **Heights**: Full viewport - no scrolling needed
- **Font**: Full size
- **Use**: Monitor, large displays

### Tablet (768px - 1024px)
- **Layout**: Column with card wrapping
  - Top: Queue section
  - Bottom: Streaming cards in 2x1 grid
- **Heights**: Queue ~50% viewport, streams flexible
- **Font**: Slightly reduced
- **Use**: iPad, large tablets

### Mobile Portrait (480px - 767px)
- **Layout**: Full vertical stack
  - Queue section first
  - Three streaming cards stacked
- **Heights**: Queue ~40% viewport, each card ~200px
- **Font**: Smaller, readable
- **Use**: Standard smartphones

### Small Mobile (up to 479px)
- **Layout**: Minimal vertical stack
  - Compact spacing
  - All elements full-width
- **Heights**: Queue ~35% viewport, cards compact
- **Font**: Smallest but readable
- **Use**: Small phones (iPhone SE, etc.)

### Landscape (any height < 600px)
- **Layout**: Horizontal streaming cards
  - Queue section left or top
  - Cards in row
- **Heights**: Queue ~300px, cards ~250px min
- **Font**: Reduced for space
- **Use**: Rotated phones, landscape tablets

---

## Responsive Breakpoints in Code

```css
/* Tablet (768px - 1024px) */
@media (max-width: 1024px) { ... }

/* Mobile Portrait (480px - 767px) */
@media (max-width: 767px) { ... }

/* Small Mobile (up to 479px) */
@media (max-width: 479px) { ... }

/* Landscape (any device, height < 600px) */
@media (orientation: landscape) and (max-height: 600px) { ... }
```

---

## Key CSS Properties Used

### Container Heights (Viewport-Based)
```
Desktop:       min-height: calc(100vh - 40px)
Tablet:        max-height: 50vh (queue)
Mobile:        max-height: 40vh (queue)
Small Mobile:  max-height: 35vh (queue)
Landscape:     max-height: 45vh (queue)
```

### Flex Direction Changes
```
Desktop:       flex-direction: row  (side-by-side)
Tablet:        flex-direction: column (stacked)
Mobile:        flex-direction: column (stacked)
Landscape:     flex-direction: row (wide)
```

### Padding Adjustments
```
Desktop:       padding: 20px
Tablet:        padding: 15px
Mobile:        padding: 10px
Small Mobile:  padding: 5px
```

---

## Testing Scenarios

| Device | Width | Height | Expected |
|--------|-------|--------|----------|
| Desktop Monitor | 1920px | 1080px | Horizontal split |
| iPad | 768px | 1024px | Vertical stack with 2-col cards |
| iPhone 14 | 390px | 844px | Full vertical stack |
| iPhone SE | 375px | 667px | Compact vertical stack |
| Landscape Phone | 812px | 375px | Horizontal cards |
| Galaxy Tab | 600px | 800px | Mixed layout |

---

## Developer Tips

### To Test Responsive Design in Browser
1. Open butler.php
2. Press F12 (DevTools)
3. Press Ctrl+Shift+M (Toggle Device Toolbar)
4. Select device or custom dimensions

### To Adjust Breakpoints
Edit styles.css media query at these lines:
- **Line ~2945**: 1024px breakpoint
- **Line ~3000**: 767px breakpoint  
- **Line ~3150**: 479px breakpoint
- **Line ~3280**: Landscape rule

### Common Adjustments

**Make queue section shorter on mobile:**
```css
.queue-section {
    max-height: 30vh;  /* was 40vh */
}
```

**Make streaming cards bigger on tablet:**
```css
.stream-card {
    flex: 1 1 calc(50% - 15px);  /* was calc(50% - 10px) */
    min-height: 350px;  /* was 300px */
}
```

**Change small mobile limit:**
```css
@media (max-width: 450px) {  /* was 479px */
    /* ... */
}
```

---

## Performance Notes

- ✅ Single CSS file (no extra requests)
- ✅ No JavaScript for responsive behavior
- ✅ Viewport meta tag already configured
- ✅ Smooth scaling using flexbox
- ✅ Optimized for all modern browsers

---

## Browser Support

All modern browsers (2020+):
- ✅ Chrome/Edge 88+
- ✅ Firefox 87+
- ✅ Safari 14+
- ✅ Mobile browsers

---

## Quick Visual Reference

```
DESKTOP (1025px+)          TABLET (768-1024px)        MOBILE (767px or less)
┌─────────────┐           ┌──────────────────┐        ┌────────────┐
│   Queue     │ Stream 1  │   Queue (full)   │        │   Queue    │
│   (70%)     │           │                  │        │ (40% height)
│             │ Stream 2  ├──────────────────┤        ├────────────┤
│             │           │ Streams (2x1)    │        │  Stream 1  │
│             │ Stream 3  │                  │        ├────────────┤
└─────────────┴───────────┴──────────────────┘        │  Stream 2  │
                                                      ├────────────┤
                                                      │  Stream 3  │
                                                      └────────────┘

LANDSCAPE (wide, short)
┌────────────────────────────────────────┐
│ Queue  │ Stream 1 │ Stream 2 │ Stream 3│
│        │          │          │         │
└────────────────────────────────────────┘
```

---

## Troubleshooting
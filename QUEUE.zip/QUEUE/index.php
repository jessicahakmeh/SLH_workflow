<?php
require_once 'config.php';
session_start();

if (!authIsEnabled()) {
    header('Location: stream.php');
    exit;
}

if (authCurrentUser()) {
    header('Location: ' . authDefaultLandingPage());
    exit;
}

header('Location: login.php');
exit;

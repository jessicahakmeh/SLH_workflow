<?php
// Kiosk display for waiting room TV - Lab & Imaging streams only
require_once 'config.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Queue Kiosk - Waiting Room Display</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            height: 100%;
            touch-action: none;
            overscroll-behavior: none;
            -webkit-user-select: none;
            user-select: none;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #e8f0f7 0%, #b3d9f2 25%, #d0e4f2 50%, #b3d9f2 75%, #e8f0f7 100%);
            background-attachment: fixed;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: flex-start;
            align-items: center;
            padding: 40px 20px 20px 20px;
            min-height: 100vh;
            pointer-events: none;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.1) 10%, transparent 20%),
                linear-gradient(90deg, transparent 50%, rgba(255,255,255,0.15) 60%, transparent 70%);
            background-size: 100% 100px;
            background-position: 0 0, 50px 50px;
            pointer-events: none;
            animation: streamAnimation 10s linear infinite;
            z-index: 0;
        }

        @keyframes streamAnimation {
            0% { background-position: 0 0, 50px 50px; }
            100% { background-position: 0 100px, 50px 150px; }
        }

        .kiosk-streams-container,
        .kiosk-footer {
            position: relative;
            z-index: 1;
        }

        /* Header Section */
        .kiosk-header {
            display: none;
        }

        /* Stream Cards Container */
        .kiosk-streams-container {
            display: flex;
            gap: 30px;
            justify-content: center;
            width: 95%;
            max-width: none;
            margin-bottom: 80px;
        }

        .kiosk-stream-card {
            flex: 1;
            background: #e8f4fc;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .stream-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            width: 100%;
            padding: 20px 30px;
            background: #1e3a4f;
            margin-bottom: 0;
        }

        .stream-icon {
            font-size: 40px;
            color: #ffffff;
            flex: 0 0 60px;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            padding-left: 8px;
        }

        .stream-title-center {
            flex: 1 1 auto;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 0 8px;
        }

        .stream-title-right {
            flex: 0 0 160px;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            text-align: right;
            direction: rtl;
            padding-left: 8px;
        }

        /* Ensure child text aligns correctly inside each region */
        .stream-icon i { display: block; text-align: left; width: 100%; }
        .stream-title-center .stream-title { width: 100%; text-align: center; }
        .stream-title-right .stream-title-ar { width: 100%; text-align: right; }

        .stream-title {
            font-size: 28px;
            font-weight: 600;
            color: #ffffff;
            margin: 0;
            line-height: 1;
            white-space: nowrap;
        }

        .stream-title-ar {
            font-size: 28px;
            font-weight: 600;
            color: #ffffff;
            margin: 0;
            font-family: 'Arial', sans-serif;
            direction: rtl;
            line-height: 1;
            white-space: nowrap;
        }

        /* Turn Indicator */
        .turn-label {
            font-size: 20px;
            font-weight: 300;
            color: #1e3a4f;
            text-align: center;
            letter-spacing: 1px;
            margin-bottom: 8px;
            width: 100%;
            padding-top: 20px;
        }

        .turn-label-ar {
            font-size: 20px;
            font-weight: 300;
            color: #1e3a4f;
            text-align: center;
            margin-bottom: 20px;
            font-family: 'Arial', sans-serif;
            direction: rtl;
            width: 100%;
        }

        .kiosk-call-cards {
            display: flex;
            flex-direction: column;
            gap: 15px;
            width: 100%;
            min-height: 200px;
            justify-content: center;
            align-items: center;
            padding: 0 30px 40px 30px;
        }

        .call-count {
            font-size: 18px;
            color: #ffffff;
            background: rgba(0,0,0,0.2);
            padding: 6px 10px;
            border-radius: 12px;
            margin-bottom: 8px;
            display: inline-block;
        }

        /* Call Cards Section */
        .kiosk-call-cards {
            display: flex;
            flex-direction: column;
            gap: 15px;
            width: 100%;
            min-height: 200px;
            justify-content: center;
            align-items: center;
            padding: 0 30px 40px 30px;
        }

        .kiosk-call-card {
            background: rgba(30, 58, 79, 0.08);
            border: 2px solid rgba(30, 58, 79, 0.2);
            border-radius: 15px;
            padding: 20px 30px;
            text-align: center;
            min-width: 200px;
        }

        .kiosk-call-card.active {
            background: rgba(33, 150, 243, 0.18); /* bright blue */
            border-color: rgba(33, 150, 243, 0.5);
            box-shadow: 0 8px 30px rgba(33,150,243,0.18);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }

        .call-queue-number {
            font-size: 48px;
            font-weight: bold;
            color: #1e3a4f;
            letter-spacing: 3px;
        }

        .call-patient-name {
            font-size: 20px;
            color: #1e3a4f;
            margin-top: 10px;
            font-weight: 500;
        }

        .no-call-indicator {
            font-size: 80px;
            color: #d0e4f2;
            font-weight: 300;
            letter-spacing: 10px;
        }

        /* Footer Section */
        .kiosk-footer {
            position: fixed;
            bottom: 30px;
            left: 0;
            right: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1px;
        }

        .hospital-logo {
            max-width: 90px;
            max-height: 90px;
            object-fit: contain;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
        }

        .footer-text {
            font-size: 14px;
            font-weight: 300;
            color: #1a3a52;
            letter-spacing: 1px;
        }

        /* Responsive */
        @media (max-width: 900px) {
            .kiosk-streams-container {
                flex-direction: column;
                gap: 30px;
                width: 95%;
            }

            .stream-title {
                font-size: 24px;
            }

            .stream-title-ar {
                font-size: 20px;
            }

            .call-queue-number {
                font-size: 36px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="kiosk-header">
        <div class="header-title">
            <i class="fas fa-hospital-user" style="color: #1e3a4f; font-size: 48px;"></i>
            <span>QUEUE MANAGEMENT</span>
        </div>
    </div>

    <!-- Stream Cards -->
    <div class="kiosk-streams-container">
        <!-- Lab Stream Card -->
        <div class="kiosk-stream-card">
            <div class="stream-header">
                    <div class="stream-icon">
                        <i class="fas fa-flask-vial"></i>
                    </div>
                    <div class="stream-title-center">
                        <div class="stream-title">Laboratory</div>
                    </div>
                    <div class="stream-title-right">
                        <div class="stream-title-ar">المختبر</div>
                    </div>
            </div>
            <div class="turn-label">Its Your Turn</div>
            <div class="turn-label-ar">حان دورك</div>
            <div class="kiosk-call-cards" id="labCallCards">
                <div class="no-call-indicator">−</div>
            </div>
        </div>

        <!-- Imaging Stream Card -->
        <div class="kiosk-stream-card">
            <div class="stream-header">
                <div class="stream-icon">
                    <i class="fas fa-x-ray"></i>
                </div>
                <div class="stream-title-center">
                    <div class="stream-title">Imaging</div>
                </div>
                <div class="stream-title-right">
                    <div class="stream-title-ar">التصوير</div>
                </div>
            </div>
            <div class="turn-label">Its Your Turn</div>
            <div class="turn-label-ar">حان دورك</div>
            <div class="kiosk-call-cards" id="imagingCallCards">
                <div class="no-call-indicator">−</div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <div class="kiosk-footer">
        <img src="logo.php" alt="Hospital Logo" class="hospital-logo" onerror="this.style.display='none'">
        <div class="footer-text">Thank you for your Patience</div>
    </div>

    <script>
        const streamConfigs = {
            lab: { 
                id: 'labCallCards',
                stream: 'lab'
            },
            imaging: { 
                id: 'imagingCallCards',
                stream: 'imaging'
            }
        };

        // Helper: fetch JSON with fallback to XHR for older Smart TV browsers
        function fetchJson(url, callback) {
            // Try Fetch API first
            if (window.fetch) {
                window.fetch(url, { cache: 'no-store' })
                    .then(function(response) { return response.text(); })
                    .then(function(text) {
                        var data = [];
                        try { data = JSON.parse(text); } catch (e) { console.error('JSON parse failed', e); data = []; }
                        callback(null, data);
                    })
                    .catch(function(err) { callback(err); });
                return;
            }

            // Fallback: XMLHttpRequest
            try {
                var xhr = new XMLHttpRequest();
                xhr.open('GET', url, true);
                xhr.setRequestHeader('Cache-Control', 'no-store');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState !== 4) return;
                    if (xhr.status >= 200 && xhr.status < 300) {
                        var data = [];
                        try { data = JSON.parse(xhr.responseText); } catch (e) { console.error('XHR JSON parse failed', e); data = []; }
                        callback(null, data);
                    } else {
                        callback(new Error('XHR status ' + xhr.status));
                    }
                };
                xhr.send(null);
            } catch (e) {
                callback(e);
            }
        }

        // Refresh streams (uses fetchJson to support older browsers)
        function refreshStreams() {
            var keys = Object.keys(streamConfigs);
            for (var i = 0; i < keys.length; i++) {
                (function(key) {
                    var config = streamConfigs[key];
                    fetchJson('queue_refresh.php?department=' + encodeURIComponent(config.stream), function(err, data) {
                        if (err) {
                            console.error('Error fetching ' + key + ':', err);
                            return;
                        }
                        // Normalize responses: some debug modes return { patients: [...] }
                        var rows = [];
                        try {
                            if (Array.isArray(data)) rows = data;
                            else if (data && Array.isArray(data.patients)) rows = data.patients;
                            else if (data && data.patients && Array.isArray(data.patients)) rows = data.patients;
                            else rows = [];
                        } catch (e) { rows = []; }

                        updateStreamDisplay(config.id, rows);
                    });
                })(keys[i]);
            }
        }

        function updateStreamDisplay(containerId, data) {
            try {
                var container = document.getElementById(containerId);
                if (!container) return;

                if (!data || data.length === 0) {
                    container.innerHTML = '<div class="no-call-indicator">−</div>';
                    return;
                }

                // Build list of Called/Recalled
                var calledList = [];
                for (var i = 0; i < data.length; i++) {
                    var p = data[i];
                    if (!p) continue;
                    if (p.status === 'Called' || p.status === 'Recalled') calledList.push(p);
                }

                if (!calledList || calledList.length === 0) {
                    container.innerHTML = '<div class="no-call-indicator">−</div>';
                    return;
                }

                // Determine max cards: default 6, or unlimited when ?max=all
                var maxCards = 6;
                try {
                    if (typeof URLSearchParams !== 'undefined') {
                        var params = new URLSearchParams(window.location.search);
                        var maxParam = params.get('max');
                        if (maxParam && String(maxParam).toLowerCase() === 'all') {
                            maxCards = Infinity;
                        } else if (maxParam) {
                            var parsed = parseInt(maxParam, 10);
                            if (!isNaN(parsed)) maxCards = parsed;
                        }
                    }
                } catch (e) {
                    /* ignore */
                }

                // Build HTML safely
                var countHtml = '<div class="call-count">Calls: ' + calledList.length + '</div>';
                var cardsHtml = '';
                var limit = (maxCards === Infinity) ? calledList.length : Math.min(calledList.length, maxCards);
                for (var j = 0; j < limit; j++) {
                    var item = calledList[j];
                    var q = (item && item.queue_number) ? item.queue_number : '';
                    cardsHtml += '<div class="kiosk-call-card active">' +
                                 '<div class="call-queue-number">' + q + '</div>' +
                                 '</div>';
                }

                container.innerHTML = countHtml + cardsHtml;
            } catch (err) {
                console.error('updateStreamDisplay error', err);
                var c = document.getElementById(containerId);
                if (c) c.innerHTML = '<div class="no-call-indicator">−</div>';
            }
        }

        // Refresh every 2 seconds
        setInterval(refreshStreams, 2000);
        refreshStreams();
    </script>
</body>
</html>
 

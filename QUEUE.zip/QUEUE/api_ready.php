<?php
/**
 * Queue + Assessment System Integration Readiness Check
 * Verifies schema, API endpoints, and configuration are ready for production
 * Run: php api_ready.php
 */

require_once __DIR__ . '/config.php';

$checks = [
    'passed' => 0,
    'failed' => 0,
    'warnings' => 0,
];

function pass($msg) {
    global $checks;
    echo "✓ $msg\n";
    $checks['passed']++;
}

function fail($msg) {
    global $checks;
    echo "✗ $msg\n";
    $checks['failed']++;
}

function warn($msg) {
    global $checks;
    echo "⚠ $msg\n";
    $checks['warnings']++;
}

echo "\n" . str_repeat("═", 60) . "\n";
echo "Queue API Readiness Check\n";
echo str_repeat("═", 60) . "\n\n";

// Check 1: Database tables
echo "Database Schema\n" . str_repeat("─", 60) . "\n";
$tables = [
    'patients' => 'Patient records',
    'tickets' => 'Ticket queue',
    'clinics_notifications_queue' => 'Outbound notification retry queue',
    'ticket_logs' => 'Ticket activity audit trail',
];

foreach ($tables as $table => $desc) {
    try {
        $result = $pdo->query("SHOW TABLES LIKE '$table'")->rowCount();
        if ($result > 0) {
            pass("Table '$table' exists ($desc)");
        } else {
            fail("Table '$table' missing");
        }
    } catch (Exception $e) {
        fail("Cannot access table '$table'");
    }
}

// Check 2: Required columns
echo "\nTickets Table Columns\n" . str_repeat("─", 60) . "\n";
$requiredColumns = [
    'ticket_id' => 'Primary key',
    'patient_id' => 'Patient reference',
    'current_status' => 'Queue status (ENUM)',
    'external_details' => 'Third-party metadata (JSON)',
    'clinics_call_time' => 'Clinics workflow timestamp',
];

try {
    $result = $pdo->query("DESCRIBE tickets");
    $columns = [];
    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
        $columns[$row['Field']] = $row['Type'];
    }
    
    foreach ($requiredColumns as $col => $desc) {
        if (isset($columns[$col])) {
            pass("Column '$col' exists ({$columns[$col]}) - $desc");
        } else {
            fail("Column '$col' missing from tickets table");
        }
    }
} catch (Exception $e) {
    fail("Cannot inspect tickets table: " . $e->getMessage());
}

// Check 3: Test data
echo "\nTest Data\n" . str_repeat("─", 60) . "\n";
try {
    $patientCount = (int)$pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
    $ticketCount = (int)$pdo->query("SELECT COUNT(*) FROM tickets")->fetchColumn();
    
    if ($patientCount > 0) {
        pass("$patientCount patient record(s) exist");
    } else {
        warn("No patient records - create via queue system");
    }
    
    if ($ticketCount > 0) {
        pass("$ticketCount ticket record(s) exist");
    } else {
        warn("No tickets - create via queue system");
    }
} catch (Exception $e) {
    fail("Cannot query test data: " . $e->getMessage());
}

// Check 4: API functions
echo "\nIntegration Functions\n" . str_repeat("─", 60) . "\n";
$functions = [
    'sendClinicsIntegrationJsonRequest' => 'HTTP request to third-party',
    'notifyClinicsExternalTicketCreated' => 'Register ticket with assessment system',
    'syncClinicsExternalPatientMrn' => 'Sync MRN to assessment system',
    'processClinicNotificationQueue' => 'Retry failed notifications (cron)',
    'mapExternalTicketStatus' => 'Convert external status to Queue enum',
];

foreach ($functions as $func => $desc) {
    if (function_exists($func)) {
        pass("Function '$func' defined - $desc");
    } else {
        fail("Function '$func' not defined");
    }
}

// Check 5: Configuration
echo "\nConfiguration\n" . str_repeat("─", 60) . "\n";
$config = [
    'CLINICS_INTEGRATION_BASE_URL' => 'Assessment system URL',
    'CLINICS_INTEGRATION_API_TOKEN' => 'Bearer token (Queue → Assessment)',
    'QUEUE_API_BEARER_TOKEN' => 'Bearer token (Assessment → Queue)',
    'CLINICS_INTEGRATION_HTTP_TIMEOUT_SECONDS' => 'Request timeout'
    ,
];

foreach ($config as $const => $desc) {
    if (defined($const)) {
        $value = constant($const);
        if ($const === 'CLINICS_INTEGRATION_API_TOKEN' || $const === 'QUEUE_API_BEARER_TOKEN') {
            $display = strlen($value) > 0 ? '✓ configured (' . strlen($value) . ' chars)' : 'not configured (optional)';
        } else {
            $display = $value;
        }
        pass("Constant '$const' = '$display' - $desc");
    } else {
        fail("Constant '$const' not defined");
    }
}

// Check 6: API endpoints accessible
echo "\nAPI Endpoints\n" . str_repeat("─", 60) . "\n";
if (file_exists(__DIR__ . '/api/index.php')) {
    pass("API handler exists at /api/index.php");
    if (file_exists(__DIR__ . '/api/.htaccess')) {
        pass("URL rewriting configured (.htaccess)");
    } else {
        warn("No .htaccess - URL rewriting may not work");
    }
} else {
    fail("API handler missing at /api/index.php");
}

// Summary
echo "\n" . str_repeat("═", 60) . "\n";
echo "Summary\n";
echo str_repeat("═", 60) . "\n";
echo "Passed:  " . $checks['passed'] . "\n";
echo "Failed:  " . $checks['failed'] . "\n";
echo "Warnings: " . $checks['warnings'] . "\n\n";

if ($checks['failed'] === 0) {
    echo "✓ System is ready for production\n\n";
    echo "Integration Points:\n";
    echo "  • Queue creates tickets → POST https://localhost/assessment/api/clinic-ticket\n";
    echo "    Auth: Authorization: Bearer secret-assessment-bearer\n\n";
    echo "  • MRN synced from billing → POST https://localhost/assessment/api/patients/{uuid}/mrn\n";
    echo "    Auth: Authorization: Bearer secret-assessment-bearer\n\n";
    echo "  • Assessment system calls → POST /api/ticket/{id}/{status}/{user}\n";
    echo "    Auth: Authorization: Bearer secret-queue-bearer\n\n";
    echo "  • Retry processor → php clinics_notification_processor.php (via cron)\n";
} else {
    echo "✗ Fix errors above before proceeding\n";
}

echo "\n";
exit($checks['failed'] > 0 ? 1 : 0);

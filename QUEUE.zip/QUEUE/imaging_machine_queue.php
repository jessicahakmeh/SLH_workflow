<?php
// imaging_machine_queue.php
require_once 'config.php';
session_start();
authRequireRoles(['imaging', 'admin'], ['log_view' => false]);

$machine = $_GET['machine'] ?? 'Xray';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// MODIFIED: Get patients assigned to this machine AND consolidate duplicates
// Group by queue_number to show each patient only once, even if they have multiple tests
$query = "
    SELECT
        t.ticket_id AS id,
        t.queue_number,
        p.patient_name,
        p.mrn,
        p.mobile,
        p.email,
        p.address,
        t.service_type as type,
        t.current_status as status,
        t.arrival_timestamp,
        t.approval_timestamp,
        t.imaging_call_time,
        t.imaging_machine,
        t.img,
        t.dp2,
        GROUP_CONCAT(DISTINCT t2.imaging_machine) as all_machines,
        COUNT(DISTINCT t2.ticket_id) as total_test_count
    FROM tickets t
    JOIN patients p ON t.patient_id = p.patient_id
    LEFT JOIN tickets t2 ON t2.queue_number = t.queue_number
        AND DATE(t2.arrival_timestamp) = DATE(t.arrival_timestamp)
        AND t2.closing_timestamp IS NULL
        AND t2.imaging_machine IS NOT NULL
    WHERE t.closing_timestamp IS NULL
    AND t.imaging_machine = ?
    AND t.current_status IN ('Waiting', 'Called', 'Skipped', 'Recalled', 'Served', 'On Hold', 'In Process')
    AND DATE(t.arrival_timestamp) = CURDATE()
";

// Add search filter if provided
if (!empty($search)) {
    // Search by patient name, queue number, or MRN
    $query .= " AND (p.patient_name LIKE ? OR t.queue_number LIKE ? OR p.mrn LIKE ?)";
    $search_param = "%{$search}%";
    $patients = executeAndFetch($pdo, $query . "
    GROUP BY t.queue_number
    ORDER BY
        FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
        COALESCE(t.approval_timestamp, t.arrival_timestamp) ASC
    ", [$machine, $search_param, $search_param, $search_param]);
} else {
    $patients = executeAndFetch($pdo, $query . "
    GROUP BY t.queue_number
    ORDER BY
        FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
        COALESCE(t.approval_timestamp, t.arrival_timestamp) ASC
    ", [$machine]);
}

// Count statistics
$waiting_count = 0;
$called_count = 0;
$in_process_count = 0;

foreach ($patients as $patient) {
    if ($patient['status'] == 'Waiting') $waiting_count++;
    if (in_array($patient['status'], ['Called', 'Recalled'])) $called_count++;
    if ($patient['status'] == 'In Process') $in_process_count++;
}
?>
<link rel=stylesheet href="styles.css"></link>
<div class="machine-queue active" id="queue-<?php echo strtolower($machine); ?>">
    <!-- Search Bar -->
    <div style="padding: 12px 15px; background: #f8f9fa; border-bottom: 1px solid #eee; display: flex; gap: 10px; align-items: center;">
        <i class="fas fa-search" style="color: #7f8c8d;"></i>
        <input type="text" id="patientSearch" placeholder="Search by name, queue #, or MRN..." style="flex: 1; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px;">
        <button onclick="clearSearch()" style="padding: 8px 12px; background: #e74c3c; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">Clear</button>
    </div>
    <div class="queue-table-container">
        <table class="queue-table">
            <thead>
                <tr>
                    <th width="80">Queue #</th>
                    <th width="100">MRN</th>
                    <th width="180">Patient Name</th>
                    <th width="100">Type</th>
                    <th width="100">Status</th>
                    <th width="150">Tests</th>
                    <th width="200">Actions</th>
                </tr>
            </thead>
            <tbody id="machineQueueBody-<?php echo strtolower($machine); ?>">
                <?php if (empty($patients)): ?>
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">
                                <i class="fas fa-inbox"></i>
                                <h3>No patients in <?php echo $machine; ?> queue</h3>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($patients as $patient): 
                        $waiting_minutes = floor((strtotime(date('Y-m-d H:i:s')) - strtotime($patient['arrival_timestamp'])) / 60);
                        $status_class = 'status-' . str_replace(' ', '-', strtolower($patient['status']));
                        $type_class = 'type-' . strtolower($patient['type']);
                        $has_duplicates = $patient['total_test_count'] > 1;
                    ?>
                        <tr id="imaging-patient-<?php echo $patient['id']; ?>" 
                            class="<?php echo $patient['type'] == 'Appointment' ? 'priority-highlight' : ''; ?><?php echo $has_duplicates ? ' duplicate-test-row' : ''; ?>"
                            style="<?php echo $has_duplicates ? 'border-left: 4px solid #e74c3c;' : ''; ?>">
                            <td style="font-weight: bold; color: #2c3e50;">
                                <?php echo $patient['queue_number']; ?>
                            </td>
                            <td style="font-size: 12px; color: #7f8c8d;">
                                <?php echo htmlspecialchars($patient['mrn'] ?? 'N/A'); ?>
                            </td>
                            <td>
                                <button class="view-pdf-btn" data-patient='<?php echo htmlspecialchars(json_encode([
                                    'id' => $patient['id'],
                                    'queue_number' => $patient['queue_number'],
                                    'patient_name' => $patient['patient_name'],
                                    'mrn' => $patient['mrn'] ?? ''
                                ]), ENT_QUOTES, 'UTF-8'); ?>' style="background:none;border:none;padding:0;font-size:inherit;cursor:pointer;color:inherit;">
                                    <?php echo htmlspecialchars($patient['patient_name']); ?>
                                </button>
                            </td>
                            <td>
                                <span class="type-badge <?php echo $type_class; ?>">
                                    <?php echo $patient['type']; ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge <?php echo $status_class; ?>">
                                    <?php echo $patient['status']; ?>
                                </span>
                                <?php if ($patient['status'] == 'Waiting' && $waiting_minutes > 15): ?>
                                    <span class="waiting-indicator long-wait"></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($has_duplicates): ?>
                                    <span style="display: inline-block; padding: 4px 8px; background: #fadbd8; color: #e74c3c; border-radius: 3px; font-size: 11px; font-weight: bold;">
                                        <i class="fas fa-copy"></i> <?php echo $patient['total_test_count']; ?> tests
                                    </span>
                                    <div style="font-size: 10px; color: #e74c3c; margin-top: 4px;">
                                        <?php echo htmlspecialchars(implode(', ', array_filter(explode(',', $patient['all_machines'])))); ?>
                                    </div>
                                <?php else: ?>
                                    <span style="display: inline-block; padding: 4px 8px; background: #e8f5e9; color: #27ae60; border-radius: 3px; font-size: 11px;">
                                        <?php echo htmlspecialchars($patient['imaging_machine']); ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <?php if ($patient['status'] == 'Waiting'): ?>
                                        <form method="POST" action="patient_actions.php" style="display: inline;">
                                            <input type="hidden" name="department" value="imaging">
                                            <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                            <input type="hidden" name="machine" value="<?php echo $machine; ?>">
                                            <input type="hidden" name="action" value="call_patient">
                                            <button type="submit" class="action-btn btn-call">
                                                <i class="fas fa-bullhorn"></i> Call
                                            </button>
                                        </form>
                                    <?php elseif ($patient['status'] == 'Called'): ?>
                                        <form method="POST" action="patient_actions.php" style="display: inline;">
                                            <input type="hidden" name="department" value="imaging">
                                            <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                            <input type="hidden" name="machine" value="<?php echo $machine; ?>">
                                            <input type="hidden" name="action" value="start_procedure">
                                            <button type="submit" class="action-btn btn-complete">
                                                <i class="fas fa-play"></i> Start
                                            </button>
                                        </form>
                                        <button class="action-btn btn-skip" 
                                                onclick="skipPatient(<?php echo $patient['id']; ?>, '<?php echo $machine; ?>')">
                                            <i class="fas fa-forward"></i> Skip
                                        </button>
                                    <?php elseif ($patient['status'] == 'In Process'): ?>
                                        <form method="POST" action="patient_actions.php" style="display: inline;">
                                            <input type="hidden" name="department" value="imaging">
                                            <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                            <input type="hidden" name="machine" value="<?php echo $machine; ?>">
                                            <input type="hidden" name="action" value="complete_patient">
                                            <button type="submit" class="action-btn btn-complete">
                                                <i class="fas fa-check-circle"></i> Complete
                                            </button>
                                        </form>
                                        <form method="POST" action="patient_actions.php" style="display: inline;">
                                            <input type="hidden" name="department" value="imaging">
                                            <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                            <input type="hidden" name="machine" value="<?php echo $machine; ?>">
                                            <input type="hidden" name="action" value="send_back">
                                            <button type="submit" class="action-btn" style="background: #e74c3c; color: white;">
                                                <i class="fas fa-arrow-left"></i> Back
                                            </button>
                                        </form>
                                    <?php elseif (in_array($patient['status'], ['Skipped', 'Recalled'])): ?>
                                        <button class="action-btn btn-call" 
                                                onclick="recallPatient(<?php echo $patient['id']; ?>, '<?php echo $machine; ?>')">
                                            <i class="fas fa-undo"></i> Recall
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
    <script>
    // Helper to escape HTML
    function escapeHtml(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    // Search functionality
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('patientSearch');
        if (searchInput) {
            searchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    performSearch();
                }
            });
        }
    });

    function performSearch() {
        const searchInput = document.getElementById('patientSearch');
        const machine = '<?php echo addslashes($machine); ?>';
        const searchValue = searchInput?.value || '';
        
        if (searchValue.trim() === '') {
            alert('Please enter a search term (name, queue #, or MRN)');
            return;
        }
        
        window.location.href = `imaging_machine_queue.php?machine=${encodeURIComponent(machine)}&search=${encodeURIComponent(searchValue)}`;
    }

    function clearSearch() {
        const machine = '<?php echo addslashes($machine); ?>';
        window.location.href = `imaging_machine_queue.php?machine=${encodeURIComponent(machine)}`;
    }

    function showPdfSelectorQueue(patient) {
        let modal = document.getElementById('pdfSelectorModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'pdfSelectorModal';
            modal.className = 'patient-modal';
            modal.innerHTML = `
                <div class="patient-modal-content">
                    <div class="patient-modal-header">
                        <div class="patient-modal-title"><i class="fas fa-file-pdf"></i> Open Document</div>
                        <button class="patient-modal-close" id="pdfModalClose" aria-label="Close">
                            <i class="fas fa-times" aria-hidden="true"></i>
                            <span style="font-size:16px; line-height:1; margin-left:4px;">&times;</span>
                        </button>
                    </div>
                    <div class="patient-modal-body" id="pdfModalBody"></div>
                </div>`;
            document.body.appendChild(modal);
            modal.querySelector('#pdfModalClose').addEventListener('click', () => modal.classList.remove('active'));
        }
        const body = modal.querySelector('#pdfModalBody');
        body.innerHTML = `
            <div style="margin-bottom:12px;"><strong>${escapeHtml(patient.patient_name || '')}</strong> — ${escapeHtml(patient.queue_number || '')}</div>
            <div style="display:flex; gap:8px;">
                <button id="openIdBtn" class="action-btn start"><i class="fas fa-id-card"></i> Open ID</button>
                <button id="openPrescBtn" class="action-btn whatsapp" style="background:#9b59b6; color:white;"><i class="fas fa-prescription"></i> Open Prescription</button>
            </div>
        `;
        modal.classList.add('active');
        function openFile(type) {
            const filenameBase = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : patient.id;
            const url = 'download_pdf.php?type=' + encodeURIComponent(type) + '&file=' + encodeURIComponent(filenameBase + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
            window.open(url, '_blank', 'noopener');
        }
        modal.querySelector('#openIdBtn').onclick = () => openFile('id');
        modal.querySelector('#openPrescBtn').onclick = () => openFile('insurance');
    }

    // Delegate click for view-pdf-btn inside this fragment
    document.addEventListener('click', function(e) {
        const btn = e.target.closest && e.target.closest('.view-pdf-btn');
        if (btn) {
            e.preventDefault();
            const data = btn.getAttribute('data-patient');
            try { const patient = JSON.parse(data); showPdfSelectorQueue(patient); } catch(err) { console.error('Invalid patient data', err); }
        }
    });

    // Convert action forms and buttons to AJAX to prevent redirect
    document.addEventListener('click', function(e) {
        const form = e.target.closest('form[action*="patient_actions.php"]');
        if (form && e.target.tagName === 'BUTTON' && form.method.toUpperCase() === 'POST') {
            e.preventDefault();
            const formData = new FormData(form);
            fetch('patient_actions.php', {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: formData
            })
            .then(r => r.json())
            .then(data => console.log('Action completed:', data))
            .catch(err => console.error('Action error:', err));
        }
    });

    // Helper functions for skip and recall actions
    function skipPatient(patientId, machine) {
        const formData = new FormData();
        formData.append('department', 'imaging');
        formData.append('patient_id', patientId);
        formData.append('machine', machine);
        formData.append('action', 'skip');
        
        fetch('patient_actions.php', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: formData
        })
        .then(r => r.json())
        .then(data => console.log('Patient skipped:', data))
        .catch(err => console.error('Skip error:', err));
    }

    function recallPatient(patientId, machine) {
        const formData = new FormData();
        formData.append('department', 'imaging');
        formData.append('patient_id', patientId);
        formData.append('machine', machine);
        formData.append('action', 'recall');
        
        fetch('patient_actions.php', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: formData
        })
        .then(r => r.json())
        .then(data => console.log('Patient recalled:', data))
        .catch(err => console.error('Recall error:', err));
    }

    // Auto-refresh queue with new consolidated format
    (function(){
        const machine = '<?php echo addslashes($machine); ?>';
        const tbodyId = 'machineQueueBody-' + machine.toLowerCase();
        
        function refreshQueue() {
            if (document.hidden) return;
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000);
            fetch(`queue_refresh.php?department=imaging&machine=${encodeURIComponent(machine)}`, { signal: controller.signal })
                .then(response => { clearTimeout(timeoutId); if (!response.ok) throw new Error('HTTP error ' + response.status); return response.json(); })
                .then(patients => {
                    const tbody = document.getElementById(tbodyId);
                    if (!tbody) return;
                    if (!Array.isArray(patients) || patients.length === 0) {
                        tbody.innerHTML = `<tr><td colspan=7><div class="empty-state"><i class="fas fa-inbox"></i><h3>No patients in ${escapeHtml(machine)} queue</h3></div></td></tr>`;
                        return;
                    }
                    let html = '';
                    patients.forEach(patient => {
                        const patientType = patient.type || 'Private';
                        const status_class = 'status-' + (patient.status || '').toLowerCase().replace(/\s+/g,'-');
                        const type_class = 'type-' + (patientType || '').toLowerCase();
                        const hasMultipleTests = patient.all_machines && patient.all_machines.split(',').length > 1;
                        
                        const actionButtons = (function(){
                            if (patient.status === 'Waiting') return `
                                <form method="POST" action="patient_actions.php" style="display:inline;">
                                    <input type="hidden" name="department" value="imaging">
                                    <input type="hidden" name="patient_id" value="${patient.id}">
                                    <input type="hidden" name="machine" value="${machine}">
                                    <input type="hidden" name="action" value="call_patient">
                                    <button type="submit" class="action-btn btn-call"><i class="fas fa-bullhorn"></i> Call</button>
                                </form>`;
                            if (patient.status === 'Called' || patient.status === 'Recalled') return `
                                <form method="POST" action="patient_actions.php" style="display:inline;">
                                    <input type="hidden" name="department" value="imaging">
                                    <input type="hidden" name="patient_id" value="${patient.id}">
                                    <input type="hidden" name="machine" value="${machine}">
                                    <input type="hidden" name="action" value="start_procedure">
                                    <button type="submit" class="action-btn btn-complete"><i class="fas fa-play"></i> Start</button>
                                </form>
                                <button class="action-btn btn-skip" onclick="skipPatient(${patient.id}, '${machine}')"><i class="fas fa-forward"></i> Skip</button>`;
                            if (patient.status === 'In Process') return `
                                <form method="POST" action="patient_actions.php" style="display:inline;">
                                    <input type="hidden" name="department" value="imaging">
                                    <input type="hidden" name="patient_id" value="${patient.id}">
                                    <input type="hidden" name="machine" value="${machine}">
                                    <input type="hidden" name="action" value="complete_patient">
                                    <button type="submit" class="action-btn btn-complete"><i class="fas fa-check-circle"></i> Complete</button>
                                </form>`;
                            return '';
                        })();
                        
                        const testBadgeContent = hasMultipleTests 
                            ? `<span style="display: inline-block; padding: 4px 8px; background: #fadbd8; color: #e74c3c; border-radius: 3px; font-size: 11px; font-weight: bold;"><i class="fas fa-copy"></i> Multiple tests</span>`
                            : `<span style="display: inline-block; padding: 4px 8px; background: #e8f5e9; color: #27ae60; border-radius: 3px; font-size: 11px;">${escapeHtml(machine)}</span>`;

                        html += `<tr id="imaging-patient-${patient.id}" class="${patientType === 'Appointment' ? 'priority-highlight' : ''}${hasMultipleTests ? ' duplicate-test-row' : ''}" style="${hasMultipleTests ? 'border-left: 4px solid #e74c3c;' : ''}">
                            <td style="font-weight:bold;color:#2c3e50;">${patient.queue_number}</td>
                            <td style="font-size: 12px; color: #7f8c8d;">${escapeHtml(patient.mrn || 'N/A')}</td>
                            <td>
                                <button class="view-pdf-btn" data-patient='${JSON.stringify({id: patient.id, queue_number: patient.queue_number, patient_name: patient.patient_name, mrn: patient.mrn || ''}).replace(/'/g, "&apos;")}' style="background:none;border:none;padding:0;font-size:inherit;cursor:pointer;color:inherit;">
                                    ${escapeHtml(patient.patient_name)}
                                </button>
                            </td>
                            <td><span class="type-badge ${type_class}">${escapeHtml(patientType)}</span></td>
                            <td><span class="status-badge ${status_class}">${escapeHtml(patient.status || '')}</span></td>
                            <td>${testBadgeContent}</td>
                            <td><div class="action-buttons">${actionButtons}</div></td>
                        </tr>`;
                    });
                    tbody.innerHTML = html;
                })
                .catch(err => { clearTimeout(timeoutId); if (err.name === 'AbortError') console.warn('Queue refresh timeout'); else console.error('Queue refresh error', err); });
        }

        // Kick off interval
        setInterval(() => { if (!document.hidden) refreshQueue(); }, 2000);
    })();
    </script>
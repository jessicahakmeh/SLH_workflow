<?php
declare(strict_types=1);
require_once 'config.php';
session_start();

/**
 * imaging_queue.php
 *
 * Startup page for the imaging workstation.
 *
 * Behavior:
 * - When opened from the command line, it launches this page in the browser.
 * - When opened in the browser, it auto-authenticates as the imaging user and
 *   redirects to the imaging landing page.
 */

$username = '.\\imaging';
$password = 'imaging';
$returnTo = 'imaging.php';
$localUrl = 'https://hsl-sharepoint/QUEUE/imaging_queue.php';

if (PHP_SAPI === 'cli') {
    require_once __DIR__ . '/lib/exec_helpers.php';
    $cmd = '"' . $localUrl . '"';
    // Use background helper to detach safely
    run_process_background($cmd);
    log_event('spawn', 'imaging_queue background start: ' . $cmd);
    echo "[imaging_queue] Opened browser -> $localUrl\n";
    exit(0);
}

$currentUser = authCurrentUser();
if ($currentUser) {
    $currentUsername = authNormalizeLoginName((string)($currentUser['username'] ?? ''));
    if ($currentUsername === 'imaging') {
        header('Location: ' . $returnTo);
        exit;
    }
    authLogoutUser();
}

$error = '';
if (authLoginUser($username, $password, $error)) {
    header('Location: ' . $returnTo);
    exit;
}

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imaging Login</title>
    <style>
        body{margin:0;font-family:Segoe UI,Tahoma,sans-serif;background:linear-gradient(135deg,#e7eef7,#f8fafc);color:#17212f}
        .wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}
        .card{width:min(460px,100%);background:#fff;border-radius:18px;padding:28px;box-shadow:0 24px 64px rgba(23,33,47,.14)}
        h1{margin:0 0 8px;font-size:28px}
        .muted{color:#607086;margin:0 0 20px;line-height:1.5}
        .pill{display:inline-block;padding:4px 8px;background:#eef5ff;color:#0b66c3;border-radius:999px;font-size:12px;font-weight:700}
        .status{margin-top:18px;font-size:14px;color:#455468}
        .fallback{margin-top:18px;display:inline-block;padding:10px 14px;border-radius:10px;background:#0b66c3;color:#fff;text-decoration:none;font-weight:700;border:0;cursor:pointer}
        noscript{display:block;margin-top:16px;color:#a12626;font-size:13px}
    </style>
</head>
<body>
<div class="wrap">
    <div class="card">
        <span class="pill">Imaging Startup</span>
        <h1>Automatic sign-in failed</h1>
        <p class="muted">Could not authenticate as the imaging workstation user.</p>
        <?php if ($error !== ''): ?>
            <div class="status"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
        <a class="fallback" href="login.php?return_to=<?php echo urlencode($returnTo); ?>">Open login page</a>
    </div>
</div>
</body>
</html>

<?php
// download_pdf.php - serve PDFs from network locations via HTTP
require_once 'config.php';
session_start();
authRequireRoles(['butler', 'billing', 'imaging', 'laboratory', 'admin'], ['log_view' => false]);

// Simple input validation
$type = isset($_GET['type']) ? $_GET['type'] : '';
$file = isset($_GET['file']) ? $_GET['file'] : '';

if (empty($type) || empty($file)) {
    http_response_code(400);
    echo 'Missing parameters';
    exit;
}

// Only allow pdf extension
if (strtolower(pathinfo($file, PATHINFO_EXTENSION)) !== 'pdf') {
    http_response_code(400);
    echo 'Only PDF files are allowed';
    exit;
}

// Sanitize filename (allow letters, numbers, underscore, dash, dot)
$sanitized = preg_replace('/[^A-Za-z0-9_\-\.]/', '', $file);
if ($sanitized !== $file) {
    http_response_code(400);
    echo 'Invalid filename';
    exit;
}

// Determine base path
if ($type === 'id') {
    $base = ID_SAVE_PATH;
} elseif ($type === 'insurance') {
    $base = INSURANCE_SAVE_PATH;
} else {
    http_response_code(400);
    echo 'Invalid type';
    exit;
}

// Resolve server/share root for net use if needed
function connectNetworkShareIfNeeded($basePath) {
    // Attempt to access; if readable, return true
    if (@is_readable($basePath)) return true;

    // Extract server and share (\\server\share\...)
    $p = preg_replace('#^\\\\+#', '', $basePath); // remove leading backslashes
    $parts = explode('\\', $p);
    if (count($parts) < 2) return false;
    $server = $parts[0];
    $share = $parts[1];
    $root = "\\\\{$server}\\{$share}";

    // Run net use
    $user = NETWORK_USERNAME;
    $pass = NETWORK_PASSWORD;
    require_once __DIR__ . '/lib/exec_helpers.php';
    $cmd = 'net use ' . escapeshellarg($root) . ' /user:' . escapeshellarg($user) . ' ' . escapeshellarg($pass) . ' 2>&1';
    $r = run_process($cmd, null, 10);
    $output = preg_split('/\r?\n/', trim($r['stdout']));
    $ret = $r['exit'];
    if ($ret !== 0) error_log("net use failed: " . implode('\n', $output));
    if ($ret === 0) return true;
    error_log("net use failed: " . implode("\n", $output));
    return false;
}

// Ensure network share is accessible
connectNetworkShareIfNeeded($base);

// Allow optional patient id for fallback attempts
$patient_id = isset($_GET['patient']) ? intval($_GET['patient']) : null;

// Build candidate filenames to try (in order)
$candidates = [];
$candidates[] = $sanitized; // requested

if ($patient_id) {
    $candidates[] = $patient_id . '.pdf';
    // Also try common variants used by scanner
    $candidates[] = $patient_id . '_ID.pdf';
    $candidates[] = $patient_id . '_Insurance_Prescription.pdf';
    // Try to find MRN from DB and add as candidate
    try {
        $row = executeAndFetchOne($pdo, "SELECT p.mrn, t.queue_number FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
        if ($row) {
            if (!empty($row['mrn'])) {
                // sanitize mrn to safe filename
                $mrnbase = preg_replace('/[^A-Za-z0-9_\\-\\.]/', '', $row['mrn']);
                if ($mrnbase !== '') $candidates[] = $mrnbase . '.pdf';
            }
            if (!empty($row['queue_number'])) {
                $qbase = preg_replace('/[^A-Za-z0-9_\\-\\.]/', '', $row['queue_number']);
                if ($qbase !== '') {
                    $candidates[] = $qbase . '.pdf';
                    $candidates[] = $qbase . '_ID.pdf';
                    $candidates[] = $qbase . '_Insurance_Prescription.pdf';
                }
            }
        }
    } catch (Exception $e) {
        // ignore DB errors here
    }
}

// Ensure network share is accessible (attempt to connect once)
connectNetworkShareIfNeeded($base);

 $found = false;
// For debugging, track attempted paths
$attempts = [];
foreach ($candidates as $candidate) {
    $fullpath = $base . $candidate;
    $attempts[] = $fullpath;
    if (file_exists($fullpath) && is_readable($fullpath)) {
        // Stream file
        $filesize = filesize($fullpath);
        require_once __DIR__ . '/lib/monitoring.php';
        // If file is unusually large, log and cap stream to 20MB to avoid DoS via huge files
        $maxServe = 20 * 1024 * 1024; // 20MB
        if ($filesize > $maxServe) {
            log_event('download', 'Large PDF blocked or capped: ' . $fullpath . ' size=' . $filesize);
            // We still serve first part but warn in headers
            header('X-Content-Warning: truncated');
            $serveSize = $maxServe;
        } else {
            $serveSize = $filesize;
        }
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="' . basename($candidate) . '"');
        header('Content-Length: ' . $serveSize);
        if (ob_get_level()) ob_end_clean();

        $fp = fopen($fullpath, 'rb');
        if ($fp) {
            $sent = 0;
            while (!feof($fp) && $sent < $serveSize) {
                $toRead = min(8192, $serveSize - $sent);
                $buf = fread($fp, $toRead);
                if ($buf === false) break;
                echo $buf;
                flush();
                $sent += strlen($buf);
            }
            fclose($fp);
        }
        $found = true;
        break;
    }
}

if (!$found) {
        // No exact candidate found. Do NOT perform broad glob/substring matching to avoid
        // accidental partial matches (e.g., MRN '456' matching file '123456.pdf').
        // Log attempted exact paths for diagnostics and return 404.
        $allAttempts = $attempts; // only exact candidates were tried
        error_log('download_pdf: file not found. Tried exact: ' . implode(' | ', $allAttempts));
        http_response_code(404);
        echo 'File not found';
        exit;
}
exit;
?>
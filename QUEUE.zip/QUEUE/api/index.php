<?php
session_start();
$_GET['suppress_output'] = true;
require_once dirname(__DIR__) . '/config.php';

header('Content-Type: application/json; charset=utf-8');

$GLOBALS['queue_api_request_context'] = [
    'method' => strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')),
    'uri' => (string)($_SERVER['REQUEST_URI'] ?? ''),
    'remote_addr' => (string)($_SERVER['REMOTE_ADDR'] ?? ''),
    'body' => '',
];

function apiRespond($code, $payload) {
    if (function_exists('logIntegrationApiTraffic')) {
        logIntegrationApiTraffic('inbound-response', 'queue-api', [
            'request' => $GLOBALS['queue_api_request_context'] ?? [],
            'status_code' => (int)$code,
            'response_body' => $payload,
        ]);
    }
    http_response_code((int)$code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function apiReadJsonBody() {
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        $GLOBALS['queue_api_request_context']['body'] = '';
        return [];
    }
    $GLOBALS['queue_api_request_context']['body'] = $raw;
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : null;
}

function apiRequestPathParts() {
    $scriptName = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $requestUri = str_replace('\\', '/', (string)($_SERVER['REQUEST_URI'] ?? ''));
    $path = parse_url($requestUri, PHP_URL_PATH);
    $baseDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
    if ($baseDir !== '' && strpos($path, $baseDir) === 0) {
        $path = substr($path, strlen($baseDir));
    }
    $path = trim((string)$path, '/');
    return $path === '' ? [] : explode('/', $path);
}

function apiAuthorizeIfConfigured() {
    $expected = trim((string)(defined('QUEUE_API_BEARER_TOKEN') ? QUEUE_API_BEARER_TOKEN : ''));
    if ($expected === '') {
        return;
    }

    $headerToken = trim((string)($_SERVER['HTTP_X_QUEUE_API_KEY'] ?? ''));
    if ($headerToken === '') {
        $authHeader = trim((string)($_SERVER['HTTP_AUTHORIZATION'] ?? ''));
        if (stripos($authHeader, 'Bearer ') === 0) {
            $headerToken = trim(substr($authHeader, 7));
        }
    }

    if ($headerToken === '' || !hash_equals($expected, $headerToken)) {
        apiRespond(401, ['success' => false, 'error' => 'unauthorized']);
    }
}

function applyMappedStatusUpdate($pdo, $ticketId, $mappedStatus, $timestamp) {
    $sets = ['current_status = ?'];
    $params = [$mappedStatus];

    if ($mappedStatus === 'Called' || $mappedStatus === 'Recalled') {
        $sets[] = 'clinics_call_time = ?';
        $params[] = $timestamp;
    }
    if ($mappedStatus === 'In Process' || $mappedStatus === 'Served') {
        $sets[] = 'approval_timestamp = COALESCE(approval_timestamp, ?)';
        $params[] = $timestamp;
    }
    if ($mappedStatus === 'Completed' || $mappedStatus === 'Canceled') {
        $sets[] = 'closing_timestamp = ?';
        $params[] = $timestamp;
    }

    $params[] = $ticketId;
    $sql = 'UPDATE tickets SET ' . implode(', ', $sets) . ' WHERE ticket_id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
}

apiAuthorizeIfConfigured();

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$parts = apiRequestPathParts();

if (function_exists('logIntegrationApiTraffic')) {
    logIntegrationApiTraffic('inbound-request', 'queue-api', [
        'method' => $method,
        'parts' => $parts,
        'uri' => (string)($_SERVER['REQUEST_URI'] ?? ''),
        'remote_addr' => (string)($_SERVER['REMOTE_ADDR'] ?? ''),
    ]);
}

if (count($parts) >= 2 && $parts[0] === 'patients' && $method === 'GET') {
    $patientUuid = trim((string)$parts[1]);
    if ($patientUuid === '') {
        apiRespond(400, ['success' => false, 'error' => 'missing_patient_uuid']);
    }

    if (isset($parts[2]) && $parts[2] !== 'mrn') {
        apiRespond(404, ['success' => false, 'error' => 'not_found']);
    }

    $stmt = $pdo->prepare('SELECT patient_uuid, patient_name, COALESCE(mrn, \'\') AS mrn FROM patients WHERE patient_uuid = ? LIMIT 1');
    $stmt->execute([$patientUuid]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$patient) {
        apiRespond(404, ['success' => false, 'error' => 'patient_not_found']);
    }

    if (isset($parts[2]) && $parts[2] === 'mrn') {
        apiRespond(200, [
            'patient_uuid' => (string)$patient['patient_uuid'],
            'mrn' => (string)$patient['mrn'],
        ]);
    }

    apiRespond(200, [
        'patient_uuid' => (string)$patient['patient_uuid'],
        'patient_name' => (string)$patient['patient_name'],
        'mrn' => (string)$patient['mrn'],
    ]);
}

if (count($parts) === 4 && $parts[0] === 'ticket' && $method === 'POST') {
    $ticketId = (int)$parts[1];
    $statusFromPath = trim((string)$parts[2]);
    $usernameFromPath = trim((string)$parts[3]);
    if ($ticketId <= 0 || $statusFromPath === '' || $usernameFromPath === '') {
        apiRespond(400, ['success' => false, 'error' => 'invalid_path_parameters']);
    }

    $payload = apiReadJsonBody();
    if ($payload === null) {
        apiRespond(400, ['success' => false, 'error' => 'invalid_json']);
    }

    $ticketNumber = trim((string)($payload['ticket'] ?? ''));
    $status = trim((string)($payload['status'] ?? $statusFromPath));
    $timestamp = trim((string)($payload['timestamp'] ?? ''));
    $username = trim((string)($payload['user'] ?? $usernameFromPath));

    $mappedStatus = mapExternalTicketStatus($status);
    if ($mappedStatus === '') {
        apiRespond(400, ['success' => false, 'error' => 'unsupported_status', 'received_status' => $status]);
    }

    if ($timestamp === '') {
        $timestamp = (new DateTime('now', new DateTimeZone(APP_TIMEZONE)))->format('Y-m-d H:i:s');
    } else {
        try {
            $timestamp = (new DateTime($timestamp))->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            apiRespond(400, ['success' => false, 'error' => 'invalid_timestamp']);
        }
    }

    $ticketStmt = $pdo->prepare('SELECT ticket_id, queue_number, current_status FROM tickets WHERE ticket_id = ? LIMIT 1');
    $ticketStmt->execute([$ticketId]);
    $ticket = $ticketStmt->fetch(PDO::FETCH_ASSOC);
    if (!$ticket) {
        apiRespond(404, ['success' => false, 'error' => 'ticket_not_found']);
    }

    if ($ticketNumber !== '' && trim((string)($ticket['queue_number'] ?? '')) !== '' && $ticketNumber !== trim((string)$ticket['queue_number'])) {
        apiRespond(409, ['success' => false, 'error' => 'ticket_number_mismatch']);
    }

    $userId = null;
    $userStmt = $pdo->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
    $userStmt->execute([$username]);
    $foundUserId = (int)($userStmt->fetchColumn() ?: 0);
    if ($foundUserId > 0) {
        $userId = $foundUserId;
    }

    applyMappedStatusUpdate($pdo, $ticketId, $mappedStatus, $timestamp);

    // Capture any extra fields from payload as external details
    $externalDetails = [];
    foreach ($payload as $key => $value) {
        if (!in_array($key, ['ticket', 'status', 'timestamp', 'user'], true)) {
            $externalDetails[$key] = $value;
        }
    }
    
    if (!empty($externalDetails)) {
        $detailsJson = json_encode($externalDetails, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($detailsJson !== false) {
            $updateStmt = $pdo->prepare('UPDATE tickets SET external_details = ? WHERE ticket_id = ?');
            $updateStmt->execute([$detailsJson, $ticketId]);
        }
    }

    $notes = 'External status update by ' . $username . ' at ' . $timestamp . ' | Raw status: ' . $status;
    $logStmt = $pdo->prepare("INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes, created_at) VALUES (?, 'External Status Update', ?, ?, ?, ?, ?)");
    $logStmt->execute([
        $ticketId,
        (string)($ticket['current_status'] ?? ''),
        $mappedStatus,
        $userId,
        $notes,
        $timestamp,
    ]);

    apiRespond(200, [
        'success' => true,
        'ticket_id' => $ticketId,
        'ticket_number' => (string)($ticket['queue_number'] ?? ''),
        'status' => $mappedStatus,
        'performed_by' => $username,
        'timestamp' => $timestamp,
    ]);
}

apiRespond(404, ['success' => false, 'error' => 'not_found']);
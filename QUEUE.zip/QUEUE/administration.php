﻿<?php
require_once 'config.php';
session_start();

// Prevent caching of feedback status and page data
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');

authRequireRoles(['quality', 'admin']);

/**
 * Convert a local phone number plus country code into WhatsApp-compatible digits.
 */
function formatWhatsAppNumber($mobile, $countryCode = '+961') {
    $mobileDigits = preg_replace('/\D+/', '', (string)$mobile);
    $countryDigits = preg_replace('/\D+/', '', (string)$countryCode);

    if ($mobileDigits === '') {
        return '';
    }

    if ($countryDigits !== '' && strpos($mobileDigits, $countryDigits) === 0) {
        return $mobileDigits;
    }

    return $countryDigits . $mobileDigits;
}

function interpretWhatsAppApiResponse($httpCode, $responseBody) {
    $httpCode = (int)$httpCode;
    $raw = trim((string)$responseBody);
    $normalized = strtolower(strip_tags($raw));

    $providerCode = null;
    if ($raw !== '') {
        $parts = explode(';', strip_tags($raw));
        if (count($parts) >= 3) {
            $candidate = trim($parts[2]);
            if ($candidate !== '' && preg_match('/^-?\d+$/', $candidate) === 1) {
                $providerCode = (int)$candidate;
            }
        }
    }

    $isHttpOk = ($httpCode >= 200 && $httpCode < 300);
    $hasMediaErrorHint = (
        strpos($normalized, 'media') !== false ||
        strpos($normalized, 'pdf') !== false ||
        strpos($normalized, 'url') !== false ||
        strpos($normalized, 'file') !== false ||
        strpos($normalized, 'not found') !== false
    );
    $hasGenericErrorHint = (
        strpos($normalized, 'error') !== false ||
        strpos($normalized, 'failed') !== false ||
        strpos($normalized, 'invalid') !== false ||
        strpos($normalized, 'denied') !== false ||
        strpos($normalized, 'rejected') !== false ||
        strpos($normalized, 'unable') !== false
    );

    $success = $isHttpOk;
    $errorType = '';

    if (!$isHttpOk) {
        $success = false;
        $errorType = 'http_error';
    } elseif ($providerCode !== null && $providerCode !== 0) {
        $success = false;
        $errorType = $hasMediaErrorHint ? 'media_error' : 'provider_error';
    } elseif ($hasMediaErrorHint) {
        $success = false;
        $errorType = 'media_error';
    } elseif ($hasGenericErrorHint) {
        $success = false;
        $errorType = 'provider_error';
    }

    return [
        'success' => $success,
        'provider_code' => $providerCode,
        'error_type' => $errorType,
    ];
}

function sendWhatsAppTemplateWithVariables($phoneNumber, $template, $variables) {
    if ($phoneNumber === '' || trim((string)$variables) === '') {
        return [
            'success' => false,
            'http_code' => 0,
            'response' => 'Missing phone number or template variables.',
            'request_url' => '',
            'provider_code' => null,
            'error_type' => 'validation_error',
        ];
    }

    $sendResult = sendWhatsAppTemplateRequest(
        preg_replace('/\D+/', '', $phoneNumber),
        $template,
        (string)$variables
    );

    if (!empty($sendResult['curl_error'])) {
        return [
            'success' => false,
            'http_code' => (int)($sendResult['http_code'] ?? 0),
            'response' => (string)$sendResult['curl_error'],
            'request_url' => (string)($sendResult['request_url'] ?? ''),
            'provider_code' => null,
            'error_type' => 'network_error',
        ];
    }

    $httpCode = (int)($sendResult['http_code'] ?? 0);
    $responseText = (string)($sendResult['response'] ?? '');
    $interpreted = interpretWhatsAppApiResponse($httpCode, $responseText);

    return [
        'success' => (bool)$interpreted['success'],
        'http_code' => $httpCode,
        'response' => $responseText,
        'request_url' => (string)($sendResult['request_url'] ?? ''),
        'provider_code' => $interpreted['provider_code'],
        'error_type' => $interpreted['error_type'],
    ];
}

// Result API integration removed: results view and related remote calls disabled.

// Result API helpers removed.

function buildFilterUrl($overrides = []) {
    $params = array_merge($_GET, $overrides);
    foreach ($params as $key => $value) {
        if ($value === null || $value === '') {
            unset($params[$key]);
        }
    }
    return 'administration.php' . (!empty($params) ? ('?' . http_build_query($params)) : '');
}

function parseRangeString($rangeInput) {
    $rangeInput = trim((string)$rangeInput);
    if ($rangeInput === '') {
        return [null, null];
    }

    $parts = preg_split('/\s+to\s+/i', $rangeInput);
    $rawStart = trim((string)($parts[0] ?? ''));
    $rawEnd = trim((string)($parts[1] ?? $rawStart));

    $start = DateTime::createFromFormat('Y-m-d', $rawStart);
    $end = DateTime::createFromFormat('Y-m-d', $rawEnd);

    if (!$start || !$end) {
        return [null, null];
    }

    $startDate = $start->format('Y-m-d');
    $endDate = $end->format('Y-m-d');

    if ($startDate > $endDate) {
        [$startDate, $endDate] = [$endDate, $startDate];
    }

    return [$startDate, $endDate];
}

$period = $_GET['period'] ?? 'today';
$allowedPeriods = ['today', 'yesterday', 'last_week', 'custom'];
if (!in_array($period, $allowedPeriods, true)) {
    $period = 'today';
}

$today = new DateTime('today');
$startDate = $today->format('Y-m-d');
$endDate = $today->format('Y-m-d');

if ($period === 'yesterday') {
    $yesterday = (clone $today)->modify('-1 day');
    $startDate = $yesterday->format('Y-m-d');
    $endDate = $yesterday->format('Y-m-d');
} elseif ($period === 'last_week') {
    $startDate = (clone $today)->modify('-6 days')->format('Y-m-d');
    $endDate = $today->format('Y-m-d');
}

$rangeInput = trim((string)($_GET['date_range'] ?? ''));
if ($rangeInput !== '') {
    [$rangeStart, $rangeEnd] = parseRangeString($rangeInput);
    if ($rangeStart && $rangeEnd) {
        $startDate = $rangeStart;
        $endDate = $rangeEnd;
        $period = 'custom';
    }
}

$startDateTime = $startDate . ' 00:00:00';
$endDateTimeExclusive = date('Y-m-d 00:00:00', strtotime($endDate . ' +1 day'));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_feedback_ticket'])) {
    $redirectPeriod = $_POST['period'] ?? $period;
    $redirectDateRange = trim((string)($_POST['date_range'] ?? ($startDate . ' to ' . $endDate)));

    if (!in_array($redirectPeriod, $allowedPeriods, true)) {
        $redirectPeriod = $period;
    }

    $redirectParams = [
        'period' => $redirectPeriod,
        'date_range' => $redirectDateRange,
    ];
    $redirectUrl = 'administration.php?' . http_build_query($redirectParams);

    $patientId = isset($_POST['patient_id']) ? (int)$_POST['patient_id'] : 0;
    $ticketId = isset($_POST['ticket_id']) ? (int)$_POST['ticket_id'] : 0;
    if ($patientId <= 0 || $ticketId <= 0) {
        $_SESSION['admin_notice'] = ['type' => 'error', 'text' => 'Invalid patient/ticket selected for feedback sending.'];
        header('Location: ' . $redirectUrl);
        exit;
    }

    $patientRow = executeAndFetchOne($pdo,
        "SELECT p.patient_id, p.patient_name, p.country_code, p.mobile, p.care_country_code, p.care_mobile
         FROM patients p
         WHERE p.patient_id = ?",
        [$patientId]
    );
    if (!$patientRow) {
        $_SESSION['admin_notice'] = ['type' => 'error', 'text' => 'Patient not found for feedback sending.'];
        header('Location: ' . $redirectUrl);
        exit;
    }

    $ticketCheckRow = executeAndFetchOne($pdo, "SELECT ticket_id FROM tickets WHERE ticket_id = ? AND patient_id = ? LIMIT 1", [$ticketId, $patientId]);
    $verifiedTicketId = (int)($ticketCheckRow['ticket_id'] ?? 0);
    if ($verifiedTicketId <= 0) {
        $_SESSION['admin_notice'] = ['type' => 'error', 'text' => 'Feedback ticket does not belong to this patient.'];
        header('Location: ' . $redirectUrl);
        exit;
    }

    $countryCode = $patientRow['care_country_code'] ?: ($patientRow['country_code'] ?: '+961');
    $mobile = $patientRow['care_mobile'] ?: $patientRow['mobile'];
    $phone = formatWhatsAppNumber($mobile, $countryCode);
    if ($phone === '') {
        $_SESSION['admin_notice'] = ['type' => 'error', 'text' => 'Cannot send feedback: no valid phone number.'];
        header('Location: ' . $redirectUrl);
        exit;
    }

    $feedbackLink = FEEDBACK_TALLY_FORM_URL;
    // $feedbackLink = buildFeedbackAccessUrl($verifiedTicketId, $pdo);
    // Token-based feedback links are currently disabled.

    $sendResult = sendWhatsAppTemplateWithVariables($phone, 'feedback', $feedbackLink);
    $isSuccess = !empty($sendResult['success']);

    // Token and fill tracking are currently disabled for direct feedback link sends.
    // $upsertStmt = $pdo->prepare(
    //     "INSERT INTO feedback_tickets (ticket_id, feedback_sent, feedback_filled, fill_timestamp, tally_id)
    //      VALUES (?, ?, 0, NULL, NULL)
    //      ON DUPLICATE KEY UPDATE feedback_sent = VALUES(feedback_sent)"
    // );
    executeUpdate($pdo,
        "INSERT INTO feedback_tickets (ticket_id, feedback_sent)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE feedback_sent = VALUES(feedback_sent)",
        [$verifiedTicketId, $isSuccess ? 1 : 0]
    );

    executeUpdate($pdo,
        "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes)
         VALUES (?, ?, NULL, NULL, ?, ?)",
        [$verifiedTicketId, $logAction, authCurrentUserId() ?: null, $logNotes]
    );

    if ($isSuccess) {
        $_SESSION['admin_notice'] = ['type' => 'success', 'text' => 'Feedback link sent successfully to ' . $patientRow['patient_name'] . '.'];
    } else {
        $_SESSION['admin_notice'] = ['type' => 'error', 'text' => 'Failed to send feedback link to ' . $patientRow['patient_name'] . '.'];
    }

    header('Location: ' . $redirectUrl);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_feedback_all'])) {
    $redirectPeriod = $_POST['period'] ?? $period;
    $redirectDateRange = trim((string)($_POST['date_range'] ?? ($startDate . ' to ' . $endDate)));
    if (!in_array($redirectPeriod, $allowedPeriods, true)) {
        $redirectPeriod = $period;
    }
    $redirectParams = ['period' => $redirectPeriod, 'date_range' => $redirectDateRange];
    $redirectUrl = 'administration.php?' . http_build_query($redirectParams);

    $allPatients = executeAndFetch($pdo, "
        SELECT p.patient_id, p.patient_name, p.country_code, p.mobile, p.care_country_code, p.care_mobile,
               DATE(t.arrival_timestamp) AS visit_date,
               MAX(t.ticket_id) AS latest_ticket_id
        FROM tickets t
        INNER JOIN patients p ON p.patient_id = t.patient_id
        WHERE t.arrival_timestamp >= :start_date
          AND t.arrival_timestamp < :end_date
          AND t.current_status <> 'Canceled'
        GROUP BY p.patient_id, p.patient_name, p.country_code, p.mobile, p.care_country_code, p.care_mobile, visit_date
    ", [':start_date' => $startDateTime, ':end_date' => $endDateTimeExclusive]);

    // Build feedback status map for the latest ticket per patient-day (feedback is per patient-day, not per ticket).
    $allTicketIds = array_values(array_filter(array_map(fn($r) => (int)($r['latest_ticket_id'] ?? 0), $allPatients), fn($id) => $id > 0));
    $allFeedbackMap = [];
    if (!empty($allTicketIds)) {
        $ph = implode(',', array_fill(0, count($allTicketIds), '?'));
        
        // Ensure records exist for latest tickets only (initialize with feedback_sent = 0 if not present)
        try {
            foreach ($allTicketIds as $tid) {
                executeUpdate($pdo,
                    "INSERT IGNORE INTO feedback_tickets (ticket_id, feedback_sent)
                     VALUES (?, 0)",
                    [$tid]
                );
            }
        } catch (Exception $e) {
            // Silent fail - proceed with query anyway
        }
        
        $allFeedbackResults = executeAndFetch($pdo,
            "SELECT ticket_id, feedback_sent
             FROM feedback_tickets
             WHERE ticket_id IN ($ph)",
            $allTicketIds
        );
        foreach ($allFeedbackResults as $fsRow) {
            $ticketId = (int)($fsRow['ticket_id'] ?? 0);
            if ($ticketId <= 0) {
                continue;
            }
            $allFeedbackMap[$ticketId] = [
                'feedback_sent' => (int)($fsRow['feedback_sent'] ?? 0),
            ];
        }
    }

    $sentCount = 0;
    $failCount = 0;
    $skipCount = 0;

    foreach ($allPatients as $ap) {
        $apId = (int)($ap['patient_id'] ?? 0);
        $apTicketId = (int)($ap['latest_ticket_id'] ?? 0);
        $apCountryCode = $ap['care_country_code'] ?: ($ap['country_code'] ?: '+961');
        $apMobile = $ap['care_mobile'] ?: $ap['mobile'];
        $apPhone = formatWhatsAppNumber($apMobile, $apCountryCode);

        $apFeedback = $allFeedbackMap[$apTicketId] ?? ['feedback_sent' => 0];
        $apCanSend = ($apTicketId > 0)
            && ($apPhone !== '')
            && ((int)$apFeedback['feedback_sent'] !== 1);

        if (!$apCanSend) {
            $skipCount++;
            continue;
        }

        // Verify ticket ownership before sending.
        $ownRow = executeAndFetchOne($pdo, "SELECT ticket_id FROM tickets WHERE ticket_id = ? AND patient_id = ? LIMIT 1", [$apTicketId, $apId]);
        $verifiedId = (int)($ownRow['ticket_id'] ?? 0);
        if ($verifiedId <= 0) {
            $skipCount++;
            continue;
        }

        $feedbackLink = FEEDBACK_TALLY_FORM_URL;
        // $feedbackLink = buildFeedbackAccessUrl($verifiedId, $pdo);
        // Token-based feedback links are currently disabled.

        $sendResult = sendWhatsAppTemplateWithVariables($apPhone, 'feedback', $feedbackLink);
        $isSuccess = !empty($sendResult['success']);

        // Token and fill tracking are currently disabled for direct feedback link sends.
        // $upsertStmt = $pdo->prepare(
        //     "INSERT INTO feedback_tickets (ticket_id, feedback_sent, feedback_filled, fill_timestamp, tally_id)
        //      VALUES (?, ?, 0, NULL, NULL)
        //      ON DUPLICATE KEY UPDATE feedback_sent = VALUES(feedback_sent)"
        // );
        executeUpdate($pdo,
            "INSERT INTO feedback_tickets (ticket_id, feedback_sent)
             VALUES (?, ?)
             ON DUPLICATE KEY UPDATE feedback_sent = VALUES(feedback_sent)",
            [$verifiedId, $isSuccess ? 1 : 0]
        );

        $logAction = $isSuccess ? 'Feedback WhatsApp Sent' : 'Feedback WhatsApp Failed';
        $logNotes = 'bulk=1 | Template=feedback | link=' . $feedbackLink;
        if (!$isSuccess) {
            $logNotes .= ' | error=' . trim((string)($sendResult['response'] ?? 'send_error'));
        }
        executeUpdate($pdo,
            "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, ?, NULL, NULL, ?, ?)",
            [$verifiedId, $logAction, authCurrentUserId() ?: null, $logNotes]
        );

        if ($isSuccess) {
            $sentCount++;
        } else {
            $failCount++;
        }
    }

    $noticeText = "Bulk feedback: {$sentCount} sent, {$failCount} failed, {$skipCount} skipped (already sent or no phone).";
    $noticeType = ($failCount > 0 && $sentCount === 0) ? 'error' : (($failCount > 0) ? 'warning' : 'success');
    $_SESSION['admin_notice'] = ['type' => $noticeType, 'text' => $noticeText];
    header('Location: ' . $redirectUrl);
    exit;
}

$query = "
    SELECT
        p.patient_id,
        DATE(t.arrival_timestamp) AS visit_date,
        p.mrn,
        p.patient_name,
        p.country_code,
        p.mobile,
        p.care_country_code,
        p.care_mobile,
        COUNT(t.ticket_id) AS ticket_count,
        MIN(t.arrival_timestamp) AS first_arrival,
        MAX(t.arrival_timestamp) AS last_arrival,
        MAX(t.ticket_id) AS latest_ticket_id,
        GROUP_CONCAT(DISTINCT t.queue_number ORDER BY t.queue_number SEPARATOR ', ') AS queue_numbers
    FROM tickets t
    INNER JOIN patients p ON p.patient_id = t.patient_id
    WHERE t.arrival_timestamp >= :start_date
      AND t.arrival_timestamp < :end_date
      AND t.current_status <> 'Canceled'
    GROUP BY
        p.patient_id,
        visit_date,
        p.mrn,
        p.patient_name,
        p.country_code,
        p.mobile,
        p.care_country_code,
        p.care_mobile
";

$query .= " ORDER BY last_arrival DESC, p.patient_name ASC";

$patients = executeAndFetch($pdo, $query, [
    ':start_date' => $startDateTime,
    ':end_date' => $endDateTimeExclusive,
]);

// Build feedback status map for latest tickets per patient-day (feedback is per patient-day, not per ticket)
$ticketFeedbackStatusMap = [];
if (!empty($patients)) {
    $ticketIds = array_values(array_unique(array_map(static function ($row) {
        return (int)($row['latest_ticket_id'] ?? 0);
    }, $patients)));
    $ticketIds = array_values(array_filter($ticketIds, static function ($id) {
        return $id > 0;
    }));

    if (!empty($ticketIds)) {
        $placeholders = implode(',', array_fill(0, count($ticketIds), '?'));
        
        // Ensure records exist for latest tickets only (initialize with feedback_sent = 0 if not present)
        try {
            foreach ($ticketIds as $tid) {
                executeUpdate($pdo,
                    "INSERT IGNORE INTO feedback_tickets (ticket_id, feedback_sent)
                     VALUES (?, 0)",
                    [$tid]
                );
            }
        } catch (Exception $e) {
            // Silent fail - proceed with query anyway
        }
        
        $feedbackResults = executeAndFetch($pdo,
            "SELECT ticket_id, feedback_sent
             FROM feedback_tickets
             WHERE ticket_id IN ($placeholders)",
            $ticketIds
        );
        foreach ($feedbackResults as $feedbackRow) {
            $ticketId = (int)($feedbackRow['ticket_id'] ?? 0);
            if ($ticketId <= 0) {
                continue;
            }
            $ticketFeedbackStatusMap[$ticketId] = [
                'feedback_sent' => (int)($feedbackRow['feedback_sent'] ?? 0),
            ];
        }
    }
}

$patientTicketsMap = [];
if (!empty($patients)) {
    $patientIds = array_values(array_unique(array_map(static function ($row) {
        return (int)($row['patient_id'] ?? 0);
    }, $patients)));
    $patientIds = array_values(array_filter($patientIds, static function ($id) {
        return $id > 0;
    }));

    if (!empty($patientIds)) {
        $placeholders = implode(',', array_fill(0, count($patientIds), '?'));
        $ticketSql =
            "SELECT t.ticket_id, t.patient_id, t.queue_number, DATE(t.arrival_timestamp) AS visit_date, t.arrival_timestamp
             FROM tickets t
             WHERE t.patient_id IN ($placeholders)
               AND t.arrival_timestamp >= ?
               AND t.arrival_timestamp < ?
               AND t.current_status <> 'Canceled'
             ORDER BY t.arrival_timestamp DESC, t.ticket_id DESC";
        $ticketParams = array_merge($patientIds, [$startDateTime, $endDateTimeExclusive]);
        $ticketResults = executeAndFetch($pdo, $ticketSql, $ticketParams);

        foreach ($ticketResults as $ticketRow) {
            $pid = (int)($ticketRow['patient_id'] ?? 0);
            if ($pid <= 0) {
                continue;
            }
            if (!isset($patientTicketsMap[$pid])) {
                $patientTicketsMap[$pid] = [];
            }
            $patientTicketsMap[$pid][] = $ticketRow;
        }
    }
}

$patientResultEntriesMap = [];
$patientResultErrorsMap = [];
// Results lookup removed; administration page shows only feedback now.

$totalPatients = count($patients);
$totalTickets = 0;
foreach ($patients as $row) {
    $totalTickets += (int)$row['ticket_count'];
}

$sendableCount = 0;
foreach ($patients as $row) {
    $feedbackTicketId = (int)($row['latest_ticket_id'] ?? 0);
    $displayCountryCode = $row['care_country_code'] ?: ($row['country_code'] ?: '+961');
    $displayMobile = $row['care_mobile'] ?: $row['mobile'];
    $feedbackStatus = $ticketFeedbackStatusMap[$feedbackTicketId] ?? [
        'feedback_sent' => 0,
    ];

    $canSendFeedback = ($feedbackTicketId > 0)
        && (formatWhatsAppNumber($displayMobile, $displayCountryCode) !== '')
        && ((int)$feedbackStatus['feedback_sent'] !== 1);

    if ($canSendFeedback) {
        $sendableCount++;
    }
}

if (isset($_GET['export']) && $_GET['export'] === 'patients') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="administration_patients_' . $startDate . '_to_' . $endDate . '.csv"');

    $output = fopen('php://output', 'w');
    fwrite($output, "\xEF\xBB\xBF");

    fputcsv($output, ['MRN', 'Patient Name', 'Contact Number', 'Ticket Number', 'Arrival Time', 'Completion Time', 'Department', 'Machine']);

    // Fetch all tickets with department and machine information
    $ticketQuery = "
        SELECT 
            p.mrn,
            p.patient_name,
            p.country_code,
            p.mobile,
            p.care_country_code,
            p.care_mobile,
            t.queue_number,
            t.arrival_timestamp,
            t.closing_timestamp,
            t.img,
            t.lab,
            t.dp2,
            t.cl,
            t.imaging_machine
        FROM tickets t
        INNER JOIN patients p ON p.patient_id = t.patient_id
        WHERE t.arrival_timestamp >= :start_date
          AND t.arrival_timestamp < :end_date
          AND t.current_status <> 'Canceled'
        ORDER BY p.patient_name ASC, t.arrival_timestamp ASC
    ";

    $ticketExportResults = executeAndFetch($pdo, $ticketQuery, [
        ':start_date' => $startDateTime,
        ':end_date' => $endDateTimeExclusive,
    ]);

    foreach ($ticketExportResults as $ticket) {
        $countryCode = $ticket['care_country_code'] ?: ($ticket['country_code'] ?: '+961');
        $mobile = $ticket['care_mobile'] ?: $ticket['mobile'];
        $contactNumber = trim($countryCode . ' ' . $mobile);
        if ($contactNumber === '') {
            $contactNumber = 'N/A';
        }

        // Determine departments
        $departments = [];
        if ((int)$ticket['img'] === 1) {
            $departments[] = 'Imaging';
        }
        if ((int)$ticket['lab'] === 1) {
            $departments[] = 'Lab';
        }
        if ((int)$ticket['dp2'] === 1) {
            $departments[] = 'DP2';
        }
        if ((int)$ticket['cl'] === 1) {
            $departments[] = 'Clinics';
        }
        $departmentList = !empty($departments) ? implode(', ', $departments) : 'N/A';

        // Get machine information for imaging department
        $machineInfo = '';
        if ((int)$ticket['img'] === 1 && !empty($ticket['imaging_machine'])) {
            $machineInfo = (string)$ticket['imaging_machine'];
        } elseif ((int)$ticket['img'] === 1) {
            $machineInfo = 'Not Specified';
        }

        // Format timestamps
        $arrivalTime = !empty($ticket['arrival_timestamp']) ? date('Y-m-d H:i:s', strtotime($ticket['arrival_timestamp'])) : 'N/A';
        $completionTime = !empty($ticket['closing_timestamp']) ? date('Y-m-d H:i:s', strtotime($ticket['closing_timestamp'])) : 'N/A';

        fputcsv($output, [
            $ticket['mrn'] ?: 'N/A',
            $ticket['patient_name'],
            $contactNumber,
            $ticket['queue_number'],
            $arrivalTime,
            $completionTime,
            $departmentList,
            $machineInfo,
        ]);
    }

    fclose($output);
    exit;
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration | Patient Feedback</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="statistics.css">
    <style>
        :root {
            --bg: #f5f7fa;
            --surface: #ffffff;
            --surface-soft: #f8f9fb;
            --text: #2c3e50;
            --muted: #6b7c93;
            --primary: #2f80c2;
            --primary-strong: #24679d;
            --accent: #f0f3f7;
            --feedback: #607d8b;
            --border: #dde5ed;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text);
            background: var(--bg);
        }

        .wrap {
            max-width: 1250px;
            margin: 0 auto;
            padding: 22px;
        }

        .header {
            background: #fff;
            color: var(--text);
            border: 1px solid var(--border);
            border-left: 4px solid var(--primary);
            border-radius: 12px;
            padding: 18px 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .header h1 {
            margin: 0 0 6px;
            font-size: clamp(1.2rem, 2.4vw, 1.95rem);
            letter-spacing: 0.2px;
        }

        .header p {
            margin: 0;
            color: var(--muted);
            opacity: 1;
        }

        .panel {
            margin-top: 18px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .filter-row {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
        }

        .preset-link {
            text-decoration: none;
            color: var(--primary-strong);
            border: 1px solid #cdd9e5;
            background: #f7fbff;
            border-radius: 8px;
            padding: 8px 12px;
            font-weight: 600;
            font-size: 0.92rem;
        }

        .preset-link.active {
            color: #fff;
            background: var(--primary);
            border-color: var(--primary);
        }

        .filter-form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
            flex: 1;
        }

        .date-input {
            min-width: 220px;
            padding: 10px 12px;
            border: 1px solid #cad5e1;
            border-radius: 8px;
            font-size: 0.95rem;
            background: #fff;
        }

        .btn {
            border: 0;
            border-radius: 8px;
            padding: 10px 14px;
            font-weight: 700;
            color: #fff;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            white-space: nowrap;
        }

        .btn.apply {
            background: var(--primary);
        }

        .btn.clear {
            background: #6c7a89;
        }

        .stats {
            margin-top: 12px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        .stat {
            background: var(--surface-soft);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 10px 12px;
            min-width: 160px;
        }

        .stat strong {
            display: block;
            font-size: 1.1rem;
        }

        .cards {
            margin-top: 16px;
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        .patient-card {
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            padding: 14px;
        }

        .patient-header {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #d8e2eb;
        }

        .patient-title {
            display: flex;
            flex-direction: column;
            gap: 3px;
        }

        .patient-meta {
            color: var(--muted);
            font-size: 0.9rem;
        }

        .card-sections {
            margin-top: 12px;
            display: grid;
            /* Single-column layout: results view removed, keep feedback centered */
            grid-template-columns: 1fr;
            gap: 12px;
        }

        .card-section {
            background: var(--surface-soft);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 10px;
        }

        .card-section h3 {
            margin: 0 0 10px;
            font-size: 0.95rem;
            color: #2d4358;
        }

        .section-lines {
            display: flex;
            flex-direction: column;
            gap: 6px;
            font-size: 0.9rem;
        }

        .actions {
            margin-top: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .actions form {
            margin: 0;
        }

        .results-list {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .result-item {
            background: #fff;
            border: 1px solid #dce6ef;
            border-radius: 8px;
            padding: 8px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
            justify-content: space-between;
        }

        .result-item-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            color: #3e5367;
            font-size: 0.88rem;
        }

        .result-empty {
            color: var(--muted);
            font-size: 0.88rem;
        }

        .timeline-link {
            color: #0a63b8;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
            border: 0;
            background: transparent;
            padding: 0;
        }

        .timeline-link:hover {
            text-decoration: underline;
        }

        .ticket-links {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }

        .ticket-links .timeline-link {
            background: #eef6ff;
            border: 1px solid #cddff4;
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 0.82rem;
        }

        .status-pill {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 3px 8px;
            font-size: 0.78rem;
            font-weight: 700;
            border: 1px solid transparent;
        }

        .status-pill.sent {
            background: #e8f8ef;
            border-color: #bde5cb;
            color: #11643a;
        }

        .status-pill.pending {
            background: #fdf5e8;
            border-color: #f2d7a9;
            color: #8b5a0c;
        }

        .notice {
            margin: 10px 0 0;
            padding: 10px 12px;
            border-radius: 10px;
            font-size: 0.9rem;
            border: 1px solid transparent;
        }

        .notice.success {
            background: #e8f8ef;
            border-color: #b6e3c8;
            color: #16653a;
        }

        .notice.error {
            background: #fdecea;
            border-color: #f2b7af;
            color: #8f2214;
        }

        .btn.feedback { background: #1f9d55; }

        .btn.disabled {
            background: #c4ccc9;
            pointer-events: none;
            color: #f8fbfa;
        }

        .status-text-sent { color: #11643a; font-weight: 700; }
        .status-text-pending { color: #8b5a0c; font-weight: 700; }
        .status-text-muted { color: #6f7f88; font-weight: 700; }

        .no-data {
            margin-top: 16px;
            padding: 20px;
            text-align: center;
            border-radius: 12px;
            border: 1px dashed #b8cec6;
            background: #f8fcfa;
            color: var(--muted);
        }

        @media (max-width: 900px) {
            .wrap {
                padding: 12px;
            }

            .panel {
                padding: 12px;
            }

            .card-sections {
                grid-template-columns: 1fr;
            }

            .date-input {
                min-width: 180px;
                width: 100%;
            }

            .filter-form .btn.apply,
            .filter-form .btn.clear {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <div class="wrap">
        <div class="header">
            <h1>Patient Administration</h1>
            <p>Filter by period and send feedback.</p>
        </div>

        <?php if (isset($_SESSION['admin_notice']) && is_array($_SESSION['admin_notice'])): ?>
            <div class="notice <?php echo ($_SESSION['admin_notice']['type'] ?? '') === 'success' ? 'success' : 'error'; ?>">
                <?php echo h($_SESSION['admin_notice']['text'] ?? ''); ?>
            </div>
            <?php unset($_SESSION['admin_notice']); ?>
        <?php endif; ?>

        <div class="panel">
            <div class="filter-row">
                <a class="preset-link <?php echo $period === 'today' ? 'active' : ''; ?>" href="<?php echo h(buildFilterUrl(['period' => 'today', 'date_range' => null])); ?>">Today</a>
                <a class="preset-link <?php echo $period === 'yesterday' ? 'active' : ''; ?>" href="<?php echo h(buildFilterUrl(['period' => 'yesterday', 'date_range' => null])); ?>">Yesterday</a>
                <a class="preset-link <?php echo $period === 'last_week' ? 'active' : ''; ?>" href="<?php echo h(buildFilterUrl(['period' => 'last_week', 'date_range' => null])); ?>">Last Week</a>

                <form method="GET" class="filter-form">
                    <input type="hidden" name="period" value="custom">
                    <input
                        class="date-input"
                        id="dateRange"
                        name="date_range"
                        type="text"
                        value="<?php echo h($startDate . ' to ' . $endDate); ?>"
                        placeholder="Select date range"
                    >
                    <button type="submit" class="btn apply">Apply</button>
                    <a class="btn clear" href="administration.php">Clear</a>
                </form>
            </div>

            <div class="stats">
                <div class="stat">
                    <strong><?php echo h($totalPatients); ?></strong>
                    <span>Patient-Day Groups</span>
                </div>
                <div class="stat">
                    <strong><?php echo h($totalTickets); ?></strong>
                    <span>Total Tickets</span>
                </div>
                <div class="stat">
                    <strong><?php echo h($startDate); ?></strong>
                    <span>Start Date</span>
                </div>
                <div class="stat">
                    <strong><?php echo h($endDate); ?></strong>
                    <span>End Date</span>
                </div>
                <div class="stat">
                    <strong><?php echo h($sendableCount); ?></strong>
                    <span>Ready to Send</span>
                </div>
                <div class="stat" style="display:flex;align-items:center;justify-content:center;">
                    <form
                        method="POST"
                        action="administration.php"
                        style="width:100%;"
                        onsubmit="return confirm('Send feedback to <?php echo h((string)$sendableCount); ?> eligible patient-day groups in this view?');"
                    >
                        <input type="hidden" name="send_feedback_all" value="1">
                        <input type="hidden" name="period" value="<?php echo h($period); ?>">
                        <input type="hidden" name="date_range" value="<?php echo h($startDate . ' to ' . $endDate); ?>">
                        <button
                            type="submit"
                            class="btn feedback <?php echo $sendableCount > 0 ? '' : 'disabled'; ?>"
                            <?php echo $sendableCount > 0 ? '' : 'disabled'; ?>
                            style="width:100%;"
                        >Send Feedback to All</button>
                    </form>
                </div>
                <div class="stat" style="display:flex;align-items:center;justify-content:center;">
                    <a class="btn apply" href="<?php echo h(buildFilterUrl(['export' => 'patients'])); ?>" style="width:100%;">
                        Export CSV
                    </a>
                </div>
            </div>
        </div>

        <?php if (empty($patients)): ?>
            <div class="no-data">No patient tickets were found in this date range.</div>
        <?php else: ?>
            <div class="cards">
                <?php foreach ($patients as $patient): ?>
                    <?php
                        $patientId = (int)($patient['patient_id'] ?? 0);
                        $mrn = trim((string)($patient['mrn'] ?? ''));
                        $displayCountryCode = $patient['care_country_code'] ?: ($patient['country_code'] ?: '+961');
                        $displayMobile = $patient['care_mobile'] ?: $patient['mobile'];
                        $mobileLabel = trim($displayCountryCode . ' ' . $displayMobile);

                        $feedbackTemplateName = 'feedback';
                        $feedbackTemplateVariable = 'tally';
                        $feedbackTicketId = (int)($patient['latest_ticket_id'] ?? 0);
                        $feedbackStatus = $ticketFeedbackStatusMap[$feedbackTicketId] ?? [
                            'feedback_sent' => 0,
                        ];
                        $feedbackSentLabel = ((int)$feedbackStatus['feedback_sent'] === 1) ? 'Sent' : 'Not Sent';
                        $feedbackSentClass = ((int)$feedbackStatus['feedback_sent'] === 1) ? 'status-text-sent' : 'status-text-pending';

                        // Feedback 'filled' tracking is currently disabled in admin view.
                        // $feedbackFilledLabel = ((int)$feedbackStatus['feedback_filled'] === 1) ? 'Filled' : 'Not Filled';
                        // $feedbackFilledClass = ((int)$feedbackStatus['feedback_filled'] === 1) ? 'status-text-sent' : 'status-text-muted';

                        $hasValidPhone = ($feedbackTicketId > 0)
                            && (formatWhatsAppNumber($displayMobile, $displayCountryCode) !== '');
                        $buttonLabel = ((int)$feedbackStatus['feedback_sent'] === 1) ? 'RESEND' : 'Send Feedback';
                        $buttonDisabled = !$hasValidPhone;

                        $resultEntries = $patientResultEntriesMap[$patientId] ?? [];
                        $resultError = trim((string)($patientResultErrorsMap[$patientId] ?? ''));
                        $rawTimelineTickets = $patientTicketsMap[$patientId] ?? [];
                        $timelineTickets = [];
                        $timelineSeen = [];
                        foreach ($rawTimelineTickets as $ticketRow) {
                            $queueNumber = trim((string)($ticketRow['queue_number'] ?? ''));
                            $arrivalTs = trim((string)($ticketRow['arrival_timestamp'] ?? ''));
                            $visitDate = trim((string)($ticketRow['visit_date'] ?? ''));
                            if ($queueNumber === '') {
                                continue;
                            }
                            $timelineKey = $queueNumber . '|' . $visitDate;
                            if (isset($timelineSeen[$timelineKey])) {
                                continue;
                            }
                            $timelineSeen[$timelineKey] = true;
                            $timelineTickets[] = [
                                'ticket_id' => (int)($ticketRow['ticket_id'] ?? 0),
                                'queue_number' => $queueNumber,
                                'arrival_timestamp' => $arrivalTs,
                            ];
                        }
                    ?>
                    <article class="patient-card">
                        <div class="patient-header">
                            <div class="patient-title">
                                <strong><?php echo h($patient['patient_name']); ?></strong>
                                <span class="patient-meta">MRN: <?php echo h($mrn !== '' ? $mrn : 'N/A'); ?></span>
                            </div>
                            <div class="patient-meta">
                                Mobile: <?php echo h($mobileLabel !== '' ? $mobileLabel : 'N/A'); ?> | Tickets: <?php echo h((string)((int)$patient['ticket_count'])); ?>
                            </div>
                        </div>

                        <div class="card-sections">
                            <section class="card-section">
                                <h3>Feedback</h3>
                                <div class="section-lines">
                                    <div>Sent: <span class="<?php echo h($feedbackSentClass); ?>"><?php echo h($feedbackSentLabel); ?></span></div>
                                    <?php // Filled tracking is currently disabled. ?>
                                    <!-- <div>Filled: <span class="<?php echo h($feedbackFilledClass); ?>"><?php echo h($feedbackFilledLabel); ?></span></div> -->
                                    <div>
                                        Tickets:
                                        <?php if (empty($timelineTickets)): ?>
                                            <span class="status-text-muted">N/A</span>
                                        <?php else: ?>
                                            <span class="ticket-links">
                                                <?php foreach ($timelineTickets as $timelineTicket): ?>
                                                    <button
                                                        type="button"
                                                        class="timeline-link"
                                                        data-patient-id="<?php echo h((string)$timelineTicket['ticket_id']); ?>"
                                                        data-patient-name="<?php echo h($patient['patient_name']); ?>"
                                                        data-queue-number="<?php echo h($timelineTicket['queue_number']); ?>"
                                                        data-mrn="<?php echo h($mrn); ?>"
                                                        data-arrival="<?php echo h($timelineTicket['arrival_timestamp']); ?>"
                                                    ><?php echo h($timelineTicket['queue_number']); ?></button>
                                                <?php endforeach; ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="actions">
                                    <form method="POST" action="administration.php">
                                        <input type="hidden" name="send_feedback_ticket" value="1">
                                        <input type="hidden" name="patient_id" value="<?php echo h($patientId); ?>">
                                        <input type="hidden" name="ticket_id" value="<?php echo h($feedbackTicketId); ?>">
                                        <input type="hidden" name="period" value="<?php echo h($period); ?>">
                                        <input type="hidden" name="date_range" value="<?php echo h($startDate . ' to ' . $endDate); ?>">
                                        <button
                                            type="submit"
                                            class="btn feedback <?php echo $buttonDisabled ? 'disabled' : ''; ?>"
                                            <?php echo $buttonDisabled ? 'disabled' : ''; ?>
                                            data-feedback-template="<?php echo h($feedbackTemplateName); ?>"
                                            data-feedback-variable="<?php echo h($feedbackTemplateVariable); ?>"
                                            title="Template: <?php echo h($feedbackTemplateName); ?> | Variable: <?php echo h($feedbackTemplateVariable); ?>"
                                        ><?php echo h($buttonLabel); ?></button>
                                    </form>
                                </div>
                            </section>

                            <!-- Results section removed — administration shows only Feedback -->
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <script src="statistics.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        flatpickr('#dateRange', {
            mode: 'range',
            dateFormat: 'Y-m-d',
            defaultDate: ['<?php echo h($startDate); ?>', '<?php echo h($endDate); ?>']
        });

        document.querySelectorAll('.timeline-link').forEach((button) => {
            button.addEventListener('click', () => {
                const patientId = button.getAttribute('data-patient-id') || '';
                const patientName = button.getAttribute('data-patient-name') || 'Patient';
                const queueNumber = button.getAttribute('data-queue-number') || '';
                const mrn = button.getAttribute('data-mrn') || '';
                const arrivalTs = button.getAttribute('data-arrival') || '';

                showPatientTimeline(patientId, patientName, mrn, queueNumber, arrivalTs);
            });
        });
    </script>
</body>
</html>



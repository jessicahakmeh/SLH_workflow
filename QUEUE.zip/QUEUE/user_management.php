<?php
require_once 'config.php';
session_start();
authRequireRoles(['admin']);

$roleOptions = authAllRoles();
$roleDescriptions = [
    'admin' => 'Full system access',
    'billing' => 'Billing and clinics access',
    'butler' => 'Butler and registration access',
    'imaging' => 'Imaging access',
    'laboratory' => 'Laboratory access',
    'quality' => 'Statistics and administration access',
];
$legacyRolePriority = [
    'butler' => 1,
    'billing' => 2,
    'laboratory' => 3,
    'imaging' => 4,
];

$message = '';
$error = '';
$adSearchTerm = '';
$adSearchResults = [];
$adSearchError = '';
$selectedUserId = (int)($_GET['user_id'] ?? $_POST['user_id'] ?? 0);
$adEnabled = defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED;

function userManagementLoadUsers($pdo) {
    $sql = "
        SELECT u.id, u.username, u.full_name, u.is_active, u.auth_source, u.ad_username, u.last_login_at,
               GROUP_CONCAT(ur.role_key ORDER BY ur.role_key SEPARATOR ',') AS role_keys
        FROM users u
        LEFT JOIN user_roles ur ON ur.user_id = u.id
        WHERE NOT (u.username = 'admin' AND u.auth_source = 'local' AND u.full_name = 'Default Admin User')
        GROUP BY u.id, u.username, u.full_name, u.is_active, u.auth_source, u.ad_username, u.last_login_at
        ORDER BY u.full_name ASC, u.username ASC
    ";
    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

function userManagementLoadUser($pdo, $userId) {
    $user = executeAndFetchOne($pdo, "SELECT id, username, full_name, is_active, auth_source, ad_username, last_login_at FROM users WHERE id = ? LIMIT 1", [(int)$userId]);
    if (!$user) {
        return null;
    }
    $user['roles'] = authGetUserRoles((int)$user['id']);
    return $user;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string)($_POST['form_action'] ?? 'save_user'));

    if ($action === 'save_user') {
        $userId = (int)($_POST['user_id'] ?? 0);
        $username = trim((string)($_POST['username'] ?? ''));
        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $authSource = $adEnabled ? 'ad' : strtolower(trim((string)($_POST['auth_source'] ?? 'local')));
        $adUsername = trim((string)($_POST['ad_username'] ?? ''));
        $password = $adEnabled ? '' : (string)($_POST['password'] ?? '');
        $confirmPassword = $adEnabled ? '' : (string)($_POST['confirm_password'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $roles = isset($_POST['roles']) && is_array($_POST['roles']) ? array_values(array_unique(array_map('strval', $_POST['roles']))) : [];
        $roles = array_values(array_filter($roles, static function ($role) use ($roleOptions) {
            return in_array($role, $roleOptions, true);
        }));

        if ($username === '') {
            $error = 'Username is required.';
        } elseif (!in_array($authSource, ['local', 'ad'], true)) {
            $error = 'Invalid auth source.';
        } elseif ($password !== $confirmPassword) {
            $error = 'Passwords do not match.';
        } elseif ($authSource === 'local' && $userId <= 0 && $password === '') {
            $error = 'Password is required for a new local user.';
        } else {
            if (!executeAndFetchOne($pdo, "SELECT id FROM users WHERE username = ? AND id <> ? LIMIT 1", [$username, $userId])) {
                // Username is available
            } else {
                $error = 'Username already exists.';
            }
        }

        if ($error === '') {
            $primaryRoleId = null;
            foreach ($roles as $roleKey) {
                if (isset($legacyRolePriority[$roleKey])) {
                    $primaryRoleId = $legacyRolePriority[$roleKey];
                    break;
                }
            }

            $pdo->beginTransaction();
            try {
                if ($userId > 0) {
                    if ($password !== '') {
                        executeUpdate($pdo, "UPDATE users SET username = ?, full_name = ?, is_active = ?, auth_source = ?, ad_username = ?, password_value = ?, password_hash = NULL, role_id = ?, updated_at = NOW() WHERE id = ?", [$username, $fullName, $isActive, $authSource, $adUsername !== '' ? $adUsername : null, base64_encode($password), $primaryRoleId, $userId]);
                    } else {
                        executeUpdate($pdo, "UPDATE users SET username = ?, full_name = ?, is_active = ?, auth_source = ?, ad_username = ?, role_id = ?, updated_at = NOW() WHERE id = ?", [$username, $fullName, $isActive, $authSource, $adUsername !== '' ? $adUsername : null, $primaryRoleId, $userId]);
                    }
                } else {
                    executeUpdate($pdo, "INSERT INTO users (username, full_name, is_active, auth_source, ad_username, password_value, password_hash, role_id, updated_at) VALUES (?, ?, ?, ?, ?, ?, NULL, ?, NOW())", [$username, $fullName, $isActive, $authSource, $adUsername !== '' ? $adUsername : null, $password !== '' ? base64_encode($password) : null, $primaryRoleId]);
                    $userId = (int)$pdo->lastInsertId();
                }

                executeUpdate($pdo, "DELETE FROM user_roles WHERE user_id = ?", [$userId]);
                
                foreach ($roles as $roleKey) {
                    executeUpdate($pdo, "INSERT INTO user_roles (user_id, role_key) VALUES (?, ?)", [$userId, $roleKey]);
                }

                $pdo->commit();
                authLogAction('manage_user_saved', ['target_user_id' => $userId, 'target_username' => $username, 'roles' => $roles, 'auth_source' => $authSource], 'user_management.php');
                if ($userId === authCurrentUserId()) {
                    authRefreshCurrentSessionUser($userId);
                }
                $message = 'User saved successfully. Form has been reset for the next entry.';
                $selectedUserId = 0;
                $adSearchTerm = '';
                $adSearchResults = [];
                $adSearchError = '';
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = 'Failed to save user: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'new_form') {
        $selectedUserId = 0;
    } elseif ($action === 'search_ad') {
        if (!$adEnabled) {
            $adSearchError = 'AD search is available only when AD mode is enabled.';
        } else {
            $adSearchTerm = trim((string)($_POST['ad_search_term'] ?? ''));
            if ($adSearchTerm === '') {
                $adSearchError = 'Enter a name, username, or email to search AD.';
            } else {
                $adSearchResults = authSearchActiveDirectoryUsers($adSearchTerm, 20, $searchError);
                if ($searchError !== '') {
                    $adSearchError = $searchError;
                } elseif (empty($adSearchResults)) {
                    $message = 'No AD users found for your search term.';
                }
            }
        }
    }
}

$users = userManagementLoadUsers($pdo);
$selectedUser = $selectedUserId > 0 ? userManagementLoadUser($pdo, $selectedUserId) : null;
if (!$selectedUser) {
    $selectedUser = [
        'id' => 0,
        'username' => '',
        'full_name' => '',
        'is_active' => 1,
        'auth_source' => 'local',
        'ad_username' => '',
        'last_login_at' => null,
        'roles' => [],
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <style>
        body{margin:0;font-family:Segoe UI,Tahoma,sans-serif;background:#f3f6fb;color:#17212f}
        .wrap{max-width:1280px;margin:28px auto;padding:0 20px}
        .meta{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:16px}
        .meta a{color:#0b66c3;text-decoration:none}
        .grid{display:grid;grid-template-columns:380px minmax(0,1fr);gap:22px}
        .card{background:#fff;border-radius:16px;padding:22px;box-shadow:0 18px 48px rgba(23,33,47,.10)}
        h1,h2{margin-top:0}
        .list{display:flex;flex-direction:column;gap:12px;max-height:70vh;overflow:auto}
        .user-item{display:block;padding:14px 16px;border:1px solid #dbe4ef;border-radius:12px;text-decoration:none;color:inherit;background:#fff}
        .user-item.active{border-color:#0b66c3;background:#eef5ff}
        .user-top{display:flex;justify-content:space-between;gap:10px;align-items:center}
        .user-name{font-weight:700}
        .muted{color:#607086;font-size:13px}
        .pill{display:inline-block;padding:4px 8px;border-radius:999px;background:#eef5ff;color:#0b66c3;font-size:12px;font-weight:700;margin:2px 6px 2px 0}
        .pill.off{background:#fde7e7;color:#a12626}
        .ok,.error{padding:12px 14px;border-radius:10px;margin-bottom:14px}.ok{background:#e9f8ef;color:#1f6f43}.error{background:#fde7e7;color:#a12626}
        label{display:block;font-weight:600;margin:14px 0 6px}
        input[type=text],input[type=password],select{width:100%;box-sizing:border-box;padding:12px 14px;border:1px solid #c9d3e1;border-radius:10px;font-size:14px}
        .row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
        .roles{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:8px}
        .role-box{display:flex;gap:10px;align-items:flex-start;padding:12px;border:1px solid #dbe4ef;border-radius:12px;background:#f9fbfe}
        .role-box input{margin-top:3px}
        .actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:20px}
        .btn{display:inline-block;border:0;border-radius:10px;padding:12px 16px;background:#0b66c3;color:#fff;font-weight:700;cursor:pointer;text-decoration:none}
        .btn.secondary{background:#e8eef6;color:#17212f}
        .inline-check{display:flex;align-items:center;gap:10px;margin-top:18px}
        .inline-check input{width:auto}
        .small{font-size:12px;color:#607086}
        .ad-search{margin:14px 0 8px;padding:12px;border:1px solid #dbe4ef;border-radius:12px;background:#f9fbfe}
        .ad-search-row{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end}
        .ad-search-results{margin-top:10px;display:flex;flex-direction:column;gap:8px;max-height:220px;overflow:auto}
        .ad-user-option{display:block;width:100%;text-align:left;background:#fff;border:1px solid #dbe4ef;border-radius:10px;padding:10px 12px;cursor:pointer}
        .ad-user-option:hover{border-color:#0b66c3;background:#eef5ff}
        .ad-user-option .line{font-size:13px;color:#17212f}
        .ad-user-option .sub{font-size:12px;color:#607086;margin-top:2px}
        @media (max-width: 980px){.grid{grid-template-columns:1fr}.row,.roles{grid-template-columns:1fr}}
    </style>
</head>
<body>
    <?php authRenderUserMenu(); ?>
<div class="wrap">
    <div class="meta">
        <a href="<?php echo htmlspecialchars(authDefaultLandingPage(), ENT_QUOTES, 'UTF-8'); ?>">Back</a>
        <a href="user_actions.php">User Actions</a>
        <?php if (!$adEnabled): ?><a href="change_password.php">Change Password</a><?php endif; ?>
        <a href="logout.php">Logout</a>
    </div>
    <div class="grid">
        <div class="card">
            <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
                <h2>Users</h2>
                <form method="post" action="user_management.php" style="margin:0;">
                    <input type="hidden" name="form_action" value="new_form">
                    <button class="btn secondary" type="submit">New User</button>
                </form>
            </div>
            <div class="list">
                <?php foreach ($users as $userRow): ?>
                    <?php $rowRoles = trim((string)($userRow['role_keys'] ?? '')); ?>
                    <a class="user-item <?php echo (int)$userRow['id'] === (int)$selectedUser['id'] ? 'active' : ''; ?>" href="user_management.php?user_id=<?php echo (int)$userRow['id']; ?>">
                        <div class="user-top">
                            <div>
                                <div class="user-name"><?php echo htmlspecialchars((string)($userRow['full_name'] ?: $userRow['username']), ENT_QUOTES, 'UTF-8'); ?></div>
                                <div class="muted"><?php echo htmlspecialchars((string)$userRow['username'], ENT_QUOTES, 'UTF-8'); ?></div>
                            </div>
                            <span class="pill <?php echo (int)$userRow['is_active'] === 1 ? '' : 'off'; ?>"><?php echo (int)$userRow['is_active'] === 1 ? 'Active' : 'Inactive'; ?></span>
                        </div>
                        <div class="muted" style="margin-top:8px;">Roles: <?php echo htmlspecialchars($rowRoles !== '' ? $rowRoles : 'none', ENT_QUOTES, 'UTF-8'); ?></div>
                        <div class="muted">Auth: <?php echo htmlspecialchars((string)$userRow['auth_source'], ENT_QUOTES, 'UTF-8'); ?><?php echo !empty($userRow['last_login_at']) ? ' | Last login: ' . htmlspecialchars((string)$userRow['last_login_at'], ENT_QUOTES, 'UTF-8') : ''; ?></div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="card">
            <h1><?php echo (int)$selectedUser['id'] > 0 ? 'Edit User' : 'Create User'; ?></h1>
            <p class="small"><?php echo $adEnabled ? 'AD authentication is enabled globally. This page is used to match AD users to system roles. Users can have multiple roles or none. If no role is assigned, AD login succeeds but access is refused with a no-role message.' : 'Users can have multiple roles or none. Billing includes clinics access. Quality includes statistics and administration. No role means the user can log in but will only land on the stream page.'; ?></p>
            <?php if ($message !== ''): ?><div class="ok"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
            <?php if ($error !== ''): ?><div class="error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
            <form method="post" action="user_management.php">
                <input type="hidden" name="form_action" value="save_user">
                <input type="hidden" name="user_id" value="<?php echo (int)$selectedUser['id']; ?>">
                <div class="row">
                    <div>
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars((string)$selectedUser['username'], ENT_QUOTES, 'UTF-8'); ?>" required>
                    </div>
                    <div>
                        <label for="full_name">Full Name</label>
                        <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars((string)$selectedUser['full_name'], ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                </div>
                <?php if ($adEnabled): ?>
                    <div class="ad-search">
                        <label for="ad_search_term" style="margin-top:0;">Search Active Directory Users</label>
                        <div class="ad-search-row">
                            <input type="text" id="ad_search_term" name="ad_search_term" form="ad-search-form" value="<?php echo htmlspecialchars($adSearchTerm, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search by username, display name, or email">
                            <button class="btn secondary" type="submit" form="ad-search-form">Search AD</button>
                        </div>
                        <div class="small" style="margin-top:6px;">Pick a result to auto-fill Username, Full Name, and AD Username before saving roles.</div>
                        <?php if ($adSearchError !== ''): ?>
                            <div class="error" style="margin-top:10px;margin-bottom:0;"><?php echo htmlspecialchars($adSearchError, ENT_QUOTES, 'UTF-8'); ?></div>
                        <?php endif; ?>
                        <?php if (!empty($adSearchResults)): ?>
                            <div class="ad-search-results" id="ad-search-results">
                                <?php foreach ($adSearchResults as $adUser): ?>
                                    <button
                                        type="button"
                                        class="ad-user-option"
                                        data-username="<?php echo htmlspecialchars((string)($adUser['username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"
                                        data-fullname="<?php echo htmlspecialchars((string)($adUser['full_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"
                                        data-adusername="<?php echo htmlspecialchars((string)($adUser['ad_username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"
                                    >
                                        <div class="line"><?php echo htmlspecialchars((string)($adUser['full_name'] ?: $adUser['username']), ENT_QUOTES, 'UTF-8'); ?></div>
                                        <div class="sub"><?php echo htmlspecialchars((string)$adUser['username'], ENT_QUOTES, 'UTF-8'); ?><?php echo !empty($adUser['upn']) ? ' | ' . htmlspecialchars((string)$adUser['upn'], ENT_QUOTES, 'UTF-8') : ''; ?><?php echo !empty($adUser['email']) ? ' | ' . htmlspecialchars((string)$adUser['email'], ENT_QUOTES, 'UTF-8') : ''; ?></div>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div>
                            <label for="ad_username">AD Username (optional override)</label>
                            <input type="text" id="ad_username" name="ad_username" value="<?php echo htmlspecialchars((string)$selectedUser['ad_username'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="stlouis\\username or username@stlouis.com">
                        </div>
                        <div>
                            <label>Authentication Mode</label>
                            <input type="text" value="Active Directory enabled globally" readonly>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <div>
                            <label for="auth_source">Auth Source</label>
                            <select id="auth_source" name="auth_source">
                                <option value="local" <?php echo (string)$selectedUser['auth_source'] === 'local' ? 'selected' : ''; ?>>Local</option>
                                <option value="ad" <?php echo (string)$selectedUser['auth_source'] === 'ad' ? 'selected' : ''; ?>>Active Directory</option>
                            </select>
                        </div>
                        <div>
                            <label for="ad_username">AD Username</label>
                            <input type="text" id="ad_username" name="ad_username" value="<?php echo htmlspecialchars((string)$selectedUser['ad_username'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="user@domain.local">
                        </div>
                    </div>
                    <div class="row">
                        <div>
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" placeholder="<?php echo (int)$selectedUser['id'] > 0 ? 'Leave blank to keep current password' : 'Required for local user'; ?>">
                        </div>
                        <div>
                            <label for="confirm_password">Confirm Password</label>
                            <input type="password" id="confirm_password" name="confirm_password">
                        </div>
                    </div>
                <?php endif; ?>
                <div class="inline-check">
                    <input type="checkbox" id="is_active" name="is_active" value="1" <?php echo (int)$selectedUser['is_active'] === 1 ? 'checked' : ''; ?>>
                    <label for="is_active" style="margin:0;">Active user</label>
                </div>
                <label>Roles (optional)</label>
                <div class="roles">
                    <?php foreach ($roleOptions as $roleKey): ?>
                        <label class="role-box">
                            <input type="checkbox" name="roles[]" value="<?php echo htmlspecialchars($roleKey, ENT_QUOTES, 'UTF-8'); ?>" <?php echo in_array($roleKey, $selectedUser['roles'], true) ? 'checked' : ''; ?>>
                            <span>
                                <strong><?php echo htmlspecialchars(ucfirst($roleKey), ENT_QUOTES, 'UTF-8'); ?></strong><br>
                                <span class="small"><?php echo htmlspecialchars((string)($roleDescriptions[$roleKey] ?? ''), ENT_QUOTES, 'UTF-8'); ?></span>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <div class="actions">
                    <button class="btn" type="submit">Save User</button>
                    <a class="btn secondary" href="user_management.php">Reset Form</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php if ($adEnabled): ?>
<form id="ad-search-form" method="post" action="user_management.php" style="display:none;">
    <input type="hidden" name="form_action" value="search_ad">
    <input type="hidden" name="user_id" value="<?php echo (int)$selectedUser['id']; ?>">
    <input type="hidden" name="ad_search_term" id="ad_search_term_hidden" value="">
</form>
<script>
(function () {
    const searchVisible = document.getElementById('ad_search_term');
    const searchHidden = document.getElementById('ad_search_term_hidden');
    const form = document.getElementById('ad-search-form');
    const username = document.getElementById('username');
    const fullName = document.getElementById('full_name');
    const adUsername = document.getElementById('ad_username');
    const results = document.getElementById('ad-search-results');

    if (form && searchVisible && searchHidden) {
        form.addEventListener('submit', function () {
            searchHidden.value = searchVisible.value || '';
        });
        const submitBtn = document.querySelector('button[form="ad-search-form"]');
        if (submitBtn) {
            submitBtn.addEventListener('click', function () {
                searchHidden.value = searchVisible.value || '';
            });
        }
    }

    if (!results || !username || !adUsername) {
        return;
    }

    results.addEventListener('click', function (event) {
        const option = event.target.closest('.ad-user-option');
        if (!option) {
            return;
        }
        const u = option.getAttribute('data-username') || '';
        const fn = option.getAttribute('data-fullname') || '';
        const adu = option.getAttribute('data-adusername') || '';
        if (u !== '') {
            username.value = u;
        }
        if (fn !== '' && fullName) {
            fullName.value = fn;
        }
        adUsername.value = adu !== '' ? adu : u;
    });
})();
</script>
<?php endif; ?>
<?php if (!$adEnabled): ?>
<script>
(function () {
    const authSource = document.getElementById('auth_source');
    const passwordInput = document.getElementById('password');
    const confirmInput = document.getElementById('confirm_password');
    const adInput = document.getElementById('ad_username');
    if (!authSource) {
        return;
    }
    function syncAuthSource() {
        const isAd = authSource.value === 'ad';
        adInput.required = isAd;
        passwordInput.required = !isAd && <?php echo (int)$selectedUser['id'] === 0 ? 'true' : 'false'; ?>;
        if (isAd) {
            passwordInput.placeholder = 'Optional local fallback password';
            confirmInput.placeholder = 'Optional local fallback password';
        } else {
            passwordInput.placeholder = <?php echo json_encode((int)$selectedUser['id'] > 0 ? 'Leave blank to keep current password' : 'Required for local user'); ?>;
            confirmInput.placeholder = '';
        }
    }
    authSource.addEventListener('change', syncAuthSource);
    syncAuthSource();
})();
</script>
<?php endif; ?>
</body>
</html>

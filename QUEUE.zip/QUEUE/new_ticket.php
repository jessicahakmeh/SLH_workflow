<?php
require_once 'config.php';
session_start();
authRequireRoles(['butler', 'billing', 'admin'], ['log_view' => false]);

$show_success_modal = false;
$success_queue_number = '';
$success_patient_id = '';
$from_page = isset($_GET['from']) ? trim($_GET['from']) : (isset($_POST['from']) ? trim($_POST['from']) : '');
$selected_patient_prefill = null;
$selected_patient_id_from_picker = null;

// Return flow from patient_selection.php.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['selected_patient_id']) && !isset($_POST['submit'])) {
    $selected_patient_id_from_picker = (int)$_POST['selected_patient_id'];
    if ($selected_patient_id_from_picker > 0) {
        $selected_patient_prefill = executeAndFetchOne($pdo, "SELECT patient_id, patient_name, country_code, mobile, care_country_code, care_mobile, email, address
                                  FROM patients
                                  WHERE patient_id = ?", [$selected_patient_id_from_picker]);
    }
}

// ====================
// PHONE NUMBER FORMATTING HELPER
// ====================
/**
 * Format phone number with country code
 * @param string $phone_number - The local phone number (without country code)
 * @param string $country_code - The country code (e.g., '+961', '+1')
 * @return string - The formatted international phone number
 */
function formatInternationalNumber($phone_number, $country_code) {
    // Remove all non-numeric characters from phone number
    $phone_number = preg_replace('/[^0-9]/', '', $phone_number);
    
    // Remove country code from both for processing
    $country_code_digits = preg_replace('/[^0-9]/', '', $country_code);
    
    // Remove country code if it already exists in the phone number
    if (strpos($phone_number, $country_code_digits) === 0) {
        $phone_number = substr($phone_number, strlen($country_code_digits));
    }
    
    // Combine and return
    return $country_code_digits . $phone_number;
}

// ====================
// WHATSAPP MESSAGING FUNCTION
// ====================
/**
 * Send WhatsApp message via API
 * @param string $phone_number - Destination phone number (should already be formatted with country code)
 * @param string $template - Template name (call_queue, skip_queue, ticket_queue)
 * @param array $variables - Optional template variables (e.g., ['queue_number' => '1001'])
 */
function sendWhatsAppMessage($phone_number, $template, $variables = []) {
    try {
        if (empty($phone_number)) {
            error_log("WhatsApp API: No phone number provided");
            return false; // Skip if no phone number
        }
        $phone_number = preg_replace('/[^0-9]/', '', $phone_number);

        if (strlen($phone_number) <= 9) {
            $phone_number = '961' . $phone_number;
        }

        $sendResult = sendWhatsAppTemplateRequest($phone_number, $template, $variables);
        $full_url = (string)($sendResult['request_url'] ?? '');
        
        // Log the request for debugging
        error_log("WhatsApp API Request: " . $full_url);

        $response = (string)($sendResult['response'] ?? '');
        $http_code = (int)($sendResult['http_code'] ?? 0);
        $curl_error = (string)($sendResult['curl_error'] ?? '');
        
        // Log the response for debugging
        error_log("WhatsApp API Response (HTTP $http_code): " . $response);
        
        if ($curl_error) {
            error_log("WhatsApp API cURL Error: " . $curl_error);
            return false;
        }
        
        // Check if response indicates success
        if ($http_code >= 200 && $http_code < 300) {
            error_log("WhatsApp message sent successfully to $phone_number with template: $template");
            return true;
        } else {
            error_log("WhatsApp API returned HTTP $http_code for $phone_number");
            return false;
        }
        
    } catch (Exception $e) {
        error_log("WhatsApp API Exception: " . $e->getMessage());
        return false;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['submit'])) {
        try {
            // Validation
            $errors = [];
            
            // Check service_type (skip if from clinics, as it's auto-set)
            if ($from_page !== 'clinics' && empty($_POST['service_type'])) {
                $errors[] = 'Please select a service type (Appointment, Private, Guarantor, or Clinics)';
            }
            
            // Check patient_name
            if (empty($_POST['patient_name'])) {
                $errors[] = 'Please enter the patient name';
            }
            
            // Check mobile
            if (empty($_POST['mobile'])) {
                $errors[] = 'Please enter a mobile number';
            }
            
            // Check country_code
            if (empty($_POST['country_code'])) {
                $errors[] = 'Please select a country code';
            }
            // care_country_code is optional but if care_mobile entered without it, default later
            
            // If there are errors, stay on the form and display them
            if (!empty($errors)) {
                // Use first error for display, store all in session for reference
                $message = $errors[0];
                $message_type = 'error';
                $_SESSION['validation_errors'] = $errors;
            } else {
                // All validations passed, store form data in session
                $_SESSION['pending_patient_data'] = [
                    'service_type' => $_POST['service_type'],
                    'existing_patient_id' => isset($_POST['existing_patient_id']) && $_POST['existing_patient_id'] !== '' ? (int)$_POST['existing_patient_id'] : null,
                    'patient_name' => $_POST['patient_name'],
                    'mobile' => $_POST['mobile'],
                    'care_mobile' => $_POST['care_mobile'] ?? '',
                    'country_code' => $_POST['country_code'],
                    'care_country_code' => $_POST['country_code_care'] ?? '',
                    'email' => $_POST['email'] ?? '',
                    'address' => $_POST['address'] ?? ''
                ];
                
                // Clear any previous validation errors
                unset($_SESSION['validation_errors']);
                
                // Redirect to scan_docs.php (preserve calling page)
                $redirectUrl = 'scan_docs.php?pending=true';
                if (!empty($from_page)) {
                    $redirectUrl .= '&from=' . urlencode($from_page);
                }
                header('Location: ' . $redirectUrl);
                exit;
            }
            
        } catch (Exception $e) {
            $message = "Error processing form: " . $e->getMessage();
            $message_type = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Ticket</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <!-- Success Modal --> 
    <div class="modal <?php echo $show_success_modal ? 'active' : ''; ?>" id="successModal">
        <div class="modal-content">
            <div class="modal-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2 class="modal-title">Ticket Created Successfully!</h2>
            <div class="modal-queue-number" id="queueNumberDisplay">
                <?php echo $success_queue_number; ?>
            </div>
            <div id="patientIdDisplay" style="display: none;"><?php echo trim($success_patient_id); ?></div> 
            <p class="modal-message">
                Please give the patient their ticket number.<br>
                The patient has been added to the queue.
            </p>
            <div class="btn-group">
                <button class="modal-btn" onclick="closeModal()">
                    <i class="fas fa-check"></i> OK
                </button>
            </div>
        </div>
    </div> 
    
    <div class="container">
        <?php
        // Include shared form with options
        $options = [
            'mode' => 'create',
            'title' => 'Create New Patient Ticket',
            'button_text' => 'Proceed',
            'button_icon' => 'fa-plus-circle',
            'from_page' => $from_page,
            'prefill_patient' => $selected_patient_prefill,
            'selected_existing_patient_id' => $selected_patient_id_from_picker
        ];
        include 'shared_form.php';
        ?>
    </div>

    <script>
        // Modal functions 
        function closeModal() {
            // Redirect to scan_docs with a flag to indicate pending patient data
            setTimeout(function() {
                var url = 'scan_docs.php?pending=true';
                <?php if ($from_page): ?>
                url += '&from=<?php echo urlencode($from_page); ?>';
                <?php endif; ?>
                window.location.href = url;
            }, 300);
        }
        
        // Auto-show modal if success
        <?php if ($show_success_modal): ?>
        document.getElementById('successModal').classList.add('active');
        <?php endif; ?>
    </script>
</body>
</html>
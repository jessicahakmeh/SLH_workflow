<?php
require_once 'config.php';
session_start();
authLogoutUser();
header('Location: login.php');
exit;

<?php
// exec_helpers.php - safer process execution helpers using proc_open
require_once __DIR__ . '/monitoring.php';

function run_process($command, $cwd = null, $timeout = 30) {
    // Return structure: ['exit' => int|null, 'stdout' => string, 'stderr' => string, 'timed_out' => bool]
    $descriptors = [
        0 => ['pipe', 'r'],
        1 => ['pipe', 'w'],
        2 => ['pipe', 'w']
    ];

    $start = time();
    $process = @proc_open($command, $descriptors, $pipes, $cwd);
    increment_metric('external_spawns');
    log_event('spawn', 'run_process: ' . $command);

    if (!is_resource($process)) {
        return ['exit' => null, 'stdout' => '', 'stderr' => 'proc_open failed', 'timed_out' => false];
    }

    // set non-blocking streams
    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);

    $stdout = '';
    $stderr = '';
    $timedOut = false;

    while (true) {
        $status = proc_get_status($process);
        $running = $status['running'];

        $read = [$pipes[1], $pipes[2]];
        $write = null;
        $except = null;
        // Use stream_select to wait for data or timeout
        $tv_sec = 1;
        $tv_usec = 0;
        $numChanged = @stream_select($read, $write, $except, $tv_sec, $tv_usec);
        if ($numChanged === false) $numChanged = 0;

        foreach ($read as $r) {
            $data = stream_get_contents($r);
            if ($r === $pipes[1]) $stdout .= $data;
            else $stderr .= $data;
        }

        if (!$running) break;

        if ((time() - $start) > $timeout) {
            // timed out: terminate process
            $timedOut = true;
            @proc_terminate($process);
            break;
        }
    }

    // final read
    $stdout .= stream_get_contents($pipes[1]);
    $stderr .= stream_get_contents($pipes[2]);

    foreach ($pipes as $p) {
        @fclose($p);
    }

    $exit = proc_close($process);

    return ['exit' => $exit, 'stdout' => $stdout, 'stderr' => $stderr, 'timed_out' => $timedOut];
}

function run_process_background($command) {
    // Attempt to start process detached and return immediately
    increment_metric('external_spawns');
    log_event('spawn', 'run_process_background: ' . $command);

    if (stripos(PHP_OS, 'WIN') === 0) {
        // On Windows use start to detach
        pclose(popen('start /B "" ' . $command, 'r'));
        return true;
    } else {
        // POSIX: append background operator
        $cmd = $command . ' > /dev/null 2>&1 &';
        @exec($cmd);
        return true;
    }
}

?>
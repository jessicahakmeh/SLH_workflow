<?php
// Lightweight monitoring utilities
// Usage: require_once __DIR__ . '/lib/monitoring.php';

if (!defined('MONITOR_DIR')) define('MONITOR_DIR', __DIR__ . '/../temp/monitoring');
if (!defined('MONITOR_LOG')) define('MONITOR_LOG', __DIR__ . '/../logs/monitor.log');
if (!defined('MONITOR_MAX_LOG_SIZE')) define('MONITOR_MAX_LOG_SIZE', 5 * 1024 * 1024); // 5MB

if (!is_dir(MONITOR_DIR)) {
    @mkdir(MONITOR_DIR, 0777, true);
}
if (!is_dir(dirname(MONITOR_LOG))) {
    @mkdir(dirname(MONITOR_LOG), 0777, true);
}

function rotate_monitor_log() {
    $log = MONITOR_LOG;
    $max = MONITOR_MAX_LOG_SIZE;
    if (!file_exists($log)) return;
    clearstatcache(true, $log);
    $size = @filesize($log) ?: 0;
    if ($size <= $max) return;
    // rotate: monitor.log -> monitor.log.1 (overwrite)
    $rot = $log . '.1';
    if (file_exists($rot)) @unlink($rot);
    @rename($log, $rot);
}

function log_event($category, $message) {
    $time = date('Y-m-d H:i:s');
    $line = "[$time] [$category] $message\n";
    // rotate if needed
    rotate_monitor_log();
    @file_put_contents(MONITOR_LOG, $line, FILE_APPEND | LOCK_EX);
}

// Metrics are stored per-minute files to allow rate calculations
function increment_metric($name) {
    $minute = date('YmdHi'); // e.g., 202608271230
    $dir = MONITOR_DIR . '/' . $name;
    if (!is_dir($dir)) @mkdir($dir, 0777, true);
    $file = "$dir/$minute.count";
    // Use atomic append
    @file_put_contents($file, "1\n", FILE_APPEND | LOCK_EX);
}

function get_metric_counts($name, $minutes = 60) {
    $dir = MONITOR_DIR . '/' . $name;
    $counts = [];
    if (!is_dir($dir)) return $counts;
    $now = time();
    for ($i = 0; $i < $minutes; $i++) {
        $t = $now - ($i * 60);
        $minute = date('YmdHi', $t);
        $file = "$dir/$minute.count";
        if (file_exists($file)) {
            $lines = @file($file, FILE_SKIP_EMPTY_LINES | LOCK_EX) ?: [];
            $counts[$minute] = count($lines);
        } else {
            $counts[$minute] = 0;
        }
    }
    return $counts; // keyed by minute string
}

function get_metric_sum_last_minutes($name, $minutes = 60) {
    $counts = get_metric_counts($name, $minutes);
    return array_sum($counts);
}

function get_monitoring_snapshot() {
    $metrics = [
        'db_reconnect_success' => get_metric_sum_last_minutes('db_reconnect_success', 60),
        'db_reconnect_fail' => get_metric_sum_last_minutes('db_reconnect_fail', 60),
        'sse_client_connects' => get_metric_sum_last_minutes('sse_client_connects', 60),
        'sse_reconnect_attempts' => get_metric_sum_last_minutes('sse_reconnect_attempts', 60),
        'external_spawns' => get_metric_sum_last_minutes('external_spawns', 60),
    ];
    return $metrics;
}

?>
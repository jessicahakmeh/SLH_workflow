<?php
// statistics.php - Dashboard with patient statistics and analytics
require_once 'config.php';
session_start();
authRequireRoles(['quality', 'admin']);

// Default date range - last 30 days
$start_date = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$mrn_filter = $_GET['mrn'] ?? '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Ticket type filter
$service_types = isset($_GET['service_types']) ? $_GET['service_types'] : ['Appointment', 'Private', 'Guarantor'];
if (!is_array($service_types)) {
    $service_types = [$service_types];
}
$service_types = array_intersect($service_types, ['Appointment', 'Private', 'Guarantor', 'Clinics']);
if (empty($service_types)) {
    $service_types = ['Appointment', 'Private', 'Guarantor'];
}

// Multi-test filter
$multi_test_only = isset($_GET['multi_test_filter']) && $_GET['multi_test_filter'] === 'on';


// Validate and normalize dates
if (strtotime($start_date) > strtotime($end_date)) {
    $temp = $start_date;
    $start_date = $end_date;
    $end_date = $temp;
}

// Ensure dates are valid
if (strtotime($start_date) === false || strtotime($end_date) === false) {
    $start_date = date('Y-m-d', strtotime('-30 days'));
    $end_date = date('Y-m-d');
}

// Add one day to end_date to include the entire end date
$end_date_inclusive = date('Y-m-d', strtotime($end_date . ' +1 day'));

// Build a grouped patient subquery to treat duplicate tickets (same queue_number on same day)
// as a single logical patient. Aggregations provide clear timeline:
// Timeline: arrival_ts → first_call_ts → last_closing_ts → approval_ts (billing)
$group_query = "
    SELECT
        t.queue_number,
        p.mrn,
        t.service_type,
        MIN(t.arrival_timestamp) as arrival_ts,
        CASE 
            WHEN MIN(IFNULL(t.lab_call_time, '9999-01-01')) <= MIN(IFNULL(t.imaging_call_time, '9999-01-01'))
            THEN MIN(IFNULL(t.lab_call_time, '9999-01-01'))
            ELSE MIN(IFNULL(t.imaging_call_time, '9999-01-01'))
        END as first_call_ts,
        MIN(IFNULL(t.lab_call_time, NULL)) as earliest_lab_call,
        MIN(IFNULL(t.imaging_call_time, NULL)) as earliest_imaging_call,
        MIN(IFNULL(t.clinics_call_time, NULL)) as earliest_clinics_call,
        MAX(t.closing_timestamp) as last_closing_ts,
        MIN(IFNULL(t.approval_timestamp, NULL)) as earliest_approval_ts,
        GROUP_CONCAT(DISTINCT IF(t.current_status='On Hold', t.imaging_machine, NULL)) as hold_machines,
        GROUP_CONCAT(DISTINCT t.imaging_machine) as all_machines,
        COUNT(*) as ticket_count,
        COUNT(DISTINCT IF(t.current_status='On Hold', 1, NULL)) as hold_count
    FROM tickets t
    JOIN patients p ON t.patient_id = p.patient_id
    WHERE t.arrival_timestamp >= ? AND t.arrival_timestamp < ? AND t.service_type IN (" . implode(',', array_fill(0, count($service_types), '?')) . ")
    GROUP BY t.queue_number, DATE(t.arrival_timestamp), p.mrn
";

// Helper function: build parameter array for queries with service type filter
function buildQueryParams($start_date, $end_date_inclusive, $service_types = []) {
    $params = [$start_date . ' 00:00:00', $end_date_inclusive . ' 00:00:00'];
    return array_merge($params, $service_types);
}

// Helper function: compute patient journey timeline with explicit timestamps
function computePatientTimeline($group, $pdo) {
    $timeline = [];
    
    // Stage 1: Arrival
    $timeline['arrival_time'] = $group['arrival_ts'] ?? null;
    
    // Stage 2: First Call (to any department)
    $first_call = $group['first_call_ts'] ?? null;
    if ($first_call && $first_call != '9999-01-01') {
        $timeline['first_call_time'] = $first_call;
        
        // Calculate wait time, but need to exclude time spent in "Needed by Billing" status
        // For now, use simple calculation and we'll refine with log data
        $wait_mins = round((strtotime($first_call) - strtotime($group['arrival_ts'] ?? '')) / 60, 1);
        $timeline['wait_time_minutes'] = max(0, $wait_mins);
        $timeline['wait_time_includes_billing'] = true; // Flag that this wait time might include billing time
        
        // Determine which department called
        $timeline['first_department'] = 'Unknown';
        $deptCandidates = [];
        if (!empty($group['earliest_lab_call'])) {
            $deptCandidates['Lab'] = $group['earliest_lab_call'];
        }
        if (!empty($group['earliest_imaging_call'])) {
            $deptCandidates['Imaging'] = $group['earliest_imaging_call'];
        }
        if (!empty($group['earliest_clinics_call'])) {
            $deptCandidates['Clinics'] = $group['earliest_clinics_call'];
        }

        if (!empty($deptCandidates)) {
            asort($deptCandidates);
            $timeline['first_department'] = (string)array_key_first($deptCandidates);
        }
    } else {
        $timeline['first_call_time'] = null;
        $timeline['wait_time_minutes'] = null;
        $timeline['first_department'] = 'Not Called';
    }
    
    // Stage 2b: Time spent in "Needed by Billing" status (new)
    $timeline['needed_by_billing_time'] = null;
    
    // Stage 3: Service (from first call to last closing)
    $timeline['last_closing_time'] = $group['last_closing_ts'] ?? null;
    if ($timeline['first_call_time'] && $timeline['last_closing_time']) {
        $service_mins = round((strtotime($timeline['last_closing_time']) - strtotime($timeline['first_call_time'])) / 60, 1);
        $timeline['service_time_minutes'] = max(0, $service_mins);
    } else {
        $timeline['service_time_minutes'] = null;
    }
    
    // Stage 4: Total duration
    if ($timeline['last_closing_time']) {
        $total_mins = round((strtotime($timeline['last_closing_time']) - strtotime($timeline['arrival_time'])) / 60, 1);
        $timeline['total_time_minutes'] = max(0, $total_mins);
    } else {
        $timeline['total_time_minutes'] = null;
    }
    
    // Stage 5: Billing (approval to closure)
    $timeline['approval_time'] = $group['earliest_approval_ts'] ?? null;
    if ($timeline['approval_time'] && $timeline['last_closing_time']) {
        $billing_mins = round((strtotime($timeline['last_closing_time']) - strtotime($timeline['approval_time'])) / 60, 1);
        $timeline['billing_time_minutes'] = max(0, $billing_mins);
    } else {
        $timeline['billing_time_minutes'] = null;
    }
    
    // On-hold information
    $timeline['hold_count'] = $group['hold_count'] ?? 0;
    $timeline['is_on_hold'] = $timeline['hold_count'] > 0;
    
    // Departments visited
    $timeline['departments'] = ($group['all_machines'] ?? null) ? explode(',', $group['all_machines']) : [];
    $timeline['ticket_count'] = $group['ticket_count'] ?? 0;
    $timeline['is_multi_test'] = ($group['ticket_count'] ?? 0) > 1;
    
    return $timeline;
}

// Helper function: compute stage-by-stage timings from ticket_logs
function computeStageTimings($ticket_id, $pdo) {
    static $stmtLogs = null;
    if ($stmtLogs === null) {
        $stmtLogs = $pdo->prepare("
            SELECT created_at, action, from_status, to_status, notes 
            FROM ticket_logs 
            WHERE ticket_id = ? 
            ORDER BY created_at ASC
        ");
    }
    $stmtLogs->execute([$ticket_id]);
    $logs = $stmtLogs->fetchAll(PDO::FETCH_ASSOC);

    // Query patient record for timestamps
    static $stmtPat = null;
    if ($stmtPat === null) {
        $stmtPat = $pdo->prepare("
            SELECT arrival_timestamp, approval_timestamp, closing_timestamp, 
                   lab_call_time, imaging_call_time 
            FROM tickets 
            WHERE ticket_id = ?
        ");
    }
    $stmtPat->execute([$ticket_id]);
    $pat = $stmtPat->fetch(PDO::FETCH_ASSOC);
    if (!$pat) return null;

    $stages = [
        'arrival_to_billing_wait' => null,  // arrival → In Process start
        'in_process_duration' => null,       // In Process start → In Process end
        'billing_to_waiting_wait' => null,   // In Process end → Waiting
        'waiting_to_served_duration' => null, // Waiting → first call
        'needed_by_billing_duration' => null  // Time spent in "Needed by Billing" status
    ];

    // Find state transitions
    $in_process_start = null;
    $in_process_end = null;
    $waiting_start = null;
    $first_served_call = null;
    $needed_by_billing_start = null;
    $needed_by_billing_end = null;

    foreach ($logs as $log) {
        $ts = strtotime($log['created_at']);
        $to_status = trim($log['to_status'] ?? '');
        $from_status = trim($log['from_status'] ?? '');
        $action = strtolower($log['action'] ?? '');
        $notes = strtolower($log['notes'] ?? '');

        // Detect "Needed by Billing" start
        if (!$needed_by_billing_start && strcasecmp($to_status, 'Needed by Billing') === 0) {
            $needed_by_billing_start = $ts;
        }

        // Detect "Needed by Billing" end (transition away)
        if ($needed_by_billing_start && !$needed_by_billing_end && strcasecmp($from_status, 'Needed by Billing') === 0) {
            $needed_by_billing_end = $ts;
        }

        // Detect In Process start
        if (!$in_process_start && strcasecmp($to_status, 'In Process') === 0) {
            $in_process_start = $ts;
        }

        // Detect In Process end (transition away)
        if ($in_process_start && !$in_process_end && strcasecmp($from_status, 'In Process') === 0) {
            $in_process_end = $ts;
        }

        // Detect Waiting status
        if (!$waiting_start && strcasecmp($to_status, 'Waiting') === 0) {
            $waiting_start = $ts;
        }

        // Detect lab/imaging call (first served indication)
        if (!$first_served_call && (strpos($action, 'call') !== false || strpos($notes, 'called') !== false)) {
            $first_served_call = $ts;
        }
    }

    // Compute stage durations
    $arrival_ts = strtotime($pat['arrival_timestamp']);

    if ($in_process_start) {
        $stages['arrival_to_billing_wait'] = max(0, round(($in_process_start - $arrival_ts) / 60, 1));
    }
    if ($in_process_start && $in_process_end) {
        $stages['in_process_duration'] = max(0, round(($in_process_end - $in_process_start) / 60, 1));
    }
    if ($waiting_start && $first_served_call) {
        $stages['waiting_to_served_duration'] = max(0, round(($first_served_call - $waiting_start) / 60, 1));
    }
    
    // Calculate "Needed by Billing" duration
    if ($needed_by_billing_start) {
        if ($needed_by_billing_end) {
            $stages['needed_by_billing_duration'] = max(0, round(($needed_by_billing_end - $needed_by_billing_start) / 60, 1));
        } else {
            // If still in "Needed by Billing", calculate from start to now
            $stages['needed_by_billing_duration'] = max(0, round((time() - $needed_by_billing_start) / 60, 1));
        }
    }

    // Fallback: if approval_timestamp exists, use it as proxy for In Process end
    if ($in_process_start && !$in_process_end && $pat['approval_timestamp']) {
        $approval_ts = strtotime($pat['approval_timestamp']);
        $stages['in_process_duration'] = max(0, round(($approval_ts - $in_process_start) / 60, 1));
    }

    return $stages;
}

$stats = [
    'total_patients' => 0,
    'undo_actions' => 0,
    'avg_waiting_time' => 0,
    'avg_service_time' => 0,
    'patients_per_day' => [],
    'waiting_times' => [],
    'skipped_patients' => [],
    'skipped_count' => 0,
    'wrong_info_patients' => [],
    'wrong_info_count' => 0,
    'completed_patients' => [],
    'completed_count' => 0,
    'canceled_patients' => [],
    'canceled_count' => 0,
    'billing_actions' => [],
    'billing_total' => 0,
    'billing_completed' => 0,
    'billing_canceled' => 0,
    'avg_billing_time' => 0,
    'data_quality_issues' => 0,
    'department_metrics' => [
        'lab' => [
            'total_called' => 0,
            'completed' => 0,
            'skipped' => 0,
            'avg_wait_time' => 0,
            'total_wait_time' => 0
        ],
        'imaging' => [
            'total_called' => 0,
            'completed' => 0,
            'skipped' => 0,
            'avg_wait_time' => 0,
            'total_wait_time' => 0
        ],
        'clinics' => [
            'total_called' => 0,
            'completed' => 0,
            'skipped' => 0,
            'avg_wait_time' => 0,
            'total_wait_time' => 0
        ]
    ],
    'inter_test' => [
        'multi_test_patient_count' => 0,
        'avg_inter_test_wait' => 0,
        'total_inter_test_wait' => 0,
        'avg_on_hold_minutes' => 0,
        'top_offenders' => []
    ],
    'stage_timings' => [
        'avg_arrival_to_billing_wait' => 0,
        'min_arrival_to_billing_wait' => 0,
        'max_arrival_to_billing_wait' => 0,
        'avg_in_process_duration' => 0,
        'min_in_process_duration' => 0,
        'max_in_process_duration' => 0,
        'avg_waiting_to_served_duration' => 0
    ],
    'peak_arrival_times' => []
];

try {
    // 1. Get total patients in date range (deduplicated by queue_number/date/MRN)
    $stats['total_patients'] = (int)(executeAndFetchOne($pdo, "SELECT COUNT(*) as count FROM (" . $group_query . ") t", buildQueryParams($start_date, $end_date_inclusive, $service_types)))['count'];

    // 2. Count undo actions (for all service types)
    $stats['undo_actions'] = executeAndFetchOne($pdo, "
        SELECT COUNT(*) as count 
        FROM ticket_logs tl
        JOIN tickets t ON tl.ticket_id = t.ticket_id
        WHERE tl.action = 'Undo Action' 
        AND tl.created_at >= ? AND tl.created_at < ?
        AND t.service_type IN (" . implode(',', array_fill(0, count($service_types), '?')) . ")
    ", buildQueryParams($start_date, $end_date_inclusive, $service_types))['count'];

    // 3. Patients per day (using grouped logical patients)
    $stats['patients_per_day'] = executeAndFetch($pdo, "SELECT DATE(arrival_ts) as date, COUNT(*) as count FROM (" . $group_query . ") t GROUP BY DATE(arrival_ts) ORDER BY date ASC", buildQueryParams($start_date, $end_date_inclusive, $service_types));

    // 3.5. Peak arrival times (hourly distribution)
    $peak_hours_raw = executeAndFetch($pdo, "SELECT HOUR(arrival_ts) as hour, COUNT(*) as count FROM (" . $group_query . ") t GROUP BY HOUR(arrival_ts) ORDER BY hour ASC", buildQueryParams($start_date, $end_date_inclusive, $service_types));
    
    // Initialize all 24 hours with 0, then fill in actual data
    $stats['peak_arrival_times'] = [];
    for ($h = 0; $h < 24; $h++) {
        $stats['peak_arrival_times'][$h] = 0;
    }
    foreach ($peak_hours_raw as $row) {
        $stats['peak_arrival_times'][(int)$row['hour']] = (int)$row['count'];
    }

    // 4. Calculate waiting times (arrival to first department call)
    // Clear timeline: Arrival → Wait → First Call → Service → Closing
    $all_groups = executeAndFetch($pdo, "SELECT * FROM (" . $group_query . ") t ORDER BY t.arrival_ts DESC", buildQueryParams($start_date, $end_date_inclusive, $service_types));
    
    $stats['waiting_times'] = [];
    $total_wait = 0;
    $valid_waits = 0;
    $data_quality_issues = 0;

    // Stage timing accumulators
    $stage_arrivals_to_billing = [];
    $stage_in_process = [];
    $stage_billing_to_waiting = [];
    $stage_waiting_to_served = [];
    
    // Details for each stage (for modal display)
    $stage_details = [
        'arrival_to_billing' => [],
        'in_process' => [],
        'waiting_to_served' => []
    ];
    
    // Note: These are prepared and reused in the foreach loop below
    
    foreach ($all_groups as $group) {
        $timeline = computePatientTimeline($group, $pdo);

        // Fetch all tickets in this logical group to collect stage timings
        $allTickets = executeAndFetch($pdo, "SELECT t.ticket_id AS id FROM tickets t WHERE t.queue_number = ? AND DATE(t.arrival_timestamp) = ? ORDER BY t.arrival_timestamp ASC", [$group['queue_number'], date('Y-m-d', strtotime($group['arrival_ts']))]);
        
        // For each ticket in group, compute stage timings
        foreach ($allTickets as $ticket) {
            $stages = computeStageTimings($ticket['id'], $pdo);
            if ($stages) {
                // Get patient info for this ticket
                $patientInfo = executeAndFetchOne($pdo, "SELECT p.patient_name, p.mrn, t.queue_number FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$ticket['id']]);
                
                if ($stages['arrival_to_billing_wait'] !== null) {
                    $stage_arrivals_to_billing[] = $stages['arrival_to_billing_wait'];
                    $stage_details['arrival_to_billing'][] = [
                        'patient' => $patientInfo['patient_name'] ?? 'N/A',
                        'mrn' => $patientInfo['mrn'] ?? 'N/A',
                        'queue' => $patientInfo['queue_number'] ?? 'N/A',
                        'value' => $stages['arrival_to_billing_wait']
                    ];
                }
                if ($stages['in_process_duration'] !== null) {
                    $stage_in_process[] = $stages['in_process_duration'];
                    $stage_details['in_process'][] = [
                        'patient' => $patientInfo['patient_name'] ?? 'N/A',
                        'mrn' => $patientInfo['mrn'] ?? 'N/A',
                        'queue' => $patientInfo['queue_number'] ?? 'N/A',
                        'value' => $stages['in_process_duration']
                    ];
                }
                if ($stages['waiting_to_served_duration'] !== null) {
                    $stage_waiting_to_served[] = $stages['waiting_to_served_duration'];
                    $stage_details['waiting_to_served'][] = [
                        'patient' => $patientInfo['patient_name'] ?? 'N/A',
                        'mrn' => $patientInfo['mrn'] ?? 'N/A',
                        'queue' => $patientInfo['queue_number'] ?? 'N/A',
                        'value' => $stages['waiting_to_served_duration']
                    ];
                }
            }
        }

        // try to fetch a representative patient record (id and name) for display
        $repId = md5($group['queue_number'] . ($group['mrn'] ?? '') . $group['arrival_ts']);
        $repName = '';
        $rep = executeAndFetchOne($pdo, "SELECT t.ticket_id AS id, p.patient_name, p.mrn, t.queue_number FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.queue_number = ? AND DATE(t.arrival_timestamp) = ? LIMIT 1", [$group['queue_number'], date('Y-m-d', strtotime($group['arrival_ts']))]);
        if ($rep) {
            $repId = $rep['id'] ?? $repId;
            $repName = $rep['patient_name'] ?? '';
        }

        $record = [
            'id' => $repId,
            'patient_name' => $repName,
            'queue_number' => $group['queue_number'],
            'mrn' => $group['mrn'],
            'service_type' => $group['service_type'],
            'arrival_timestamp' => $timeline['arrival_time'],
            'first_call_time' => $timeline['first_call_time'],
            'first_dept' => $timeline['first_department'],
            'wait_minutes' => $timeline['wait_time_minutes'],
            'service_time_minutes' => $timeline['service_time_minutes'],
            'total_time_minutes' => $timeline['total_time_minutes'],
            'last_closing_time' => $timeline['last_closing_time'],
            'is_multi_test' => $timeline['is_multi_test'],
            'departments' => implode(', ', $timeline['departments'])
        ];

        $stats['waiting_times'][] = $record;
        
        // Accumulate stats for average
        if ($timeline['wait_time_minutes'] !== null && $timeline['wait_time_minutes'] >= 0) {
            $total_wait += $timeline['wait_time_minutes'];
            $valid_waits++;
        } elseif ($timeline['wait_time_minutes'] !== null && $timeline['wait_time_minutes'] < 0) {
            $data_quality_issues++;
        }
    }
    
    $stats['avg_waiting_time'] = $valid_waits > 0 ? round($total_wait / $valid_waits, 2) : 0;
    $stats['data_quality_issues'] = $data_quality_issues;

    // Calculate department-specific metrics (Lab vs Imaging)
    foreach ($stats['waiting_times'] as $patient) {
        $dept = strtolower($patient['first_dept'] ?? '');
        
        if ($dept === 'lab') {
            $stats['department_metrics']['lab']['total_called']++;
            if ($patient['wait_minutes'] !== null && $patient['wait_minutes'] >= 0) {
                $stats['department_metrics']['lab']['total_wait_time'] += $patient['wait_minutes'];
            }
        } elseif ($dept === 'imaging') {
            $stats['department_metrics']['imaging']['total_called']++;
            if ($patient['wait_minutes'] !== null && $patient['wait_minutes'] >= 0) {
                $stats['department_metrics']['imaging']['total_wait_time'] += $patient['wait_minutes'];
            }
        } elseif ($dept === 'clinics') {
            $stats['department_metrics']['clinics']['total_called']++;
            if ($patient['wait_minutes'] !== null && $patient['wait_minutes'] >= 0) {
                $stats['department_metrics']['clinics']['total_wait_time'] += $patient['wait_minutes'];
            }
        }
    }
    
    // Calculate average wait times by department
    if ($stats['department_metrics']['lab']['total_called'] > 0) {
        $stats['department_metrics']['lab']['avg_wait_time'] = round($stats['department_metrics']['lab']['total_wait_time'] / $stats['department_metrics']['lab']['total_called'], 2);
    }
    if ($stats['department_metrics']['imaging']['total_called'] > 0) {
        $stats['department_metrics']['imaging']['avg_wait_time'] = round($stats['department_metrics']['imaging']['total_wait_time'] / $stats['department_metrics']['imaging']['total_called'], 2);
    }
    if ($stats['department_metrics']['clinics']['total_called'] > 0) {
        $stats['department_metrics']['clinics']['avg_wait_time'] = round($stats['department_metrics']['clinics']['total_wait_time'] / $stats['department_metrics']['clinics']['total_called'], 2);
    }

    // Compute stage timing averages and store details
    $stats['stage_timings']['avg_arrival_to_billing_wait'] = count($stage_arrivals_to_billing) > 0 ? round(array_sum($stage_arrivals_to_billing) / count($stage_arrivals_to_billing), 2) : 0;
    $stats['stage_timings']['min_arrival_to_billing_wait'] = count($stage_arrivals_to_billing) > 0 ? round(min($stage_arrivals_to_billing), 2) : 0;
    $stats['stage_timings']['max_arrival_to_billing_wait'] = count($stage_arrivals_to_billing) > 0 ? round(max($stage_arrivals_to_billing), 2) : 0;
    
    $stats['stage_timings']['avg_in_process_duration'] = count($stage_in_process) > 0 ? round(array_sum($stage_in_process) / count($stage_in_process), 2) : 0;
    $stats['stage_timings']['min_in_process_duration'] = count($stage_in_process) > 0 ? round(min($stage_in_process), 2) : 0;
    $stats['stage_timings']['max_in_process_duration'] = count($stage_in_process) > 0 ? round(max($stage_in_process), 2) : 0;
    
    $stats['stage_timings']['avg_waiting_to_served_duration'] = count($stage_waiting_to_served) > 0 ? round(array_sum($stage_waiting_to_served) / count($stage_waiting_to_served), 2) : 0;
    
    // Store detailed patient data for each stage
    $stats['stage_timings']['details'] = [
        'arrival_to_billing' => $stage_details['arrival_to_billing'],
        'in_process' => $stage_details['in_process'],
        'waiting_to_served' => $stage_details['waiting_to_served']
    ];

    // 5. Get skipped patients with clear timeline
    // Note: Skipped status means patient was skipped before being called to any department or mid-service
    $skipped_pairs = executeAndFetch($pdo, "
        SELECT DISTINCT DATE(t.arrival_timestamp) as arr_date, t.queue_number, p.mrn
        FROM tickets t
        JOIN patients p ON t.patient_id = p.patient_id
        WHERE t.arrival_timestamp >= ? AND t.arrival_timestamp < ?
        AND t.service_type IN (" . implode(',', array_fill(0, count($service_types), '?')) . ")
        AND t.current_status = 'Skipped'
        ORDER BY t.arrival_timestamp DESC
    ", buildQueryParams($start_date, $end_date_inclusive, $service_types));
    
    // Get corresponding grouped data for each skipped patient
    $stats['skipped_patients'] = [];
    
    foreach ($skipped_pairs as $pair) {
        $group = executeAndFetchOne($pdo, "SELECT * FROM (" . $group_query . ") t WHERE t.queue_number = ? AND DATE(t.arrival_ts) = ?", [$pair['queue_number'], $pair['arr_date']]);
        if ($group) {
            $timeline = computePatientTimeline($group, $pdo);
            
            // Determine when skip occurred
            $skip_data = executeAndFetchOne($pdo, "SELECT MAX(t.closing_timestamp) as skip_time FROM tickets t WHERE t.queue_number = ? AND DATE(t.arrival_timestamp) = ? AND t.current_status = 'Skipped'", [$pair['queue_number'], $pair['arr_date']]);
            $skip_time = $skip_data['skip_time'];
            
            if ($timeline['first_call_time']) {
                $wait_before_skip = $timeline['wait_time_minutes'];
                $time_on_hold = 0;
            } else {
                // Skipped before being called
                $wait_before_skip = round((strtotime($skip_time) - strtotime($timeline['arrival_time'])) / 60, 1);
                $time_on_hold = 0;
            }
            
            $stats['skipped_patients'][] = [
                'id' => md5($pair['queue_number'] . $pair['mrn']),
                'queue_number' => $pair['queue_number'],
                'mrn' => $pair['mrn'],
                'arrival_timestamp' => $timeline['arrival_time'],
                'first_call_time' => $timeline['first_call_time'],
                'skip_time' => $skip_time,
                'wait_before_skip' => max(0, $wait_before_skip),
                'first_dept' => $timeline['first_department'],
                'total_service_time' => $timeline['total_time_minutes'],
                'current_status' => 'Skipped'
            ];
        }
    }
    
    $stats['skipped_count'] = count($stats['skipped_patients']);

    // 6. Get completed patients with clear timeline
    // Timeline: Arrival → Wait → First Call → Service → Closing → Billing
    $completed_groups = executeAndFetch($pdo, "SELECT * FROM (" . $group_query . ") t WHERE t.last_closing_ts IS NOT NULL ORDER BY t.last_closing_ts DESC", buildQueryParams($start_date, $end_date_inclusive, $service_types));
    
    $stats['completed_patients'] = [];
    $total_service_time = 0;
    $service_time_count = 0;
    
    foreach ($completed_groups as $group) {
        $timeline = computePatientTimeline($group, $pdo);
        
        $stats['completed_patients'][] = [
            'id' => md5($group['queue_number'] . $group['mrn']),
            'queue_number' => $group['queue_number'],
            'mrn' => $group['mrn'],
            'service_type' => $group['service_type'] ?? 'Unknown',
            'arrival_timestamp' => $timeline['arrival_time'],
            'first_call_time' => $timeline['first_call_time'],
            'closing_timestamp' => $timeline['last_closing_time'],
            'approval_timestamp' => $timeline['approval_time'],
            'wait_time' => $timeline['wait_time_minutes'],
            'service_time' => $timeline['service_time_minutes'],
            'total_time' => $timeline['total_time_minutes'],
            'billing_time' => $timeline['billing_time_minutes'],
            'first_dept' => $timeline['first_department'],
            'departments' => implode(', ', array_filter($timeline['departments'])),
            'is_multi_test' => $timeline['is_multi_test']
        ];
        
        if ($timeline['service_time_minutes'] !== null && $timeline['service_time_minutes'] >= 0) {
            $total_service_time += $timeline['service_time_minutes'];
            $service_time_count++;
        }
    }
    
    $stats['completed_count'] = count($stats['completed_patients']);
    $stats['avg_service_time'] = $service_time_count > 0 ? round($total_service_time / $service_time_count, 2) : 0;

    // 7. Get canceled patients with cancellation reason and first department
    $canceled_raw = executeAndFetch($pdo, "
        SELECT 
            t.ticket_id AS id,
            p.patient_name,
            t.queue_number,
            p.mrn,
            t.arrival_timestamp,
            t.closing_timestamp,
            t.current_status,
            CASE
                WHEN t.closing_timestamp IS NOT NULL THEN TIMESTAMPDIFF(MINUTE, t.arrival_timestamp, t.closing_timestamp)
                ELSE TIMESTAMPDIFF(MINUTE, t.arrival_timestamp, NOW())
            END as time_before_cancel
        FROM tickets t
        JOIN patients p ON t.patient_id = p.patient_id
        WHERE t.arrival_timestamp >= ? AND t.arrival_timestamp < ?
        AND t.service_type IN (" . implode(',', array_fill(0, count($service_types), '?')) . ")
        AND t.current_status = 'Canceled'
        ORDER BY t.closing_timestamp DESC
    ", buildQueryParams($start_date, $end_date_inclusive, $service_types));
    
    // Compute first_dept for each canceled patient
    $stats['canceled_patients'] = [];
    foreach ($canceled_raw as $patient) {
        $timeline = computePatientTimeline($patient, $pdo);
        $stats['canceled_patients'][] = [
            'id' => $patient['id'],
            'patient_name' => $patient['patient_name'],
            'queue_number' => $patient['queue_number'],
            'mrn' => $patient['mrn'],
            'arrival_timestamp' => $patient['arrival_timestamp'],
            'closing_timestamp' => $patient['closing_timestamp'],
            'current_status' => $patient['current_status'],
            'time_before_cancel' => $patient['time_before_cancel'],
            'first_dept' => $timeline['first_department']
        ];
    }
    $stats['canceled_count'] = count($stats['canceled_patients']);

    // 7b. Get wrong info patients with timeline
    $wrong_info_raw = executeAndFetch($pdo, "
        SELECT 
            t.ticket_id AS id,
            p.patient_name,
            t.queue_number,
            p.mrn,
            t.arrival_timestamp,
            t.current_status,
            TIMESTAMPDIFF(MINUTE, t.arrival_timestamp, NOW()) as time_in_status
        FROM tickets t
        JOIN patients p ON t.patient_id = p.patient_id
        WHERE t.arrival_timestamp >= ? AND t.arrival_timestamp < ?
        AND t.service_type IN (" . implode(',', array_fill(0, count($service_types), '?')) . ")
        AND t.current_status = 'Wrong Info'
        ORDER BY t.arrival_timestamp DESC
    ", buildQueryParams($start_date, $end_date_inclusive, $service_types));
    
    // Process wrong info patients
    $stats['wrong_info_patients'] = [];
    foreach ($wrong_info_raw as $patient) {
        $timeline = computePatientTimeline($patient, $pdo);
        $stats['wrong_info_patients'][] = [
            'id' => $patient['id'],
            'patient_name' => $patient['patient_name'],
            'queue_number' => $patient['queue_number'],
            'mrn' => $patient['mrn'],
            'arrival_timestamp' => $patient['arrival_timestamp'],
            'current_status' => $patient['current_status'],
            'time_in_status' => $patient['time_in_status'],
            'first_dept' => $timeline['first_department']
        ];
    }
    $stats['wrong_info_count'] = count($stats['wrong_info_patients']);

    // Count completions and cancellations by department (NOW that both arrays are populated)
    foreach ($stats['completed_patients'] as $patient) {
        $dept = strtolower($patient['first_dept'] ?? '');
        if ($dept === 'lab') {
            $stats['department_metrics']['lab']['completed']++;
        } elseif ($dept === 'imaging') {
            $stats['department_metrics']['imaging']['completed']++;
        }
    }
    
    foreach ($stats['skipped_patients'] as $patient) {
        $dept = strtolower($patient['first_dept'] ?? '');
        if ($dept === 'lab') {
            $stats['department_metrics']['lab']['skipped']++;
        } elseif ($dept === 'imaging') {
            $stats['department_metrics']['imaging']['skipped']++;
        }
    }

    // 8. Get billing audit data with clear timeline
    // Timeline: Arrival → Service → Approval (billing start) → Closing (billing end)
    $billing_groups = executeAndFetch($pdo, "SELECT * FROM (" . $group_query . ") t WHERE t.earliest_approval_ts IS NOT NULL ORDER BY t.earliest_approval_ts DESC", buildQueryParams($start_date, $end_date_inclusive, $service_types));
    
    $stats['billing_actions'] = [];
    $billing_completed = 0;
    $billing_canceled = 0;
    $total_billing_time = 0;
    $billing_time_count = 0;
    
    foreach ($billing_groups as $group) {
        $timeline = computePatientTimeline($group, $pdo);
        
        // Get current status for this patient
        $status_result = executeAndFetchOne($pdo, "SELECT DISTINCT current_status FROM tickets WHERE queue_number = ? AND DATE(arrival_timestamp) = DATE(?) LIMIT 1", [$group['queue_number'], $group['arrival_ts']]);
        $current_status = $status_result['current_status'] ?? 'Unknown';
        
        $stats['billing_actions'][] = [
            'id' => md5($group['queue_number'] . $group['mrn']),
            'queue_number' => $group['queue_number'],
            'mrn' => $group['mrn'],
            'service_type' => $group['service_type'],
            'patient_name' => 'N/A', // Not in grouped query
            'arrival_timestamp' => $timeline['arrival_time'],
            'approval_timestamp' => $timeline['approval_time'],
            'closing_timestamp' => $timeline['last_closing_time'],
            'billing_time_minutes' => $timeline['billing_time_minutes'],
            'wait_time' => $timeline['wait_time_minutes'],
            'service_time' => $timeline['service_time_minutes'],
            'current_status' => $current_status
        ];
        
        // Track billing stats
        if ($current_status === 'Completed' || $current_status === 'Served') {
            $billing_completed++;
        } elseif ($current_status === 'Canceled') {
            $billing_canceled++;
        }
        
        if ($timeline['billing_time_minutes'] !== null && $timeline['billing_time_minutes'] >= 0) {
            $total_billing_time += $timeline['billing_time_minutes'];
            $billing_time_count++;
        }
    }
    
    $stats['billing_total'] = count($stats['billing_actions']);
    $stats['billing_completed'] = $billing_completed;
    $stats['billing_canceled'] = $billing_canceled;
    $stats['avg_billing_time'] = $billing_time_count > 0 ? round($total_billing_time / $billing_time_count, 2) : 0;

    // Note: MRN filter is now handled through the standard waiting_times display
    // Patients can click any row to view timeline (no separate MRN filter needed)

    // 9. Inter-test wait analysis for multi-test patients
    // For patients with multiple tests, compute idle gaps between tests (end of test N → call for test N+1)
    // Also track on-hold durations separately within service window
    
    $stats['inter_test'] = [
        'multi_test_patient_count' => 0,
        'avg_inter_test_wait' => 0,
        'total_inter_test_wait' => 0,
        'avg_on_hold_minutes' => 0,
        'top_offenders' => []
    ];

    // Get multi-test patients (more than 1 ticket)
    $multi_groups = executeAndFetch($pdo, "SELECT * FROM (" . $group_query . ") t WHERE t.ticket_count > 1 ORDER BY t.arrival_ts DESC", buildQueryParams($start_date, $end_date_inclusive, $service_types));

    $all_inter_test_waits = [];
    $all_on_hold_durations = [];
    $offenders = [];

    // Note: $ticketStmt and $holdStmt are used with executeAndFetch in the foreach loop below

    foreach ($multi_groups as $group) {
        $qn = $group['queue_number'];
        $day = date('Y-m-d', strtotime($group['arrival_ts']));
        
        // Get all individual tickets for this logical patient
        $tickets = executeAndFetch($pdo, "
            SELECT 
                t.ticket_id AS id, 
                t.queue_number,
                p.mrn,
                t.arrival_timestamp,
                t.imaging_machine,
                t.imaging_call_time, 
                t.lab_call_time,
                t.closing_timestamp,
                t.current_status
            FROM tickets t
            JOIN patients p ON t.patient_id = p.patient_id
            WHERE t.queue_number = ? AND DATE(t.arrival_timestamp) = ?
            ORDER BY COALESCE(t.closing_timestamp, t.imaging_call_time, t.lab_call_time, t.arrival_timestamp) ASC
        ", [$qn, $day]);

        if (count($tickets) < 2) continue; // Skip if less than 2 tickets

        // Helper: get call time for a ticket (earliest of lab or imaging)
        $getCallTime = function($ticket) {
            $lab = $ticket['lab_call_time'];
            $img = $ticket['imaging_call_time'];
            if ($lab && $img) {
                return min(strtotime($lab), strtotime($img)) == strtotime($lab) ? $lab : $img;
            }
            return $lab ?: $img;
        };

        // Stage 1: Calculate inter-test waits
        // Inter-test wait = time from end of test N to call for test N+1 (idle gap between tests)
        $group_inter_waits = [];
        for ($i = 0; $i < count($tickets) - 1; $i++) {
            $curr_ticket = $tickets[$i];
            $next_ticket = $tickets[$i + 1];

            $curr_closing = $curr_ticket['closing_timestamp'];
            $next_call = $getCallTime($next_ticket);

            if ($curr_closing && $next_call) {
                $wait_seconds = strtotime($next_call) - strtotime($curr_closing);
                $wait_minutes = round($wait_seconds / 60, 1);

                if ($wait_minutes >= 0) {
                    $group_inter_waits[] = [
                        'from_ticket' => $i + 1,
                        'to_ticket' => $i + 2,
                        'wait_minutes' => $wait_minutes
                    ];
                    $all_inter_test_waits[] = $wait_minutes;
                }
            }
        }

        // Stage 2: Calculate on-hold durations during service
        // On-hold time = duration patient was on hold status during service window
        $group_on_hold = 0;
        foreach ($tickets as $ticket_idx => $ticket) {
            $holds = executeAndFetch($pdo, "
                SELECT 
                    created_at,
                    to_status
                FROM ticket_logs 
                WHERE ticket_id = ? AND action = 'Status Changed' AND to_status = 'On Hold'
                ORDER BY created_at ASC
            ", [$ticket['id']]);

            foreach ($holds as $hold_entry) {
                $hold_start = $hold_entry['created_at'];
                
                // Find end of hold (next status change or ticket closing)
                $end_result = executeAndFetchOne($pdo, "
                    SELECT MIN(created_at) as end_time FROM ticket_logs 
                    WHERE ticket_id = ? AND created_at > ? AND to_status != 'On Hold'
                ", [$ticket['id'], $hold_start]);
                $hold_end = $end_result['end_time'] ?? $ticket['closing_timestamp'] ?? date('Y-m-d H:i:s');

                if ($hold_end) {
                    $hold_mins = round((strtotime($hold_end) - strtotime($hold_start)) / 60, 1);
                    $group_on_hold += max(0, $hold_mins);
                }
            }
        }

        // Accumulate statistics
        $total_inter_wait = array_sum(array_column($group_inter_waits, 'wait_minutes'));
        if ($total_inter_wait > 0) {
            $all_on_hold_durations[] = $group_on_hold;
            $offenders[] = [
                'queue_number' => $qn,
                'mrn' => $group['mrn'],
                'total_inter_wait' => $total_inter_wait,
                'inter_wait_count' => count($group_inter_waits),
                'on_hold_minutes' => $group_on_hold
            ];
        }
    }

    // Compute aggregate statistics
    $stats['inter_test']['multi_test_patient_count'] = count($multi_groups);
    $stats['inter_test']['total_inter_test_wait'] = round(array_sum($all_inter_test_waits), 1);
    $stats['inter_test']['avg_inter_test_wait'] = count($all_inter_test_waits) > 0 ? round(array_sum($all_inter_test_waits) / count($all_inter_test_waits), 2) : 0;
    $stats['inter_test']['avg_on_hold_minutes'] = count($all_on_hold_durations) > 0 ? round(array_sum($all_on_hold_durations) / count($all_on_hold_durations), 2) : 0;

    // Sort offenders by total inter-test wait (descending)
    usort($offenders, function($a, $b) { 
        return $b['total_inter_wait'] <=> $a['total_inter_wait']; 
    });
    $stats['inter_test']['top_offenders'] = array_slice($offenders, 0, 10);

    // 10. Calculate ticket type breakdown
    $type_breakdown = executeAndFetch($pdo, "
        SELECT 
            service_type,
            COUNT(*) as count,
            COUNT(DISTINCT patient_id) as patient_count
        FROM tickets t
        WHERE t.arrival_timestamp >= ? AND t.arrival_timestamp < ?
        AND t.service_type IN (" . implode(',', array_fill(0, count($service_types), '?')) . ")
        GROUP BY service_type
    ", buildQueryParams($start_date, $end_date_inclusive, $service_types));
    
    $stats['type_breakdown'] = [];
    $total_type_tickets = 0;
    foreach ($type_breakdown as $row) {
        $stats['type_breakdown'][$row['service_type']] = $row;
        $total_type_tickets += $row['count'];
    }
    
    // Calculate percentages
    foreach ($stats['type_breakdown'] as &$type_data) {
        $type_data['percentage'] = $total_type_tickets > 0 ? round(($type_data['count'] / $total_type_tickets) * 100, 1) : 0;
    }
    unset($type_data);

    // Apply multi-test filter if enabled
    if ($multi_test_only) {
        $stats['waiting_times'] = array_filter($stats['waiting_times'], function($patient) {
            return isset($patient['is_multi_test']) && $patient['is_multi_test'];
        });
        
        $stats['completed_patients'] = array_filter($stats['completed_patients'], function($patient) {
            return isset($patient['is_multi_test']) && $patient['is_multi_test'];
        });
        
        // Recalculate totals for filtered data
        $stats['completed_count'] = count($stats['completed_patients']);
    }

} catch (Exception $e) {
    $error_message = "Error fetching statistics: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistics Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="statistics.css">
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <div class="dashboard-container">
        <!-- Header and Filter Section -->
        <div class="dashboard-header">
            <h1>
                <i class="fas fa-chart-bar"></i>
                Statistics Dashboard
            </h1>

            <form method="GET" class="filter-section" style="grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); grid-auto-flow: dense; align-items: end; gap: 15px;">
                <div class="form-group">
                    <label for="start_date">Start Date</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
                </div>
                <div class="form-group">
                    <label for="end_date">End Date</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
                </div>
                <div class="form-group">
                    <label for="search">Search by Name/MRN/Queue</label>
                    <input type="text" id="search" name="search" placeholder="Enter name, MRN, or queue #" value="<?php echo htmlspecialchars($search ?? ''); ?>">
                </div>
                <div class="form-group" style="display: flex; flex-direction: column; gap: 8px; grid-column: span 2;">
                    <label style="margin: 0; font-weight: 600; color: #2c3e50;">Ticket Type:</label>
                    <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                        <label style="display: flex; align-items: center; gap: 6px; margin: 0; cursor: pointer;">
                            <input type="checkbox" name="service_types[]" value="Appointment" <?php echo in_array('Appointment', $service_types) ? 'checked' : ''; ?> style="cursor: pointer;">
                            <span style="font-size: 13px; color: #1565c0;">Appointment</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 6px; margin: 0; cursor: pointer;">
                            <input type="checkbox" name="service_types[]" value="Private" <?php echo in_array('Private', $service_types) ? 'checked' : ''; ?> style="cursor: pointer;">
                            <span style="font-size: 13px; color: #7b1fa2;">Private</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 6px; margin: 0; cursor: pointer;">
                            <input type="checkbox" name="service_types[]" value="Guarantor" <?php echo in_array('Guarantor', $service_types) ? 'checked' : ''; ?> style="cursor: pointer;">
                            <span style="font-size: 13px; color: #2e7d32;">Guarantor</span>
                        </label>
                    </div>
                </div>
                <div class="form-group" style="display: flex; align-items: center; gap: 8px;">
                    <label for="multi_test_filter" style="margin: 0;">
                        <input type="checkbox" id="multi_test_filter" name="multi_test_filter" value="on" style="margin-right: 5px;" <?php echo $multi_test_only ? 'checked' : ''; ?> onchange="document.querySelector('form').submit();">
                        Multi-Test Only
                    </label>
                </div>
                <div class="filter-buttons">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Filter
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='statistics.php'">
                        <i class="fas fa-redo"></i> Reset
                    </button>
                </div>
            </form>
        </div>

        <!-- Error Message -->
        <?php if (isset($error_message)): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <!-- Active Filters Summary -->
        <div style="background: white; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
            <div style="display: flex; align-items: center; flex-wrap: wrap; gap: 15px;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-filter" style="color: #667eea; font-size: 16px;"></i>
                    <span style="font-weight: 600; color: #2c3e50;">Active Filters:</span>
                </div>
                <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                    <span style="background: #e3f2fd; color: #1565c0; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500;">
                        📅 <?php echo date('M d', strtotime($start_date)); ?> - <?php echo date('M d, Y', strtotime($end_date)); ?>
                    </span>
                    <?php foreach ($service_types as $type): ?>
                        <span style="background: <?php 
                            if ($type === 'Appointment') echo '#e3f2fd; color: #1565c0;';
                            elseif ($type === 'Private') echo '#f3e5f5; color: #7b1fa2;';
                            elseif ($type === 'Guarantor') echo '#e8f5e9; color: #2e7d32;';
                            else echo '#fff3e0; color: #e65100;';
                        ?>; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500;">
                            🎫 <?php echo $type; ?>
                        </span>
                    <?php endforeach; ?>
                    <?php if (!empty($search)): ?>
                        <span style="background: #f3e5f5; color: #7b1fa2; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500;">
                            🔍 <?php echo htmlspecialchars($search); ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Export Section -->
        <div style="background: #f5f7fa; padding: 20px; border-radius: 8px; margin-bottom: 30px; border-left: 4px solid #2980b9;">
            <h3 style="margin-top: 0; color: #2980b9;">
                <i class="fas fa-download"></i> Export Data
            </h3>
            <button onclick="exportToExcel('<?php echo $start_date; ?>', '<?php echo $end_date; ?>')" class="btn btn-primary" style="margin-right: 10px;">
                <i class="fas fa-file-excel"></i> Export to Excel
            </button>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">
                <i class="fas fa-info-circle"></i> Export transaction records for the selected date range to Excel
            </p>
        </div>

        <!-- Patient MRN Search Section -->
        <div style="background: #f9f3e6; padding: 20px; border-radius: 8px; margin-bottom: 30px; border-left: 4px solid #e67e22;">
            <h3 style="margin-top: 0; color: #e67e22;">
                <i class="fas fa-search"></i> Search Patient by MRN
            </h3>
            <div style="display: flex; gap: 10px; margin-bottom: 15px;">
                <input type="text" id="mrnSearchInput" placeholder="Enter MRN" style="flex: 1; padding: 10px 12px; border: 2px solid #ecf0f1; border-radius: 6px; font-size: 14px;">
                <button onclick="searchPatientByMRN()" class="btn btn-primary">
                    <i class="fas fa-search"></i> Search
                </button>
                <button onclick="clearMRNSearch()" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Clear
                </button>
            </div>
            <p style="font-size: 12px; color: #666;">
                <i class="fas fa-info-circle"></i> Enter a patient MRN to view all their tickets. Click any ticket to view the timeline.
            </p>

            <!-- Patient Search Results -->
            <div id="mrnSearchResults" style="display: none; margin-top: 20px;">
                <div style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #ddd;">
                    <h4 id="patientInfoHeader" style="margin-top: 0; color: #2c3e50; border-bottom: 2px solid #e67e22; padding-bottom: 10px;"></h4>
                    <table class="stats-table" id="patientTicketsTable" style="width: 100%; margin-top: 15px;">
                        <thead>
                            <tr>
                                <th>Queue #</th>
                                <th>Date</th>
                                <th>Department</th>
                                <th>Type</th>
                                <th>Arrival</th>
                                <th>First Call</th>
                                <th>Closing</th>
                                <th>Wait (min)</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="patientTicketsBody">
                        </tbody>
                    </table>
                </div>
            </div>

            <div id="mrnSearchError" style="display: none; margin-top: 15px; background: #fadbd8; border-left: 4px solid #e74c3c; padding: 15px; border-radius: 4px; color: #c0392b;">
                <i class="fas fa-exclamation-circle"></i> <span id="mrnSearchErrorText"></span>
            </div>
        </div>

        <!-- Ticket Type Breakdown -->
        <div style="background: white; padding: 25px; border-radius: 12px; margin-bottom: 30px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
            <h2 style="color: #2c3e50; margin-bottom: 20px; font-size: 18px; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-chart-doughnut" style="color: #667eea;"></i>
                Ticket Type Distribution
            </h2>
            
            <?php 
            $type_colors = [
                'Appointment' => ['bg' => '#e3f2fd', 'color' => '#1565c0', 'icon' => '📅'],
                'Private' => ['bg' => '#f3e5f5', 'color' => '#7b1fa2', 'icon' => '👤'],
                'Guarantor' => ['bg' => '#e8f5e9', 'color' => '#2e7d32', 'icon' => '🏢'],
                'Clinics' => ['bg' => '#fff3e0', 'color' => '#e65100', 'icon' => '🏥']
            ];
            $total_in_filtered = 0;
            foreach ($stats['type_breakdown'] as $type_data) {
                $total_in_filtered += $type_data['count'];
            }
            ?>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 20px;">
                <?php foreach ($stats['type_breakdown'] as $type_name => $type_data): 
                    $type_info = $type_colors[$type_name] ?? ['bg' => '#f0f0f0', 'color' => '#666', 'icon' => '📄'];
                    $bar_width = $type_data['percentage'];
                ?>
                <div style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; background: <?php echo $type_info['bg']; ?>; border-left: 4px solid <?php echo $type_info['color']; ?>;">
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                        <span style="font-size: 24px;"><?php echo $type_info['icon']; ?></span>
                        <div>
                            <div style="font-weight: 600; color: #2c3e50; font-size: 16px;"><?php echo $type_name; ?></div>
                            <div style="font-size: 12px; color: #7f8c8d;">Ticket Type</div>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 12px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                            <span style="font-size: 14px; font-weight: 600; color: <?php echo $type_info['color']; ?>"><?php echo $type_data['count']; ?> tickets</span>
                            <span style="font-size: 14px; font-weight: 600; color: #667eea;"><?php echo $type_data['percentage']; ?>%</span>
                        </div>
                        <div style="background: rgba(255,255,255,0.5); height: 6px; border-radius: 3px; overflow: hidden; border: 1px solid <?php echo $type_info['color']; ?>;">
                            <div style="background: <?php echo $type_info['color']; ?>; height: 100%; width: <?php echo $bar_width; ?>%; transition: width 0.3s ease;"></div>
                        </div>
                    </div>
                    
                    <div style="font-size: 12px; color: #7f8c8d; padding-top: 8px; border-top: 1px solid rgba(0,0,0,0.1);">
                        <strong><?php echo $type_data['patient_count']; ?></strong> unique patients
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Summary Stats -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px;">
                <div style="text-align: center; padding: 10px 0;">
                    <div style="font-size: 28px; font-weight: bold; margin-bottom: 5px;"><?php echo $total_in_filtered; ?></div>
                    <div style="font-size: 13px; opacity: 0.9;">Total Tickets</div>
                </div>
                <div style="text-align: center; padding: 10px 0; border-left: 1px solid rgba(255,255,255,0.2); border-right: 1px solid rgba(255,255,255,0.2);">
                    <div style="font-size: 28px; font-weight: bold; margin-bottom: 5px;"><?php echo $stats['total_patients']; ?></div>
                    <div style="font-size: 13px; opacity: 0.9;">Unique Patients</div>
                </div>
                <div style="text-align: center; padding: 10px 0;">
                    <div style="font-size: 28px; font-weight: bold; margin-bottom: 5px;"><?php echo count($stats['type_breakdown']); ?></div>
                    <div style="font-size: 13px; opacity: 0.9;">Types Selected</div>
                </div>
            </div>
        </div>
            

        <!-- DEPARTMENT PERFORMANCE - PRIMARY FOCUS -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #2c3e50; margin-bottom: 20px; font-size: 20px;">
                <i class="fas fa-hospital"></i> Department Performance
            </h2>
            <div class="statistics-grid">
                <!-- Laboratory Department -->
                <div class="stat-card" style="background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%); border-left: 4px solid #388e3c;">
                    <i class="fas fa-flask" style="color: #388e3c;"></i>
                    <h3>Laboratory</h3>
                    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div>
                            <div class="stat-value" style="color: #388e3c;"><?php echo $stats['department_metrics']['lab']['total_called']; ?></div>
                            <div class="stat-unit">Patients Called</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #1b5e20;"><?php echo $stats['department_metrics']['lab']['avg_wait_time']; ?></div>
                            <div class="stat-unit">Avg Wait (min)</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #27ae60; font-size: 24px;"><?php echo $stats['department_metrics']['lab']['completed']; ?></div>
                            <div class="stat-unit">Completed</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #ff9800; font-size: 24px;"><?php echo $stats['department_metrics']['lab']['skipped']; ?></div>
                            <div class="stat-unit">Skipped</div>
                        </div>
                    </div>
                </div>

                <!-- Imaging Department -->
                <div class="stat-card" style="background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); border-left: 4px solid #1565c0;">
                    <i class="fas fa-camera" style="color: #1565c0;"></i>
                    <h3>Imaging</h3>
                    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div>
                            <div class="stat-value" style="color: #1565c0;"><?php echo $stats['department_metrics']['imaging']['total_called']; ?></div>
                            <div class="stat-unit">Patients Called</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #0d47a1;"><?php echo $stats['department_metrics']['imaging']['avg_wait_time']; ?></div>
                            <div class="stat-unit">Avg Wait (min)</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #27ae60; font-size: 24px;"><?php echo $stats['department_metrics']['imaging']['completed']; ?></div>
                            <div class="stat-unit">Completed</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #ff9800; font-size: 24px;"><?php echo $stats['department_metrics']['imaging']['skipped']; ?></div>
                            <div class="stat-unit">Skipped</div>
                        </div>
                    </div>
                </div>

                <!-- Clinics Department -->
                <div class="stat-card" style="background: linear-gradient(135deg, #fef6e9 0%, #f8e1c1 100%); border-left: 4px solid #9a5c0d;">
                    <i class="fas fa-clinic-medical" style="color: #9a5c0d;"></i>
                    <h3>Clinics</h3>
                    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div>
                            <div class="stat-value" style="color: #9a5c0d;"><?php echo $stats['department_metrics']['clinics']['total_called']; ?></div>
                            <div class="stat-unit">Patients Called</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #6d3e06;"><?php echo $stats['department_metrics']['clinics']['avg_wait_time']; ?></div>
                            <div class="stat-unit">Avg Wait (min)</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #27ae60; font-size: 24px;"><?php echo $stats['department_metrics']['clinics']['completed']; ?></div>
                            <div class="stat-unit">Completed</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #ff9800; font-size: 24px;"><?php echo $stats['department_metrics']['clinics']['skipped']; ?></div>
                            <div class="stat-unit">Skipped</div>
                        </div>
                    </div>
                </div>

                <!-- Overall Statistics -->
                <div class="stat-card" style="background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%); border-left: 4px solid #7b1fa2;">
                    <i class="fas fa-chart-pie" style="color: #7b1fa2;"></i>
                    <h3>Overall Summary</h3>
                    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div>
                            <div class="stat-value" style="color: #7b1fa2;"><?php echo $stats['total_patients']; ?></div>
                            <div class="stat-unit">Total Patients</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #512da8;"><?php echo $stats['avg_waiting_time']; ?></div>
                            <div class="stat-unit">Avg Wait (min)</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #27ae60; font-size: 24px;"><?php echo $stats['completed_count']; ?></div>
                            <div class="stat-unit">Completed</div>
                        </div>
                        <div>
                            <div class="stat-value" style="color: #ff9800; font-size: 24px;"><?php echo $stats['skipped_count']; ?></div>
                            <div class="stat-unit">Skipped</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- BILLING PERFORMANCE -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #2c3e50; margin-bottom: 20px; font-size: 20px;">
                <i class="fas fa-credit-card"></i> Billing Performance
            </h2>
            <div class="statistics-grid">
                <!-- Pickup Time Card -->
                <div class="stat-card" style="background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%); border-left: 4px solid #f57c00;">
                    <i class="fas fa-hourglass-start" style="color: #e65100;"></i>
                    <h3>Ticket Start Time</h3>
                    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div style="background: white; padding: 10px; border-radius: 6px; text-align: center;">
                            <div style="font-size: 11px; color: #666; margin-bottom: 3px;">Average</div>
                            <div class="stat-value" style="color: #f57c00; font-size: 24px;"><?php echo $stats['stage_timings']['avg_arrival_to_billing_wait']; ?></div>
                            <div style="font-size: 10px; color: #999;">min</div>
                        </div>
                        <div style="background: white; padding: 10px; border-radius: 6px; text-align: center;">
                            <div style="font-size: 11px; color: #666; margin-bottom: 3px;">Range</div>
                            <div style="font-size: 13px; color: #d84315; font-weight: 600;">
                                <?php echo $stats['stage_timings']['min_arrival_to_billing_wait']; ?> - <?php echo $stats['stage_timings']['max_arrival_to_billing_wait']; ?>
                            </div>
                            <div style="font-size: 10px; color: #999;">min</div>
                        </div>
                    </div>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #ffe0b2; text-align: center;">
                        <div style="font-size: 12px; color: #666;">
                            <strong><?php echo count($stats['stage_timings']['details']['arrival_to_billing']); ?></strong> tickets tracked
                        </div>
                    </div>
                </div>

                <!-- In-Process Duration Card -->
                <div class="stat-card" style="background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%); border-left: 4px solid #7b1fa2;">
                    <i class="fas fa-hourglass-end" style="color: #6a1b9a;"></i>
                    <h3>Billing Approval Time</h3>
                    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div style="background: white; padding: 10px; border-radius: 6px; text-align: center;">
                            <div style="font-size: 11px; color: #666; margin-bottom: 3px;">Average</div>
                            <div class="stat-value" style="color: #7b1fa2; font-size: 24px;"><?php echo $stats['stage_timings']['avg_in_process_duration']; ?></div>
                            <div style="font-size: 10px; color: #999;">min</div>
                        </div>
                        <div style="background: white; padding: 10px; border-radius: 6px; text-align: center;">
                            <div style="font-size: 11px; color: #666; margin-bottom: 3px;">Range</div>
                            <div style="font-size: 13px; color: #512da8; font-weight: 600;">
                                <?php echo $stats['stage_timings']['min_in_process_duration']; ?> - <?php echo $stats['stage_timings']['max_in_process_duration']; ?>
                            </div>
                            <div style="font-size: 10px; color: #999;">min</div>
                        </div>
                    </div>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #e1bee7; text-align: center;">
                        <div style="font-size: 12px; color: #666;">
                            <strong><?php echo count($stats['stage_timings']['details']['in_process']); ?></strong> tickets tracked
                        </div>
                    </div>
                    <div style="margin-top: 8px; font-size: 11px; color: #7b1fa2; background: #f8f0ff; padding: 6px; border-radius: 4px; text-align: center;">
                        💡 Billing processing time per ticket
                    </div>
                </div>

                <!-- Total Billing Cycle Card -->
                <div class="stat-card" style="background: linear-gradient(135deg, #e8eaf6 0%, #c5cae9 100%); border-left: 4px solid #3f51b5;">
                    <i class="fas fa-sync-alt" style="color: #3949ab;"></i>
                    <h3>Billing Cycle</h3>
                    <div style="margin-top: 15px; display: grid; grid-template-columns: 1fr; gap: 10px;">
                        <div style="background: white; padding: 12px; border-radius: 6px;">
                            <div style="font-size: 11px; color: #666; margin-bottom: 5px;">Pickup → Complete</div>
                            <div style="display: flex; justify-content: space-around; align-items: center;">
                                <div style="text-align: center;">
                                    <div style="font-size: 18px; font-weight: bold; color: #f57c00;">
                                        <?php echo $stats['stage_timings']['avg_arrival_to_billing_wait']; ?>
                                    </div>
                                    <div style="font-size: 10px; color: #999;">Pickup</div>
                                </div>
                                <div style="color: #999; font-size: 20px;">+</div>
                                <div style="text-align: center;">
                                    <div style="font-size: 18px; font-weight: bold; color: #7b1fa2;">
                                        <?php echo $stats['stage_timings']['avg_in_process_duration']; ?>
                                    </div>
                                    <div style="font-size: 10px; color: #999;">Processing</div>
                                </div>
                                <div style="color: #999; font-size: 20px;">=</div>
                                <div style="text-align: center;">
                                    <div style="font-size: 18px; font-weight: bold; color: #3949ab;">
                                        <?php echo round($stats['stage_timings']['avg_arrival_to_billing_wait'] + $stats['stage_timings']['avg_in_process_duration'], 2); ?>
                                    </div>
                                    <div style="font-size: 10px; color: #999;">Total</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #c5cae9; text-align: center;">
                        <div style="font-size: 11px; color: #666;">
                            Average time from arrival to end of billing process
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- STAGE-BY-STAGE TIMING -->
        <div style="margin-bottom: 30px;">
            <h2 style="color: #2c3e50; margin-bottom: 20px; font-size: 20px;">
                <i class="fas fa-stream"></i> Stage Timings (Patient Journey)
            </h2>
            <div class="statistics-grid">
                <div class="stat-card" style="background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%); border-left: 4px solid #7b1fa2; cursor: pointer;" onclick="showStageBreakdown('in_process', 'In-Process Duration', 'Time spent in processing/billing status', <?php echo json_encode($stats['stage_timings']['details']['in_process'] ?? []); ?>)">
                    <i class="fas fa-cog" style="color: #6a1b9a;"></i>
                    <h3>Serving Duration</h3>
                    <div class="stat-value" style="color: #6a1b9a;"><?php echo $stats['avg_service_time']; ?></div>
                    <div class="stat-unit">Avg service (min)</div>
                </div>
                <div class="stat-card" style="background: linear-gradient(135deg, #e0f2f1 0%, #b2dfdb 100%); border-left: 4px solid #00796b; cursor: pointer;" onclick="showStageBreakdown('waiting_to_served', 'Waiting to Served', 'Time from waiting to first service call', <?php echo json_encode($stats['stage_timings']['details']['waiting_to_served'] ?? []); ?>)">
                    <i class="fas fa-phone" style="color: #004d40;"></i>
                    <h3>Waiting to be Served</h3>
                    <div class="stat-value" style="color: #004d40;"><?php echo $stats['stage_timings']['avg_waiting_to_served_duration']; ?></div>
                    <div class="stat-unit">Avg to call (min)</div>
                </div>
            </div>
        </div>

        <!-- Data Quality Warning -->
        <?php if ($stats['data_quality_issues'] > 0): ?>
            <div style="background: #fff3cd; border: 1px solid #ffc107; padding: 15px; border-radius: 6px; margin-bottom: 30px; display: flex; align-items: flex-start; gap: 10px;">
                <i class="fas fa-exclamation-triangle" style="color: #ff9800; margin-top: 2px;"></i>
                <div>
                    <strong style="color: #856404;">Data Quality Warning:</strong>
                    <p style="margin: 5px 0 0 0; color: #856404; font-size: 13px;">
                        <?php echo $stats['data_quality_issues']; ?> patient record(s) have negative wait times (system/data integrity issue). 
                        These records were excluded from the average calculation.
                    </p>
                </div>
            </div>
        <?php endif; ?>

        
        <!-- Charts Section -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px;">
            <!-- Peak Arrival Times Chart -->
            <div class="chart-container">
                <h3 style="color: #3498db; margin-bottom: 20px;">
                    <i class="fas fa-chart-line"></i> Peak Arrival Times (Hourly)
                </h3>
                <div style="position: relative; height: 300px;">
                    <canvas id="peakArrivalsChart"></canvas>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 15px; font-size: 12px;">
                    <div style="background: #e3f2fd; padding: 8px; border-radius: 4px; text-align: center;">
                        <strong style="color: #1976d2;">Peak Hour:</strong>
                        <div id="peakHour" style="color: #666; margin-top: 3px;">-</div>
                    </div>
                    <div style="background: #e8f5e9; padding: 8px; border-radius: 4px; text-align: center;">
                        <strong style="color: #388e3c;">Peak Count:</strong>
                        <div id="peakCount" style="color: #666; margin-top: 3px;">-</div>
                    </div>
                    <div style="background: #fff3e0; padding: 8px; border-radius: 4px; text-align: center;">
                        <strong style="color: #f57c00;">Avg/Hour:</strong>
                        <div id="avgPerHour" style="color: #666; margin-top: 3px;">-</div>
                    </div>
                </div>
            </div>

            <!-- Patients Per Day Chart -->
            <div class="chart-container">
                <h3 style="color: #27ae60; margin-bottom: 20px;">
                    <i class="fas fa-chart-bar"></i> Patients Per Day
                </h3>
                <div style="position: relative; height: 300px;">
                    <canvas id="patientsPerDayChart"></canvas>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 15px; font-size: 12px;">
                    <div style="background: #e8f5e9; padding: 8px; border-radius: 4px; text-align: center;">
                        <strong style="color: #388e3c;">Busiest Day:</strong>
                        <div id="busiestDay" style="color: #666; margin-top: 3px;">-</div>
                    </div>
                    <div style="background: #e3f2fd; padding: 8px; border-radius: 4px; text-align: center;">
                        <strong style="color: #1976d2;">Total Period:</strong>
                        <div id="totalPeriod" style="color: #666; margin-top: 3px;"><?php echo $stats['total_patients']; ?></div>
                    </div>
                    <div style="background: #f3e5f5; padding: 8px; border-radius: 4px; text-align: center;">
                        <strong style="color: #7b1fa2;">Daily Avg:</strong>
                        <div id="dailyAvg" style="color: #666; margin-top: 3px;">-</div>
                    </div>
                </div>
            </div>
        </div>


        <!-- Skip/Cancel Quick Actions -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
            <div style="background: #fff3e0; padding: 20px; border-radius: 8px; border-left: 4px solid #f39c12;">
                <h3 style="margin-top: 0; color: #f39c12;">
                    <i class="fas fa-forward"></i> View Skipped Tickets
                </h3>
                <p style="margin: 0; font-size: 12px; color: #666; margin-bottom: 12px;">
                    Patients who were skipped in the queue
                </p>
                <button onclick="showSkipCancelTickets('<?php echo $start_date; ?>', '<?php echo $end_date; ?>', 'skip')" class="btn btn-primary" style="background: #f39c12; border: none;">
                    View <?php echo $stats['skipped_count']; ?> Skipped Records
                </button>
            </div>
            <div style="background: #ffe6e6; padding: 20px; border-radius: 8px; border-left: 4px solid #e74c3c;">
                <h3 style="margin-top: 0; color: #e74c3c;">
                    <i class="fas fa-times-circle"></i> View Canceled Tickets
                </h3>
                <p style="margin: 0; font-size: 12px; color: #666; margin-bottom: 12px;">
                    Patients whose tickets were canceled
                </p>
                <button onclick="showSkipCancelTickets('<?php echo $start_date; ?>', '<?php echo $end_date; ?>', 'cancel')" class="btn btn-primary" style="background: #e74c3c; border: none;">
                    View <?php echo $stats['canceled_count']; ?> Canceled Records
                </button>
            </div>
        </div>

        <!-- Waiting Times Analysis -->
        <div class="chart-container">
            <h2>
                <i class="fas fa-hourglass-half"></i>
                Waiting Times Between Arrival and First Department Call
            </h2>
            <p style="font-size: 13px; color: #7f8c8d; margin-bottom: 10px;">
                <i class="fas fa-info-circle"></i> Filtered by: 
                <?php foreach (['Appointment', 'Private', 'Guarantor'] as $type): 
                    $is_active = in_array($type, $service_types);
                ?>
                    <span class="waiting-filter-pill" data-service-type="<?php echo $type; ?>" data-active="<?php echo $is_active ? '1' : '0'; ?>" style="display: inline-block; background: <?php 
                        if ($type === 'Appointment') echo '#e3f2fd; color: #1565c0;';
                        elseif ($type === 'Private') echo '#f3e5f5; color: #7b1fa2;';
                        elseif ($type === 'Guarantor') echo '#e8f5e9; color: #2e7d32;';
                    ?>; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; margin-right: 6px; cursor: pointer; border: 2px solid <?php 
                        if ($type === 'Appointment') echo '#1565c0';
                        elseif ($type === 'Private') echo '#7b1fa2';
                        elseif ($type === 'Guarantor') echo '#2e7d32';
                    ?>; opacity: <?php echo $is_active ? '1' : '0.4'; ?>; transition: all 0.2s;">
                        <?php echo $type; ?>
                    </span>
                <?php endforeach; ?>
            </p>
            <p style="font-size: 13px; color: #7f8c8d; margin-bottom: 15px;">
                <i class="fas fa-info-circle"></i> Click on any row to view the patient's complete timeline
            </p>
            <!-- Department Filter Buttons -->
            <div style="margin-bottom: 15px; display: flex; gap: 8px;">
                <button id="filterAllWaiting" class="btn btn-active" onclick="filterWaitingTimesByDept('all')" style="background: #7b1fa2; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">
                    <i class="fas fa-list"></i> All Departments
                </button>
                <button id="filterLabWaiting" class="btn" onclick="filterWaitingTimesByDept('lab')" style="background: #e8f5e9; color: #388e3c; border: 2px solid #388e3c; padding: 8px 16px; border-radius: 4px; cursor: pointer;">
                    <i class="fas fa-flask"></i> Lab Only
                </button>
                <button id="filterImagingWaiting" class="btn" onclick="filterWaitingTimesByDept('imaging')" style="background: #e3f2fd; color: #1565c0; border: 2px solid #1565c0; padding: 8px 16px; border-radius: 4px; cursor: pointer;">
                    <i class="fas fa-camera"></i> Imaging Only
                </button>
                <button id="filterClinicsWaiting" class="btn" onclick="filterWaitingTimesByDept('clinics')" style="background: #fef6e9; color: #9a5c0d; border: 2px solid #9a5c0d; padding: 8px 16px; border-radius: 4px; cursor: pointer;">
                    <i class="fas fa-clinic-medical"></i> Clinics Only
                </button>
            </div>
            <?php if (!empty($stats['waiting_times'])): ?>
                <div class="table-scroll" style="max-height:400px; overflow-y:auto;">
                <table class="waiting-times-table" id="waitingTimesTable">
                    <thead>
                        <tr>
                            <th>Queue #</th>
                            <th>MRN</th>
                            <th>Patient Name</th>
                            <th>Ticket Type</th>
                            <th>Arrival Time</th>
                            <th>First Department</th>
                            <th>Wait Time (minutes)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats['waiting_times'] as $wait_data): 
                            $has_data_issue = $wait_data['wait_minutes'] !== null && $wait_data['wait_minutes'] < 0;
                            $dept_class = strtolower($wait_data['first_dept'] ?? 'unknown');
                            
                            // Get type badge styling
                            $type_style = '';
                            if ($wait_data['service_type'] === 'Appointment') {
                                $type_style = 'background: #e3f2fd; color: #1565c0;';
                            } elseif ($wait_data['service_type'] === 'Private') {
                                $type_style = 'background: #f3e5f5; color: #7b1fa2;';
                            } elseif ($wait_data['service_type'] === 'Guarantor') {
                                $type_style = 'background: #e8f5e9; color: #2e7d32;';
                            }
                        ?>
                            <tr class="waiting-row waiting-row-<?php echo $dept_class; ?>" data-patient-id="<?php echo $wait_data['id']; ?>" data-mrn="<?php echo htmlspecialchars($wait_data['mrn'] ?? ''); ?>" data-arrival="<?php echo htmlspecialchars($wait_data['arrival_timestamp']); ?>" data-dept="<?php echo $dept_class; ?>" data-service-type="<?php echo $wait_data['service_type']; ?>" style="<?php echo $has_data_issue ? 'background-color: #fff3cd;' : ''; ?>">
                                <td><?php echo htmlspecialchars($wait_data['queue_number']); ?></td>
                                <td style="font-size: 12px; color: #7f8c8d;"><?php echo htmlspecialchars($wait_data['mrn'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($wait_data['patient_name']); ?></td>
                                <td><span style="<?php echo $type_style; ?> padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; display: inline-block;"><?php echo $wait_data['service_type']; ?></span></td>
                                <td><?php echo date('M d, Y H:i', strtotime($wait_data['arrival_timestamp'])); ?></td>
                                <td>
                                    <span class="dept-badge <?php echo strtolower($wait_data['first_dept']); ?>">
                                        <?php echo $wait_data['first_dept']; ?>
                                    </span>
                                </td>
                                <td><?php echo $wait_data['wait_minutes'] !== null && $wait_data['wait_minutes'] >= 0 ? $wait_data['wait_minutes'] : ($has_data_issue ? '<span title="Data integrity issue">⚠ ' . $wait_data['wait_minutes'] . '</span>' : '-'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-inbox"></i>
                    <p>No waiting time data available for the selected period</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Skipped Patients Section -->
        <div id="skippedPatientsSection">
        <div class="chart-container" style="border-left: 4px solid #ff9800;">
            <h3 style="color: #ff9800;">
                <i class="fas fa-exclamation-circle"></i> Skipped Patients
                <span class="stat-badge" style="background-color: #ff9800;"><?php echo $stats['skipped_count'] ?? 0; ?></span>
            </h3>
            <?php if (!empty($stats['skipped_patients'])): ?>
                <p class="help-text" style="font-size: 12px; color: #666; margin-bottom: 15px;">
                    <i class="fas fa-info-circle"></i> Click any row to view the patient's timeline
                </p>
                <table class="stats-table">
                    <thead>
                        <tr>
                            <th>Queue #</th>
                            <th>MRN</th>
                            <th>Arrival<br/>(Stage 1)</th>
                            <th>First Call<br/>(if any)</th>
                            <th>Skip Time</th>
                            <th>Wait Before Skip<br/>(min)</th>
                            <th>Department</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats['skipped_patients'] as $skip_data): 
                            $wait_issue = $skip_data['wait_before_skip'] !== null && $skip_data['wait_before_skip'] < 0;
                        ?>
                            <tr data-patient-id="<?php echo $skip_data['id']; ?>" data-mrn="<?php echo htmlspecialchars($skip_data['mrn'] ?? ''); ?>" style="cursor: pointer; transition: background-color 0.2s; font-size: 12px; <?php echo $wait_issue ? 'background-color: #fff3cd;' : ''; ?>">
                                <td><strong><?php echo htmlspecialchars($skip_data['queue_number']); ?></strong></td>
                                <td style="color: #7f8c8d;"><?php echo htmlspecialchars($skip_data['mrn'] ?? 'N/A'); ?></td>
                                <td><?php echo date('H:i:s', strtotime($skip_data['arrival_timestamp'])); ?></td>
                                <td><?php echo $skip_data['first_call_time'] ? date('H:i:s', strtotime($skip_data['first_call_time'])) : '(None)'; ?></td>
                                <td><?php echo $skip_data['skip_time'] ? date('H:i:s', strtotime($skip_data['skip_time'])) : '-'; ?></td>
                                <td style="text-align: center; font-weight: bold;">
                                    <?php echo $skip_data['wait_before_skip'] !== null && $skip_data['wait_before_skip'] >= 0 ? number_format($skip_data['wait_before_skip'], 1) : ($wait_issue ? '⚠' : '-'); ?>
                                </td>
                                <td><?php echo htmlspecialchars($skip_data['first_dept'] ?? 'N/A'); ?></td>
                                <td>
                                    <span class="status-badge" style="background-color: #ff9800; color: white; padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold;">
                                        <?php echo htmlspecialchars($skip_data['current_status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-check-circle"></i>
                    <p>No skipped patients in the selected period</p>
                </div>
            <?php endif; ?>
        </div>
        </div>

        <!-- Completed Patients Section -->
        <div id="completedPatientsSection">
        <div class="chart-container" style="border-left: 4px solid #27ae60;">
            <h3 style="color: #27ae60;">
                <i class="fas fa-check-circle"></i> Completed Patients
                <span class="stat-badge" style="background-color: #27ae60;"><?php echo $stats['completed_count'] ?? 0; ?></span>
            </h3>
            <p style="font-size: 13px; color: #7f8c8d; margin-bottom: 10px;">
                <i class="fas fa-info-circle"></i> Filtered by: 
                <?php foreach (['Appointment', 'Private', 'Guarantor'] as $type): 
                    $is_active = in_array($type, $service_types);
                ?>
                    <span class="completed-filter-pill" data-service-type="<?php echo $type; ?>" data-active="<?php echo $is_active ? '1' : '0'; ?>" style="display: inline-block; background: <?php 
                        if ($type === 'Appointment') echo '#e3f2fd; color: #1565c0;';
                        elseif ($type === 'Private') echo '#f3e5f5; color: #7b1fa2;';
                        elseif ($type === 'Guarantor') echo '#e8f5e9; color: #2e7d32;';
                    ?>; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; margin-right: 6px; cursor: pointer; border: 2px solid <?php 
                        if ($type === 'Appointment') echo '#1565c0';
                        elseif ($type === 'Private') echo '#7b1fa2';
                        elseif ($type === 'Guarantor') echo '#2e7d32';
                    ?>; opacity: <?php echo $is_active ? '1' : '0.4'; ?>; transition: all 0.2s;">
                        <?php echo $type; ?>
                    </span>
                <?php endforeach; ?>
            </p>
            <?php if (!empty($stats['completed_patients'])): ?>
                <p class="help-text" style="font-size: 12px; color: #666; margin-bottom: 15px;">
                    <i class="fas fa-info-circle"></i> Click any row to view the patient's timeline
                </p>
                <div class="table-scroll" style="max-height:400px; overflow-y:auto;">
                <table class="stats-table" id="completedPatientsTable">
                    <thead>
                        <tr>
                            <th>Queue #</th>
                            <th>MRN</th>
                            <th>Arrival<br/>(Stage 1)</th>
                            <th>First Call<br/>(Stage 3)</th>
                            <th>Wait<br/>(min)</th>
                            <th>Service<br/>(min)</th>
                            <th>Closed<br/>(Stage 5)</th>
                            <th>Total<br/>(min)</th>
                            <th>Billing<br/>(min)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats['completed_patients'] as $comp_data): 
                            $has_data_issue = ($comp_data['total_time'] !== null && $comp_data['total_time'] < 0) || ($comp_data['service_time'] !== null && $comp_data['service_time'] < 0);
                        ?>
                            <tr data-patient-id="<?php echo $comp_data['id']; ?>" data-mrn="<?php echo htmlspecialchars($comp_data['mrn'] ?? ''); ?>" data-service-type="<?php echo $comp_data['service_type'] ?? 'Unknown'; ?>" style="cursor: pointer; transition: background-color 0.2s; font-size: 12px; <?php echo $has_data_issue ? 'background-color: #fff3cd;' : ''; ?>">
                                <td><strong><?php echo htmlspecialchars($comp_data['queue_number']); ?></strong></td>
                                <td style="color: #7f8c8d;"><?php echo htmlspecialchars($comp_data['mrn'] ?? 'N/A'); ?></td>
                                <td><?php echo $comp_data['arrival_timestamp'] ? date('H:i:s', strtotime($comp_data['arrival_timestamp'])) : '-'; ?></td>
                                <td><?php echo $comp_data['first_call_time'] ? date('H:i:s', strtotime($comp_data['first_call_time'])) : '-'; ?></td>
                                <td style="text-align: center; font-weight: bold; <?php echo ($comp_data['wait_time'] ?? 0) > 30 ? 'color: #e74c3c;' : ''; ?>">
                                    <?php echo $comp_data['wait_time'] !== null && $comp_data['wait_time'] >= 0 ? number_format($comp_data['wait_time'], 1) : '-'; ?>
                                </td>
                                <td style="text-align: center; font-weight: bold;">
                                    <?php echo $comp_data['service_time'] !== null && $comp_data['service_time'] >= 0 ? number_format($comp_data['service_time'], 1) : ($has_data_issue ? '⚠' : '-'); ?>
                                </td>
                                <td><?php echo $comp_data['closing_timestamp'] ? date('H:i:s', strtotime($comp_data['closing_timestamp'])) : '-'; ?></td>
                                <td style="text-align: center; font-weight: bold;">
                                    <?php echo $comp_data['total_time'] !== null && $comp_data['total_time'] >= 0 ? number_format($comp_data['total_time'], 1) : ($has_data_issue ? '⚠' : '-'); ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php echo $comp_data['billing_time'] !== null && $comp_data['billing_time'] >= 0 ? number_format($comp_data['billing_time'], 1) : '-'; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-inbox"></i>
                    <p>No completed patients in the selected period</p>
                </div>
            <?php endif; ?>
        </div>
        </div>

        <!-- Canceled Tickets Section -->
        <div id="canceledPatientsSection">
        <div class="chart-container" style="border-left: 4px solid #e74c3c;">
            <h3 style="color: #e74c3c;">
                <i class="fas fa-times-circle"></i> Canceled Tickets
                <span class="stat-badge" style="background-color: #e74c3c;"><?php echo $stats['canceled_count'] ?? 0; ?></span>
            </h3>
            <?php if (!empty($stats['canceled_patients'])): ?>
                <p class="help-text" style="font-size: 12px; color: #666; margin-bottom: 15px;">
                    <i class="fas fa-info-circle"></i> Click any row to view the patient's timeline
                </p>
                <table class="stats-table">
                    <thead>
                        <tr>
                            <th>Queue #</th>
                            <th>MRN</th>
                            <th>Patient Name</th>
                            <th>Arrival Time</th>
                            <th>Cancellation Time</th>
                            <th>Time Before Cancel (min)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats['canceled_patients'] as $cancel_data): ?>
                            <tr data-patient-id="<?php echo $cancel_data['id']; ?>" data-mrn="<?php echo htmlspecialchars($cancel_data['mrn'] ?? ''); ?>" style="cursor: pointer; transition: background-color 0.2s;">
                                <td><?php echo htmlspecialchars($cancel_data['queue_number']); ?></td>
                                <td style="font-size: 12px; color: #7f8c8d;"><?php echo htmlspecialchars($cancel_data['mrn'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($cancel_data['patient_name']); ?></td>
                                <td><?php echo date('M d, Y H:i', strtotime($cancel_data['arrival_timestamp'])); ?></td>
                                <td><?php echo $cancel_data['closing_timestamp'] ? date('M d, Y H:i', strtotime($cancel_data['closing_timestamp'])) : '-'; ?></td>
                                <td><strong><?php echo $cancel_data['time_before_cancel'] ?? '-'; ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-check-circle"></i>
                    <p>No canceled tickets in the selected period</p>
                </div>
            <?php endif; ?>
        </div>
        </div>

        <!-- Billing Audit Section -->
        <div id="billingActionsSection">
        <div class="chart-container" style="border-left: 4px solid #3498db;">
            <h3 style="color: #3498db;">
                <i class="fas fa-file-invoice-dollar"></i> Billing Audit
                <span class="stat-badge" style="background-color: #3498db;"><?php echo $stats['billing_total'] ?? 0; ?></span>
            </h3>
            <p style="font-size: 13px; color: #7f8c8d; margin-bottom: 10px;">
                <i class="fas fa-info-circle"></i> Filtered by: 
                <?php foreach (['Appointment', 'Private', 'Guarantor'] as $type): 
                    $is_active = in_array($type, $service_types);
                ?>
                    <span class="billing-filter-pill" data-service-type="<?php echo $type; ?>" data-active="<?php echo $is_active ? '1' : '0'; ?>" style="display: inline-block; background: <?php 
                        if ($type === 'Appointment') echo '#e3f2fd; color: #1565c0;';
                        elseif ($type === 'Private') echo '#f3e5f5; color: #7b1fa2;';
                        elseif ($type === 'Guarantor') echo '#e8f5e9; color: #2e7d32;';
                    ?>; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; margin-right: 6px; cursor: pointer; border: 2px solid <?php 
                        if ($type === 'Appointment') echo '#1565c0';
                        elseif ($type === 'Private') echo '#7b1fa2';
                        elseif ($type === 'Guarantor') echo '#2e7d32';
                    ?>; opacity: <?php echo $is_active ? '1' : '0.4'; ?>; transition: all 0.2s;">
                        <?php echo $type; ?>
                    </span>
                <?php endforeach; ?>
            </p>
            <?php if (!empty($stats['billing_actions'])): ?>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px; font-size: 13px;">
                    <div style="background: #d4e9f2; padding: 10px; border-radius: 6px; text-align: center;">
                        <strong style="color: #3498db;" id="billingCompletedStat"><?php echo $stats['billing_completed']; ?></strong>
                        <div style="color: #666; margin-top: 3px;">Completed</div>
                    </div>
                    <div style="background: #ffe6e6; padding: 10px; border-radius: 6px; text-align: center;">
                        <strong style="color: #e74c3c;" id="billingCanceledStat"><?php echo $stats['billing_canceled']; ?></strong>
                        <div style="color: #666; margin-top: 3px;">Canceled</div>
                    </div>
                    <div style="background: #e8f8f5; padding: 10px; border-radius: 6px; text-align: center;">
                        <strong style="color: #16a085;" id="billingAvgTimeStat"><?php echo $stats['avg_billing_time']; ?></strong>
                        <div style="color: #666; margin-top: 3px;">Avg Time (min)</div>
                    </div>
                </div>
                <p class="help-text" style="font-size: 12px; color: #666; margin-bottom: 15px;">
                    <i class="fas fa-info-circle"></i> Click any row to view the patient's timeline
                </p>
                <div class="table-scroll" style="max-height:400px; overflow-y:auto;">
                <table class="stats-table" id="billingAuditTable">
                    <thead>
                        <tr>
                            <th>Queue #</th>
                            <th>MRN</th>
                            <th>Ticket Type</th>
                            <th>Arrival<br/>(Stage 1)</th>
                            <th>Approval<br/>(Billing Start)</th>
                            <th>Closing<br/>(Stage 5)</th>
                            <th>Wait<br/>(min)</th>
                            <th>Service<br/>(min)</th>
                            <th>Billing<br/>(min)</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stats['billing_actions'] as $billing_data): 
                            // Get type badge styling
                            $type_style = '';
                            if ($billing_data['service_type'] === 'Appointment') {
                                $type_style = 'background: #e3f2fd; color: #1565c0;';
                            } elseif ($billing_data['service_type'] === 'Private') {
                                $type_style = 'background: #f3e5f5; color: #7b1fa2;';
                            } elseif ($billing_data['service_type'] === 'Guarantor') {
                                $type_style = 'background: #e8f5e9; color: #2e7d32;';
                            }
                        ?>
                            <tr data-patient-id="<?php echo $billing_data['id']; ?>" data-mrn="<?php echo htmlspecialchars($billing_data['mrn'] ?? ''); ?>" data-service-type="<?php echo $billing_data['service_type']; ?>" style="cursor: pointer; transition: background-color 0.2s; font-size: 12px;">
                                <td><strong><?php echo htmlspecialchars($billing_data['queue_number']); ?></strong></td>
                                <td style="color: #7f8c8d;"><?php echo htmlspecialchars($billing_data['mrn'] ?? 'N/A'); ?></td>
                                <td><span style="<?php echo $type_style; ?> padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; display: inline-block;"><?php echo $billing_data['service_type']; ?></span></td>
                                <td><?php echo $billing_data['arrival_timestamp'] ? date('H:i:s', strtotime($billing_data['arrival_timestamp'])) : '-'; ?></td>
                                <td><?php echo $billing_data['approval_timestamp'] ? date('H:i:s', strtotime($billing_data['approval_timestamp'])) : '-'; ?></td>
                                <td><?php echo $billing_data['closing_timestamp'] ? date('H:i:s', strtotime($billing_data['closing_timestamp'])) : 'Pending'; ?></td>
                                <td style="text-align: center;">
                                    <?php echo $billing_data['wait_time'] !== null && $billing_data['wait_time'] >= 0 ? number_format($billing_data['wait_time'], 1) : '-'; ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php echo $billing_data['service_time'] !== null && $billing_data['service_time'] >= 0 ? number_format($billing_data['service_time'], 1) : '-'; ?>
                                </td>
                                <td style="text-align: center; font-weight: bold;">
                                    <?php echo $billing_data['billing_time_minutes'] !== null && $billing_data['billing_time_minutes'] >= 0 ? number_format($billing_data['billing_time_minutes'], 1) : '-'; ?>
                                </td>
                                <td>
                                    <span style="display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold;
                                        <?php 
                                        if ($billing_data['current_status'] === 'Completed' || $billing_data['current_status'] === 'Served') {
                                            echo "background-color: #d5f4e6; color: #27ae60;";
                                        } elseif ($billing_data['current_status'] === 'Canceled') {
                                            echo "background-color: #ffe6e6; color: #e74c3c;";
                                        } else {
                                            echo "background-color: #fff6e6; color: #f39c12;";
                                        }
                                        ?>">
                                        <?php echo htmlspecialchars($billing_data['current_status']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <i class="fas fa-inbox"></i>
                    <p>No billing actions in the selected period</p>
                </div>
            <?php endif; ?>
        </div>
        </div>
        <!-- Top Offenders (Multi-Test Patients with High Inter-Test Wait) -->
        <?php if (!empty($stats['inter_test']['top_offenders'])): ?>
        <div id="topOffendersSection">
        <div class="chart-container" style="border-left: 4px solid #ff5722;">
            <h3 style="color: #ff5722;">
                <i class="fas fa-exclamation-circle"></i> Top Offenders - Inter-Test Wait
                <span class="stat-badge" style="background-color: #ff5722;"><?php echo count($stats['inter_test']['top_offenders']); ?></span>
            </h3>
            <p class="help-text" style="font-size: 12px; color: #666; margin-bottom: 15px;">
                <i class="fas fa-info-circle"></i> Patients with longest cumulative wait time between tests. These represent workflow bottlenecks.
            </p>
            <table class="stats-table">
                <thead>
                    <tr>
                        <th>Queue #</th>
                        <th>MRN</th>
                        <th>Total Inter-Test Wait (min)</th>
                        <th>Impact</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($stats['inter_test']['top_offenders'] as $idx => $offender): 
                        $impact_class = $offender['total_inter_wait'] > 60 ? 'critical' : ($offender['total_inter_wait'] > 30 ? 'warning' : 'info');
                        $impact_color = $impact_class === 'critical' ? '#e74c3c' : ($impact_class === 'warning' ? '#f39c12' : '#3498db');
                        $impact_bg = $impact_class === 'critical' ? '#fadbd8' : ($impact_class === 'warning' ? '#fdebd0' : '#d6eaf8');
                    ?>
                        <tr style="border-left: 4px solid <?php echo $impact_color; ?>; cursor: pointer; transition: background-color 0.2s;" onclick="openOffenderDetail('<?php echo htmlspecialchars($offender['queue_number']); ?>', '<?php echo htmlspecialchars($offender['mrn'] ?? ''); ?>')">
                            <td style="font-weight: bold; color: #2c3e50;"><?php echo htmlspecialchars($offender['queue_number']); ?></td>
                            <td style="font-size: 12px; color: #7f8c8d;"><?php echo htmlspecialchars($offender['mrn'] ?? 'N/A'); ?></td>
                            <td style="font-weight: bold; color: #2c3e50;"><?php echo $offender['total_inter_wait']; ?></td>
                            <td>
                                <span style="display: inline-block; padding: 4px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; background-color: <?php echo $impact_bg; ?>; color: <?php echo $impact_color; ?>;">
                                    <?php echo strtoupper($impact_class); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        </div>
        <?php endif; ?>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <script>
    // CSV Export utility (no external library needed)
    function downloadCSV(data, filename) {
        // Convert array of objects to CSV with UTF-8 BOM for proper encoding
        if (!data || data.length === 0) {
            alert('No data to export');
            return;
        }
        
        const headers = Object.keys(data[0]);
        const csvLines = [
            headers.join(','),
            ...data.map(row =>
                headers.map(field => {
                    const value = row[field];
                    // Escape quotes and wrap in quotes if contains comma or quotes
                    const escaped = String(value || '').replace(/"/g, '""');
                    return escaped.includes(',') || escaped.includes('"') ? `"${escaped}"` : escaped;
                }).join(',')
            )
        ];
        
        // Add UTF-8 BOM and join lines
        const csvContent = '\uFEFF' + csvLines.join('\n');
        
        // Create blob and download
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    </script>
    <script src="statistics.js"></script>

    <script>
    // Chart colors
    const chartColors = {
        peak: '#3498db',
        daily: '#27ae60',
        border: '#bdc3c7'
    };

    // Peak Arrival Times Chart Data
    const peakHoursData = <?php echo json_encode(array_values($stats['peak_arrival_times'])); ?>;
    const peakHoursLabels = Array.from({length: 24}, (_, i) => (i < 10 ? '0' : '') + i + ':00');

    // Initialize Peak Arrivals Chart
    const peakCtx = document.getElementById('peakArrivalsChart');
    if (peakCtx) {
        const peakChart = new Chart(peakCtx, {
            type: 'bar',
            data: {
                labels: peakHoursLabels,
                datasets: [{
                    label: 'Arrivals',
                    data: peakHoursData,
                    backgroundColor: chartColors.peak,
                    borderColor: chartColors.peak,
                    borderWidth: 0,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#f0f0f0' }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });

        // Calculate peak hour stats
        const maxCount = Math.max(...peakHoursData);
        const peakHourIndex = peakHoursData.indexOf(maxCount);
        const avgPerHour = (peakHoursData.reduce((a, b) => a + b, 0) / 24).toFixed(1);
        
        const peakHourEl = document.getElementById('peakHour');
        const peakCountEl = document.getElementById('peakCount');
        const avgPerHourEl = document.getElementById('avgPerHour');
        
        if (peakHourEl) peakHourEl.textContent = peakHoursLabels[peakHourIndex];
        if (peakCountEl) peakCountEl.textContent = maxCount;
        if (avgPerHourEl) avgPerHourEl.textContent = avgPerHour;
    }

    // Patients Per Day Chart Data
    const patientsPerDayData = <?php echo json_encode($stats['patients_per_day']); ?>;
    const dailyLabels = patientsPerDayData.map(d => {
        const date = new Date(d.date + 'T00:00:00');
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    });
    const dailyCounts = patientsPerDayData.map(d => parseInt(d.count));

    // Initialize Patients Per Day Chart
    const dailyCtx = document.getElementById('patientsPerDayChart');
    if (dailyCtx) {
        const dailyChart = new Chart(dailyCtx, {
            type: 'line',
            data: {
                labels: dailyLabels,
                datasets: [{
                    label: 'Patients',
                    data: dailyCounts,
                    backgroundColor: 'rgba(39, 174, 96, 0.1)',
                    borderColor: chartColors.daily,
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: chartColors.daily,
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#f0f0f0' }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });

        // Calculate daily stats
        const maxDaily = Math.max(...dailyCounts);
        const busiestIndex = dailyCounts.indexOf(maxDaily);
        const dailyAvg = (dailyCounts.reduce((a, b) => a + b, 0) / dailyCounts.length).toFixed(1);
        
        const busiestDayEl = document.getElementById('busiestDay');
        const dailyAvgEl = document.getElementById('dailyAvg');
        
        if (busiestDayEl) busiestDayEl.textContent = dailyLabels[busiestIndex] || '-';
        if (dailyAvgEl) dailyAvgEl.textContent = dailyAvg;
    }

    // Export to CSV function (no external library needed)
    function exportToExcel(startDate, endDate) {
        // Show loading message
        const btn = event.target;
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Exporting...';
        btn.disabled = true;

        fetch('statistics_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'export_excel',
                start_date: startDate,
                end_date: endDate
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data) {
                // Use CSV export instead of XLSX
                const timestamp = new Date().toISOString().split('T')[0];
                const filename = `patient_records_${timestamp}.csv`;
                downloadCSV(data.data, filename);
                
                // Restore button
                btn.innerHTML = originalText;
                btn.disabled = false;
            } else {
                throw new Error(data.message || 'Export failed');
            }
        })
        .catch(err => {
            console.error('Export error:', err);
            alert('Error exporting data: ' + err.message);
            btn.innerHTML = originalText;
            btn.disabled = false;
        });
    }

    // Load billing statistics
    fetch('statistics_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            action: 'get_billing_stats',
            start_date: '<?php echo $start_date; ?>',
            end_date: '<?php echo $end_date; ?>'
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success && data.data) {
            const stats = data.data;
            const avgEl = document.getElementById('avgBillingTime');
            const minEl = document.getElementById('minBillingTime');
            const maxEl = document.getElementById('maxBillingTime');
            const countEl = document.getElementById('totalBillingCount');
            
            if (avgEl) avgEl.textContent = stats.avg_processing_time ? parseFloat(stats.avg_processing_time).toFixed(1) : '-';
            if (minEl) minEl.textContent = stats.min_processing_time || '-';
            if (maxEl) maxEl.textContent = stats.max_processing_time || '-';
            if (countEl) countEl.textContent = stats.total_billing || 0;
        }
    })
    .catch(err => console.error('Error loading billing stats:', err));

    // Function to update billing stats based on visible rows
    function updateBillingStats() {
        const table = document.getElementById('billingAuditTable');
        if (!table) return;

        const rows = table.querySelectorAll('tbody tr');
        let completed = 0, canceled = 0, totalBillingTime = 0, billingTimeCount = 0;

        rows.forEach(row => {
            if (row.style.display === 'none') return; // Skip hidden rows

            // Get status from last cell
            const statusCell = row.cells[9]; // Status is in the 10th column (0-indexed: 9)
            if (!statusCell) return;

            const status = statusCell.textContent.trim();
            const billingTimeCell = row.cells[8]; // Billing time is in the 9th column (0-indexed: 8)
            const billingTime = billingTimeCell ? parseFloat(billingTimeCell.textContent.trim()) : null;

            if (status === 'Completed' || status === 'Served') {
                completed++;
            } else if (status === 'Canceled') {
                canceled++;
            }

            if (billingTime !== null && !isNaN(billingTime)) {
                totalBillingTime += billingTime;
                billingTimeCount++;
            }
        });

        const avgTime = billingTimeCount > 0 ? (totalBillingTime / billingTimeCount).toFixed(2) : '-';

        // Update the display with null checks
        const completedEl = document.getElementById('billingCompletedStat');
        const canceledEl = document.getElementById('billingCanceledStat');
        const avgTimeEl = document.getElementById('billingAvgTimeStat');
        
        if (completedEl) completedEl.textContent = completed;
        if (canceledEl) canceledEl.textContent = canceled;
        if (avgTimeEl) avgTimeEl.textContent = avgTime;
    }

    // Billing Audit Filter Pills - Toggle filtering
    document.querySelectorAll('.billing-filter-pill').forEach(pill => {
        pill.addEventListener('click', function() {
            const serviceType = this.getAttribute('data-service-type');
            const table = document.getElementById('billingAuditTable');
            if (!table) return;

            // Toggle active state of the pill
            const isActive = this.getAttribute('data-active') === '1';
            this.setAttribute('data-active', isActive ? '0' : '1');
            this.style.opacity = isActive ? '0.4' : '1';

            // Get all active filter types
            const activePills = document.querySelectorAll('.billing-filter-pill[data-active="1"]');
            const activeTypes = Array.from(activePills).map(p => p.getAttribute('data-service-type'));

            // Filter table rows
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const rowType = row.getAttribute('data-service-type');
                if (activeTypes.length === 0) {
                    // If no filters selected, show all rows
                    row.style.display = '';
                } else if (activeTypes.includes(rowType)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });

            // Update stats to reflect filtered data
            updateBillingStats();
        });
    });

    // Waiting Times Filter Pills - Toggle filtering
    document.querySelectorAll('.waiting-filter-pill').forEach(pill => {
        pill.addEventListener('click', function() {
            const serviceType = this.getAttribute('data-service-type');
            const table = document.getElementById('waitingTimesTable');
            if (!table) return;

            // Toggle active state of the pill
            const isActive = this.getAttribute('data-active') === '1';
            this.setAttribute('data-active', isActive ? '0' : '1');
            this.style.opacity = isActive ? '0.4' : '1';

            // Get all active filter types
            const activePills = document.querySelectorAll('.waiting-filter-pill[data-active="1"]');
            const activeTypes = Array.from(activePills).map(p => p.getAttribute('data-service-type'));

            // Filter table rows
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const rowType = row.getAttribute('data-service-type');
                if (activeTypes.length === 0) {
                    row.style.display = '';
                } else if (activeTypes.includes(rowType)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    });

    // Completed Patients Filter Pills - Toggle filtering
    document.querySelectorAll('.completed-filter-pill').forEach(pill => {
        pill.addEventListener('click', function() {
            const serviceType = this.getAttribute('data-service-type');
            const table = document.getElementById('completedPatientsTable');
            if (!table) return;

            // Toggle active state of the pill
            const isActive = this.getAttribute('data-active') === '1';
            this.setAttribute('data-active', isActive ? '0' : '1');
            this.style.opacity = isActive ? '0.4' : '1';

            // Get all active filter types
            const activePills = document.querySelectorAll('.completed-filter-pill[data-active="1"]');
            const activeTypes = Array.from(activePills).map(p => p.getAttribute('data-service-type'));

            // Filter table rows
            const rows = table.querySelectorAll('tbody tr');
            rows.forEach(row => {
                const rowType = row.getAttribute('data-service-type');
                if (activeTypes.length === 0) {
                    row.style.display = '';
                } else if (activeTypes.includes(rowType)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    });

    // Open drilldown modal for top offender
    function openOffenderDetail(queueNumber, mrn) {
        // Create modal overlay
        let modal = document.getElementById('offenderDetailModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'offenderDetailModal';
            modal.style.cssText = 'display:none;position:fixed;z-index:1000;left:0;top:0;width:100%;height:100%;background-color:rgba(0,0,0,0.5);';
            
            const content = document.createElement('div');
            content.style.cssText = 'background-color:#fff;margin:5% auto;padding:20px;border:1px solid #888;width:80%;max-width:600px;border-radius:8px;';
            content.innerHTML = `
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                    <h2 style="margin:0;">Patient Detail - Queue #` + queueNumber + ` / MRN: ` + mrn + `</h2>
                    <button onclick="closeOffenderDetail()" style="background:none;border:none;font-size:24px;cursor:pointer;">&times;</button>
                </div>
                <div id="offenderDetailContent" style="max-height:500px;overflow-y:auto;">
                    <p style="text-align:center;"><i class="fas fa-spinner fa-spin"></i> Loading details...</p>
                </div>
            `;
            
            modal.appendChild(content);
            document.body.appendChild(modal);
        }
        
        // Show modal
        modal.style.display = 'block';
        
        // Fetch detail data
        fetch('statistics_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'get_offender_detail',
                queue_number: queueNumber,
                mrn: mrn,
                start_date: '<?php echo $start_date; ?>',
                end_date: '<?php echo $end_date; ?>'
            })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data) {
                renderOffenderDetail(data.data);
            } else {
                document.getElementById('offenderDetailContent').innerHTML = '<p style="color:red;">Error: ' + (data.message || 'Failed to load details') + '</p>';
            }
        })
        .catch(err => {
            console.error('Error loading offender detail:', err);
            document.getElementById('offenderDetailContent').innerHTML = '<p style="color:red;">Error loading details: ' + err.message + '</p>';
        });
    }

    // Render offender detail content
    function renderOffenderDetail(detail) {
        let html = '<div style="font-family:Arial,sans-serif;font-size:14px;">';
        
        if (detail.tickets && detail.tickets.length > 0) {
            html += '<h3>Test Timeline:</h3>';
            html += '<table style="width:100%;border-collapse:collapse;margin-bottom:20px;">';
            html += '<tr style="background:#f5f5f5;"><th style="border:1px solid #ddd;padding:8px;text-align:left;">Date</th><th style="border:1px solid #ddd;padding:8px;text-align:left;">Machine</th><th style="border:1px solid #ddd;padding:8px;text-align:left;">Call Time</th><th style="border:1px solid #ddd;padding:8px;text-align:left;">Status</th></tr>';
            
            for (let i = 0; i < detail.tickets.length; i++) {
                const ticket = detail.tickets[i];
                const date = new Date(ticket.arrival_timestamp).toLocaleDateString();
                const callTime = ticket.call_time ? new Date(ticket.call_time).toLocaleTimeString() : 'N/A';
                html += '<tr style="border:1px solid #ddd;">';
                html += '<td style="border:1px solid #ddd;padding:8px;">' + date + '</td>';
                html += '<td style="border:1px solid #ddd;padding:8px;">' + (ticket.machine || 'N/A') + '</td>';
                html += '<td style="border:1px solid #ddd;padding:8px;">' + callTime + '</td>';
                html += '<td style="border:1px solid #ddd;padding:8px;">' + (ticket.status || 'N/A') + '</td>';
                html += '</tr>';
            }
            
            html += '</table>';
            
            // Show inter-test waits if available
            if (detail.inter_test_waits && detail.inter_test_waits.length > 0) {
                html += '<h3>Inter-Test Waits:</h3>';
                html += '<ul>';
                for (let wait of detail.inter_test_waits) {
                    let waitText = wait.from_machine + ' → ' + wait.to_machine + ': <strong>' + wait.wait_minutes.toFixed(1) + ' min</strong>';
                    if (wait.wait_minutes > 60) {
                        waitText += ' <span style="color:#e74c3c;font-weight:bold;">(CRITICAL)</span>';
                    } else if (wait.wait_minutes > 30) {
                        waitText += ' <span style="color:#f39c12;font-weight:bold;">(WARNING)</span>';
                    }
                    html += '<li>' + waitText + '</li>';
                }
                html += '</ul>';
            }
        } else {
            html += '<p>No ticket details available.</p>';
        }
        
        html += '</div>';
        document.getElementById('offenderDetailContent').innerHTML = html;
    }

    // Close offender detail modal
    function closeOffenderDetail() {
        const modal = document.getElementById('offenderDetailModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    // Close modal when clicking outside of it
    window.onclick = function(event) {
        const modal = document.getElementById('offenderDetailModal');
        if (modal && event.target === modal) {
            modal.style.display = 'none';
        }
    };

    // Filter waiting times by department
    function filterWaitingTimesByDept(dept) {
        // Update button states
        document.getElementById('filterAllWaiting').style.background = dept === 'all' ? '#7b1fa2' : 'transparent';
        document.getElementById('filterAllWaiting').style.color = dept === 'all' ? 'white' : '#7b1fa2';
        
        document.getElementById('filterLabWaiting').style.background = dept === 'lab' ? '#388e3c' : '#e8f5e9';
        document.getElementById('filterLabWaiting').style.color = dept === 'lab' ? 'white' : '#388e3c';
        
        document.getElementById('filterImagingWaiting').style.background = dept === 'imaging' ? '#1565c0' : '#e3f2fd';
        document.getElementById('filterImagingWaiting').style.color = dept === 'imaging' ? 'white' : '#1565c0';

        const clinicsBtn = document.getElementById('filterClinicsWaiting');
        if (clinicsBtn) {
            clinicsBtn.style.background = dept === 'clinics' ? '#9a5c0d' : '#fef6e9';
            clinicsBtn.style.color = dept === 'clinics' ? 'white' : '#9a5c0d';
        }
        
        // Show/hide rows
        const rows = document.querySelectorAll('.waiting-row');
        rows.forEach(row => {
            if (dept === 'all') {
                row.style.display = '';
            } else {
                row.style.display = row.getAttribute('data-dept') === dept ? '' : 'none';
            }
        });
    }

    // Show billing extremes (min/max processing time records)
    function showBillingExtremes(type, startDate, endDate) {
        fetch('statistics_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'get_billing_extremes',
                type: type,
                start_date: startDate,
                end_date: endDate
            })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success && data.data) {
                let modal = document.getElementById('billingExtremesModal');
                if (!modal) {
                    modal = document.createElement('div');
                    modal.id = 'billingExtremesModal';
                    modal.style.cssText = 'position:fixed;z-index:1000;left:0;top:0;width:100%;height:100%;background:rgba(0,0,0,0.5);display:none;overflow:auto;';
                    document.body.appendChild(modal);
                }
                
                const title = type === 'max' ? 'Records with Maximum Processing Time' : 'Records with Minimum Processing Time';
                const htmlContent = `
                    <div style="background:white;margin:5%;width:90%;border-radius:8px;">
                        <div style="padding:20px;border-bottom:1px solid #ddd;">
                            <h2 style="margin:0;color:#2c3e50;">${title}</h2>
                        </div>
                        <div style="padding:20px;max-height:600px;overflow-y:auto;">
                            <table style="width:100%;border-collapse:collapse;">
                                <thead>
                                    <tr style="background:#f5f5f5;">
                                        <th style="border:1px solid #ddd;padding:10px;text-align:left;">Queue #</th>
                                        <th style="border:1px solid #ddd;padding:10px;text-align:left;">Patient Name</th>
                                        <th style="border:1px solid #ddd;padding:10px;text-align:left;">MRN</th>
                                        <th style="border:1px solid #ddd;padding:10px;text-align:left;">Approval Time</th>
                                        <th style="border:1px solid #ddd;padding:10px;text-align:left;">Processing Time (min)</th>
                                        <th style="border:1px solid #ddd;padding:10px;text-align:left;">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${data.data.map(record => `
                                        <tr style="border:1px solid #ddd;cursor:pointer;" onclick="showPatientTimeline('${record.id}', '', '${record.mrn}', '${record.queue_number}', '${record.approval_timestamp}')">
                                            <td style="border:1px solid #ddd;padding:10px;">${record.queue_number}</td>
                                            <td style="border:1px solid #ddd;padding:10px;">${record.patient_name || 'N/A'}</td>
                                            <td style="border:1px solid #ddd;padding:10px;">${record.mrn || 'N/A'}</td>
                                            <td style="border:1px solid #ddd;padding:10px;">${new Date(record.approval_timestamp).toLocaleString()}</td>
                                            <td style="border:1px solid #ddd;padding:10px;font-weight:bold;color:${type === 'max' ? '#e74c3c' : '#27ae60'};">${record.processing_time_minutes || '-'}</td>
                                            <td style="border:1px solid #ddd;padding:10px;">${record.current_status}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                        <div style="padding:15px;border-top:1px solid #ddd;text-align:right;">
                            <button onclick="closeBillingExtremesModal()" style="background:#ccc;border:none;padding:8px 16px;border-radius:4px;cursor:pointer;">Close</button>
                        </div>
                    </div>
                `;
                modal.innerHTML = htmlContent;
                modal.style.display = 'block';
            }
        })
        .catch(err => console.error('Error loading billing extremes:', err));
    }

    function closeBillingExtremesModal() {
        const modal = document.getElementById('billingExtremesModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    // Search patient by MRN
    function searchPatientByMRN() {
        const mrn = document.getElementById('mrnSearchInput').value.trim();
        const resultsDiv = document.getElementById('mrnSearchResults');
        const errorDiv = document.getElementById('mrnSearchError');
        const errorText = document.getElementById('mrnSearchErrorText');
        
        if (!mrn) {
            if (errorDiv) errorDiv.style.display = 'block';
            if (errorText) errorText.textContent = 'Please enter an MRN to search.';
            if (resultsDiv) resultsDiv.style.display = 'none';
            return;
        }

        // Fetch patient tickets by MRN
        fetch('statistics_api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action: 'get_patient_by_mrn',
                mrn: mrn,
                start_date: '<?php echo $start_date; ?>',
                end_date: '<?php echo $end_date; ?>'
            })
        })
        .then(r => r.json())
        .then(data => {
            if (errorDiv) errorDiv.style.display = 'none';
            if (data.success && data.data) {
                const patient = data.data;
                const tickets = patient.tickets || [];
                
                // Check if tickets is an array
                if (!Array.isArray(tickets)) {
                    if (errorDiv) errorDiv.style.display = 'block';
                    if (errorText) errorText.textContent = 'Invalid response data format.';
                    if (resultsDiv) resultsDiv.style.display = 'none';
                    return;
                }
                
                const headerEl = document.getElementById('patientInfoHeader');
                if (headerEl) {
                    headerEl.innerHTML = `<strong>${patient.patient_name || 'Unknown'}</strong> (MRN: ${patient.mrn}) - ${tickets.length} ticket(s)`;
                }
                
                const tbody = document.getElementById('patientTicketsBody');
                if (tbody) {
                    tbody.innerHTML = '';
                    
                    tickets.forEach(ticket => {
                        const typeColor = 
                            ticket.service_type === 'Appointment' ? '#1565c0' :
                            ticket.service_type === 'Private' ? '#7b1fa2' :
                            ticket.service_type === 'Guarantor' ? '#2e7d32' : '#666';
                        
                        const row = document.createElement('tr');
                        row.style.cursor = 'pointer';
                        row.style.transition = 'background-color 0.2s';
                        row.onclick = function() {
                            showPatientTimeline(ticket.id, patient.patient_name, patient.mrn, ticket.queue_number, ticket.arrival_timestamp);
                        };
                        
                        row.innerHTML = `
                            <td><strong>${ticket.queue_number}</strong></td>
                            <td>${new Date(ticket.arrival_timestamp).toLocaleDateString()}</td>
                            <td>${ticket.department || '-'}</td>
                            <td><span style="background: ${typeColor === '#1565c0' ? '#e3f2fd' : typeColor === '#7b1fa2' ? '#f3e5f5' : '#e8f5e9'}; color: ${typeColor}; padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; display: inline-block;">${ticket.service_type}</span></td>
                            <td>${ticket.arrival_timestamp ? new Date(ticket.arrival_timestamp).toLocaleTimeString() : '-'}</td>
                            <td>${ticket.first_call_timestamp ? new Date(ticket.first_call_timestamp).toLocaleTimeString() : '-'}</td>
                            <td>${ticket.closing_timestamp ? new Date(ticket.closing_timestamp).toLocaleTimeString() : 'Pending'}</td>
                            <td style="text-align: center;">${ticket.wait_minutes !== null && ticket.wait_minutes >= 0 ? Math.round(ticket.wait_minutes) : '-'}</td>
                            <td>${ticket.status || '-'}</td>
                        `;
                        tbody.appendChild(row);
                    });
                }
                
                if (resultsDiv) resultsDiv.style.display = 'block';
            } else {
                if (errorDiv) errorDiv.style.display = 'block';
                if (errorText) errorText.textContent = data.message || 'Patient not found.';
                if (resultsDiv) resultsDiv.style.display = 'none';
            }
        })
        .catch(err => {
            console.error('Search error:', err);
            if (errorDiv) errorDiv.style.display = 'block';
            if (errorText) errorText.textContent = 'Error searching for patient: ' + err.message;
            resultsDiv.style.display = 'none';
        });
    }

    // Clear MRN search
    function clearMRNSearch() {
        document.getElementById('mrnSearchInput').value = '';
        document.getElementById('mrnSearchResults').style.display = 'none';
        document.getElementById('mrnSearchError').style.display = 'none';
        document.getElementById('mrnSearchInput').focus();
    }

    // Allow Enter key to search
    document.getElementById('mrnSearchInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchPatientByMRN();
        }
    });
    </script>
</body>
</html>

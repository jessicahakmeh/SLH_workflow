/**
 * Test Suite for Cross-Page Status Updates
 * Tests the RefreshManager and realtime_updates.php integration
 * 
 * Usage:
 * 1. Open multiple pages in different browser tabs (butler.php, imaging.php, laboratory.php)
 * 2. Run this test file in browser console on each page
 * 3. Monitor status updates across tabs
 */

class CrossPageStatusTester {
    constructor() {
        this.testResults = [];
        this.eventListeners = [];
        this.isTestRunning = false;
    }
    
    /**
     * Initialize test environment
     */
    init() {
        console.log('%c=== CROSS-PAGE STATUS UPDATE TESTER ===', 'color: blue; font-size: 16px; font-weight: bold;');
        console.log('Available commands:');
        console.log('  tester.testSSEConnection()     - Test SSE connectivity');
        console.log('  tester.testFocusPreservation() - Test focus state preservation');
        console.log('  tester.testFormState()         - Test form value preservation');
        console.log('  tester.testStatusBroadcast()   - Test status event broadcasting');
        console.log('  tester.testMachineAssignment() - Test imaging machine assignment');
        console.log('  tester.runAllTests()           - Run complete test suite');
        console.log('  tester.getResults()            - Display test results');
        console.log('');
        
        // Make tester globally available
        window.tester = this;
    }
    
    /**
     * Test 1: SSE Connection
     */
    testSSEConnection() {
        console.log('%c[TEST 1] Testing SSE Connection', 'color: green; font-weight: bold;');
        
        if (!window.EventSource) {
            this.logResult('SSE_SUPPORT', false, 'EventSource not supported in this browser');
            return;
        }
        
        const testSSE = new EventSource('realtime_updates.php?stream=all');
        let sseWorking = false;
        let eventCount = 0;
        
        const timeout = setTimeout(() => {
            testSSE.close();
            this.logResult('SSE_CONNECTION', sseWorking || eventCount > 0, 
                `Connected and received ${eventCount} events`);
        }, 5000);
        
        testSSE.addEventListener('status_update', (e) => {
            eventCount++;
            sseWorking = true;
            console.log('✓ Received status_update event:', JSON.parse(e.data));
        });
        
        testSSE.addEventListener('machine_assignment', (e) => {
            eventCount++;
            sseWorking = true;
            console.log('✓ Received machine_assignment event:', JSON.parse(e.data));
        });
        
        testSSE.addEventListener('new_arrival', (e) => {
            eventCount++;
            sseWorking = true;
            console.log('✓ Received new_arrival event:', JSON.parse(e.data));
        });
        
        testSSE.addEventListener('heartbeat', (e) => {
            console.log('✓ Received heartbeat:', JSON.parse(e.data));
        });
        
        testSSE.onerror = (error) => {
            testSSE.close();
            clearTimeout(timeout);
            this.logResult('SSE_CONNECTION', false, 'SSE connection error: ' + error);
        };
    }
    
    /**
     * Test 2: Focus Preservation
     */
    testFocusPreservation() {
        console.log('%c[TEST 2] Testing Focus Preservation', 'color: green; font-weight: bold;');
        
        if (!window.refreshManager) {
            this.logResult('FOCUS_PRESERVATION', false, 'RefreshManager not loaded');
            return;
        }
        
        // Create test element
        const testInput = document.createElement('input');
        testInput.id = 'test-focus-input';
        testInput.type = 'text';
        testInput.value = 'Test Focus';
        document.body.appendChild(testInput);
        
        // Focus the input
        testInput.focus();
        const focusedBefore = document.activeElement === testInput;
        
        console.log(`Before refresh: Focused element = ${testInput.id}, value = "${testInput.value}"`);
        
        // Trigger refresh after short delay
        setTimeout(() => {
            window.refreshManager.refreshPage(true).then(() => {
                const refreshedInput = document.getElementById('test-focus-input');
                const focusedAfter = document.activeElement === refreshedInput;
                
                const success = focusedBefore && focusedAfter;
                this.logResult('FOCUS_PRESERVATION', success, 
                    `Focus ${success ? 'preserved' : 'lost'} on element: ${refreshedInput?.id}`);
                
                // Cleanup
                if (refreshedInput) refreshedInput.remove();
            });
        }, 100);
    }
    
    /**
     * Test 3: Form State Preservation
     */
    testFormState() {
        console.log('%c[TEST 3] Testing Form State Preservation', 'color: green; font-weight: bold;');
        
        if (!window.refreshManager) {
            this.logResult('FORM_STATE', false, 'RefreshManager not loaded');
            return;
        }
        
        // Find existing form fields on the page
        const searchInput = document.querySelector('input[id*="search"], input[placeholder*="search"]');
        const typeFilter = document.querySelector('select[id*="type"], select[id*="Type"]');
        const statusFilter = document.querySelector('select[id*="status"], select[id*="Status"]');
        
        if (!searchInput && !typeFilter && !statusFilter) {
            this.logResult('FORM_STATE', false, 'No form fields found on current page');
            return;
        }
        
        // Save form values
        const originalValues = {
            search: searchInput?.value || '',
            type: typeFilter?.value || '',
            status: statusFilter?.value || ''
        };
        
        console.log('Original form values:', originalValues);
        
        // Wait for next refresh
        setTimeout(() => {
            const currentValues = {
                search: searchInput?.value || '',
                type: typeFilter?.value || '',
                status: statusFilter?.value || ''
            };
            
            const preserved = JSON.stringify(originalValues) === JSON.stringify(currentValues);
            this.logResult('FORM_STATE', preserved, 
                `Form values ${preserved ? 'preserved' : 'changed'}: ${JSON.stringify(currentValues)}`);
        }, 2000);
    }
    
    /**
     * Test 4: Status Broadcast Events
     */
    testStatusBroadcast() {
        console.log('%c[TEST 4] Testing Status Broadcast Events', 'color: green; font-weight: bold;');
        
        let statusUpdateReceived = false;
        let machineAssignmentReceived = false;
        let newArrivalReceived = false;
        
        // Listen for custom events
        const handleStatusUpdate = (e) => {
            statusUpdateReceived = true;
            console.log('✓ ticket-status-updated event received:', e.detail);
        };
        
        const handleMachineAssignment = (e) => {
            machineAssignmentReceived = true;
            console.log('✓ machine-assigned event received:', e.detail);
        };
        
        const handleNewArrival = (e) => {
            newArrivalReceived = true;
            console.log('✓ new-arrival event received:', e.detail);
        };
        
        window.addEventListener('ticket-status-updated', handleStatusUpdate);
        window.addEventListener('machine-assigned', handleMachineAssignment);
        window.addEventListener('new-arrival', handleNewArrival);
        
        this.eventListeners.push(
            { event: 'ticket-status-updated', handler: handleStatusUpdate },
            { event: 'machine-assigned', handler: handleMachineAssignment },
            { event: 'new-arrival', handler: handleNewArrival }
        );
        
        // Wait for events
        setTimeout(() => {
            const allReceived = statusUpdateReceived || machineAssignmentReceived || newArrivalReceived;
            this.logResult('STATUS_BROADCAST', allReceived,
                `Events received - Status: ${statusUpdateReceived}, Machine: ${machineAssignmentReceived}, Arrival: ${newArrivalReceived}`);
        }, 5000);
    }
    
    /**
     * Test 5: Machine Assignment AJAX
     */
    testMachineAssignment() {
        console.log('%c[TEST 5] Testing Machine Assignment AJAX', 'color: green; font-weight: bold;');
        
        // Check if we're on imaging.php
        if (!window.location.pathname.includes('imaging.php')) {
            this.logResult('MACHINE_ASSIGNMENT_AJAX', false, 
                'This test must be run on imaging.php page');
            return;
        }
        
        // Find machine assignment form
        const assignmentForm = document.querySelector('.assignment-form');
        if (!assignmentForm) {
            this.logResult('MACHINE_ASSIGNMENT_AJAX', false, 
                'No machine assignment form found on imaging.php');
            return;
        }
        
        console.log('✓ Machine assignment form found');
        
        // Check if form uses AJAX
        const machineSelects = assignmentForm.querySelectorAll('select[name="machines[]"]');
        const assignBtn = assignmentForm.querySelector('button[name="assign_machine"]');
        
        if (!machineSelects.length || !assignBtn) {
            this.logResult('MACHINE_ASSIGNMENT_AJAX', false, 
                'Machine selects or assign button not found');
            return;
        }
        
        console.log(`✓ Found ${machineSelects.length} machine select(s)`);
        
        // Test by selecting a machine (but don't submit)
        const firstSelect = machineSelects[0];
        const originalValue = firstSelect.value;
        
        // Get available options
        const options = Array.from(firstSelect.querySelectorAll('option'))
            .filter(opt => opt.value && opt.value !== originalValue);
        
        if (options.length > 0) {
            firstSelect.value = options[0].value;
            firstSelect.focus();
            
            const focusedCorrectly = document.activeElement === firstSelect;
            this.logResult('MACHINE_ASSIGNMENT_AJAX', focusedCorrectly,
                `Form is ready for AJAX submission. Focus test: ${focusedCorrectly}`);
            
            console.log('%cTo complete test: Select a machine and click Assign button. Focus should stay on dropdown.', 
                'color: orange; font-style: italic;');
            
            // Restore
            firstSelect.value = originalValue;
        } else {
            this.logResult('MACHINE_ASSIGNMENT_AJAX', false, 'No alternative machines available to test');
        }
    }
    
    /**
     * Test 6: Page-Specific Auto-Refresh
     */
    testAutoRefresh() {
        console.log('%c[TEST 6] Testing Auto-Refresh', 'color: green; font-weight: bold;');
        
        if (!window.refreshManager) {
            this.logResult('AUTO_REFRESH', false, 'RefreshManager not loaded');
            return;
        }
        
        const initialTime = Date.now();
        let refreshCount = 0;
        let lastRefreshTime = initialTime;
        
        // Monitor for refresh by checking for changes in DOM
        const observer = new MutationObserver(() => {
            const now = Date.now();
            if (now - lastRefreshTime > 900) { // 900ms to account for timing variance
                refreshCount++;
                lastRefreshTime = now;
            }
        });
        
        // Observe queue table or relevant container
        const container = document.querySelector('#queueTableBody, #labQueueBody, .queue-table-container');
        if (container) {
            observer.observe(container, { childList: true, subtree: true });
            
            console.log('Observing page for 6 seconds (expecting ~6 refreshes at 1s interval)');
            
            setTimeout(() => {
                observer.disconnect();
                const expectedRefreshes = 6;
                const success = refreshCount >= (expectedRefreshes - 1); // Allow 1 miss
                
                this.logResult('AUTO_REFRESH', success,
                    `Detected ${refreshCount} refreshes (expected ~${expectedRefreshes})`);
            }, 6000);
        } else {
            this.logResult('AUTO_REFRESH', false, 'No observable queue container found');
        }
    }
    
    /**
     * Test 7: Cross-Tab Communication
     */
    testCrossTabCommunication() {
        console.log('%c[TEST 7] Testing Cross-Tab Communication', 'color: green; font-weight: bold;');
        
        // Use localStorage to simulate cross-tab messaging
        const testKey = 'queue_test_cross_tab_' + Date.now();
        const testData = {
            page: window.location.pathname,
            timestamp: new Date().toISOString(),
            testId: 'cross-tab-test'
        };
        
        try {
            localStorage.setItem(testKey, JSON.stringify(testData));
            
            // Try to read it back
            const retrieved = JSON.parse(localStorage.getItem(testKey));
            const success = JSON.stringify(retrieved) === JSON.stringify(testData);
            
            this.logResult('CROSS_TAB_COMM', success,
                'Cross-tab storage working. Current page: ' + window.location.pathname);
            
            // Cleanup
            localStorage.removeItem(testKey);
        } catch (error) {
            this.logResult('CROSS_TAB_COMM', false, 'LocalStorage error: ' + error.message);
        }
    }
    
    /**
     * Run all tests in sequence
     */
    runAllTests() {
        console.log('%c╔════════════════════════════════════════════╗', 'color: blue; font-weight: bold;');
        console.log('%c║  RUNNING COMPLETE TEST SUITE              ║', 'color: blue; font-weight: bold;');
        console.log('%c╚════════════════════════════════════════════╝', 'color: blue; font-weight: bold;');
        
        this.isTestRunning = true;
        this.testResults = [];
        
        // Run tests sequentially with delays
        this.testSSEConnection();
        setTimeout(() => this.testFocusPreservation(), 1000);
        setTimeout(() => this.testFormState(), 3000);
        setTimeout(() => this.testStatusBroadcast(), 5000);
        setTimeout(() => this.testAutoRefresh(), 7000);
        setTimeout(() => this.testMachineAssignment(), 14000);
        setTimeout(() => this.testCrossTabCommunication(), 15000);
        
        setTimeout(() => {
            this.isTestRunning = false;
            this.printResults();
        }, 20000);
    }
    
    /**
     * Log a test result
     */
    logResult(testName, passed, message) {
        const result = {
            test: testName,
            passed: passed,
            message: message,
            timestamp: new Date().toISOString()
        };
        
        this.testResults.push(result);
        
        const icon = passed ? '✓' : '✗';
        const color = passed ? 'green' : 'red';
        console.log(`%c${icon} ${testName}: ${message}`, `color: ${color};`);
    }
    
    /**
     * Display all test results
     */
    getResults() {
        return this.testResults;
    }
    
    /**
     * Print formatted test results
     */
    printResults() {
        console.log('%c╔════════════════════════════════════════════╗', 'color: blue; font-weight: bold;');
        console.log('%c║  TEST RESULTS SUMMARY                     ║', 'color: blue; font-weight: bold;');
        console.log('%c╚════════════════════════════════════════════╝', 'color: blue; font-weight: bold;');
        
        const passed = this.testResults.filter(r => r.passed).length;
        const total = this.testResults.length;
        
        this.testResults.forEach(result => {
            const icon = result.passed ? '✓' : '✗';
            const color = result.passed ? 'color: green' : 'color: red';
            console.log(`%c${icon} ${result.test.padEnd(25)} ${result.message}`, color);
        });
        
        console.log('');
        console.log(`%cPassed: ${passed}/${total}`, `color: ${passed === total ? 'green' : 'orange'}; font-weight: bold;`);
    }
    
    /**
     * Cleanup event listeners
     */
    cleanup() {
        this.eventListeners.forEach(item => {
            window.removeEventListener(item.event, item.handler);
        });
        this.eventListeners = [];
    }
}

// Auto-initialize on load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        const tester = new CrossPageStatusTester();
        tester.init();
    });
} else {
    const tester = new CrossPageStatusTester();
    tester.init();
}

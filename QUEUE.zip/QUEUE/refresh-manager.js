/**
 * RefreshManager - Intelligent page refresh with state preservation
 * Features:
 * - Preserves focused elements
 * - Maintains form field values
 * - Smooth partial updates
 * - Cross-page status broadcasting
 */
class RefreshManager {
    constructor() {
        this.isRefreshing = false;
        this.focusedElement = null;
        this.formState = {};
        this.lastUpdateTime = 0;
        this.updateInterval = 1000; // 1 second
        this.refreshInFlight = false;
        
        // Listen for focus changes
        document.addEventListener('focusin', (e) => this.saveFocusState(e.target));
        
        // Listen for form input changes
        document.addEventListener('change', (e) => this.saveFormState(e.target));
        
        // Listen for status update events from server
        if (window.EventSource) {
            this.setupServerSentEvents();
        }
    }
    
    /**
     * Save the currently focused element
     */
    saveFocusState(element) {
        if (element && element.id) {
            this.focusedElement = {
                id: element.id,
                value: element.value || element.textContent
            };
        }
    }
    
    /**
     * Save form field state for recovery after refresh
     */
    saveFormState(element) {
        if (element && element.name) {
            this.formState[element.name] = {
                value: element.value,
                id: element.id
            };
        }
    }
    
    /**
     * Restore focus to previously focused element
     */
    restoreFocus() {
        if (this.focusedElement && this.focusedElement.id) {
            const element = document.getElementById(this.focusedElement.id);
            if (element) {
                setTimeout(() => {
                    element.focus();
                    // Restore value if it's an input
                    if (element.value !== this.focusedElement.value) {
                        element.value = this.focusedElement.value;
                    }
                }, 50);
            }
        }
    }
    
    /**
     * Restore form state
     */
    restoreFormState() {
        Object.keys(this.formState).forEach(name => {
            const state = this.formState[name];
            const element = state.id ? 
                document.getElementById(state.id) : 
                document.querySelector(`[name="${name}"]`);
            
            if (element) {
                element.value = state.value;
                // Trigger change event
                element.dispatchEvent(new Event('change', { bubbles: true }));
            }
        });
    }
    
    /**
     * Refresh specific section of the page via AJAX
     */
    async refreshSection(selector, url) {
        if (this.refreshInFlight) return;
        
        this.refreshInFlight = true;
        try {
            const response = await fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                cache: 'no-store'
            });
            
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            
            // Try to parse as JSON first, fall back to HTML
            const contentType = response.headers.get('content-type');
            let content = '';
            
            if (contentType && contentType.includes('application/json')) {
                // Response is JSON - parse and handle appropriately
                const data = await response.json();
                
                // Check if this is from queue_refresh.php (returns array of patients)
                if (Array.isArray(data)) {
                    // For butler.php: call renderPatients if available
                    if (typeof window.renderPatients === 'function') {
                        window.renderPatients(data);
                    } else {
                        console.warn('renderPatients function not found for JSON response');
                    }
                    this.refreshInFlight = false;
                    return;
                } else if (data.error) {
                    throw new Error(data.error);
                }
                content = JSON.stringify(data);
            } else {
                // Response is HTML
                content = await response.text();
            }
            
            const container = document.querySelector(selector);
            
            if (container) {
                container.innerHTML = content;
                // Restore focus and form state
                this.restoreFocus();
                this.restoreFormState();
            }
        } catch (error) {
            console.error('Refresh error:', error);
        } finally {
            this.refreshInFlight = false;
        }
    }
    
    /**
     * Refresh entire page with state preservation
     */
    async refreshPage(preserveFocus = true) {
        if (this.refreshInFlight) return;
        
        this.refreshInFlight = true;
        
        try {
            // Get current state
            const activeElement = document.activeElement;
            const focusedId = activeElement?.id;
            
            // Fetch fresh page content
            const response = await fetch(window.location.href, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            
            const html = await response.text();
            const parser = new DOMParser();
            const newDoc = parser.parseFromString(html, 'text/html');
            
            // Replace body content while keeping scripts
            const newBody = newDoc.querySelector('body');
            if (newBody) {
                document.body.innerHTML = newBody.innerHTML;
            }
            
            // Restore focus
            if (preserveFocus && focusedId) {
                this.restoreFocus();
            }
            
        } catch (error) {
            console.error('Page refresh error:', error);
        } finally {
            this.refreshInFlight = false;
        }
    }
    
    /**
     * Setup Server-Sent Events for real-time updates
     */
    setupServerSentEvents() {
        try {
            const sse = new EventSource('realtime_updates.php?stream=all');
            
            sse.addEventListener('status_update', (event) => {
                const data = JSON.parse(event.data);
                this.handleStatusUpdate(data);
            });
            
            sse.addEventListener('machine_assignment', (event) => {
                const data = JSON.parse(event.data);
                this.handleMachineAssignment(data);
            });
            
            sse.onerror = () => {
                sse.close();
                // Retry in 5 seconds
                setTimeout(() => this.setupServerSentEvents(), 5000);
            };
        } catch (error) {
            console.error('SSE setup error:', error);
        }
    }
    
    /**
     * Handle status update from server
     */
    handleStatusUpdate(data) {
        // Broadcast custom event for other listeners
        window.dispatchEvent(new CustomEvent('ticket-status-updated', { detail: data }));
        
        // Don't do full page refresh if on butler dashboard with stream cards
        // Stream cards handle their own updates via polling
        const currentPage = window.location.pathname;
        if (currentPage.includes('butler.php')) {
            // Let stream cards and dashboard polling handle the update
            return;
        }
        
        // Auto-refresh if on affected page
        if (this.shouldRefreshForStatusUpdate(data)) {
            this.refreshPage(true);
        }
    }
    
    /**
     * Handle machine assignment update
     */
    handleMachineAssignment(data) {
        // Broadcast custom event
        window.dispatchEvent(new CustomEvent('machine-assigned', { detail: data }));
        
        // Refresh imaging queue if on imaging page
        if (window.location.pathname.includes('imaging')) {
            this.refreshPage(true);
        }
    }
    
    /**
     * Determine if page should refresh based on status update
     */
    shouldRefreshForStatusUpdate(data) {
        const currentPage = window.location.pathname;
        
        // Don't refresh butler.php - it's handled by stream card polling
        if (currentPage.includes('butler.php')) {
            return false;
        }
        
        // Refresh imaging page if imaging status changed
        if (currentPage.includes('imaging.php') && data.img) {
            return true;
        }
        
        // Refresh lab page if lab status changed
        if (currentPage.includes('laboratory.php') && data.lab) {
            return true;
        }
        
        // Refresh stream displays
        if (currentPage.includes('stream.php')) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Start auto-refresh at specified interval
     */
    startAutoRefresh(interval = 1000) {
        if (this._refreshIntervalId) clearInterval(this._refreshIntervalId);
        
        this.updateInterval = interval;
        this._refreshIntervalId = setInterval(() => {
            // Check if page is hidden
            if (document.hidden) return;
            
            // Check if confirmation modal is open (stream card interaction)
            if (window.isModalOpen === true) return;
            
            // Check if stream modal is open (stream card interaction)
            if (window.isStreamModalOpen === true) return;
            
            // Check if any modal is open
            const modals = document.querySelectorAll('[role="dialog"][class*="active"], .modal.active, [id*="modal"][class*="active"]');
            if (modals.length > 0) return;
            
            // Check if any menu/details element is open (including nested submenus)
            const openMenus = document.querySelectorAll('details[open]');
            if (openMenus.length > 0) return;
            
            // Check if user is hovering/focusing on a card or interactive element
            const activeElement = document.activeElement;
            if (activeElement && (
                activeElement.closest('.stream-card-compact') ||
                activeElement.closest('.ticket-card') ||
                activeElement.closest('[role="button"]') ||
                activeElement.closest('.auth-user-menu') ||
                activeElement.closest('summary') ||
                activeElement.tagName === 'INPUT' ||
                activeElement.tagName === 'TEXTAREA' ||
                activeElement.tagName === 'SELECT' ||
                activeElement.tagName === 'A'
            )) return;
            
            // Only refresh if none of the above conditions are met
            this.refreshPage(true);
        }, interval);
    }
    
    /**
     * Stop auto-refresh
     */
    stopAutoRefresh() {
        if (this._refreshIntervalId) {
            clearInterval(this._refreshIntervalId);
            this._refreshIntervalId = null;
        }
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    window.refreshManager = new RefreshManager();
});

// Global smartReload helper: prefer RefreshManager over full reload
window.smartReload = function(delay = 0) {
    const doReload = () => {
        if (window.refreshManager && typeof window.refreshManager.refreshPage === 'function') {
            try {
                window.refreshManager.refreshPage(true);
                return;
            } catch (e) {
                console.error('RefreshManager failed, falling back to location.reload():', e);
            }
        }
        try { location.reload(); } catch (e) { console.error('location.reload failed:', e); }
    };
    if (delay && Number(delay) > 0) {
        setTimeout(doReload, Number(delay));
    } else {
        doReload();
    }
};

// Global helper functions
window.autoRefreshPage = (interval = 1000) => {
    if (window.refreshManager) {
        window.refreshManager.startAutoRefresh(interval);
    }
};

window.stopAutoRefresh = () => {
    if (window.refreshManager) {
        window.refreshManager.stopAutoRefresh();
    }
};

window.refreshPageSection = (selector, url) => {
    if (window.refreshManager) {
        return window.refreshManager.refreshSection(selector, url);
    }
};

window.forcePageRefresh = () => {
    if (window.refreshManager) {
        return window.refreshManager.refreshPage(true);
    }
};

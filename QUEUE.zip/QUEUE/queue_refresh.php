<?php
/**
 * queue_refresh.php - UNIFIED AJAX refresh for all interfaces
 * 
 * Supports:
 * - Targeted section updates (preserves form state)
 * - Full page updates with state preservation
 * - Machine assignment detection
 * - Real-time queue updates
 */

// Set error handling to prevent output corruption
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Set proper response headers immediately to ensure JSON content type
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Buffer output to catch any stray output
ob_start();

require_once 'config.php';
session_start();

// Get parameters early so auth checks use the intended department
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$type_filter = isset($_GET['type']) ? $_GET['type'] : 'all';
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$department = isset($_GET['department']) ? $_GET['department'] : 'all';
$machine = isset($_GET['machine']) ? $_GET['machine'] : 'all';
$action = isset($_GET['action']) ? $_GET['action'] : '';

try {
    // Allow public (no-login) refreshes for kiosk-style displays
    // that poll the lab/imaging departments. Other departments still
    // require authentication.
    if (!in_array($department, ['lab', 'imaging'], true)) {
        authRequireRoles([], ['log_view' => false]);
    }
    // Release session lock for polling requests to avoid blocking
    session_write_close();
} catch (Exception $e) {
    // If config fails, return error JSON
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    ob_end_clean();
    exit;
}



// Handle duplicate test detection endpoint
if ($action === 'get_other_machines') {
    header('Content-Type: application/json');
    $patient_name = $_GET['patient_name'] ?? '';
    $arrival_time = $_GET['arrival_time'] ?? '';
    $mobile = $_GET['mobile'] ?? '';
    
    if (!$patient_name || !$arrival_time || !$mobile) {
        echo json_encode(['error' => 'Missing parameters']);
        exit;
    }
    
    $dup_query = "
        SELECT GROUP_CONCAT(DISTINCT t.imaging_machine) as other_machines, COUNT(*) as total_tests
        FROM tickets t
        JOIN patients p ON t.patient_id = p.patient_id
        WHERE p.patient_name = ?
        AND t.arrival_timestamp = ?
        AND p.mobile = ?
        AND t.closing_timestamp IS NULL
        AND t.imaging_machine IS NOT NULL
    ";
    $result = executeAndFetchOne($pdo, $dup_query, [$patient_name, $arrival_time, $mobile]);
    
    echo json_encode([
        'total_tests' => $result['total_tests'] ?? 1,
        'other_machines' => $result['other_machines'] ?? ''
    ]);
    ob_end_clean();
    exit;
}

// Build the base query
$query = "
    SELECT
        t.ticket_id AS id,
        t.queue_number,
        p.patient_name,
        p.mrn,
        p.mobile,
        p.country_code,
        p.care_mobile,
        p.care_country_code,
        p.email,
        p.address,
        t.service_type as type,
        t.current_status as status,
        t.arrival_timestamp,
        t.approval_timestamp,
        t.lab_call_time,
        t.imaging_call_time,
        t.imaging_machine,
        t.lab,
        t.img,
        t.dp2,
        t.cl,
        t.Clinic,
        t.registered_by_username,
        t.assigned_butler_username,
        t.last_need_request_by_username,
        t.last_need_request_at,
        t.is_existing_patient,
        t.demographics_edited,
        t.demographics_changed_fields
    FROM tickets t
    JOIN patients p ON t.patient_id = p.patient_id
    WHERE t.closing_timestamp IS NULL 
    AND t.arrival_timestamp >= CURDATE()
    AND t.arrival_timestamp < (CURDATE() + INTERVAL 1 DAY)
";

// Initialize params array
$params = [];

// Add department-specific filters
switch ($department) {
    case 'butler':
        // Butler sees all except canceled
        $query .= " AND t.current_status != 'Canceled'";
        $order_by = "ORDER BY t.arrival_timestamp ASC";
        break;
        
    case 'billing':
        // Billing sees Arrived, In Process, Needed by Billing, and Wrong Info
        $query .= " AND t.current_status IN ('Arrived', 'In Process', 'Needed by Billing', 'Wrong Info')";
        // Handle type filtering for billing
        if (isset($_GET['types']) && !empty($_GET['types'])) {
            $types = array_filter(explode(',', $_GET['types'])); // Remove empty values
            if (!empty($types)) {
                $type_placeholders = str_repeat('?,', count($types) - 1) . '?';
                $query .= " AND t.service_type IN ($type_placeholders)";
                array_push($params, ...$types);
            }
        }
        $order_by = "
            ORDER BY 
                CASE WHEN t.current_status = 'Arrived' THEN 1 ELSE 2 END,
                FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor', 'Clinics'),
                t.arrival_timestamp ASC
        ";
        break;
        
    case 'lab':
        // Lab sees Waiting, Called, Skipped, Recalled, Served and lab=1
        $query .= " AND t.current_status IN ('Waiting', 'Called', 'On the Way', 'Skipped', 'Recalled', 'Served', 'On Hold') AND t.lab = 1";
        $order_by = "
            ORDER BY
                FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
                COALESCE(t.approval_timestamp, t.arrival_timestamp) ASC
        ";
        break;
        
    case 'clinics':
        // Clinics sees patients in all active states with cl=1
        $query .= " AND t.cl = 1";
        $query .= " AND t.current_status IN ('Waiting', 'Called', 'On the Way', 'Recalled', 'Served', 'On Hold', 'Skipped', 'In Process', 'Needed by Billing')";
        $order_by = "
            ORDER BY 
                FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor', 'Clinics'),
                COALESCE(t.approval_timestamp, t.arrival_timestamp) ASC,
                t.Clinic ASC
        ";
        break;

    case 'imaging':
        // Imaging sees patients waiting, called, or being served
        if ($machine != 'all') {
            $query .= " AND t.imaging_machine = ?";
            $params[] = $machine;
        }
        // Only include patients assigned to imaging (img = 1)
        $query .= " AND t.img = 1";
        $query .= " AND t.current_status IN ('Waiting', 'Called', 'On the Way', 'Recalled', 'Served', 'On Hold', 'Skipped')";
        $order_by = "
            ORDER BY 
                FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
                COALESCE(t.approval_timestamp, t.arrival_timestamp) ASC
        ";
        break;
        
    default:
        // Default: all active patients
        $query .= " AND t.current_status != 'Canceled'";
        $order_by = "ORDER BY t.arrival_timestamp DESC";
}

// Add search conditions
if (!empty($search)) {
    $query .= " AND (
        p.patient_name LIKE ? OR
        t.queue_number LIKE ? OR
        p.mobile LIKE ?
    )";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

// Add type filter
if ($type_filter != 'all') {
    $query .= " AND t.service_type = ?";
    $params[] = $type_filter;
}

// Add status filter
if ($status_filter != 'all') {
    $query .= " AND t.current_status = ?";
    $params[] = $status_filter;
}

// Add ordering
$query .= " " . $order_by;

// Execute query
try {
    $patients = executeAndFetch($pdo, $query, $params);
} catch (Exception $e) {
    // Log error and return empty array with error message
    error_log("Queue Refresh Error: " . $e->getMessage() . "\nQuery: " . $query . "\nParams: " . json_encode($params));
    $patients = [];
}

// Clean any buffered output
ob_end_clean();

// Optional diagnostic output for debugging (non-breaking when omitted)
$diagnose = isset($_GET['diagnose']) && $_GET['diagnose'] === '1';

if ($diagnose) {
    // Return patients along with the query and params for inspection
    $out = [
        'patients' => $patients,
        'debug' => [
            'query' => $query,
            'params' => $params,
            'department' => $department,
            'machine' => $machine,
            'status_filter' => $status_filter
        ]
    ];
    $response = json_encode($out);
} else {
    // Ensure response is valid JSON (array)
    $response = json_encode($patients);
}

if ($response === false) {
    error_log("JSON encoding failed for queue_refresh");
    http_response_code(500);
    echo json_encode(['error' => 'Failed to encode response']);
} else {
    echo $response;
}
?>
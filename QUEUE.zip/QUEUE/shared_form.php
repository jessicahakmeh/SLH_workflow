<?php
/**
 * Shared form component for both new_ticket.php and edit_ticket.php
 * Usage: include 'shared_form.php';
 */

// Default values if not provided
$defaults = [
    'mode' => 'create',
    'title' => 'Create New Patient Ticket',
    'patient' => null,
    'button_text' => 'Create Ticket',
    'button_icon' => 'fa-plus-circle',
    'success_message' => 'Ticket Created Successfully!'
];

// Override defaults with provided values
extract(array_merge($defaults, $options ?? []));

// Get from_page if provided
$from_page = $options['from_page'] ?? '';
$prefill_patient = $options['prefill_patient'] ?? null;
$cancel_url = $from_page === 'clinics' ? 'clinics.php' : 'butler.php';

// Determine if we're in edit mode
$is_edit_mode = $mode === 'edit';
$patient_id = $is_edit_mode ? ($patient['id'] ?? null) : null;
$selected_existing_patient_id = $is_edit_mode ? '' : ($options['selected_existing_patient_id'] ?? ($_POST['existing_patient_id'] ?? ''));
$is_existing_patient_selected = !$is_edit_mode && trim((string)$selected_existing_patient_id) !== '';
$patient_selection_url = 'patient_selection.php?return_to=new_ticket.php';
if (!empty($from_page)) {
    $patient_selection_url .= '&from=' . urlencode($from_page);
}

// Service type prefixes
$service_ranges = [
    'Appointment' => 'A',
    'Private' => 'P',
    'Guarantor' => 'G',
    'Clinics' => 'C'
];

// Load districts JSON data
$districts_data = json_decode(file_get_contents('districts.json'), true);

// Sort districts alphabetically
ksort($districts_data);

// Sort kazas within each district alphabetically
foreach ($districts_data as $district => &$kazas) {
    ksort($kazas);
    
    // Sort cities within each kaza alphabetically
    foreach ($kazas as $kaza => &$cities) {
        sort($cities);
    }
}
unset($kazas, $cities); // Unset references

// Load countries from JSON file
$countries_json = json_decode(file_get_contents('countries.json'), true);
$countries = [];
$countries_by_name = []; // For sorting by name
if ($countries_json && isset($countries_json['countries'])) {
    foreach ($countries_json['countries'] as $country) {
        // Store country info indexed by calling code
        $countries[$country['code']] = [
            'name' => $country['name'],
            'minDigits' => $country['minDigits'],
            'maxDigits' => $country['maxDigits'],
            'pattern' => $country['pattern'] ?? '',
            'example' => $country['example'] ?? ''
        ];
        // Also create name-indexed array for sorting
        $countries_by_name[$country['name']] = [
            'code' => $country['code'],
            'name' => $country['name'],
            'minDigits' => $country['minDigits'],
            'maxDigits' => $country['maxDigits'],
            'pattern' => $country['pattern'] ?? '',
            'example' => $country['example'] ?? ''
        ];
    }
    // Sort by country name
    ksort($countries_by_name);
}
// Fallback to empty if JSON not loaded
if (empty($countries)) {
    $countries = ['+961' => ['name' => 'Lebanon', 'minDigits' => 8, 'maxDigits' => 9]];
    $countries_by_name = ['Lebanon' => ['code' => '+961', 'name' => 'Lebanon', 'minDigits' => 8, 'maxDigits' => 9]];
}

// Get current values for form
$form_values = [
    'service_type' => $is_edit_mode ? ($patient['service_type'] ?? '') : ($_POST['service_type'] ?? ($from_page === 'clinics' ? 'Clinics' : '')),
    'patient_name' => $is_edit_mode ? ($patient['patient_name'] ?? '') : ($_POST['patient_name'] ?? ''),
    'country_code' => $is_edit_mode ? ($patient['country_code'] ?? '+961') : ($_POST['country_code'] ?? '+961'),
    'mobile' => $is_edit_mode ? ($patient['mobile'] ?? '') : ($_POST['mobile'] ?? ''),
    'care_country_code' => $is_edit_mode ? ($patient['care_country_code'] ?? '+961') : ($_POST['country_code_care'] ?? ($_POST['care_country_code'] ?? '+961')),
    'care_mobile' => $is_edit_mode ? ($patient['care_mobile'] ?? '') : ($_POST['care_mobile'] ?? ''),
    'email' => $is_edit_mode ? ($patient['email'] ?? '') : ($_POST['email'] ?? ''),
    'address' => $is_edit_mode ? ($patient['address'] ?? '') : ($_POST['address'] ?? ''),
    'district' => $is_edit_mode ? ($patient['district'] ?? '') : ($_POST['district'] ?? ''),
    'kaza' => $is_edit_mode ? ($patient['kaza'] ?? '') : ($_POST['kaza'] ?? ''),
    'city' => $is_edit_mode ? ($patient['city'] ?? '') : ($_POST['city'] ?? '')
];

if (!$is_edit_mode && is_array($prefill_patient)) {
    $form_values['patient_name'] = $prefill_patient['patient_name'] ?? $form_values['patient_name'];
    $form_values['country_code'] = ($prefill_patient['country_code'] ?? '') !== '' ? $prefill_patient['country_code'] : $form_values['country_code'];
    $form_values['mobile'] = $prefill_patient['mobile'] ?? $form_values['mobile'];
    $form_values['care_country_code'] = ($prefill_patient['care_country_code'] ?? '') !== '' ? $prefill_patient['care_country_code'] : $form_values['care_country_code'];
    $form_values['care_mobile'] = $prefill_patient['care_mobile'] ?? $form_values['care_mobile'];
    $form_values['email'] = $prefill_patient['email'] ?? $form_values['email'];
    $form_values['address'] = $prefill_patient['address'] ?? $form_values['address'];
    $selected_existing_patient_id = (string)($prefill_patient['patient_id'] ?? $selected_existing_patient_id);
}

// Parse address for edit mode
if ($is_edit_mode && !empty($patient['address'])) {
    $address_parts = explode(', ', $patient['address']);
    if (count($address_parts) >= 3) {
        $form_values['district'] = $address_parts[0] ?? '';
        $form_values['kaza'] = $address_parts[1] ?? '';
        $form_values['city'] = $address_parts[2] ?? '';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Ticket</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background-color: white;
            padding: 40px;
            border-radius: 12px;
            text-align: center;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            animation: modalFadeIn 0.3s ease-out;
        }
        
        @keyframes modalFadeIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .modal-icon {
            font-size: 64px;
            color: #27ae60;
            margin-bottom: 20px;
        }
        
        .modal-title {
            font-size: 28px;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .modal-queue-number {
            font-size: 48px;
            font-weight: bold;
            color: #3498db;
            margin: 20px 0;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 3px dashed #3498db;
        }
        
        .modal-message {
            font-size: 16px;
            color: #7f8c8d;
            margin-bottom: 30px;
            line-height: 1.6;
        }
        
        .modal-btn {
            padding: 14px 40px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-block;
        }
        
        .modal-btn:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
        }
        
        .modal-btn i {
            margin-right: 8px;
        }
        
        .print-btn {
            background-color: #27ae60;
            margin-left: 15px;
        }
        
        .print-btn:hover {
            background-color: #219653;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 20px;
        }

        /* Modern Form Styling */
        .container {
            max-width: 95%;
            margin: 10px auto;
            padding: 15px;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            overflow-y: auto;
            overflow-x: hidden;
        }

        .header {
            text-align: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #3498db;
        }

        .header .logo {
            font-size: 32px;
            margin-bottom: 5px;
            display: block;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 1.3em;
            margin: 5px 0;
            font-weight: 700;
        }

        .message {
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            font-size: 0.9em;
            animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        /* Form Styles */
        #ticketForm {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
        }

        .form-group {
            margin-bottom: 14px;
        }

        .form-group label {
            display: block;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 5px;
            font-size: 0.9em;
        }

        .form-group label.required::after {
            content: " *";
            color: #e74c3c;
        }

        .form-group input[type="text"],
        .form-group input[type="tel"],
        .form-group input[type="email"],
        .form-group select {
            width: 100%;
            padding: 8px 12px;
            border: 2px solid #ecf0f1;
            border-radius: 6px;
            font-size: 0.9em;
            font-family: inherit;
            transition: all 0.3s ease;
            box-sizing: border-box;
            background: #f8f9fa;
        }

        /* Mobile input group styling */
        .mobile-input-group {
            display: flex;
            gap: 8px;
            align-items: stretch;
        }

        .mobile-input-group select {
            flex: 0 0 45%;
            padding: 8px 10px;
        }

        .mobile-input-group input {
            flex: 1;
        }

        .form-group input[type="text"]:focus,
        .form-group input[type="tel"]:focus,
        .form-group input[type="email"]:focus,
        .form-group select:focus {
            outline: none;
            border-color: #3498db;
            background: white;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.08);
        }

        .form-group input[type="text"]::placeholder,
        .form-group input[type="tel"]::placeholder,
        .form-group input[type="email"]::placeholder {
            color: #95a5a6;
        }

        /* Service Type Buttons */
        .service-type-buttons {
            display: flex;
            gap: 8px;
            margin-bottom: 0;
        }

        .service-btn {
            flex: 1;
            padding: 10px 12px;
            background: #ecf0f1;
            border: 2px solid #bdc3c7;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            color: #2c3e50;
            font-size: 0.85em;
        }

        .service-btn:hover {
            background: #d5dbdb;
            border-color: #95a5a6;
        }

        .service-btn.active {
            background: #3498db;
            border-color: #2980b9;
            color: white;
            box-shadow: 0 3px 10px rgba(52, 152, 219, 0.25);
        }

        /* Address Row - Horizontal Layout */
        .address-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }

        .address-col {
            width: 100%;
        }

        .address-col select {
            width: 100%;
        }

        /* Button Group */
        .button-group {
            display: flex;
            gap: 8px;
            margin-top: 16px;
        }

        .btn {
            flex: 1;
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            font-size: 0.9em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .btn-submit {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            box-shadow: 0 3px 12px rgba(52, 152, 219, 0.25);
        }

        .btn-submit:hover {
            background: linear-gradient(135deg, #2980b9, #236fa1);
            box-shadow: 0 5px 16px rgba(52, 152, 219, 0.32);
            transform: translateY(-1px);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .btn-cancel {
            background: #ecf0f1;
            color: #2c3e50;
        }

        .btn-cancel:hover {
            background: #d5dbdb;
            color: #1a252f;
        }

        .btn i {
            font-size: 0.95em;
        }

        .inline-action-row {
            display: flex;
            justify-content: flex-start;
            margin-top: 10px;
            width: 100%;
        }

        .btn-search-patient {
            background: #f4f7fb;
            border: 1px solid #cfd8e3;
            color: #08458a;
            padding: 12px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1.2rem;
            font-weight: 700;
            width: 100%;
            text-align: center;
            transition: all 0.3s ease;
        }

        .btn-search-patient:hover {
            background: #e8f0fa;
            border-color: #1c8cd6;
        }

        .existing-patient-notice {
            display: inline-block;
            margin-top: 8px;
            padding: 5px 10px;
            border-radius: 999px;
            background: #fff0f0;
            color: #c0392b;
            border: 1px solid #f0b7b2;
            font-weight: 700;
            font-size: 12px;
        }

        .btn-edit-existing-patient {
            margin-top: 8px;
            margin-left: 8px;
            background: #eaf4ff;
            border: 1px solid #bcd8f5;
            color: #1f4a7a;
            padding: 6px 10px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.82em;
            font-weight: 600;
        }

        .btn-edit-existing-patient:hover {
            background: #deeeff;
        }

        .existing-locked {
            background: #f4f6f8 !important;
            color: #5f6b76;
        }

        .patient-search-modal {
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.55);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 2000;
        }

        .patient-search-modal.active {
            display: flex;
        }

        .patient-search-content {
            width: min(820px, 94vw);
            max-height: 82vh;
            overflow: hidden;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 14px 36px rgba(0, 0, 0, 0.22);
            padding: 18px;
        }

        .patient-search-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .patient-search-title {
            margin: 0;
            font-size: 1.05rem;
            color: #234;
        }

        .patient-search-close {
            border: none;
            background: transparent;
            font-size: 1.2rem;
            color: #4a5a6a;
            cursor: pointer;
        }

        .patient-search-input-row {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
        }

        .patient-search-input-row input {
            flex: 1;
            border: 1px solid #ccd7e2;
            border-radius: 6px;
            padding: 9px 10px;
            font-size: 0.92em;
        }

        .patient-search-results {
            max-height: 52vh;
            overflow: auto;
            border: 1px solid #e1e7ee;
            border-radius: 8px;
        }

        .patient-search-item {
            display: grid;
            grid-template-columns: 1.2fr 1fr auto;
            gap: 10px;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #edf1f5;
        }

        .patient-search-item:last-child {
            border-bottom: none;
        }

        .patient-search-meta {
            color: #587;
            font-size: 0.84em;
        }

        .patient-search-select-btn {
            border: none;
            background: #1d7dd9;
            color: #fff;
            padding: 8px 10px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.84em;
            font-weight: 600;
        }

        .patient-search-empty {
            padding: 16px;
            color: #6a7a8a;
            text-align: center;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 10px;
                margin: 5px auto;
            }

            #ticketForm {
                padding: 15px;
            }

            .address-row {
                grid-template-columns: 1fr;
            }

            .button-group {
                flex-direction: column;
            }

            .service-type-buttons {
                flex-direction: column;
            }

            .mobile-input-group {
                flex-direction: column;
            }

            .mobile-input-group select {
                flex: 1;
                width: 100%;
            }

            .mobile-input-group input {
                width: 100%;
            }
        }
    </style>
</head>

<!-- Header -->
<div class="header">
    <div class="logo">🏥</div>
    <div>
        <h1><?php echo htmlspecialchars($title); ?></h1>
    </div>
</div>

<!-- Error/Success Message Display -->
<?php if (isset($message) && $message): ?>
    <div class="message <?php echo $message_type ?? 'info'; ?>">
        <i class="fas <?php echo ($message_type ?? 'info') == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
        <?php echo htmlspecialchars($message); ?>
    </div>
<?php endif; ?>

<!-- Patient Form -->
<form id="ticketForm" method="POST" action="">
    <?php if ($is_edit_mode && $patient_id): ?>
        <input type="hidden" name="patient_id" value="<?php echo $patient_id; ?>">
    <?php endif; ?>
    <?php if ($is_edit_mode && !empty($patient['queue_number'])): ?>
        <input type="hidden" name="queue_number" value="<?php echo htmlspecialchars($patient['queue_number']); ?>">
    <?php endif; ?>
    <?php if (!$is_edit_mode && !empty($from_page)): ?>
        <input type="hidden" name="from" value="<?php echo htmlspecialchars($from_page); ?>">
    <?php endif; ?>
    <?php if (!$is_edit_mode): ?>
        <input type="hidden" name="existing_patient_id" id="existing_patient_id" value="<?php echo htmlspecialchars((string)$selected_existing_patient_id); ?>">
    <?php endif; ?>
    
    <?php if (!$is_edit_mode): ?>
            <div class="inline-action-row">
                <a class="btn-search-patient" id="openPatientSearchBtn" href="<?php echo htmlspecialchars($patient_selection_url); ?>" style="text-decoration: none; display: inline-flex; align-items: center; gap: 6px;">
                    <i class="fas fa-search"></i> Search Existing Patient
                </a>
            </div>
            <div id="existingPatientNotice" class="existing-patient-notice" style="display: <?php echo $is_existing_patient_selected ? 'inline-block' : 'none'; ?>;">
                Existing Patient Selected
            </div>
            <button type="button" id="editExistingPatientBtn" class="btn-edit-existing-patient" style="display: <?php echo $is_existing_patient_selected ? 'inline-block' : 'none'; ?>;">
                <i class="fas fa-pen"></i> Edit Patient Details
            </button>
        <?php endif; ?>
        <br>
    <!-- Service Type -->
    <div class="form-group">
        <label class="required">Service Type</label>
        <div class="service-type-buttons" id="serviceTypeButtons">
            <?php if ($from_page === 'clinics'): ?>
                <!-- When from clinics, show only Clinics as selected and disabled -->
                <button type="button" class="service-btn selected" data-type="Clinics" disabled style="opacity: 0.6; cursor: not-allowed;">
                    <i class="fas fa-lock"></i> Clinics (Auto-selected)
                </button>
            <?php else: ?>
                <?php foreach ($service_ranges as $type => $range_start): ?>
                    <button type="button" class="service-btn" data-type="<?php echo $type; ?>">
                        <?php echo $type; ?>
                    </button>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <input type="hidden" name="service_type" id="service_type" required 
               value="<?php echo htmlspecialchars($form_values['service_type']); ?>">
        <?php if ($from_page === 'clinics'): ?>
            <small style="display: block; margin-top: 4px; color: #7f8c8d;">
                <i class="fas fa-info-circle"></i> Service type automatically set to Clinics for clinic patients
            </small>
        <?php endif; ?>
    </div>
    
    <!-- Patient Name -->
    <div class="form-group">
        <label for="patient_name" class="required">Patient Name</label>
        <input type="text" id="patient_name" name="patient_name" 
               value="<?php echo htmlspecialchars($form_values['patient_name']); ?>" 
               required placeholder="Enter full name">
    </div>
    
    <!-- Mobile Number with Country Code - Current Contact -->
    <div class="form-group">
        <label for="mobile" class="required">Current Contact Mobile Number</label>
        <div class="mobile-input-group">
            <select id="country_code" name="country_code" required>
                <?php foreach ($countries_by_name as $name => $country_info): ?>
                    <?php $code = $country_info['code']; ?>
                    <option value="<?php echo htmlspecialchars($code); ?>"
                        data-pattern="<?php echo htmlspecialchars($country_info['pattern'] ?? ''); ?>"
                        data-min="<?php echo htmlspecialchars($country_info['minDigits']); ?>"
                        data-max="<?php echo htmlspecialchars($country_info['maxDigits']); ?>"
                        data-example="<?php echo htmlspecialchars($country_info['example']); ?>"
                        <?php echo $form_values['country_code'] == $code ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($code) . ' - ' . htmlspecialchars($name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="tel" id="mobile" name="mobile" 
                   value="<?php echo htmlspecialchars($form_values['mobile']); ?>" 
                   required placeholder="e.g., 71 123 456"
                   pattern="[0-9\s\-\(\)]+"
                   title="Please enter a valid phone number">
        </div>
        <small style="display: block; margin-top: 4px; color: #7f8c8d;">
            Enter the local phone number without country code (use WhatsApp for notifications)
        </small>
    </div>

    <!-- Result & Care Mobile Number -->
    <div class="form-group">
        <label for="care_mobile">Result & Care Mobile Number</label>
        <div class="mobile-input-group">
            <select id="country_code_care" name="country_code_care">
                <?php foreach ($countries_by_name as $name => $country_info): ?>
                    <?php $code = $country_info['code']; ?>
                    <option value="<?php echo htmlspecialchars($code); ?>"
                        data-pattern="<?php echo htmlspecialchars($country_info['pattern'] ?? ''); ?>"
                        data-min="<?php echo htmlspecialchars($country_info['minDigits']); ?>"
                        data-max="<?php echo htmlspecialchars($country_info['maxDigits']); ?>"
                        data-example="<?php echo htmlspecialchars($country_info['example']); ?>"
                        <?php echo ($form_values['care_country_code'] ?? '') == $code ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($code) . ' - ' . htmlspecialchars($name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="tel" id="care_mobile" name="care_mobile" 
                   value="<?php echo htmlspecialchars($form_values['care_mobile']); ?>" 
                   placeholder="e.g., 71 123 456"
                   pattern="[0-9\s\-\(\)]+"
                   title="Please enter a valid phone number">
        </div>
        <small style="display: block; margin-top: 4px; color: #7f8c8d;">
            Enter the local phone number without country code (optional, for follow-up care)
        </small>
    </div>
    
    <!-- Email -->
    <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email"
            value="<?php echo htmlspecialchars($form_values['email']); ?>"
            placeholder="patient@example.com"
            pattern="^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$"
            title="Please enter a valid email address (e.g., patient@example.com)">
    </div>
    
    <!-- Address -->
    <div class="form-group">
        <label for="address" class="required">Address</label>
        <input type="text" id="address" name="address" 
            value="<?php echo htmlspecialchars($form_values['address'] ?? (!empty($patient['address']) ? $patient['address'] : '')); ?>"
            placeholder="Enter patient address">
    </div>
    
    <?php /*
    <!-- Address Dropdowns -->
    <div class="form-group">
        <label>Address (Lebanon)</label>
        <div class="address-row">
            <!-- District -->
            <div class="address-col">
                <select id="district" name="district" required>
                    <option value="">Select District</option>
                    <?php foreach ($districts_data as $district => $kazas): ?>
                        <option value="<?php echo htmlspecialchars($district); ?>"
                            <?php echo $form_values['district'] == $district ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($district); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Kaza -->
            <div class="address-col">
                <select id="kaza" name="kaza" required <?php echo empty($form_values['district']) ? 'disabled' : ''; ?>>
                    <option value="">Select Kaza</option>
                </select>
            </div>
            
            <!-- City -->
            <div class="address-col">
                <select id="city" name="city" required <?php echo empty($form_values['kaza']) ? 'disabled' : ''; ?>>
                    <option value="">Select City</option>
                </select>
            </div>
        </div>
    </div>
    */ ?>
    
    <!-- Buttons -->
    <div class="button-group">
        <button type="submit" name="<?php echo $is_edit_mode ? 'update' : 'submit'; ?>" class="btn btn-submit">
            <i class="fas <?php echo $button_icon; ?>"></i> <?php echo $button_text; ?>
        </button>
        <button type="button" name="cancel" class="btn btn-cancel" onclick="window.location.href='<?php echo htmlspecialchars($cancel_url); ?>'">
            <i class="fas fa-times-circle"></i> Cancel
        </button>
    </div>
</form>

<script>
// Service type button selection
function initializeServiceTypeButtons() {
    const serviceButtons = document.querySelectorAll('.service-btn');
    const serviceTypeInput = document.getElementById('service_type');
    
    // Set active button based on current value
    const currentServiceType = serviceTypeInput.value;
    if (currentServiceType) {
        serviceButtons.forEach(btn => {
            if (btn.dataset.type === currentServiceType) {
                btn.classList.add('active');
            }
        });
    }
    
    // Button click handlers (only for non-disabled buttons)
    serviceButtons.forEach(button => {
        if (!button.disabled) {
            button.addEventListener('click', function() {
                serviceButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                serviceTypeInput.value = this.dataset.type;
            });
        }
    });
}

// Address dropdown chaining
function initializeAddressDropdowns() {
    const districtSelect = document.getElementById('district');
    const kazaSelect = document.getElementById('kaza');
    const citySelect = document.getElementById('city');

    // Address dropdown block is optional/commented in this form.
    if (!districtSelect || !kazaSelect || !citySelect) {
        return;
    }

    const districtsData = <?php echo json_encode($districts_data); ?>;
    
    // Populate kaza dropdown based on selected district
    function populateKaza(district) {
        kazaSelect.innerHTML = '<option value="">Select Kaza</option>';
        citySelect.innerHTML = '<option value="">Select City</option>';
        kazaSelect.disabled = true;
        citySelect.disabled = true;
        
        if (district && districtsData[district]) {
            kazaSelect.disabled = false;
            Object.keys(districtsData[district]).forEach(kaza => {
                const option = document.createElement('option');
                option.value = kaza;
                option.textContent = kaza;
                if (kaza === "<?php echo $form_values['kaza']; ?>") {
                    option.selected = true;
                }
                kazaSelect.appendChild(option);
            });
            
            // If we have a kaza value, populate cities too
            if ("<?php echo $form_values['kaza']; ?>") {
                populateCity(district, "<?php echo $form_values['kaza']; ?>");
            }
        }
    }
    
    // Populate city dropdown based on selected kaza
    function populateCity(district, kaza) {
        citySelect.innerHTML = '<option value="">Select City</option>';
        citySelect.disabled = true;
        
        if (district && kaza && districtsData[district][kaza]) {
            citySelect.disabled = false;
            districtsData[district][kaza].forEach(city => {
                const option = document.createElement('option');
                option.value = city;
                option.textContent = city;
                if (city === "<?php echo $form_values['city']; ?>") {
                    option.selected = true;
                }
                citySelect.appendChild(option);
            });
        }
    }
    
    // Event listeners
    districtSelect.addEventListener('change', function() {
        populateKaza(this.value);
    });
    
    kazaSelect.addEventListener('change', function() {
        const district = districtSelect.value;
        populateCity(district, this.value);
    });
    
    // Initialize if district is already selected
    if ("<?php echo $form_values['district']; ?>") {
        populateKaza("<?php echo $form_values['district']; ?>");
    }
}

// Form validation and phone number handling
function initializeFormValidation() {
    const form = document.getElementById('ticketForm');
    const mobileInput = document.getElementById('mobile');
    const carePhoneInput = document.getElementById('care_mobile');
    const countryCodeSelect = document.getElementById('country_code');
    const countryCodeCareSelect = document.getElementById('country_code_care');
    
    // International phone number countries with their patterns
    const phonePatterns = {
        '+961': { min: 8, max: 9, name: 'Lebanon' },              // Lebanon
        '+1': { min: 10, max: 10, name: 'US/Canada' },             // US/Canada
        '+44': { min: 10, max: 11, name: 'UK' },                   // UK
        '+33': { min: 9, max: 9, name: 'France' },                 // France
        '+49': { min: 10, max: 11, name: 'Germany' },              // Germany
        '+39': { min: 10, max: 10, name: 'Italy' },                // Italy
        '+966': { min: 9, max: 9, name: 'Saudi Arabia' },          // Saudi Arabia
        '+971': { min: 9, max: 9, name: 'UAE' },                   // UAE
        '+92': { min: 10, max: 10, name: 'Pakistan' },             // Pakistan
        '+91': { min: 10, max: 10, name: 'India' }                 // India
    };
    
    // Format international phone number as user types
    function formatInternationalPhone(value) {
        // Remove all non-digit and + characters first
        let cleaned = value.replace(/[^\d+]/g, '');
        
        // Ensure + is at the start if present
        if (cleaned.includes('+')) {
            cleaned = '+' + cleaned.replace(/\+/g, '');
        }
        
        // Add spaces for better readability
        if (cleaned.startsWith('+')) {
            // Format: +961 71 123 456
            let parts = cleaned.substring(1);
            if (parts.length > 0) {
                if (parts.length <= 2) return '+' + parts;
                if (parts.length <= 4) return '+' + parts.substring(0, 2) + ' ' + parts.substring(2);
                return '+' + parts.substring(0, 2) + ' ' + parts.substring(2, 4) + ' ' + parts.substring(4);
            }
        }
        
        return cleaned;
    }
    
    // Validate local phone number (without country code) based on selected country
    function validatePhoneNumber(value, countryCode = null) {
        if (!value || value.trim() === '') return true; // Optional field
        
        const digitsOnly = value.replace(/\D/g, '');
        const digitCount = digitsOnly.length;
        
        if (countryCode) {
            // Get min/max from selected country option
            let minDigits = 6;
            let maxDigits = 15;
            
            if (countryCode) {
                const options = document.querySelectorAll(`option[value="${countryCode}"]`);
                if (options.length > 0) {
                    const option = options[0];
                    minDigits = parseInt(option.dataset.min) || minDigits;
                    maxDigits = parseInt(option.dataset.max) || maxDigits;
                }
            }
            
            return digitCount >= minDigits && digitCount <= maxDigits;
        } else {
            // Fallback validation for local numbers
            return digitCount >= 6 && digitCount <= 15;
        }
    }
    
    // Validate current contact mobile on blur
    if (mobileInput) {
        mobileInput.addEventListener('blur', function() {
            const cleaned = this.value.replace(/[^0-9]/g, '');
            if (cleaned && cleaned.length < 6) {
                alert('Please enter a valid phone number (at least 6 digits)');
                this.focus();
            }
        });
    }
    
    // Validate care mobile on blur (similar to contact mobile)
    if (carePhoneInput) {
        carePhoneInput.addEventListener('blur', function() {
            const cleaned = this.value.replace(/[^0-9]/g, '');
            if (cleaned && cleaned.length < 6) {
                alert('Please enter a valid phone number (at least 6 digits)');
                this.focus();
            }
        });
    }
    
    form.addEventListener('submit', function(e) {
        const serviceTypeInput = document.getElementById('service_type');
        if (!serviceTypeInput.value) {
            e.preventDefault();
            alert('Please select a service type');
            return false;
        }
        
        // Validate country code and mobile are both set
        if (!countryCodeSelect.value || !mobileInput.value) {
            e.preventDefault();
            alert('Please enter both country code and mobile number');
            return false;
        }
        
        // Validate current contact mobile if provided
        if (mobileInput.value && !validatePhoneNumber(mobileInput.value, countryCodeSelect ? countryCodeSelect.value : null)) {
            e.preventDefault();
            alert('Please enter a valid current contact mobile number (at least 6 digits)');
            return false;
        }
        
        // Validate care mobile if provided (similar to contact mobile)
        if (carePhoneInput && carePhoneInput.value && !validatePhoneNumber(carePhoneInput.value, countryCodeCareSelect ? countryCodeCareSelect.value : null)) {
            e.preventDefault();
            alert('Please enter a valid care mobile number (at least 6 digits)');
            return false;
        }
        
        // If care mobile is empty, populate it with contact number
        if (carePhoneInput && !carePhoneInput.value) {
            carePhoneInput.value = mobileInput.value;
            if (countryCodeCareSelect && countryCodeSelect) {
                countryCodeCareSelect.value = countryCodeSelect.value;
            }
        }
        
        return true;
    });
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeServiceTypeButtons();
    initializeAddressDropdowns();
    initializeFormValidation();
    const openSearchBtn = document.getElementById('openPatientSearchBtn');
    if (openSearchBtn) {
        openSearchBtn.addEventListener('click', function() {
            let url = 'patient_selection.php';
            const params = new URLSearchParams();
            params.set('return_to', 'new_ticket.php');
            <?php if (!empty($from_page)): ?>
            params.set('from', <?php echo json_encode($from_page); ?>);
            <?php endif; ?>
            url += '?' + params.toString();
            window.location.href = url;
        });
    }

    const existingPatientInput = document.getElementById('existing_patient_id');
    const existingPatientNotice = document.getElementById('existingPatientNotice');
    const editExistingPatientBtn = document.getElementById('editExistingPatientBtn');

    const lockableFieldIds = [
        'patient_name',
        'country_code',
        'mobile',
        'country_code_care',
        'care_mobile',
        'email',
        'address'
    ];

    const setExistingPatientFieldsEditable = (editable) => {
        lockableFieldIds.forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;

            const tag = (el.tagName || '').toLowerCase();
            if (tag === 'select') {
                el.style.pointerEvents = editable ? '' : 'none';
                if (editable) {
                    el.removeAttribute('tabindex');
                } else {
                    el.setAttribute('tabindex', '-1');
                }
            } else {
                el.readOnly = !editable;
            }

            if (editable) {
                el.classList.remove('existing-locked');
            } else {
                el.classList.add('existing-locked');
            }
        });
    };

    const hasExistingPatientSelection = existingPatientInput && existingPatientInput.value.trim() !== '';
    if (hasExistingPatientSelection) {
        setExistingPatientFieldsEditable(false);
    }

    if (editExistingPatientBtn) {
        editExistingPatientBtn.addEventListener('click', function() {
            setExistingPatientFieldsEditable(true);
            // Keep existing_patient_id so form submission updates the existing patient row
            // Don't show the notice and button anymore since fields are now editable
            if (existingPatientNotice) {
                existingPatientNotice.style.display = 'none';
            }
            this.style.display = 'none';
        });
    }

    const clearExistingSelection = () => {
        // Don't clear existing_patient_id here - we want to preserve it so form submission
        // updates the existing patient record instead of creating a new one
        if (existingPatientNotice) {
            existingPatientNotice.style.display = 'none';
        }
        if (editExistingPatientBtn) {
            editExistingPatientBtn.style.display = 'none';
        }
    };

    ['patient_name', 'mobile', 'country_code', 'care_mobile', 'country_code_care', 'email', 'address'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', clearExistingSelection);
            el.addEventListener('change', clearExistingSelection);
        }
    });
});
</script>
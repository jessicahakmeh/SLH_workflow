<?php

/**
 * Shared helper to persist undo state in session for ticket actions.
 */
function saveUndoState($pdo, $patient_id, $previous_status, $new_status, $action, $department) {
    $patient = executeAndFetchOne($pdo, "SELECT img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]) ?: [];

    $_SESSION['last_action'] = [
        'patient_id' => $patient_id,
        'previous_status' => $previous_status,
        'current_status' => $new_status,
        'action' => $action,
        'department' => $department,
        'img' => $patient['img'] ?? 0,
        'lab' => $patient['lab'] ?? 0,
        'dp2' => $patient['dp2'] ?? 0,
        'imaging_machine' => $patient['imaging_machine'] ?? null,
        'timestamp' => time()
    ];
}

<?php
/**
 * realtime_updates.php - Server-Sent Events for real-time status broadcasting
 * 
 * Broadcasts:
 * - Status changes across all departments
 * - Machine assignments in imaging
 * - New patient arrivals
 * - Completion notifications
 */

require_once 'config.php';
require_once __DIR__ . '/lib/monitoring.php';
session_start();
session_write_close(); // Allow other scripts to run
authRequireRoles([], ['log_view' => false]);

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('X-Accel-Buffering: no');

// Set a longer execution time
set_time_limit(0);

// Track connection start to send periodic heartbeats
$connectionStart = time();
$sseClientId = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
// Record client connect
increment_metric('sse_client_connects');
log_event('sse', 'Client connected: ' . $sseClientId);

$lastCheck = time() - 5; // Check last 5 seconds for recent changes
$stream = isset($_GET['stream']) ? $_GET['stream'] : 'all';

// Connection retry configuration
$maxRetries = 3;
$retryDelay = 500000; // Start with 0.5 seconds
$connectionAttempts = 0;

while (true) {
    try {
        // Ensure database connection is alive before queries
        if (!ensureDbConnectionAlive($pdo)) {
            increment_metric('db_reconnect_fail');
            throw new PDOException("Unable to establish database connection");
        }
        
        $checkTime = date('Y-m-d H:i:s', $lastCheck);
        
        $hasOutput = false;
        
        // ====================
        // STATUS CHANGES
        // ====================
        try {
            $statusChanges = executeAndFetch($pdo, "
                SELECT 
                    tl.ticket_id,
                    t.queue_number,
                    t.current_status,
                    t.lab,
                    t.img,
                    t.dp2,
                    t.cl,
                    tl.action,
                    tl.from_status,
                    tl.to_status,
                    p.patient_name,
                    p.mobile
                FROM ticket_logs tl
                JOIN tickets t ON tl.ticket_id = t.ticket_id
                JOIN patients p ON t.patient_id = p.patient_id
                WHERE tl.created_at > ?
                AND tl.action IN ('Status Changed', 'Called in Imaging', 'Called in Lab', 
                                  'Assigned to Machine', 'Completed', 'Released from Wrong Info')
                AND DATE(t.arrival_timestamp) = CURDATE()
                ORDER BY tl.created_at DESC
                LIMIT 10
            ", [$checkTime]);
            
            if (!empty($statusChanges)) {
                foreach ($statusChanges as $change) {
                    echo "event: status_update\n";
                    echo "data: " . json_encode([
                        'ticket_id' => $change['ticket_id'],
                        'queue_number' => $change['queue_number'],
                        'patient_name' => $change['patient_name'],
                        'status' => $change['current_status'],
                        'from_status' => $change['from_status'],
                        'to_status' => $change['to_status'],
                        'action' => $change['action'],
                        'lab' => $change['lab'],
                        'img' => $change['img'],
                        'dp2' => $change['dp2'],
                        'cl' => $change['cl'],
                        'mobile' => $change['mobile'],
                        'timestamp' => date('Y-m-d H:i:s')
                    ]) . "\n\n";
                    $hasOutput = true;
                }
            }
        } catch (PDOException $e) {
            error_log("SSE Status Changes Query Error: " . $e->getMessage());
            // Continue with other queries instead of failing
        }
        
        // ====================
        // MACHINE ASSIGNMENTS
        // ====================
        try {
            $machineAssigns = executeAndFetch($pdo, "
                SELECT 
                    tl.ticket_id,
                t.queue_number,
                t.imaging_machine,
                p.patient_name,
                tl.machine_type
            FROM ticket_logs tl
            JOIN tickets t ON tl.ticket_id = t.ticket_id
            JOIN patients p ON t.patient_id = p.patient_id
            WHERE tl.created_at > ?
            AND tl.action = 'Assigned to Machine'
            AND DATE(t.arrival_timestamp) = CURDATE()
            ORDER BY tl.created_at DESC
            LIMIT 5
            ", [$checkTime]);
            
            if (!empty($machineAssigns)) {
                foreach ($machineAssigns as $assign) {
                    echo "event: machine_assignment\n";
                    echo "data: " . json_encode([
                        'ticket_id' => $assign['ticket_id'],
                        'queue_number' => $assign['queue_number'],
                        'patient_name' => $assign['patient_name'],
                        'machine' => $assign['imaging_machine'],
                        'timestamp' => date('Y-m-d H:i:s')
                    ]) . "\n\n";
                    $hasOutput = true;
                }
            }
        } catch (PDOException $e) {
            error_log("SSE Machine Assignments Query Error: " . $e->getMessage());
            // Continue with other queries instead of failing
        }
        
        // Flush any output now
                if ($hasOutput) {
            ob_flush();
            flush();
            // Reset heartbeat timer when we have activity
            $connectionStart = time();
        } else {
            // No activity: release DB connection to reduce open connections
            try { $pdo = null; } catch (Exception $e) {}
        }

        // Sleep between iterations (2 seconds)
        usleep(2000000);

        // Update last check time for next queries
        $lastCheck = time();

        // Send periodic heartbeat to keep connection alive and prompt client reconnect as necessary
        if (time() - $connectionStart > 55) {
            echo "event: heartbeat\n";
            echo "data: " . json_encode(['timestamp' => date('Y-m-d H:i:s')]) . "\n\n";
            ob_flush();
            flush();
            // Reset heartbeat timer after sending
            $connectionStart = time();
        }
    } catch (PDOException $e) {
        // Connection lost or query failed
        error_log("SSE Connection Error: " . $e->getMessage());
        
        // Close current connection and wait before reconnecting
        try { $pdo = null; } catch (Exception $closeError) {}

        // Wait before reconnecting (exponential backoff with cap)
        $connectionAttempts++;
        increment_metric('sse_reconnect_attempts');
        log_event('sse', 'Reconnection attempt #' . $connectionAttempts . ' for client ' . $sseClientId);
        usleep(min(1000000 * $connectionAttempts, 5000000)); // wait up to 5s

        try {
            // Use require to force re-execution and reinitialization of $pdo
            require 'config.php';
            // Reset connection attempts counter
            $connectionAttempts = 0;
            increment_metric('db_reconnect_success');
            log_event('db', 'Reinitialized PDO via require after SSE error');
        } catch (Exception $reconnectError) {
            // If reconnection fails, log and continue retrying
            error_log("SSE Reconnection Failed: " . $reconnectError->getMessage());
            log_event('sse', 'Reconnection failed: ' . $reconnectError->getMessage());
            usleep(1000000); // Wait 1 second before next attempt
        }
    } catch (Exception $e) {
        // Catch any other unexpected errors
        error_log("SSE Unexpected Error: " . $e->getMessage());
        break;
    }
}
?>
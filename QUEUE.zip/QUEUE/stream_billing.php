<?php
// Public no-login stream display page.
header('Location: stream.php?stream=billing');
exit;

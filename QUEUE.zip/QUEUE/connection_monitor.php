<?php
/**
 * MySQL Connection Pool Monitor
 * Tracks active connections and alerts when threshold is exceeded
 * Usage: Call periodically or include in background tasks
 */

require_once 'config.php';

function getConnectionStats($pdo) {
    try {
        $result = executeAndFetchOne($pdo, "SHOW PROCESSLIST");
        $processCount = executeAndFetchOne($pdo, "SELECT COUNT(*) as count FROM information_schema.processlist");
        
        $vars = executeAndFetch($pdo, 
            "SHOW VARIABLES WHERE variable_name IN ('max_connections', 'max_used_connections')"
        );
        
        $maxConnections = 500;
        $maxUsed = 0;
        foreach ($vars as $var) {
            if ($var['Variable_name'] == 'max_connections') {
                $maxConnections = (int)$var['Value'];
            }
            if ($var['Variable_name'] == 'max_used_connections') {
                $maxUsed = (int)$var['Value'];
            }
        }
        
        $currentConnections = (int)($processCount['count'] ?? 0);
        $percentUsed = ($currentConnections / $maxConnections) * 100;
        
        return [
            'timestamp' => date('Y-m-d H:i:s'),
            'current_connections' => $currentConnections,
            'max_connections' => $maxConnections,
            'max_used_connections' => $maxUsed,
            'percent_used' => round($percentUsed, 2),
            'status' => $percentUsed > 80 ? 'WARNING' : ($percentUsed > 90 ? 'CRITICAL' : 'OK')
        ];
    } catch (Exception $e) {
        return ['error' => $e->getMessage()];
    }
}

function logConnectionStats($stats) {
    $logFile = __DIR__ . '/logs/connection_monitor.log';
    
    // Create logs directory if needed
    if (!is_dir(dirname($logFile))) {
        @mkdir(dirname($logFile), 0777, true);
    }
    
    $logEntry = json_encode($stats) . "\n";
    @file_put_contents($logFile, $logEntry, FILE_APPEND);
}

// Main execution
if (php_sapi_name() === 'cli' || isset($_GET['monitor'])) {
    $stats = getConnectionStats($pdo);
    logConnectionStats($stats);
    
    if (php_sapi_name() === 'cli') {
        echo json_encode($stats, JSON_PRETTY_PRINT) . "\n";
    } else {
        header('Content-Type: application/json');
        echo json_encode($stats);
    }
    
    // Alert if critical
    if ($stats['status'] === 'CRITICAL') {
        // Send alert email or log critical event
        error_log("CRITICAL: MySQL connections at {$stats['percent_used']}% ({$stats['current_connections']}/{$stats['max_connections']})");
    }
}
?>

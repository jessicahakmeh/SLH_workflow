# ST. LOUIS HOSPITAL - QUEUE MANAGEMENT SYSTEM DOCUMENTATION

**System Location:** `C:\Xampp\htdocs\QUEUE\`
**Database:** `queue` (MySQL)

## Table of Contents
1. [System Overview](#system-overview)
2. [Core Features](#core-features)
3. [System Rules & Workflow](#system-rules--workflow)
4. [User Roles & Responsibilities](#user-roles--responsibilities)
5. [Technical Architecture](#technical-architecture)
6. [Database Structure](#database-structure)
7. [Configuration Reference](#configuration-reference)
8. [System-Specific Modifications](#system-specific-modifications)
9. [Real-Time Refresh & State Preservation](#real-time-refresh--state-preservation-system-new)
10. [Troubleshooting & Support](#troubleshooting--support)

---

## System Overview

The St. Louis Hospital Queue Management System coordinates patient flow across four main departments:
- **Billing** (Patient Intake Control)
- **Laboratory** (Lab Testing)
- **Imaging** (Medical Imaging - X-ray, CT, MRI, Ultrasound, Fluoroscopy, Mammography)
- **Clinics** (Specialty Clinics: ENT-URO, OBGYN, Cardio, OPS, PAU, Misc)

Integrated features include document scanning, real-time patient notifications via WhatsApp, network-based file storage, and comprehensive audit logging.

**Key Objective:** Ensure patient safety through MRN validation, maintain quality through document verification, and streamline workflows with role-based access control.

**Technology Stack:**
- **Backend:** PHP with Active Directory Integration
- **Database:** MySQL (`queue` database)
- **Authentication:** LDAP (192.168.20.1) with Local Fallback
- **Timezone:** Asia/Beirut
- **Communications:** WhatsApp via bestsmsbulk.com API
- **Document Storage:** Network Share (\\192.168.20.3\slh\Internal\Finance\Accounting Department\Admission & Billing\Common\Patients ID)
- **Feedback:** survey.slouishospital.com/feedback

---

## Core Features

### 1. **Patient Queue Management**
- **Real-time Queue Display:** Separate interfaces for Billing, Lab, Imaging, Clinics (accessible via stream.php?mode=fullscreen&stream=[lab|imaging|billing|clinics])
- **Queue Number Generation:** Daily prefixes - **A** (Appointment), **P** (Private), **G** (Guarantor), **C** (Clinics)
  - Example: A001, P042, G115, C008 (resets daily at midnight)
- **Multi-Stream Routing:** Route via flags in tickets table: `lab=1`, `img=1`, `dp2=1` (both), `cl=1` (clinics)
- **Status Tracking:** 13 defined statuses with validation (see Database Structure section)

### 2. **Multi-Department Streams**
- **Billing Stream** (`billing.php`): Central intake, MRN validation, routing decisions
- **Laboratory Stream** (`laboratory.php`): Lab-bound patients, status processing
- **Imaging Stream** (`imaging.php`): Machine-specific queues with assignment (`imaging_assignments.php`)
  - **Machines:** Xray, Fluoroscopy, Mammography, CT, Ultrasound, MRI
  - View: `imaging_machine_queue.php` shows per-machine queues
  - Stats: `imaging_stats.php` for performance metrics
- **Clinics Stream** (`clinics.php`): Clinic-specific queues
  - **Clinic Types:** Misc, ENT-URO, OBGYN, Cardio, OPS (Operations), PAU

### 3. **Document Management**
- **Prescription Scanning** (`scan_docs.php`): Captures patient documents during intake
- **Document Quality Control** (`butler.php`): Butler verifies readability and requests retakes
- **Network Share Storage:** Files saved to network paths configured in config.php:
  - **ID Documents:** `\\192.168.20.3\slh\Internal\Finance\Accounting Department\Admission & Billing\Common\Patients ID\Queue_IDs\`
  - **Insurance & Prescriptions:** `\\192.168.20.3\slh\Internal\Finance\Accounting Department\Admission & Billing\Common\Patients ID\Queue_presc&ins\`
- **PDF Generation:** FPDF library for patient ID documents (`download_pdf.php`)

### 4. **Patient Routing & Workflow**
- **Flexible Routing:** Billing sets flags before approval: `lab`, `img`, `dp2` (both), `cl`
- **Existing Patient Management** (`patient_selection.php`): Search existing patients by MRN, name, or mobile; create new tickets without duplicate identities
- **Wrong Info Pathway:** Department staff press "Wrong Info" in `patient_actions.php` → patient returns to Billing with status='Wrong Info'
- **Undo Functionality** (`undo.php`): Time-limited (10-second window) reversal stored in session under `$_SESSION['last_action']`

### 5. **Authentication & Access Control** (`auth.php`)
- **Active Directory Integration:** LDAP authentication
  - **Primary Server:** ldap://192.168.20.1:389
  - **Fallback Server:** ldap://192.168.20.100:389
  - **Domain:** stlouis.com (NETBIOS: stlouis)
  - **Base DN:** DC=stlouis,DC=com
  - **Bind User:** svc-directus
- **Local Fallback:** Backdoor admin account (u: admin, p: r4!T) stored in `users` table
- **Role-Based Access:** Six roles with specific page access controls:
  - **admin** - All pages
  - **billing** - billing.php, new_ticket.php, patient_selection.php, scan_docs.php
  - **butler** - butler.php, scan_docs.php, new_ticket.php, download_pdf.php
  - **imaging** - imaging.php, imaging_assignments.php, imaging_machine_queue.php, imaging_stats.php
  - **laboratory** - laboratory.php
  - **quality** - statistics.php, administration.php (read-only analytics)
- **Session Management:** 24-hour timeout (`AUTH_SESSION_TIMEOUT_SECONDS=86400`), activity-tracked
- **Audit Logging:** All actions logged to `user_action_logs` and `ticket_logs` tables

### 6. **Statistics & Analytics** (Quality Role)
- **Dashboard:** `statistics.php` with date range filtering (default: last 30 days)
- **Metrics:** MRN search, patient timeline (arrival → first call → closing → approval timestamps)
- **Department Breakdown:** Lab, Imaging, Clinics patient counts and processing times
- **Feedback Tracking:** `feedback_tickets` table shows sent status
- **API:** `statistics_api.php` provides data for front-end charts
- **Export:** Statistics viewable in `administration.php` for qualified users

### 7. **Notification System**
- **WhatsApp Integration:** API via bestsmsbulk.com
  - **Endpoint:** `https://www.bestsmsbulk.com/bestsmsbulkapi/common/sendSmsWpAPITemplate.php`
  - **API Key:** (configured in config.php)
  - **Templates:** call_queue, skip_queue, ticket_queue
  - **Phone Format:** Must include country code (e.g., +961)
- **Real-time Alerts:** Browser notifications via `realtime_updates.php` polling (stream data refresh)
- **Contact Management:** Two mobile numbers per patient:
  - `mobile` - Current contact (primary)
  - `care_mobile` - Result/care contact (secondary, optional)

### 8. **Real-Time Refresh & State Preservation System** (NEW)
- **RefreshManager.js**: Central class for managing page refresh with state preservation
  - **Focus Preservation:** Automatically saves and restores focused elements (e.g., machine dropdown)
  - **Form State Preservation:** Maintains field values during auto-refresh
  - **Partial Updates:** Updates specific sections without full page reload
  - **Server-Sent Events (SSE):** Real-time status broadcasts via `realtime_updates.php`
- **Cross-Page Status Broadcasting:**
  - **Status Updates:** Changes in any department broadcast to all open pages
  - **Machine Assignments:** Imaging assignments trigger updates across related pages
  - **New Arrivals:** New patient tickets broadcast in real-time
  - **Butler Dashboard:** Automatically shows updates from Imaging, Lab, Billing, Clinics
- **AJAX Form Submissions:**
  - **Machine Assignment**: Instead of form submission → full reload, now uses AJAX with focus preservation
  - **Imaging Assignment Form**: Submits via AJAX, refreshes queue, maintains focus on machine dropdown
  - **No Page Reload**: Department staff can continue actions without interruption
- **Auto-Refresh Control:**
  - **Start:** `autoRefreshPage(interval_ms)` - begins refresh cycle (default: 1000ms)
  - **Stop:** `stopAutoRefresh()` - halts refresh
  - **Refresh Section:** `refreshPageSection(selector, url)` - updates specific HTML element
  - **Full Refresh:** `forcePageRefresh()` - manual full-page refresh with state preservation
- **Status Event Listeners:**
  ```javascript
  window.addEventListener('ticket-status-updated', (e) => {
      console.log('Status changed:', e.detail);
      // e.detail: { ticket_id, queue_number, status, patient_name, lab, img, dp2, cl }
  });
  
  window.addEventListener('machine-assigned', (e) => {
      console.log('Machine assigned:', e.detail);
      // e.detail: { ticket_id, queue_number, patient_name, machine }
  });
  ```
- **Pages with RefreshManager Integration:**
  - `butler.php` - Auto-refresh dashboard with state preservation ✓
  - `imaging.php` - Machine queue refresh + assignment form AJAX ✓
  - `laboratory.php` - Lab queue refresh (in progress)
  - `billing.php` - (to be updated)
  - `clinics.php` - (to be updated)
  - `stream.php` - (to be updated)
- **Implementation Files:**
  - `refresh-manager.js` - Core class
  - `realtime_updates.php` - SSE endpoint for broadcasts
  - `queue_refresh.php` - AJAX endpoint for targeted updates

### 9. **Data Quality & Validation**
- **MRN (Medical Record Number) Validation:** `mrn` field in `patients` table, MANDATORY before routing to Lab/Imaging/Clinics
- **Phone Formatting:** `formatInternationalNumber()` in new_ticket.php strips non-numeric, combines with country code
- **Demographics Snapshot:** `demographics_snapshot` (JSON) saved at ticket creation; `demographics_edited` flag tracks changes
- **Existing Patient Flag:** `is_existing_patient=1` locks MRN from change during workflow
- **Validation Rules** (`scan_docs.php`):
  - Patient name required
  - Mobile number required (country_code + mobile)
  - Service type: Appointment, Private, Guarantor, or Clinics
  - Prescription image mandatory for Butler validation

---

## System Rules & Workflow

### Patient Intake Workflow

```
New Patient Entry
    ↓
[Scan Documents Phase]
    ↓ (Butler validates prescription readability)
[Billing Details Review]
    ↓ (Billing confirms MRN and contact info)
[Department Routing Decision]
    ├→ Lab Only
    ├→ Imaging (Machine Assignment)
    ├→ Lab + Imaging (Both)
    └→ Clinics
    ↓
[Department Processing]
    ↓ (Department validates routing appropriateness)
[Wrong Info Path] ← If data incorrect
    ↓
[Billing Correction]
    ↓
[Result Delivery & Feedback]
```

### Critical Business Rules

#### **1. MRN (Medical Record Number) Validation Rule**
- **MUST** be populated in `patients.mrn` field before setting `lab=1`, `img=1`, or `cl=1` in `tickets` table
- **Billing enforces:** Validation in billing.php prevents routing without MRN
- **Locked for existing patients:** When `is_existing_patient=1`, MRN cannot be changed during ticket workflow
- **Database requirement:** Unique constraint recommended on mrn + effective_date (for multi-location facilities)
- **UI prompt:** "MRN is required before sending to [Department]" message shown if missing

#### **2. Document Requirements (Prescription Mandatory)**
- **Policy:** Prescription file upload REQUIRED in `scan_docs.php` before patient moves to Billing
- **File Storage:** Stored in network path `\\192.168.20.3\slh\...\Queue_presc&ins\`
- **Butler Validation** (butler.php): Checks image legibility
- **Quality Criteria:**
  - Full prescription visible (no cropped edges)
  - Medication text legible at normal zoom
  - Doctor name and date readable
  - No glare, motion blur, or shadows covering text
  - Patient/patient ID visible on document

#### **3. Mobile Number Rules**
- **Database Fields:**
  - `patients.mobile` - Current contact number (required)
  - `patients.care_mobile` - Result delivery number (optional)
  - `patients.country_code` - Default '+961' (Lebanon)
  - `patients.care_country_code` - Default '+961'
- **Rule:** If both numbers identical, enter in `mobile` only; leave `care_mobile` NULL
- **WhatsApp Requirement:** Phone must be formatted with country code for delivery via bestsmsbulk.com API
- **Validation:** Both numbers phone-checked at intake; non-numeric chars stripped by `formatInternationalNumber()`

#### **4. Existing Patient Workflow**
- **Process:** Billing uses `patient_selection.php` to search `patients` table by MRN, name, or mobile
- **New Ticket Creation:** Use "New Ticket from Existing Patient" → Creates new `tickets` row with same `patient_id`
- **Flag:** `is_existing_patient=1` in tickets table
- **Constraints:** When existing patient, `demographics_snapshot` and `demographics_edited` fields record any changes
- **Allowed Updates:** Only contact info (mobile, care_mobile, email, address) can be updated; MRN is immutable
- **Save Requirement:** Changes persisted to `patients` table before departmental routing

#### **5. Status Transitions** (tickets.current_status ENUM)
| Status | Initial | Used By | Purpose |
|--------|---------|---------|----------|
| Arrived | ✓ | System | Patient scanned/registered |
| Waiting | - | Butler/Billing | Queued after doc validation |
| In Process | - | Department | Department actively processing |
| Needed by Billing | - | Department | Returned for correction |
| Called | - | Department | Patient called to station |
| On the Way | - | Department | Transitional (not heavily used) |
| Skipped | - | Department | Patient skipped/left queue |
| Recalled | - | Department | Patient re-called after skip |
| Served | - | Department | Service completed |
| On Hold | - | Imaging | Imaging machine unavailable |
| Wrong Info | - | Department | Incorrect routing/data → back to Billing |
| Completed | - | System | Final status, ticket closed |
| Canceled | - | Admin/Billing | Ticket voided |

**Transition Logic:**
```
Arrived → Waiting (after doc scan)
  ↓
Called → Served → Completed
  ↓
[If correction needed] → Wrong Info → [Return to Billing for re-routing]
```

#### **6. Undo & Correction Workflow** (stream.php & undo.php)
- **Undo Storage:** `$_SESSION['last_action']` array with keys:
  - `patient_id`, `previous_status`, `current_status`, `action`, `department`, `img`, `lab`, `dp2`, `cl`, `imaging_machine`
- **Window:** 10 seconds from action timestamp (session variable)
- **Scope:** Only at point of origin (stream where action occurred)
- **Activation:** Browser-side "Undo" button calls `undo.php?action=undo_last`
- **After Expiry:** Department uses "Wrong Info" button in `patient_actions.php`
- **Wrong Info Flow:** Updates `current_status='Wrong Info'` → Patient appears in Billing queue for correction

#### **7. Imaging Machine Assignments** (imaging_assignments.php)
| Machine | tickets.imaging_machine | Common Use |
|---------|------------------------|------------|
| Xray | Xray | Standard radiography |
| Fluoroscopy | Fluoroscopy | Real-time imaging |
| Mammography | Mammography | Breast imaging |
| CT | CT | Computed tomography |
| Ultrasound | Ultrasound | Soft tissue imaging |
| MRI | MRI | Magnetic resonance |

**Multi-Machine Workflow:**
- If patient needs 2+ machines → Duplicate patient records created
- Each duplicate has separate `ticket_id` with same `queue_number`, name, MRN
- Each assigned to single machine in `imaging_machine` field
- Imaging staff assigns machine in `imaging_assignments.php`

#### **8. Clinic Assignments** (clinics.php, tickets.Clinic ENUM)
| Clinic Code | Full Name | tickets.Clinic |
|-------------|-----------|----------------|
| Misc | Miscellaneous | Misc |
| ENT-URO | Ear, Nose, Throat & Urology | ENT-URO |
| OBGYN | Obstetrics & Gynecology | OBGYN |
| Cardio | Cardiology | Cardio |
| OPS | Operations/Orthopedic Surgery | OPS |
| PAU | Pediatric/Adult Unit | PAU |

**Routing:**
- Set `cl=1` and `Clinic='[value]'` in tickets table
- Each clinic has separate queue view in `clinics.php`
- Clinic staff selects from dropdown when routing from Billing

---

## User Roles & Responsibilities

### 1. **Admin**
**Access Level:** Full system access
**Responsibilities:**
- User account management and role assignment
- System configuration and updates
- Access to all department streams
- Audit log review
- Backup and system health monitoring

**Can Access:**
- All pages and features
- User management interface
- Administration dashboard
- Statistics and reports
- All action logs

---

### 2. **Billing**
**Access Level:** Core patient control point
**Responsibilities:**
- Patient intake and registration
- Billing details review and validation
- Department routing decisions
- MRN (PID) validation
- Correcting "Wrong Info" patients
- Creating new tickets for existing patients

**Can Access:**
- Billing queue interface
- Patient selection and creation
- Document scanning workflow
- Edit ticket details
- View patient action modals
- Statistics (if quality role assigned)

**Key Workflow:**
1. Review patient demographics
2. Confirm MRN exists and is correct
3. Validate billing information
4. Make routing decisions (Lab/Imaging/Clinics/Both)
5. Send to appropriate department
6. Receive "Wrong Info" patients for correction

**Critical Task:**
- **NEVER** bypass PID validation messages
- **NEVER** alter locked PID for existing patients
- Always confirm identity details match for existing patients

---

### 3. **Butler**
**Access Level:** Document quality and patient readiness
**Responsibilities:**
- Document quality validation (especially prescriptions)
- Patient re-documentation when needed
- Information completeness verification
- Supporting Billing and departments with document requests

**Can Access:**
- Butler queue interface
- Scan documents interface
- Patient selection and editing
- Document download/view
- Feedback on document quality

**Key Workflow:**
1. Respond to "Need Butler" requests from Billing
2. Verify document readability
3. Request patient retake if unclear
4. Confirm information is complete
5. Hand back to Billing for routing

**Critical Tasks:**
- **Prescription is MANDATORY** - check if exists
- Verify image legibility (not blurred, cut, shadowed)
- If blurred → Retake immediately with patient present
- Check image quality: entire prescription visible, no glare, doctor details readable

---

### 4. **Imaging**
**Access Level:** Imaging department operations
**Responsibilities:**
- Validate patient identity for imaging procedures
- Confirm routing appropriateness
- Process imaging-bound patients
- Return misrouted patients via Wrong Info
- Assign to appropriate imaging machines
- Handle additional procedures for existing patients

**Can Access:**
- Imaging queue interface
- Machine assignment view
- Patient action modals
- Imaging statistics
- Patient details modal

**Key Workflow:**
1. Validate patient identity and imaging procedure
2. Confirm routing is appropriate
3. Process only when status and details are correct
4. If wrong info detected → Use Wrong Info pathway
5. If patient needs additional procedure → Coordinate with Billing for new ticket

**When to Use Wrong Info:**
- Patient information is incorrect
- Patient was misrouted to Imaging
- Required data is missing/inconsistent

**Misrouting Recovery:**
- If wrong routing detected quickly (within 10 seconds) → Origin team uses Undo
- If Undo window expired → Imaging uses Wrong Info to return to Billing

---

### 5. **Laboratory**
**Access Level:** Laboratory department operations
**Responsibilities:**
- Validate patient identity for lab procedures
- Confirm routing appropriateness
- Process lab-bound patients
- Return misrouted patients via Wrong Info
- Manage lab workflow and results

**Can Access:**
- Laboratory queue interface
- Patient action modals
- Lab statistics
- Patient details modal

**Key Workflow:**
1. Confirm patient identity matches lab request
2. Confirm patient was correctly routed to Lab
3. Start/continue lab workflow only when route and data valid
4. If data incorrect or misrouted → Use Wrong Info
5. Track test progress and results

**When to Use Wrong Info:**
- Billing data is incorrect
- Patient was sent to Lab by mistake
- Required information is inconsistent

---

### 6. **Quality**
**Access Level:** Reporting and analytics
**Responsibilities:**
- Generate statistical reports
- Track patient flow metrics
- Monitor service quality indicators
- Analyze feedback data
- Create compliance reports
- Identify workflow bottlenecks

**Can Access:**
- Statistics dashboard
- Date-range filtered reports
- MRN search and filtering
- Patient timeline analysis
- Feedback sent/received tracking
- Administration panel for data review

**Reports Generated:**
- Patient arrival and processing timelines
- Department-specific metrics
- Service time calculations
- Feedback delivery status
- Trend analysis and KPIs

---

## Technical Architecture

### File Structure Overview

| File | Purpose |
|------|---------|
| `config.php` | Database connection, table creation, configuration constants |
| `auth.php` | Authentication functions, session management, role validation |
| `index.php` | Landing page router (redirects based on auth status) |
| `login.php` | Login form with AD/local fallback |
| `billing.php` | Billing department queue interface |
| `butler.php` | Butler support queue interface |
| `imaging.php` | Imaging department queue with machine assignment |
| `laboratory.php` | Laboratory department queue |
| `clinics.php` | Clinics department queue |
| `new_ticket.php` | New patient intake form |
| `patient_selection.php` | Existing patient selection modal |
| `scan_docs.php` | Document upload/scanning interface |
| `edit_ticket.php` | Ticket detail editing |
| `statistics.php` | Analytics and reporting dashboard |
| `statistics_api.php` | API endpoint for statistics data |
| `administration.php` | Admin panel for system monitoring |
| `user_management.php` | User account and role management |
| `stream.php` | Unified queue data API |
| `stream_billing.php` | Billing-specific stream |
| `stream_imaging.php` | Imaging-specific stream |
| `stream_lab.php` | Lab-specific stream |
| `stream_clinics.php` | Clinics-specific stream |
| `patient_actions.php` | Patient action handlers (route, transfer, etc.) |
| `realtime_updates.php` | Real-time queue update polling |
| `undo.php` | Undo action handler |
| `feedback.php` | Feedback form access |
| `download_pdf.php` | PDF document download |

### Key Configuration Variables (in config.php)

| Variable | Purpose | Default |
|----------|---------|---------|
| `AUTH_ENABLED` | Enable/disable authentication | `true` |
| `AUTH_AD_ENABLED` | Enable Active Directory | `true` |
| `AUTH_AD_SERVER` | Primary LDAP server | `ldap://192.168.20.1` |
| `AUTH_AD_FALLBACK_SERVER` | Fallback LDAP server | `ldap://192.168.20.100` |
| `AUTH_AD_DOMAIN` | AD domain name | `stlouis.com` |
| `AUTH_SESSION_TIMEOUT_SECONDS` | Session timeout | `86400` (24 hours) |
| `APP_TIMEZONE` | Application timezone | `Asia/Beirut` |
| `FEEDBACK_TALLY_FORM_URL` | External feedback form URL | (configured) |
| `WHATSAPP_API_URL` | WhatsApp notification API | (configured) |
| `NETWORK_USERNAME` | Network share credentials | (configured) |
| `ID_SAVE_PATH` | Network path for ID documents | (configured) |
| `INSURANCE_SAVE_PATH` | Network path for insurance docs | (configured) |

---

## Database Structure

**Database Name:** `queue` (MySQL 5.7+)
**Charset:** utf8mb4
**Collation:** utf8mb4_general_ci

### Core Tables

#### 1. **patients** - Patient Demographics
```sql
CREATE TABLE patients (
    patient_id INT AUTO_INCREMENT PRIMARY KEY,
    mrn VARCHAR(100),                          -- Medical Record Number (unique)
    patient_name VARCHAR(255) NOT NULL,        -- Full name
    country_code VARCHAR(10) DEFAULT '+961',   -- Phone country code (Lebanon)
    mobile VARCHAR(20) NOT NULL DEFAULT '',    -- Current phone
    care_country_code VARCHAR(10) DEFAULT '+961', -- Alternative country code
    care_mobile VARCHAR(20),                   -- Result delivery phone
    email VARCHAR(255),                        -- Email address
    address TEXT                               -- Physical address
);

INDEXES:
- idx_patients_name (patient_name)
- idx_patients_mobile (mobile)
- idx_patients_care_mobile (care_mobile)
```

**Usage:** Stores patient identity once; reused across multiple tickets

---

#### 2. **tickets** - Queue/Workflow Entries
```sql
CREATE TABLE tickets (
    ticket_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,                   -- FK to patients
    queue_number VARCHAR(20) NOT NULL,         -- e.g., A001, P042, G115, C008
    service_type ENUM('Appointment','Private','Guarantor','Clinics'),
    current_status ENUM(
        'Arrived','Waiting','In Process','Needed by Billing',
        'Called','On the Way','Skipped','Recalled','Served','On Hold',
        'Wrong Info','Completed','Canceled'
    ) DEFAULT 'Arrived',
    arrival_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,  -- When registered
    approval_timestamp DATETIME,               -- When Billing approved/routed
    lab TINYINT(1) DEFAULT 0,                  -- Flag: routed to lab
    img TINYINT(1) DEFAULT 0,                  -- Flag: routed to imaging
    dp2 TINYINT(1) DEFAULT 0,                  -- Flag: routed to both (legacy)
    cl TINYINT(1) DEFAULT 0,                   -- Flag: routed to clinics
    lab_call_time DATETIME,                    -- When lab called patient
    imaging_call_time DATETIME,                -- When imaging called patient
    clinics_call_time DATETIME,                -- When clinic called patient
    closing_timestamp DATETIME,                -- When ticket closed
    imaging_machine ENUM('Xray','Fluoroscopy','Mammography','CT','Ultrasound','MRI'),
    Clinic ENUM('Misc','ENT-URO','OBGYN','Cardio','OPS','PAU'),
    registered_by_username VARCHAR(100),      -- Staff who created patient
    assigned_butler_username VARCHAR(100),    -- Butler assigned to support
    last_need_request_by_username VARCHAR(100),  -- Last "Need Butler" request
    last_need_request_at DATETIME,             -- When "Need Butler" pressed
    is_existing_patient TINYINT(1) DEFAULT 0, -- Existing patient flag
    demographics_snapshot LONGTEXT,            -- JSON of patient data at entry
    demographics_edited TINYINT(1) DEFAULT 0,  -- Flag: data was edited
    demographics_changed_fields LONGTEXT,     -- JSON of changed fields
    
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE RESTRICT
);

INDEXES:
- idx_tickets_status (current_status)
- idx_tickets_queue (queue_number)
- idx_tickets_arrival (arrival_timestamp)
- idx_tickets_patient (patient_id)
- idx_tickets_closing_arrival (closing_timestamp, arrival_timestamp)
```

**Usage:** One entry per queue/workflow instance; multiple tickets can share one patient

---

#### 3. **users** - User Accounts
```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,    -- Login ID (AD or local)
    full_name VARCHAR(255),                    -- Display name
    password_value VARCHAR(255),               -- Base64 encoded (fallback)
    password_hash VARCHAR(255),                -- Unused (legacy)
    is_active TINYINT(1) DEFAULT 1,            -- Account enabled
    auth_source VARCHAR(50),                   -- 'ad', 'local', 'ad_fallback'
    ad_username VARCHAR(255),                  -- AD username if different
    role_id INT,                               -- Legacy: primary role (deprecated)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

**Usage:** One row per user; roles defined in separate user_roles junction table

---

#### 4. **user_roles** - Role Assignments (Junction Table)
```sql
CREATE TABLE user_roles (
    user_id INT NOT NULL,
    role_key VARCHAR(50) NOT NULL,  -- admin, billing, butler, imaging, laboratory, quality
    PRIMARY KEY (user_id, role_key),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

**Valid role_key values:**
- `admin` - System administrator
- `billing` - Billing/intake staff
- `butler` - Support/document quality
- `imaging` - Imaging technician
- `laboratory` - Lab technician
- `quality` - Quality/analytics staff

---

#### 5. **roles** - Role Definitions
```sql
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

**Seeded data:**
- admin → "Administrator"
- billing → "Billing & Intake"
- butler → "Butler/Support"
- imaging → "Imaging Technician"
- laboratory → "Lab Technician"
- quality → "Quality & Analytics"

---

#### 6. **ticket_logs** - Audit Trail
```sql
CREATE TABLE ticket_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,             -- Created, Routed, Called, Wrong Info, etc
    from_status VARCHAR(50),                  -- Previous status
    to_status VARCHAR(50),                    -- New status
    performed_by INT,                         -- FK to users.id
    machine_type ENUM('Xray','Fluoroscopy','Mammography','CT','Ultrasound','MRI'),
    Clinic ENUM('Misc','ENT-URO','OBGYN','Cardio','OPS','PAU'),
    notes TEXT,                               -- Additional details
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE,
    FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE SET NULL
);

INDEXES:
- idx_tl_ticket (ticket_id)
- idx_tl_created (created_at)
```

**Usage:** Complete history of all patient state changes

---

#### 7. **user_action_logs** - User Activity Logging
```sql
CREATE TABLE user_action_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action_type VARCHAR(100),                  -- login_success, access_denied, logout, etc
    details LONGTEXT,                         -- JSON encoded action details
    page_name VARCHAR(255),                   -- Page accessed
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

INDEXES:
- idx_ual_user_created (user_id, created_at)
- idx_ual_created (created_at)
```

**Usage:** Security audit trail, compliance logging

---

#### 8. **feedback_tickets** - Feedback Tracking
```sql
CREATE TABLE feedback_tickets (
    ticket_id INT NOT NULL PRIMARY KEY,
    feedback_sent TINYINT(1) DEFAULT 0,       -- Whether feedback survey was sent
    
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE
);
```

**Usage:** Tracks which tickets have had feedback requests sent

---

### Database Schema Diagram

```
patients (1) ---< (N) tickets
    |                      |
    +------< ticket_logs --+

users (1) ---< (N) user_roles
             (1) <--- (N) ticket_logs
             (1) <--- (N) user_action_logs

tickets (1) ---< (1) feedback_tickets
```

---

## Configuration Reference

### Active Directory Details (config.php, Lines 29-58)

```php
define('AUTH_AD_SERVER', 'ldap://192.168.20.1');
define('AUTH_AD_FALLBACK_SERVER', 'ldap://192.168.20.100');
define('AUTH_AD_PORT', 389);
define('AUTH_AD_DOMAIN', 'stlouis.com');
define('AUTH_AD_NETBIOS', 'stlouis');
define('AUTH_AD_BASE_DN', 'DC=stlouis,DC=com');
define('AUTH_AD_USE_TLS', false);
define('AUTH_AD_SEARCH_BIND_USER', 'svc-directus');
define('AUTH_AD_SEARCH_BIND_PASS', 'QxmXIgtaXiOR7EWrSXIb');
```

**What it does:** Users log in with their stlouis.com domain credentials. System connects to 192.168.20.1 LDAP server, with automatic fallback to 192.168.20.100 if primary is down.

---

### Network Storage Paths (config.php, Lines 62-64)

```php
define('NETWORK_USERNAME', 'stlouis\\appuser');
define('NETWORK_PASSWORD', '$ecure@pp');
define('ID_SAVE_PATH', '\\\\192.168.20.3\\slh\\Internal\\Finance\\Accounting Department\\Admission & Billing\\Common\\Patients ID\\Queue_IDs\\');
define('INSURANCE_SAVE_PATH', '\\\\192.168.20.3\\slh\\Internal\\Finance\\Accounting Department\\Admission & Billing\\Common\\Patients ID\\Queue_presc&ins\\');
```

**What it does:** Document uploads save to network share \\\\192.168.20.3 using appuser credentials. Two folders: one for IDs, one for prescriptions/insurance.

---

### WhatsApp Integration (config.php, Lines 98-99)

```php
define('WHATSAPP_API_URL', 'https://www.bestsmsbulk.com/bestsmsbulkapi/common/sendSmsWpAPITemplate.php');
define('WHATSAPP_API_KEY', '02015ec21253fe7a773d9b31710e94d9b4e835373b0f3afadf9f2ee02c592804');
```

**What it does:** Sends patient notifications via WhatsApp using bestsmsbulk.com provider. Patient receives queue updates, call notifications.

---

### Feedback System (config.php, Lines 84-91)

```php
define('FEEDBACK_TALLY_FORM_URL', 'https://survey.slouishospital.com/feedback');
define('FEEDBACK_SEND_DELAY_HOURS', 24);  // Wait 24 hours after service
define('FEEDBACK_SEND_FROM_DATE', '2026-06-16');  // Only recent tickets
```

**What it does:** After patient completes service, system waits 24 hours then sends feedback link to survey.slouishospital.com.

---

## System-Specific Modifications

### When Adding a New Department/Stream

**Example: Adding a \"Neurology\" Department**

**Step 1:** Update `config.php` (Line 52 in authAllRoles function)
```php
function authAllRoles() {
    return ['admin', 'billing', 'butler', 'imaging', 'laboratory', 'quality', 'neurology'];  // Add 'neurology'
}
```

**Step 2:** Update database schema (add to table creation in config.php, ~Line 242)
```php
// In CREATE TABLE tickets:
neuro TINYINT(1) NOT NULL DEFAULT 0,           // New department flag
neuro_call_time DATETIME DEFAULT NULL,         // When neuro called patient
```

**Step 3:** Create `stream_neurology.php` based on `stream_lab.php`
- Copy structure from stream_lab.php
- Replace `lab=1` with `neuro=1`
- Update queue query to select neuro patients
- Update action handler for neuro-specific logic

**Step 4:** Update `billing.php` (around Line 100+ where routing options shown)
- Add checkbox: \"Send to Neurology\"
- Link to `neuro` flag in database
- Add routing button for Neurology

**Step 5:** Create `neurology.php` (main interface, based on `laboratory.php`)
- Display patients with `neuro=1`
- Show current_status and control actions
- Handle \"Wrong Info\" returns to Billing

**Step 6:** Update `auth.php` (Line 1062 in authDefaultLandingPage)
```php
'neurology' => 'neurology.php',  // Add landing page for new role
```

**Step 7:** Create role in User Management UI or via SQL:
```sql
INSERT INTO roles (role_name, description) VALUES ('neurology', 'Neurology Department');
INSERT INTO user_roles (user_id, role_key) VALUES (5, 'neurology');  -- Assign to user ID 5
```

---

### Adding a New Clinic to Clinics Stream

**Files to Modify:**
1. `config.php` - Line ~245 in CREATE TABLE tickets
2. `clinics.php` - Line ~100 where clinic options dropdown

**SQL Change in config.php:**
```sql
ALTER TABLE tickets MODIFY COLUMN Clinic ENUM('Misc','ENT-URO','OBGYN','Cardio','OPS','PAU','Pediatrics') DEFAULT NULL;
```

**HTML Change in clinics.php:**
```html
<select name="current_clinic">
    <option value="ENT-URO">ENT-URO</option>
    <option value="OBGYN">OBGYN</option>
    <option value="Cardio">Cardiology</option>
    <option value="OPS">Operations</option>
    <option value="PAU">PAU</option>
    <option value="Pediatrics">Pediatrics</option>  <!-- NEW -->
</select>
```

---

### Adding a New Imaging Machine Type

**Files to Modify:**
1. `config.php` - Line ~244 in CREATE TABLE tickets (imaging_machine ENUM)
2. `imaging_assignments.php` - Line ~30 machine selection dropdown
3. `imaging.php` - Line ~500 where machine tabs created

**SQL Change in config.php:**
```sql
ALTER TABLE tickets MODIFY COLUMN imaging_machine ENUM('Xray','Fluoroscopy','Mammography','CT','Ultrasound','MRI','PetCT') DEFAULT NULL;
```

**Change in imaging_assignments.php:**
```php
$machines = ['Xray', 'Fluoroscopy', 'Mammography', 'CT', 'Ultrasound', 'MRI', 'PetCT'];
```

**Change in imaging.php (tab creation):**
```html
<button class="tab-btn" data-machine="PetCT">PET/CT Queue</button>
```

---

### Changing Session Timeout (Currently 24 Hours)

**File:** `config.php`, Line 7

**Current:**
```php
define('AUTH_SESSION_TIMEOUT_SECONDS', 86400); // 24 hours = 86400 seconds
```

**Common Values:**
- 4 hours: `14400`
- 8 hours: `28800`
- 12 hours: `43200`
- 24 hours: `86400` (current)
- 48 hours: `172800`

**How it works:** User remains logged in for this duration if active. Each click resets timer. After inactivity period, redirects to login.php.

---

### Making Email Required for Patient Intake

**File:** `scan_docs.php`, Lines 200-250

**Current code:**
```php
if (empty($email)) {
    // Email is optional, continue
}
```

**To make mandatory:**
```php
if (empty($email)) {
    throw new Exception('Email address is required for patient intake');
}
```

**Effect:** Patient cannot complete intake form without email. Applies to all new patients immediately.

---

### Custom Daily Patient Report

**File to Create:** `reports_daily_count.php`

```php
<?php
require_once 'config.php';
session_start();
authRequireRoles(['quality', 'admin']);

$date = $_GET['date'] ?? date('Y-m-d');

$stmt = $pdo->prepare("
    SELECT 
        COUNT(DISTINCT t.ticket_id) as total_tickets,
        SUM(t.lab) as to_lab,
        SUM(t.img) as to_imaging,
        SUM(t.cl) as to_clinics,
        COUNT(DISTINCT IF(t.current_status='Completed', t.ticket_id, NULL)) as completed,
        COUNT(DISTINCT IF(t.current_status='Wrong Info', t.ticket_id, NULL)) as wrong_info
    FROM tickets t
    WHERE DATE(t.arrival_timestamp) = ?
");
$stmt->execute([$date]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

?>
<h2>Daily Report for <?php echo $date; ?></h2>
<p>Total Tickets: <?php echo $stats['total_tickets']; ?></p>
<p>To Lab: <?php echo $stats['to_lab']; ?></p>
<p>To Imaging: <?php echo $stats['to_imaging']; ?></p>
<p>To Clinics: <?php echo $stats['to_clinics']; ?></p>
<p>Completed: <?php echo $stats['completed']; ?></p>
<p>Wrong Info Returns: <?php echo $stats['wrong_info']; ?></p>
```

**Access:** Add link to statistics.php menu, or access directly as `/reports_daily_count.php?date=2026-08-18`

---

### User Role Assignment via UI

**Access:** `user_management.php` (admin users only)

**Steps:**
1. Log in as admin (e.g., user with 'admin' role)
2. Navigate to `user_management.php`
3. Click on user from list (e.g., "Ahmed Ibrahim")
4. Check/uncheck desired roles:
   - ☐ admin
   - ☐ billing
   - ☐ butler  
   - ☐ imaging
   - ☐ laboratory
   - ☐ quality
5. Click "Save User"

**Notes:** User must have at least one role to access system. Roles take effect on next login.

---

### User Role Management via Database (Emergency)

```sql
-- Add 'imaging' role to user ID 12 (Ahmed)
INSERT INTO user_roles (user_id, role_key) VALUES (12, 'imaging');

-- Remove 'butler' role from user ID 12
DELETE FROM user_roles WHERE user_id = 12 AND role_key = 'butler';

-- View all users with their roles
SELECT u.id, u.username, u.full_name, GROUP_CONCAT(ur.role_key SEPARATOR ', ') as roles
FROM users u
LEFT JOIN user_roles ur ON u.id = ur.user_id
GROUP BY u.id
ORDER BY u.username;

-- View specific user's roles
SELECT role_key FROM user_roles WHERE user_id = 12;
```

---

### Reset Local Admin Password

**Scenario:** Lost admin password, need to reset

**Step 1:** Generate new base64 encoded password
```bash
echo -n "newpassword123" | base64
# Output: bmV3cGFzc3dvcmQxMjM=
```

**Step 2:** Update admin password in database
```sql
UPDATE users 
SET password_value = 'bmV3cGFzc3dvcmQxMjM=' 
WHERE username = 'admin';
```

**Step 3:** Log in with new password
- Username: `admin`
- Password: `newpassword123`

---

### Testing LDAP Connectivity to AD

**If users cannot log in with AD credentials:**

**Step 1:** Create test file `test_ldap.php`
```php
<?php
require_once 'config.php';

// Test primary server
$ldapconn = @ldap_connect('ldap://192.168.20.1', 389);
if ($ldapconn) {
    echo "✓ Primary LDAP (192.168.20.1:389): CONNECTED<br>";
    ldap_close($ldapconn);
} else {
    echo "✗ Primary LDAP (192.168.20.1:389): FAILED<br>";
}

// Test fallback server
$ldapconn = @ldap_connect('ldap://192.168.20.100', 389);
if ($ldapconn) {
    echo "✓ Fallback LDAP (192.168.20.100:389): CONNECTED<br>";
    ldap_close($ldapconn);
} else {
    echo "✗ Fallback LDAP (192.168.20.100:389): FAILED<br>";
}

echo "<br>Database Connection: ";
try {
    echo "✓ Connected to 'queue' database<br>";
} catch (Exception $e) {
    echo "✗ Failed: " . $e->getMessage() . "<br>";
}
?>
```

**Step 2:** Access `http://yourserver/queue/test_ldap.php`

**Step 3:** Check results:
- If both LDAP servers fail → Network issue
- If LDAP works but login still fails → Check user has role assigned
- If LDAP fails → Try local fallback: admin / r4!T

---

### Changing LDAP Server for AD Migration

**Scenario:** Moving to new Active Directory server

**File:** `config.php`, Lines 29-58

**Update these lines:**
```php
define('AUTH_AD_SERVER', 'ldap://192.168.20.200');     // NEW primary server
define('AUTH_AD_FALLBACK_SERVER', 'ldap://192.168.20.201');  // NEW fallback
define('AUTH_AD_DOMAIN', 'newdomain.com');             // NEW domain
define('AUTH_AD_NETBIOS', 'NEWDOMAIN');                // NEW NetBIOS name  
define('AUTH_AD_BASE_DN', 'DC=newdomain,DC=com');      // NEW base DN
```

**Validation:**
- Ask IT to confirm new LDAP server IPs are correct
- Test with `test_ldap.php` before users log in
- Have local admin fallback ready (admin / r4!T)

---

### Viewing Patient Audit Trail (ticket_logs)

**Scenario:** Need to see what happened to a patient

```sql
-- Find patient by queue number
SELECT t.ticket_id, t.queue_number, p.patient_name, t.arrival_timestamp
FROM tickets t
JOIN patients p ON t.patient_id = p.patient_id
WHERE t.queue_number = 'A123';

-- View all actions for that ticket (e.g., ticket_id = 456)
SELECT 
    l.created_at,
    l.action,
    l.from_status,
    l.to_status,
    u.username as performed_by,
    l.notes
FROM ticket_logs l
LEFT JOIN users u ON l.performed_by = u.id  
WHERE l.ticket_id = 456
ORDER BY l.created_at DESC;
```

---

## Troubleshooting & Support

### Common Issues & Solutions

#### **Issue: Users cannot log in**

**Possible Causes & Solutions:**
1. **Active Directory not accessible**
   - Check `AUTH_AD_SERVER` and `AUTH_AD_FALLBACK_SERVER` in config.php
   - Verify network connectivity to LDAP servers
   - Confirm LDAP port (default 389)

2. **User has no assigned roles**
   - Check user_roles table for user's role assignments
   - Admin must assign at least one role
   - Verify role_key matches: admin/billing/butler/imaging/laboratory/quality

3. **Session timeout too short**
   - Check `AUTH_SESSION_TIMEOUT_SECONDS` in config.php
   - Adjust if users being logged out too quickly

#### **Issue: Patient queue not showing**

**Possible Causes & Solutions:**
1. **Wrong stream selected**
   - Verify patient was routed to correct department (lab=1, img=1, cl=1)
   - Check `current_status` in tickets table

2. **Date mismatch**
   - Patients only show for current day by default
   - Check `arrival_timestamp` date in database

3. **User lacks permissions**
   - Verify user has correct role assigned
   - Check `authRequireRoles()` in relevant .php file

#### **Issue: WhatsApp messages not sending**

**Possible Causes & Solutions:**
1. **API credentials incorrect**
   - Verify `WHATSAPP_API_URL` and `WHATSAPP_API_KEY` in config.php
   - Test API endpoint directly

2. **Phone number format wrong**
   - Ensure country code included (e.g., +961)
   - Check `formatInternationalNumber()` function in new_ticket.php
   - Patient mobile must not be empty

3. **API provider rate limit**
   - Check WhatsApp provider dashboard for limits
   - Review error logs in browser console

#### **Issue: Documents not saving to network share**

**Possible Causes & Solutions:**
1. **Network credentials wrong**
   - Verify `NETWORK_USERNAME` and `NETWORK_PASSWORD` in config.php
   - Format: `domain\\username` (double backslash for Windows domain)

2. **Network path incorrect**
   - Verify `ID_SAVE_PATH` and `INSURANCE_SAVE_PATH` exist
   - Check web server process has read/write permissions
   - Format paths with double backslash: `\\\\server.ip\\share\\`

3. **Network share unavailable**
   - Ping network share server
   - Verify network connectivity from web server
   - Check share accessibility with test account

#### **Issue: Performance slow or timeout errors**

**Possible Causes & Solutions:**
1. **Large queue backlogs**
   - Archive old tickets (before 30 days)
   - Implement pagination in queue views

2. **Database indexes missing**
   - Check indexes in config.php are created
   - Run: `SHOW INDEX FROM tickets;`

3. **LDAP lookup slow**
   - Check AD server response times
   - Verify fallback server is accessible
   - Consider caching AD lookups

---

### Database Maintenance

#### **Backup Database**

```sql
-- Recommended: Use MySQL utilities
mysqldump -u root -p queue > queue_backup_$(date +%Y%m%d).sql

-- Or in PHP:
file_put_contents('backup.sql', file_get_contents('path/to/backup'));
```

#### **Archive Old Tickets**

```sql
-- Move tickets older than 90 days to archive (if archive table exists)
INSERT INTO tickets_archive SELECT * FROM tickets WHERE arrival_timestamp < DATE_SUB(NOW(), INTERVAL 90 DAY);
DELETE FROM tickets WHERE arrival_timestamp < DATE_SUB(NOW(), INTERVAL 90 DAY);
```

#### **Clear Session Data**

```sql
-- Clear old session files
DELETE FROM user_action_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 180 DAY);
```

---

### Performance Optimization Tips

1. **Regularly clear old logs:**
   - `user_action_logs` grows daily
   - Archive records older than 6 months
   - Keep database query times acceptable

2. **Monitor queue sizes:**
   - If queue exceeds 100 patients, consider adding shift hours
   - Analyze peak times with statistics dashboard

3. **Check network share access:**
   - Network timeouts slow document upload
   - Monitor network connectivity to file shares
   - Consider caching frequently accessed files

4. **Optimize LDAP:**
   - Cache AD lookups where possible
   - Use search bind service account (configured in config.php)
   - Monitor AD server response times

---

### Support Resources

**For Database Issues:**
- Check `config.php` connection settings
- Review error messages in browser console (F12 Developer Tools)
- Check PHP error logs on server

**For Authentication Issues:**
- Verify AD/LDAP connectivity
- Check user role assignments in User Management
- Review user_action_logs for access denied events

**For Workflow Issues:**
- Review ticket_logs for action history
- Check patient demographics snapshot for demographic changes
- Use Undo function for recent accidental changes

**For Feature Issues:**
- Check enabled features in config.php
- Verify API endpoints accessible (WhatsApp, Survey)
- Test with sample data to isolate issues

---

## St. Louis Hospital Specific Troubleshooting

### Issue: Users Cannot Log In with stlouis.com Credentials

**Symptom:** "Invalid username or password" on login.php

**Quick Diagnosis:**
1. Try logging in as `admin` with password `r4!T`
   - If works → AD issue confirmed
   - If fails → Local auth problem

2. Check AD servers from server command line:
   ```bash
   ping 192.168.20.1
   ping 192.168.20.100
   ```
   - If both timeout → Network down, contact IT

3. Check if user has role assigned:
   ```sql
   SELECT ur.role_key FROM user_roles ur 
   WHERE ur.user_id = (SELECT id FROM users WHERE username='ahmedibrahim' LIMIT 1);
   ```
   - No results? User has no roles. Add via user_management.php

**Solution:**
- If AD unavailable: Use admin/r4!T as temporary access
- If user has no role: Go to user_management.php → assign role → Save
- If still failing: Check browser console (F12) for error details

---

### Issue: Patient Queue Empty in Billing

**Symptom:** Billing.php page shows "No patients in queue" but you know patients exist

**Diagnosis:**
```sql
-- Check if patients exist for today
SELECT queue_number, patient_name, current_status, lab, img, cl 
FROM tickets t
JOIN patients p ON t.patient_id = p.patient_id
WHERE DATE(t.arrival_timestamp) = CURDATE()
LIMIT 5;
```

If rows returned but Billing page still empty:
1. **Check user role:** Billing user must have 'billing' role
2. **Refresh page:** F5 to reload queue
3. **Check system time:** Server time must be correct (today's date)

**Solution:**
- Assign 'billing' role to user via user_management.php
- Restart browser or clear cookies
- Ask IT to verify server clock

---

### Issue: WhatsApp Messages Never Reach Patients

**Symptom:** Patient never gets queue notification via WhatsApp

**Diagnosis:**
```sql
-- Verify patient phone data
SELECT patient_name, country_code, mobile FROM patients WHERE patient_id = 5;
-- Should show: country_code='+961', mobile='76123456' (no spaces/special chars)
```

If mobile is populated:
1. **Check bestsmsbulk.com dashboard:**
   - Log in to account at bestsmsbulk.com
   - Check "Messages" or "Delivery" section
   - Look for status: "Delivered", "Pending", or "Failed"

2. **Verify API key hasn't expired:**
   - Current key in config.php: `02015ec21253fe7a773d9b31710e94d9b4e835373b0f3afadf9f2ee02c592804`
   - If expires, get new key from bestsmsbulk.com admin

**Solution:**
- Make sure mobile number includes: +961 (Lebanon code) and 8-digit number
- Example: +96176123456 (correct), 76123456 (missing code, wrong!)
- If API key expired: Update in config.php line 99
- Test with manual message via bestsmsbulk.com dashboard

---

### Issue: Document Upload Fails, Prescription Not Saved

**Symptom:** Error in scan_docs.php when uploading document, no file in network share

**Diagnosis:**
1. **Check network share accessibility:**
   ```bash
   # From server command line:
   ping 192.168.20.3
   # If timeout: Network down
   ```

2. **Test network path access:**
   ```bash
   net use \\192.168.20.3\slh /user:stlouis\appuser $secureapp
   dir "\\192.168.20.3\slh\Internal\Finance\Accounting Department\Admission & Billing\Common\Patients ID\Queue_presc&ins\"
   ```
   - If "Access denied" → Credentials wrong or permissions missing
   - If path not found → Path typo in config.php

3. **Verify config.php paths:**
   ```php
   // Should be exactly these paths (with double backslashes):
   define('ID_SAVE_PATH', '\\\\192.168.20.3\\slh\\Internal\\Finance\\Accounting Department\\Admission & Billing\\Common\\Patients ID\\Queue_IDs\\');
   define('INSURANCE_SAVE_PATH', '\\\\192.168.20.3\\slh\\Internal\\Finance\\Accounting Department\\Admission & Billing\\Common\\Patients ID\\Queue_presc&ins\\');
   ```

**Solution:**
- If network down: Wait for IT to restore connectivity
- If credentials wrong: Contact IT to verify stlouis\appuser password
- If path wrong: Double-check paths match actual folders on \\192.168.20.3
- If permission denied: Ask IT to grant "Modify" permissions to stlouis\appuser on those folders

---

### Issue: "Wrong Info" Patient Stuck, Not Returning to Billing

**Symptom:** Lab marked patient "Wrong Info" but Billing never sees it

**Diagnosis:**
```sql
-- Find stuck patients
SELECT t.ticket_id, t.queue_number, p.patient_name, t.current_status 
FROM tickets t
JOIN patients p ON t.patient_id = p.patient_id
WHERE t.current_status = 'Wrong Info'
AND DATE(t.arrival_timestamp) = CURDATE();
```

If rows found:
1. **Check Billing can see them:** Refresh billing.php (F5)
2. **Check Billing has role:** User must have 'billing' role
3. **Check page loaded correctly:** Clear browser cache (Ctrl+Shift+Del)

**Solution:**
- If still not visible: Check database query above
- If visible but stuck: Billing clicks "View Details" → fixes info → re-routes to correct department
- If Billing doesn't see "Wrong Info" status category: Page bug, reload browser

---

### Issue: Undo Button Greyed Out / Not Working

**Symptom:** "Undo" button visible but disabled, or click does nothing

**Why it happens:**
- Undo only works within 10 seconds of action
- Only works in the stream where action originated (e.g., if Billing routed patient, must click Undo in Billing)
- If browser was closed or session expired, undo data lost

**Solution:**
- **If > 10 seconds ago:** Use "Wrong Info" button instead to return patient
- **If wrong stream:** Go back to Billing (if Billing routed) and click Undo there
- **If session lost:** Log back in and use "Wrong Info" to correct

---

### Database Maintenance (Monthly Tasks)

#### Backup Today's Tickets
```bash
mysqldump -u root -p queue tickets --where="DATE(arrival_timestamp) = CURDATE()" > /backup/queue_today_$(date +%Y%m%d).sql
```

#### Archive Tickets Older Than 6 Months
```sql
-- Create archive table first time:
CREATE TABLE tickets_archive LIKE tickets;

-- Then move old tickets:
INSERT INTO tickets_archive 
SELECT * FROM tickets 
WHERE arrival_timestamp < DATE_SUB(NOW(), INTERVAL 6 MONTH);

DELETE FROM tickets 
WHERE arrival_timestamp < DATE_SUB(NOW(), INTERVAL 6 MONTH);
```

#### Clean Old Logs (Keep Only 12 Months)
```sql
DELETE FROM user_action_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 12 MONTH);
DELETE FROM ticket_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 12 MONTH);
```

---

### Performance Check (Run Weekly)

**Check Daily Queue Size:**
```sql
SELECT COUNT(*) as active_patients FROM tickets 
WHERE DATE(arrival_timestamp) = CURDATE() 
AND current_status NOT IN ('Completed','Canceled');
-- If > 200: Consider adding staff or extending hours
```

**Check Lab Response Time:**

**Lab Processing Time:**
```sql
SELECT 
    COUNT(*) as lab_patients,
    ROUND(AVG(TIMESTAMPDIFF(MINUTE, arrival_timestamp, lab_call_time)), 1) as avg_wait_minutes
FROM tickets 
WHERE lab = 1 AND DATE(arrival_timestamp) = CURDATE();
-- If > 90 minutes: Bottleneck detected
```

**Check Imaging Queue Per Machine:**
```sql
SELECT 
    imaging_machine,
    COUNT(*) as queue_size,
    ROUND(AVG(TIMESTAMPDIFF(MINUTE, arrival_timestamp, imaging_call_time)), 1) as avg_wait_min
FROM tickets 
WHERE img = 1 AND DATE(arrival_timestamp) = CURDATE()
GROUP BY imaging_machine;
```

---

## Document History

| Version | Date | Changes |
|---------|------|---------|
| 1.0 | 2026-08-18 | Initial comprehensive documentation |

## Contact & Escalation

For issues requiring developer intervention:
1. Document the issue with patient queue numbers and timestamp
2. Provide relevant error messages from browser console (F12)
3. Include user role and specific action that failed
4. Review audit logs (User Actions page) for context

---

**Last Updated:** 2026-08-18
**System Version:** Current
**Documentation Scope:** Complete feature set and operational procedures

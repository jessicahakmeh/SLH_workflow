<?php
// Serve hospital logo from network share via HTTP
header('Content-Type: image/png');
header('Cache-Control: public, max-age=3600');

$logoPath = '\\\\192.168.20.3\\slh\\Regulations\\Logo SLH\\SLH Logo - Background Removed.png';

// Try to read and serve the logo
if (file_exists($logoPath)) {
    readfile($logoPath);
} else {
    // Return a simple placeholder if file not found
    header('Content-Type: image/svg+xml');
    echo '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
        <rect width="200" height="200" fill="#e8f0f7"/>
        <circle cx="100" cy="100" r="80" fill="#1e3a4f"/>
        <text x="100" y="110" font-size="20" fill="white" text-anchor="middle" font-family="Arial">SLH</text>
    </svg>';
}

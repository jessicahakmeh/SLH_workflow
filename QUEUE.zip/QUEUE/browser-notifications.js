(function () {
    const STORAGE_PREFIX = 'queue-notifications:';
    const BANNER_ID = 'notificationPermissionBanner';
    const STYLE_ID = 'notificationPermissionStyles';

    function isSupported() {
        return typeof window !== 'undefined' && 'Notification' in window;
    }

    function getPermission() {
        if (!isSupported()) {
            return 'unsupported';
        }

        return Notification.permission;
    }

    function isSecureContextForNotifications() {
        if (typeof window === 'undefined') {
            return false;
        }

        if (window.isSecureContext) {
            return true;
        }

        return window.location && window.location.hostname === 'localhost';
    }

    function ensureStyles() {
        if (document.getElementById(STYLE_ID)) {
            return;
        }

        const style = document.createElement('style');
        style.id = STYLE_ID;
        style.textContent = `
            .notification-permission-banner {
                display: none;
                align-items: center;
                justify-content: space-between;
                gap: 16px;
                margin: 16px 20px 0;
                padding: 14px 18px;
                border-radius: 12px;
                border: 1px solid #d6e4f0;
                background: linear-gradient(135deg, #f4f8fb, #edf6ff);
                box-shadow: 0 8px 24px rgba(24, 60, 92, 0.08);
            }

            .notification-permission-banner.is-visible {
                display: flex;
            }

            .notification-permission-banner-content {
                min-width: 0;
            }

            .notification-permission-banner-title {
                margin: 0 0 4px;
                color: #17324d;
                font-size: 15px;
                font-weight: 700;
            }

            .notification-permission-banner-text {
                margin: 0;
                color: #4d6378;
                font-size: 13px;
                line-height: 1.4;
            }

            .notification-permission-banner-actions {
                display: flex;
                align-items: center;
                gap: 10px;
                flex-shrink: 0;
            }

            .notification-permission-banner-btn {
                border: none;
                border-radius: 999px;
                padding: 10px 16px;
                background: #1565c0;
                color: #fff;
                font-size: 13px;
                font-weight: 700;
                cursor: pointer;
            }

            .notification-permission-banner-btn:hover {
                background: #0f4f96;
            }

            .notification-permission-banner-btn.secondary {
                background: #eef4fb;
                color: #17324d;
                border: 1px solid #c5d7ea;
            }

            .notification-permission-banner-btn.secondary:hover {
                background: #deecfa;
            }

            .notification-permission-banner-close {
                border: none;
                background: transparent;
                color: #5d7388;
                font-size: 18px;
                cursor: pointer;
                line-height: 1;
                padding: 4px;
            }

            @media (max-width: 720px) {
                .notification-permission-banner {
                    flex-direction: column;
                    align-items: stretch;
                }

                .notification-permission-banner-actions {
                    justify-content: flex-end;
                }
            }
        `;

        document.head.appendChild(style);
    }

    function renderPermissionBanner(options) {
        if (!isSupported()) {
            return;
        }

        ensureStyles();

        let banner = document.getElementById(BANNER_ID);
        if (!banner) {
            banner = document.createElement('div');
            banner.id = BANNER_ID;
            banner.className = 'notification-permission-banner';
            banner.innerHTML = `
                <div class="notification-permission-banner-content">
                    <p class="notification-permission-banner-title"></p>
                    <p class="notification-permission-banner-text"></p>
                </div>
                <div class="notification-permission-banner-actions">
                    <button type="button" class="notification-permission-banner-btn">Enable desktop notifications</button>
                    <button type="button" class="notification-permission-banner-btn secondary" style="display:none;">I've re-enabled, retry</button>
                    <button type="button" class="notification-permission-banner-close" aria-label="Dismiss notification prompt">&times;</button>
                </div>
            `;
            document.body.insertBefore(banner, document.body.firstChild);
        }

        const permission = getPermission();
        const title = banner.querySelector('.notification-permission-banner-title');
        const text = banner.querySelector('.notification-permission-banner-text');
        const enableButton = banner.querySelector('.notification-permission-banner-btn');
        const retryButton = banner.querySelector('.notification-permission-banner-btn.secondary');
        const closeButton = banner.querySelector('.notification-permission-banner-close');

        if (permission === 'granted' || permission === 'unsupported') {
            banner.classList.remove('is-visible');
            return;
        }

        const pageName = options && options.pageName ? options.pageName : 'this queue';

        const insecureContext = !isSecureContextForNotifications();

        title.textContent = permission === 'denied'
            ? 'Browser notifications are blocked'
            : 'Enable browser notifications';
        text.textContent = permission === 'denied'
            ? `Notifications for ${pageName} are blocked in the browser. Re-enable them in site settings if you want new ticket alerts.`
            : insecureContext
                ? `Desktop notifications require a secure origin (HTTPS or localhost). Open this page securely, then enable notifications for ${pageName}.`
                : `Allow desktop notifications for ${pageName} so new tickets can alert you even when the tab is not focused.`;
        enableButton.style.display = 'inline-flex';
        enableButton.textContent = permission === 'denied'
            ? 'Re-enable notifications'
            : 'Enable desktop notifications';

        if (permission === 'denied') {
            enableButton.disabled = false;
            enableButton.style.opacity = '1';
            enableButton.style.cursor = 'pointer';
            retryButton.style.display = 'inline-flex';
            retryButton.disabled = false;
            retryButton.style.opacity = '1';
            retryButton.style.cursor = 'pointer';
        } else {
            enableButton.disabled = insecureContext;
            enableButton.style.opacity = insecureContext ? '0.6' : '1';
            enableButton.style.cursor = insecureContext ? 'not-allowed' : 'pointer';
            retryButton.style.display = 'none';
        }

        enableButton.onclick = async function () {
            if (permission === 'denied') {
                guideNotificationReenable(pageName);
                return;
            }

            const result = await requestPermission({
                pageName: pageName,
                showConfirmation: true
            });

            if (result === 'granted') {
                banner.classList.remove('is-visible');
            }

            renderPermissionBanner(options);
        };

        retryButton.onclick = async function () {
            const currentPermission = getPermission();

            if (currentPermission === 'granted') {
                banner.classList.remove('is-visible');
                showNotification('Desktop notifications enabled', {
                    body: `You will now receive ${pageName} updates.`
                });
                return;
            }

            if (currentPermission === 'default') {
                const result = await requestPermission({
                    pageName: pageName,
                    showConfirmation: true
                });

                if (result === 'granted') {
                    banner.classList.remove('is-visible');
                }

                renderPermissionBanner(options);
                return;
            }

            alert('Notifications are still blocked. Please allow notifications in browser site settings, then click retry.');
        };

        closeButton.onclick = function () {
            banner.classList.remove('is-visible');
        };

        banner.classList.add('is-visible');
    }

    function guideNotificationReenable(pageName) {
        const ua = navigator.userAgent || '';
        let settingsUrl = '';

        if (ua.includes('Edg/')) {
            settingsUrl = 'edge://settings/content/notifications';
        } else if (ua.includes('Chrome/') && !ua.includes('Edg/')) {
            settingsUrl = 'chrome://settings/content/notifications';
        } else if (ua.includes('Firefox/')) {
            settingsUrl = 'about:preferences#privacy';
        }

        if (settingsUrl) {
            try {
                window.open(settingsUrl, '_blank', 'noopener');
            } catch (error) {
                console.warn('Unable to open browser notification settings automatically:', error);
            }
        }

        alert(
            `To re-enable desktop notifications for ${pageName}, open your browser site settings and allow notifications for this site, then reload the page.`
        );
    }

    async function requestPermission(options) {
        if (!isSupported() || getPermission() !== 'default') {
            return getPermission();
        }

        if (!isSecureContextForNotifications()) {
            return getPermission();
        }

        try {
            let permission;

            if (Notification.requestPermission.length > 0) {
                permission = await new Promise(resolve => {
                    Notification.requestPermission(resolve);
                });
            } else {
                permission = await Notification.requestPermission();
            }

            if (permission === 'granted' && options && options.showConfirmation) {
                showNotification('Desktop notifications enabled', {
                    body: `You will now receive ${options.pageName || 'queue'} updates.`
                });
            }

            return permission;
        } catch (error) {
            console.error('Unable to request notification permission:', error);
            return getPermission();
        }
    }

    function toStorageKey(pageKey) {
        return STORAGE_PREFIX + pageKey;
    }

    function readKnownIds(pageKey) {
        try {
            const raw = sessionStorage.getItem(toStorageKey(pageKey));
            if (!raw) {
                return null;
            }

            const parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed : null;
        } catch (error) {
            console.warn('Unable to read notification state for', pageKey, error);
            return null;
        }
    }

    function writeKnownIds(pageKey, ids) {
        try {
            sessionStorage.setItem(toStorageKey(pageKey), JSON.stringify(ids));
        } catch (error) {
            console.warn('Unable to persist notification state for', pageKey, error);
        }
    }

    function normalizeItem(item) {
        if (!item || item.id === undefined || item.id === null) {
            return null;
        }

        return {
            id: String(item.id),
            queueNumber: item.queueNumber || item.queue_number || '',
            patientName: item.patientName || item.patient_name || '',
            message: item.message || ''
        };
    }

    function syncTickets(pageKey, items) {
        const normalizedItems = (Array.isArray(items) ? items : [])
            .map(normalizeItem)
            .filter(Boolean);
        const currentIds = normalizedItems.map(item => item.id);
        const previousIds = readKnownIds(pageKey);

        writeKnownIds(pageKey, currentIds);

        if (previousIds === null) {
            return [];
        }

        const previousSet = new Set(previousIds);
        return normalizedItems.filter(item => !previousSet.has(item.id));
    }

    function showNotification(title, options) {
        if (!isSupported() || getPermission() !== 'granted') {
            return null;
        }

        try {
            const notification = new Notification(title, {
                body: options && options.body ? options.body : '',
                tag: options && options.tag ? options.tag : undefined,
                renotify: false,
                requireInteraction: false
            });

            notification.onclick = function () {
                window.focus();
                if (options && typeof options.onClick === 'function') {
                    options.onClick();
                }
                notification.close();
            };

            return notification;
        } catch (error) {
            console.error('Unable to show notification:', error);
            return null;
        }
    }

    function notifyForNewTickets(config) {
        if (!config || !config.pageKey) {
            return [];
        }

        const newItems = syncTickets(config.pageKey, config.items || []);
        if (!newItems.length || getPermission() !== 'granted') {
            return newItems;
        }

        newItems.forEach(item => {
            const title = typeof config.getTitle === 'function'
                ? config.getTitle(item)
                : (config.title || 'New ticket');
            const body = typeof config.getBody === 'function'
                ? config.getBody(item)
                : item.message || item.patientName || item.queueNumber || 'A new ticket has arrived.';

            showNotification(title, {
                body,
                tag: `${config.pageKey}:${item.id}`,
                onClick: config.onClick
            });
        });

        return newItems;
    }

    window.QueueNotifications = {
        isSupported,
        getPermission,
        requestPermission,
        renderPermissionBanner,
        syncTickets,
        notifyForNewTickets
    };
})();
<?php
// Public grouped streams page (read-only).
require_once 'kiosk.php';

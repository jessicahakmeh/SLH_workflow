﻿<?php
require_once 'config.php';
session_start();
require_once 'department_helpers.php';
authRequireRoles(['billing', 'admin'], ['log_view' => false]);

// Load countries data from JSON
if (!file_exists('countries.json')) {
    error_log('countries.json not found');
    $countries_json = null;
} else {
    $countries_json = json_decode(file_get_contents('countries.json'), true);
}
$countries = [];
$countries_by_name = []; // For sorting by name
if ($countries_json && isset($countries_json['countries'])) {
    foreach ($countries_json['countries'] as $country) {
        $countries[$country['code']] = [
            'name' => $country['name'],
            'minDigits' => $country['minDigits'],
            'maxDigits' => $country['maxDigits'],
            'pattern' => $country['pattern'] ?? '',
            'example' => $country['example'] ?? ''
        ];
        $countries_by_name[$country['name']] = [
            'code' => $country['code'],
            'name' => $country['name'],
            'minDigits' => $country['minDigits'],
            'maxDigits' => $country['maxDigits'],
            'pattern' => $country['pattern'] ?? '',
            'example' => $country['example'] ?? ''
        ];
    }
    ksort($countries_by_name);
}
// Fallback
if (empty($countries)) {
    $countries = ['+961' => ['name' => 'Lebanon', 'minDigits' => 8, 'maxDigits' => 9]];
    $countries_by_name = ['Lebanon' => ['code' => '+961', 'name' => 'Lebanon', 'minDigits' => 8, 'maxDigits' => 9]];
}

$assignableButlers = [];
try {
    $butlerStmt = $pdo->query(
        "SELECT DISTINCT u.id, u.username, u.full_name
         FROM users u
         INNER JOIN user_roles ur ON ur.user_id = u.id
         WHERE u.is_active = 1 AND ur.role_key = 'butler'
         ORDER BY COALESCE(NULLIF(TRIM(u.full_name), ''), u.username) ASC, u.id ASC"
    );
    foreach ($butlerStmt->fetchAll(PDO::FETCH_ASSOC) as $butlerRow) {
        $displayName = trim((string)($butlerRow['full_name'] ?? ''));
        if ($displayName === '') {
            $displayName = trim((string)($butlerRow['username'] ?? ''));
        }
        $assignableButlers[] = [
            'id' => (int)($butlerRow['id'] ?? 0),
            'username' => trim((string)($butlerRow['username'] ?? '')),
            'display_name' => $displayName,
        ];
    }
} catch (Exception $e) {
    $assignableButlers = [];
}

function normalizeDemographicValue($value) {
    return trim((string)($value ?? ''));
}

function getCurrentTicketDemographics($pdo, $ticketId) {
    return executeAndFetchOne($pdo, "SELECT
            p.mrn,
            p.patient_name,
            p.mobile,
            p.country_code,
            p.care_mobile,
            p.care_country_code,
            p.email,
            p.address
        FROM tickets t
        JOIN patients p ON t.patient_id = p.patient_id
        WHERE t.ticket_id = ?", [$ticketId]);
}

function updateTicketDemographicsChangeFlags($pdo, $ticketId) {
    $ticketRow = executeAndFetchOne($pdo, "SELECT demographics_snapshot FROM tickets WHERE ticket_id = ?", [$ticketId]);
    if (!$ticketRow) {
        return;
    }

    $snapshot = [];
    if (!empty($ticketRow['demographics_snapshot'])) {
        $decoded = json_decode($ticketRow['demographics_snapshot'], true);
        if (is_array($decoded)) {
            $snapshot = $decoded;
        }
    }

    $current = getCurrentTicketDemographics($pdo, $ticketId);
    if (!$current) {
        return;
    }

    $fieldsToCheck = [
        'mrn',
        'patient_name',
        'mobile',
        'country_code',
        'care_mobile',
        'care_country_code',
        'email',
        'address'
    ];

    $changedFields = [];
    if (!empty($snapshot)) {
        foreach ($fieldsToCheck as $field) {
            // For legacy snapshots, only compare fields that exist in the snapshot.
            if (!array_key_exists($field, $snapshot)) {
                continue;
            }

            $snapshotValue = normalizeDemographicValue($snapshot[$field] ?? null);
            $currentValue = normalizeDemographicValue($current[$field] ?? null);
            if ($snapshotValue !== $currentValue) {
                $changedFields[] = $field;
            }
        }
    }

    $edited = !empty($changedFields) ? 1 : 0;
    $changedJson = $edited ? json_encode($changedFields, JSON_UNESCAPED_UNICODE) : null;

    executeUpdate($pdo, "UPDATE tickets SET demographics_edited = ?, demographics_changed_fields = ? WHERE ticket_id = ?", [$edited, $changedJson, $ticketId]);
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if it's an AJAX request
    $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
              strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
    
    if (isset($_POST['start_ticket'])) {
        $patient_id = $_POST['patient_id'];
        
        // Get current status and department flags BEFORE update
        $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
        
        executeUpdate($pdo, "UPDATE tickets SET current_status = 'In Process', lab = 0, img = 0, dp2 = 0, approval_timestamp = NOW() WHERE ticket_id = ?", [$patient_id]);
        
        // Log the action
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) 
                   VALUES (?, 'Status Changed', 'Arrived', 'In Process', ?, 'Billing started processing')", [$patient_id, authCurrentUserId()]);
        authLogTicketAction('ticket_billing_started', $patient_id, [
            'ticket_action' => 'Billing Started',
            'department' => 'billing',
            'from_status' => $current['current_status'],
            'to_status' => 'In Process',
            'notes' => 'Billing started processing',
        ], 'billing.php');
        
        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'In Process',
            'action' => 'Billing started',
            'department' => 'billing',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];
        
        $_SESSION['success_message'] = "Ticket started successfully!";
    } elseif (isset($_POST['save_mrn'])) {
            $patient_id = (int)($_POST['patient_id'] ?? 0);
            $mrn = trim($_POST['mrn']);
            $overrideExistingMrn = isset($_POST['mrn_override']) && (string)$_POST['mrn_override'] === '1';
            $conflictPatientIdFromClient = (int)($_POST['conflict_patient_id'] ?? 0);

            $ticketPatientRow = executeAndFetchOne($pdo, "SELECT
                    t.ticket_id,
                    t.queue_number,
                    t.patient_id,
                    t.is_existing_patient,
                    p.patient_name,
                    p.mrn,
                    p.mobile,
                    p.country_code,
                    p.care_mobile,
                    p.care_country_code,
                    p.email,
                    p.address
                FROM tickets t
                JOIN patients p ON t.patient_id = p.patient_id
                WHERE t.ticket_id = ?", [$patient_id]);
            if (!$ticketPatientRow) {
                $error = 'Ticket not found.';
                if ($isAjax) {
                    if (ob_get_length()) ob_end_clean();
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['success' => false, 'error' => $error], JSON_UNESCAPED_UNICODE);
                    exit();
                }
                $_SESSION['success_message'] = $error;
                header('Location: billing.php'); exit();
            }

            $currentPatientDbId = (int)$ticketPatientRow['patient_id'];

            if (!empty($ticketPatientRow['is_existing_patient']) && !empty($ticketPatientRow['mrn'])) {
                $error = 'PID is locked for existing patients and cannot be edited.';
                if ($isAjax) {
                    if (ob_get_length()) ob_end_clean();
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['success' => false, 'error' => $error], JSON_UNESCAPED_UNICODE);
                    exit();
                }
                $_SESSION['success_message'] = $error;
                header('Location: billing.php'); exit();
            }

            if ($mrn === '') {
                if ($isAjax) {
                    if (ob_get_length()) ob_end_clean();
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['success' => false, 'error' => 'MRN cannot be empty'], JSON_UNESCAPED_UNICODE);
                    exit();
                }
                $_SESSION['success_message'] = 'MRN cannot be empty.';
                header('Location: billing.php'); exit();
            }

            // This will prevent users from changing an MRN once it has been set
            if (!empty($ticketPatientRow['mrn'])) {
                $error = 'MRN has already been set and cannot be edited.';
                if ($isAjax) {
                    if (ob_get_length()) ob_end_clean();
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode(['success' => false, 'error' => $error], JSON_UNESCAPED_UNICODE);
                    exit();
                }
                $_SESSION['success_message'] = $error;
                header('Location: billing.php'); exit();
            }

            // If this MRN already belongs to an existing patient record, ask for confirmation before overriding.
            $mrnConflictRow = executeAndFetchOne($pdo, "SELECT
                    p.patient_id,
                    p.patient_name,
                    p.mrn,
                    p.mobile,
                    p.country_code,
                    p.care_mobile,
                    p.care_country_code,
                    p.email,
                    p.address,
                    MAX(CASE WHEN t.is_existing_patient = 1 THEN 1 ELSE 0 END) AS has_existing_ticket
                FROM patients p
                LEFT JOIN tickets t ON t.patient_id = p.patient_id
                WHERE p.mrn = ?
                  AND p.patient_id <> ?
                GROUP BY
                    p.patient_id,
                    p.patient_name,
                    p.mrn,
                    p.mobile,
                    p.country_code,
                    p.care_mobile,
                    p.care_country_code,
                    p.email,
                    p.address
                ORDER BY has_existing_ticket DESC, p.patient_id ASC
                LIMIT 1", [$mrn, $currentPatientDbId]);

            if ($mrnConflictRow && !$overrideExistingMrn) {
                $error = 'This MRN already exists for another patient. Please confirm if both are the same person.';
                if ($isAjax) {
                    if (ob_get_length()) ob_end_clean();
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode([
                        'success' => false,
                        'conflict' => true,
                        'error' => $error,
                        'current_patient' => [
                            'ticket_id' => $patient_id,
                            'patient_id' => $currentPatientDbId,
                            'patient_name' => (string)($ticketPatientRow['patient_name'] ?? ''),
                            'mrn' => $mrn,
                            // PDF is still named after queue_number (MRN not saved yet)
                            'pdf_filename' => (string)($ticketPatientRow['queue_number'] ?? (string)$patient_id),
                            'mobile' => (string)($ticketPatientRow['mobile'] ?? ''),
                            'country_code' => (string)($ticketPatientRow['country_code'] ?? ''),
                            'care_mobile' => (string)($ticketPatientRow['care_mobile'] ?? ''),
                            'care_country_code' => (string)($ticketPatientRow['care_country_code'] ?? ''),
                            'email' => (string)($ticketPatientRow['email'] ?? ''),
                            'address' => (string)($ticketPatientRow['address'] ?? ''),
                        ],
                        'existing_patient' => [
                            'patient_id' => (int)($mrnConflictRow['patient_id'] ?? 0),
                            'patient_name' => (string)($mrnConflictRow['patient_name'] ?? ''),
                            'mrn' => (string)($mrnConflictRow['mrn'] ?? ''),
                            // PDF is named after MRN for existing patient
                            'pdf_filename' => (string)($mrnConflictRow['mrn'] ?? (string)($mrnConflictRow['patient_id'] ?? '')),
                            'mobile' => (string)($mrnConflictRow['mobile'] ?? ''),
                            'country_code' => (string)($mrnConflictRow['country_code'] ?? ''),
                            'care_mobile' => (string)($mrnConflictRow['care_mobile'] ?? ''),
                            'care_country_code' => (string)($mrnConflictRow['care_country_code'] ?? ''),
                            'email' => (string)($mrnConflictRow['email'] ?? ''),
                            'address' => (string)($mrnConflictRow['address'] ?? ''),
                        ],
                    ], JSON_UNESCAPED_UNICODE);
                    exit();
                }
                $_SESSION['success_message'] = $error;
                header('Location: billing.php'); exit();
            }

            if ($overrideExistingMrn) {
                $resolvedConflictId = (int)($mrnConflictRow['patient_id'] ?? 0);
                if ($resolvedConflictId <= 0 || ($conflictPatientIdFromClient > 0 && $resolvedConflictId !== $conflictPatientIdFromClient)) {
                    $error = 'MRN override target could not be resolved. Please retry.';
                    if ($isAjax) {
                        if (ob_get_length()) ob_end_clean();
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode(['success' => false, 'error' => $error], JSON_UNESCAPED_UNICODE);
                        exit();
                    }
                    $_SESSION['success_message'] = $error;
                    header('Location: billing.php'); exit();
                }
            }

            // Fetch OLD MRN and queue_number BEFORE updating (to know what files to rename)
            $prevMrn = '';
            $queueNum = '';
            try {
                $infoRow = executeAndFetchOne($pdo, "SELECT p.mrn, t.queue_number FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
                $prevMrn = $infoRow['mrn'] ?? '';
                $queueNum = $infoRow['queue_number'] ?? '';
            } catch (Exception $e) {
                $prevMrn = '';
                $queueNum = '';
            }

            if ($overrideExistingMrn && $mrnConflictRow) {
                $overridePatientId = (int)$mrnConflictRow['patient_id'];

                $pdo->beginTransaction();
                try {
                    executeUpdate($pdo, "UPDATE patients SET
                            patient_name = ?,
                            mobile = ?,
                            email = ?,
                            address = ?,
                            country_code = ?,
                            care_country_code = ?,
                            care_mobile = ?,
                            mrn = ?
                        WHERE patient_id = ?", [
                        (string)($ticketPatientRow['patient_name'] ?? ''),
                        (string)($ticketPatientRow['mobile'] ?? ''),
                        (string)($ticketPatientRow['email'] ?? ''),
                        (string)($ticketPatientRow['address'] ?? ''),
                        (string)($ticketPatientRow['country_code'] ?? ''),
                        (string)($ticketPatientRow['care_country_code'] ?? ''),
                        (string)($ticketPatientRow['care_mobile'] ?? ''),
                        $mrn,
                        $overridePatientId,
                    ]);

                    executeUpdate($pdo, "UPDATE tickets SET patient_id = ? WHERE patient_id = ?", [$overridePatientId, $currentPatientDbId]);

                    executeUpdate($pdo, "DELETE FROM patients WHERE patient_id = ?", [$currentPatientDbId]);

                    $pdo->commit();
                } catch (Exception $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $error = 'Failed to override existing patient: ' . $e->getMessage();
                    if ($isAjax) {
                        if (ob_get_length()) ob_end_clean();
                        header('Content-Type: application/json; charset=utf-8');
                        echo json_encode(['success' => false, 'error' => $error], JSON_UNESCAPED_UNICODE);
                        exit();
                    }
                    $_SESSION['success_message'] = $error;
                    header('Location: billing.php'); exit();
                }
            } else {
                // Update current patient with NEW MRN when no conflict override is required.
                executeUpdate($pdo, "UPDATE patients SET mrn = ? WHERE patient_id = ?", [$mrn, $currentPatientDbId]);
            }

            updateTicketDemographicsChangeFlags($pdo, $patient_id);

            // Attempt to rename existing PDFs on network share to {mrn}.pdf
            $messages = [];

            // Prepare candidate sources: previous MRN, queue number, then patient id
            $sources = [];
            if (!empty($prevMrn)) $sources[] = preg_replace('/[^A-Za-z0-9_\-\.]/', '', $prevMrn);
            if (!empty($queueNum)) $sources[] = preg_replace('/[^A-Za-z0-9_\-\.]/', '', $queueNum);
            $sources[] = preg_replace('/[^A-Za-z0-9_\-\.]/', '', $patient_id);

            // Destination base
            $destBase = preg_replace('/[^A-Za-z0-9_\-\.]/', '', $mrn);

            // Helper to attempt rename in a base path
            // Helper to rename a PDF in a given path (try atomic rename first, fall back to copy+delete)
            $renameInPath = function($basePath) use ($sources, $destBase, &$messages) {
                $dest = $basePath . $destBase . '.pdf';
                foreach ($sources as $srcBase) {
                    if (!$srcBase) continue;
                    $src = $basePath . $srcBase . '.pdf';
                    if (file_exists($src) && is_readable($src)) {
                        // Skip no-op (src and dest are the same file)
                        if (realpath($src) !== false && realpath($src) === realpath($dest)) {
                            $messages[] = basename($dest) . ' already in place, no rename needed.';
                            return;
                        }
                        if (@rename($src, $dest)) {
                            $messages[] = 'Renamed ' . basename($src) . ' -> ' . basename($dest);
                        } elseif (@copy($src, $dest)) {
                            if (@unlink($src)) {
                                $messages[] = 'Renamed ' . basename($src) . ' -> ' . basename($dest);
                            } else {
                                $messages[] = 'Copied ' . basename($src) . ' -> ' . basename($dest) . ' (source not deleted — check share permissions)';
                            }
                        } else {
                            $messages[] = 'Failed to rename ' . basename($src) . ' to ' . basename($dest);
                        }
                        return;
                    }
                }
                $messages[] = 'No existing file found in ' . $basePath . ' for ' . $destBase . '.pdf';
            };

            // Try ID and Insurance folders
            $renameInPath(ID_SAVE_PATH);
            $renameInPath(INSURANCE_SAVE_PATH);

            if ($isAjax) {
                if (ob_get_length()) ob_end_clean();
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['success' => true, 'messages' => $messages], JSON_UNESCAPED_UNICODE);
                exit();
            }

            $_SESSION['success_message'] = 'MRN saved successfully.' . (count($messages) ? ' ' . implode(' | ', $messages) : '');
            header('Location: billing.php');
            exit();
    } elseif (isset($_POST['send_to_lab'])) {
        $patient_id = $_POST['patient_id'];
        // Ensure MRN is present for this patient
        $mrnRow = executeAndFetchOne($pdo, "SELECT p.mrn FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
        if (empty($mrnRow['mrn'])) {
            $_SESSION['success_message'] = "Please fill the PID in Details before sending to Lab.";
            if ($isAjax) { echo json_encode(['success' => false, 'error' => 'MRN required']); exit(); }
            header('Location: billing.php'); exit();
        }
        
        // Get current status and department flags BEFORE update
        $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
        
        // If patient has 'Wrong Info' status, reset all department flags before setting lab
        if ($current['current_status'] === 'Wrong Info') {
            executeUpdate($pdo, "UPDATE tickets SET lab = 1, img = 0, dp2 = 0, current_status = 'Waiting' WHERE ticket_id = ?", [$patient_id]);
        } else {
            executeUpdate($pdo, "UPDATE tickets SET lab = 1, current_status = 'Waiting' WHERE ticket_id = ?", [$patient_id]);
        }

        // Log the action
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes)
                   VALUES (?, 'Sent to Lab', 'In Process', 'Waiting', 'Sent to Laboratory')", [$patient_id]);
        authLogTicketAction('ticket_sent_to_lab', $patient_id, [
            'ticket_action' => 'Sent to Lab',
            'department' => 'billing',
            'from_status' => $current['current_status'],
            'to_status' => 'Waiting',
            'lab' => 1,
            'img' => 0,
            'dp2' => 0,
            'notes' => 'Sent to Laboratory',
        ], 'billing.php');

        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Waiting',
            'action' => 'Sent to Lab',
            'department' => 'billing',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];

        $_SESSION['success_message'] = "Patient sent to Laboratory!";

    } elseif (isset($_POST['send_to_imaging'])) {
        $patient_id = $_POST['patient_id'];
        // Ensure MRN is present for this patient
        $mrnRow = executeAndFetchOne($pdo, "SELECT p.mrn FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
        if (empty($mrnRow['mrn'])) {
            $_SESSION['success_message'] = "Please fill the PID in Details before sending to Imaging.";
            if ($isAjax) { echo json_encode(['success' => false, 'error' => 'MRN required']); exit(); }
            header('Location: billing.php'); exit();
        }
        
        // Get current status and department flags BEFORE update
        $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
        
        // If patient has 'Wrong Info' status, reset all department flags before setting img
        if ($current['current_status'] === 'Wrong Info') {
            executeUpdate($pdo, "UPDATE tickets SET img = 1, lab = 0, dp2 = 0, current_status = 'Waiting' WHERE ticket_id = ?", [$patient_id]);
        } else {
            executeUpdate($pdo, "UPDATE tickets SET img = 1, current_status = 'Waiting' WHERE ticket_id = ?", [$patient_id]);
        }

        // Log the action
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes)
                   VALUES (?, 'Sent to Imaging', 'In Process', 'Waiting', ?, 'Sent to Imaging')", [$patient_id, authCurrentUserId()]);
        authLogTicketAction('ticket_sent_to_imaging', $patient_id, [
            'ticket_action' => 'Sent to Imaging',
            'department' => 'billing',
            'from_status' => $current['current_status'],
            'to_status' => 'Waiting',
            'lab' => 0,
            'img' => 1,
            'dp2' => 0,
            'notes' => 'Sent to Imaging',
        ], 'billing.php');

        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Waiting',
            'action' => 'Sent to Imaging',
            'department' => 'billing',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];

        $_SESSION['success_message'] = "Patient sent to Imaging!";

    } elseif (isset($_POST['send_to_both'])) {
        $patient_id = $_POST['patient_id'];
        // Ensure MRN is present for this patient
        $mrnRow = executeAndFetchOne($pdo, "SELECT p.mrn FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
        if (empty($mrnRow['mrn'])) {
            $_SESSION['success_message'] = "Please fill the PID in Details before sending to Lab/Imaging.";
            if ($isAjax) { echo json_encode(['success' => false, 'error' => 'MRN required']); exit(); }
            header('Location: billing.php'); exit();
        }
        
        // Get current status and department flags BEFORE update
        $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
        
        // If patient has 'Wrong Info' status, reset dp2 flag before setting both lab and img
        if ($current['current_status'] === 'Wrong Info') {
            executeUpdate($pdo, "UPDATE tickets SET lab = 1, img = 1, dp2 = 0, current_status = 'Waiting' WHERE ticket_id = ?", [$patient_id]);
        } else {
            executeUpdate($pdo, "UPDATE tickets SET lab = 1, img = 1, current_status = 'Waiting' WHERE ticket_id = ?", [$patient_id]);
        }

        // Log the action
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes)
                   VALUES (?, 'Sent to Both', 'In Process', 'Waiting', 'Sent to Both (Lab first)')", [$patient_id]);
        authLogTicketAction('ticket_sent_to_both', $patient_id, [
            'ticket_action' => 'Sent to Both',
            'department' => 'billing',
            'from_status' => $current['current_status'],
            'to_status' => 'Waiting',
            'lab' => 1,
            'img' => 1,
            'dp2' => 0,
            'notes' => 'Sent to Both (Lab first)',
        ], 'billing.php');

        
        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Waiting',
            'action' => 'Sent to Both',
            'department' => 'billing',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];

        $_SESSION['success_message'] = "Patient sent to Both (Lab -> Imaging)!";
        
    } elseif (isset($_POST['send_to_clinics'])) {
        $patient_id = $_POST['patient_id'];
        // Ensure MRN is present for this patient
        $mrnRow = executeAndFetchOne($pdo, "SELECT p.mrn FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);
        if (empty($mrnRow['mrn'])) {
            $_SESSION['success_message'] = "Please fill the PID in Details before sending to Clinics.";
            if ($isAjax) { echo json_encode(['success' => false, 'error' => 'MRN required']); exit(); }
            header('Location: billing.php'); exit();
        }
        
        // Get current status and department flags BEFORE update
        $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
        
        // If patient has 'Wrong Info' status, reset all department flags before setting cl
        if ($current['current_status'] === 'Wrong Info') {
            executeUpdate($pdo, "UPDATE tickets SET service_type = 'Clinics', cl = 1, Clinic = NULL, img = 0, lab = 0, dp2 = 0, current_status = 'Waiting' WHERE ticket_id = ?", [$patient_id]);
        } else {
            executeUpdate($pdo, "UPDATE tickets SET service_type = 'Clinics', cl = 1, Clinic = NULL, current_status = 'Waiting' WHERE ticket_id = ?", [$patient_id]);
        }
        $stmt->execute([$patient_id]);

        // Log the action
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes)
                   VALUES (?, 'Sent to Clinics', ?, 'Waiting', 'Sent to Clinics')", [$patient_id, $current['current_status']]);
        authLogTicketAction('ticket_sent_to_clinics', $patient_id, [
            'ticket_action' => 'Sent to Clinics',
            'department' => 'billing',
            'from_status' => $current['current_status'],
            'to_status' => 'Waiting',
            'service_type' => 'Clinics',
            'notes' => 'Sent to Clinics',
        ], 'billing.php');
        
        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Waiting',
            'action' => 'Sent to Clinics',
            'department' => 'billing',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];

        $_SESSION['success_message'] = "Patient sent to Clinics!";
        
    } elseif (isset($_POST['cancel_ticket'])) {
        $patient_id = $_POST['patient_id'];
        
        // Get current status and department flags BEFORE update
        $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
        
        executeUpdate($pdo, "UPDATE tickets SET current_status = 'Canceled', closing_timestamp = NOW() WHERE ticket_id = ?", [$patient_id]);
        
        // Log the action
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes) 
                   VALUES (?, 'Canceled', 'In Process', 'Canceled', 'Ticket canceled by Billing')", [$patient_id]);
        authLogTicketAction('ticket_canceled_by_billing', $patient_id, [
            'ticket_action' => 'Canceled',
            'department' => 'billing',
            'from_status' => $current['current_status'],
            'to_status' => 'Canceled',
            'notes' => 'Ticket canceled by Billing',
        ], 'billing.php');
        
        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Canceled',
            'action' => 'Ticket canceled',
            'department' => 'billing',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];
        
        $_SESSION['success_message'] = "Ticket canceled!";
        
    } elseif (isset($_POST['need_patient'])) {
        $patient_id = $_POST['patient_id'];

        $currentUser = authCurrentUser();
        $requestedByUserId = authCurrentUserId();
        $requestedByUsername = '';
        if (is_array($currentUser)) {
            $requestedByUsername = trim((string)($currentUser['full_name'] ?? ''));
            if ($requestedByUsername === '') {
                $requestedByUsername = trim((string)($currentUser['username'] ?? ''));
            }
        }
        if ($requestedByUsername === '') {
            $requestedByUsername = authCurrentUsername();
        }
        $requestedByUsername = trim((string)$requestedByUsername);
        
        // Get current status and department flags BEFORE update
        $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine, assigned_butler_username, registered_by_username FROM tickets WHERE ticket_id = ?", [$patient_id]);

        $assignedButlerUsername = trim((string)($current['assigned_butler_username'] ?? ''));
        if ($assignedButlerUsername === '') {
            $assignedButlerUsername = null;
        }

        if ($assignedButlerUsername === null) {
            $fallbackName = trim((string)($current['registered_by_username'] ?? ''));
            $assignedButlerUsername = $fallbackName !== '' ? $fallbackName : null;
        }
    
        // Set status to 'Needed by Billing'
        executeUpdate($pdo, "UPDATE tickets
                               SET current_status = 'Needed by Billing',
                                   last_need_request_by_username = ?,
                                   last_need_request_at = NOW(),
                                   assigned_butler_username = ?
                               WHERE ticket_id = ?", [
            $requestedByUsername !== '' ? $requestedByUsername : null,
            $assignedButlerUsername,
            $patient_id
        ]);
        
        // Log the action
        $logRequester = $requestedByUsername !== '' ? $requestedByUsername : 'Unknown user';
        $logButler = $assignedButlerUsername !== null ? $assignedButlerUsername : 'Unassigned';
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes) 
            VALUES (?, 'Needed by Billing', 'In Process', 'Needed by Billing', ?)", [$patient_id, 'Patient requested at billing counter by ' . $logRequester . ' | Assigned butler: ' . $logButler]);
        authLogTicketAction('ticket_needed_by_billing', $patient_id, [
            'ticket_action' => 'Needed by Billing',
            'department' => 'billing',
            'from_status' => $current['current_status'],
            'to_status' => 'Needed by Billing',
            'requested_by' => $logRequester,
            'assigned_butler' => $logButler,
            'notes' => 'Patient requested at billing counter by ' . $logRequester . ' | Assigned butler: ' . $logButler,
        ], 'billing.php');
        
        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'Needed by Billing',
            'action' => 'Patient Needed',
            'department' => 'billing',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];
        
        // If it's an AJAX request, return JSON
        if ($isAjax) {
            echo json_encode(['success' => true, 'message' => 'Patient marked as Needed by Billing']);
            exit();
        }
        
        $_SESSION['success_message'] = "Patient marked as 'Needed by Billing' - WhatsApp sent!";
    
    } elseif (isset($_POST['confirm_return'])) {
        $patient_id = $_POST['patient_id'];
        
        // Get current status and department flags BEFORE update
        $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
        
        // Set status back to 'In Process' and reset department flags
        executeUpdate($pdo, "UPDATE tickets SET current_status = 'In Process', lab = 0, img = 0, dp2 = 0 WHERE ticket_id = ?", [$patient_id]);
        
        // Log the action
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes) 
                VALUES (?, 'Patient Returned', 'Needed by Billing', 'In Process', 'Patient returned to billing counter')", [$patient_id]);
        authLogTicketAction('ticket_returned_to_billing', $patient_id, [
            'ticket_action' => 'Patient Returned',
            'department' => 'billing',
            'from_status' => $current['current_status'],
            'to_status' => 'In Process',
            'notes' => 'Patient returned to billing counter',
        ], 'billing.php');
        
        // Build undo state with pre-fetched values
        $_SESSION['last_action'] = [
            'patient_id' => $patient_id,
            'previous_status' => $current['current_status'],
            'current_status' => 'In Process',
            'action' => 'Patient Returned',
            'department' => 'billing',
            'img' => $current['img'] ?? 0,
            'lab' => $current['lab'] ?? 0,
            'dp2' => $current['dp2'] ?? 0,
            'imaging_machine' => $current['imaging_machine'] ?? null,
            'timestamp' => time()
        ];
        
        // If it's an AJAX request, return JSON
        if ($isAjax) {
            echo json_encode(['success' => true, 'message' => 'Patient returned to In Process']);
            exit();
        }
        
        $_SESSION['success_message'] = "Patient returned to billing - status set to 'In Process'!";
    
    } elseif (isset($_POST['update_patient'])) {
        $patient_id = $_POST['patient_id'];
        $patient_name = $_POST['patient_name'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'] ?? '';
        $address = $_POST['address'] ?? '';
        $country_code = $_POST['country_code'] ?? '';
        $care_country_code = $_POST['care_country_code'] ?? '';
        $care_mobile = $_POST['care_mobile'] ?? '';
        // If care_mobile is empty, fall back to contact mobile so DB is never left null
        if (empty($care_mobile)) {
            $care_mobile = $mobile;
        }
        if (empty($care_country_code)) {
            $care_country_code = $country_code;
        }
        
        // Update patient information
        executeUpdate($pdo, "UPDATE patients SET
                patient_name = ?,
                mobile = ?,
                email = ?,
                address = ?,
                country_code = ?,
                care_country_code = ?,
                care_mobile = ?
            WHERE patient_id = (SELECT patient_id FROM tickets WHERE ticket_id = ?)", [$patient_name, $mobile, $email, $address, $country_code, $care_country_code, $care_mobile, $patient_id]);

        updateTicketDemographicsChangeFlags($pdo, $patient_id);
        
        // Log the action
        executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes) 
                   VALUES (?, 'Patient Info Updated', 'Arrived/Needed by Billing', 'Arrived/Needed by Billing', 'Patient information edited by Butler')", [$patient_id]);
        authLogTicketAction('ticket_info_updated', $patient_id, [
            'ticket_action' => 'Patient Info Updated',
            'department' => 'billing',
            'notes' => 'Patient information edited by billing/butler workflow',
        ], 'billing.php');
        
        if ($isAjax) {
            echo json_encode(['success' => true, 'message' => 'Patient information updated']);
            exit();
        }
        
        $_SESSION['success_message'] = "Patient information updated successfully!";
    }
    
    // Only redirect for non-AJAX requests
    if (!$isAjax) {
        header('Location: billing.php');
        exit();
    }
}

// Handle type selection from POST (checkbox form submission) or GET request and store in session
if (isset($_POST['types']) && is_array($_POST['types'])) {
    // Store selected types in session so they persist across refreshes
    // Only allow valid types
    $_SESSION['billing_types'] = array_intersect($_POST['types'], ['Appointment', 'Private', 'Guarantor', 'Clinics']);
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['types'])) {
    // Store selected types in session so they persist across refreshes
    // Only allow valid types
    $_SESSION['billing_types'] = array_intersect($_GET['types'], ['Appointment', 'Private', 'Guarantor', 'Clinics']);
}

// Get selected patient types from session or default
// Allow Clinics as a valid billing type
$selected_types = isset($_SESSION['billing_types']) ? $_SESSION['billing_types'] : ['Appointment', 'Private', 'Guarantor', 'Clinics'];
$selected_types = array_intersect($selected_types, ['Appointment', 'Private', 'Guarantor', 'Clinics']);
// Fetch patients for initial page render (billing view)
try {
    $params = [];
    $query = "SELECT
        t.ticket_id AS id,
        t.queue_number,
        t.is_existing_patient,
        t.demographics_edited,
        t.demographics_changed_fields,
        p.patient_name,
        p.mrn,
        p.mobile,
        p.country_code,
        p.care_mobile,
        p.care_country_code,
        p.email,
        p.address,
        t.service_type as type,
        t.current_status as status,
        t.arrival_timestamp,
        t.approval_timestamp,
        t.registered_by_username,
        t.assigned_butler_username,
        t.last_need_request_by_username,
        t.last_need_request_at
    FROM tickets t
    JOIN patients p ON t.patient_id = p.patient_id
    WHERE t.closing_timestamp IS NULL
    AND DATE(t.arrival_timestamp) = CURDATE()
    AND (
        (t.current_status IN ('Arrived', 'In Process', 'Needed by Billing'))
        OR
        (t.current_status = 'Wrong Info')
    )";

    // Apply selected type filters if present (but Wrong Info always shows)
    if (!empty($selected_types)) {
        $types = array_values($selected_types);
        $placeholders = implode(',', array_fill(0, count($types), '?'));
        $query .= " AND (t.current_status = 'Wrong Info' OR t.service_type IN ($placeholders))";
        $params = array_merge($params, $types);
    }

    $query .= " ORDER BY
        CASE WHEN t.current_status = 'Arrived' THEN 1 WHEN t.current_status = 'Wrong Info' THEN 2 ELSE 3 END,
        FIELD(t.service_type, 'Appointment','Private','Guarantor','Clinics'),
        t.arrival_timestamp ASC";

    $patients = executeAndFetch($pdo, $query, $params);
} catch (Exception $e) {
    error_log('Failed to fetch patients for billing.php: ' . $e->getMessage());
    $patients = [];
}

// Sync cached request rows for today's active billing tickets that already have an MRN.
try {
    $syncRows = executeAndFetch($pdo,
        "SELECT t.ticket_id
         FROM tickets t
         INNER JOIN patients p ON p.patient_id = t.patient_id
         WHERE t.closing_timestamp IS NULL
           AND DATE(t.arrival_timestamp) = CURDATE()
           AND TRIM(COALESCE(p.mrn, '')) <> ''"
    );
    // executeAndFetch returns an array of rows; extract ticket_id column
    $syncTicketIds = is_array($syncRows) ? array_column($syncRows, 'ticket_id') : [];
    foreach ($syncTicketIds as $syncTicketId) {
        $syncTicketId = (int)$syncTicketId;
        if ($syncTicketId > 0) {
            // placeholder for future sync processing
        }
    }
} catch (Exception $e) {
    // Keep billing page available even if JSON sync fails.
}

// Handle type selection form
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="browser-notifications.js"></script>
    
    <!-- JavaScript Functions - MUST be in head for inline onclick to work -->
    <script>
    // ==================== GLOBAL FUNCTIONS ====================
    // Network paths from PHP
    const ID_SAVE_PATH = '<?php echo addslashes(ID_SAVE_PATH); ?>';
    const INSURANCE_SAVE_PATH = '<?php echo addslashes(INSURANCE_SAVE_PATH); ?>';
    const BILLING_NOTIFICATION_PAGE = 'Billing';
    let billingQueueRefreshInFlight = false;
    const ASSIGNABLE_BUTLERS = <?php echo json_encode($assignableButlers, JSON_UNESCAPED_UNICODE); ?>;

    function getSelectedBillingTypes() {
        const selectedTypes = [];
        document.querySelectorAll('input[name="types[]"]:checked').forEach(checkbox => {
            selectedTypes.push(checkbox.value);
        });
        return selectedTypes.sort();
    }

    function buildBillingNotificationKey(selectedTypes) {
        return `billing:${selectedTypes.length ? selectedTypes.join('|') : 'all'}`;
    }

    function buildBillingWrongInfoNotificationKey(selectedTypes) {
        return `billing:wrong-info:${selectedTypes.length ? selectedTypes.join('|') : 'all'}`;
    }

    function collectCurrentBillingTicketsFromDom() {
        const rows = document.querySelectorAll('#billingTableBody tr[id^="patient-row-"]');
        return Array.from(rows).map(row => {
            const cells = row.querySelectorAll('td');
            return {
                id: row.id.replace('patient-row-', ''),
                queueNumber: cells[1] ? cells[1].textContent.trim() : '',
                patientName: cells[2] ? cells[2].textContent.trim() : ''
            };
        });
    }

    function collectCurrentBillingWrongInfoTicketsFromDom() {
        const rows = document.querySelectorAll('#billingTableBody tr[id^="patient-row-"]');
        return Array.from(rows).map(row => {
            const statusBadge = row.querySelector('.status-badge');
            const statusText = statusBadge ? statusBadge.textContent.trim() : '';
            if (statusText !== 'Wrong Info') {
                return null;
            }

            const cells = row.querySelectorAll('td');
            return {
                id: row.id.replace('patient-row-', ''),
                queueNumber: cells[1] ? cells[1].textContent.trim() : '',
                patientName: cells[2] ? cells[2].textContent.trim() : '',
                message: `${cells[1] ? cells[1].textContent.trim() : ''} - ${cells[2] ? cells[2].textContent.trim() : ''}`
            };
        }).filter(Boolean);
    }

    function parseChangedFields(rawChangedFields) {
        if (Array.isArray(rawChangedFields)) return rawChangedFields;
        if (typeof rawChangedFields === 'string' && rawChangedFields.trim() !== '') {
            try {
                const parsed = JSON.parse(rawChangedFields);
                return Array.isArray(parsed) ? parsed : [];
            } catch (e) {
                return [];
            }
        }
        return [];
    }

    function mapChangedFieldLabel(fieldKey) {
        const labels = {
            mrn: 'PID (MRN)',
            patient_name: 'Patient Name',
            mobile: 'Current Mobile',
            country_code: 'Current Country Code',
            care_mobile: 'Result & Care Mobile',
            care_country_code: 'Care Country Code',
            email: 'Email',
            address: 'Address'
        };
        return labels[fieldKey] || fieldKey;
    }

    function buildTicketMetaBadgesHtml(patient) {
        return '';
    }

    function notifyNewBillingTickets(patients, selectedTypes) {
        if (!window.QueueNotifications) {
            return;
        }

        QueueNotifications.notifyForNewTickets({
            pageKey: buildBillingNotificationKey(selectedTypes),
            items: (patients || [])
                .filter(patient => (patient.status || '').toLowerCase() !== 'wrong info')
                .map(patient => ({
                    id: patient.id,
                    queueNumber: patient.queue_number,
                    patientName: patient.patient_name,
                    message: `${patient.queue_number} - ${patient.patient_name}`
                })),
            title: 'New billing ticket',
            getBody: (item) => item.message || 'A new billing ticket is now visible.',
            onClick: () => window.focus()
        });

        QueueNotifications.notifyForNewTickets({
            pageKey: buildBillingWrongInfoNotificationKey(selectedTypes),
            items: (patients || [])
                .filter(patient => (patient.status || '').toLowerCase() === 'wrong info')
                .map(patient => ({
                    id: patient.id,
                    queueNumber: patient.queue_number,
                    patientName: patient.patient_name,
                    message: `${patient.queue_number} - ${patient.patient_name}`
                })),
            title: 'Wrong Info patient (Billing)',
            getBody: (item) => item.message || 'A Wrong Info patient is now visible in Billing.',
            onClick: () => window.focus()
        });
    }
    
    // Handle Need Butler button click
    function handleNeedButlerClick(patientId) {
        console.log('handleNeedButlerClick called for patient ID:', patientId);
        
        // Update patient status via AJAX
        updatePatientStatusAjax(patientId);
        
        return false;
    }
    
    // Update patient status via AJAX
    function updatePatientStatusAjax(patientId) {
        console.log('Updating patient status for ID:', patientId);
        
        const formData = new FormData();
        formData.append('patient_id', patientId);
        formData.append('need_patient', '1');
        
        fetch('billing.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('âœ“ Patient status updated successfully:', data.message);
                // Refresh after short delay (prefer smart partial refresh)
                setTimeout(() => {
                    if (window.smartReload) window.smartReload(0); else window.location.reload();
                }, 1500);
            } else {
                console.error('Status update failed:', data);
                alert('Could not update patient status. Please refresh the page.');
            }
        })
        .catch(error => {
            console.error('AJAX error:', error);
            // Still refresh to show updated status (prefer smartReload)
            setTimeout(() => {
                if (window.smartReload) window.smartReload(0); else window.location.reload();
            }, 1500);
        });
    }

    // Save MRN via AJAX
    function saveMRN(patientId, mrn, options = {}) {
        const formData = new FormData();
        formData.append('save_mrn', '1');
        formData.append('patient_id', patientId);
        formData.append('mrn', mrn);
        if (options && options.override === true) {
            formData.append('mrn_override', '1');
            if (options.conflictPatientId) {
                formData.append('conflict_patient_id', String(options.conflictPatientId));
            }
        }

        return fetch('billing.php', {
            method: 'POST',
            body: formData,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then(r => r.json());
    }


    
    // Refresh billing queue with AJAX
    function refreshBillingQueue() {
        if (billingQueueRefreshInFlight) {
            return;
        }

        billingQueueRefreshInFlight = true;

        // Get selected types from checkboxes
        const selectedTypes = getSelectedBillingTypes();
        
        // Use queue_refresh.php with billing department and type filtering
        fetch(`queue_refresh.php?department=billing&types=${encodeURIComponent(selectedTypes.join(','))}`, {
            cache: 'no-store'
        })
            .then(response => {
                // Check if response is JSON
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text().then(text => {
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        console.error('Failed to parse JSON response from queue_refresh.php:', text);
                        throw new Error('Invalid JSON response: ' + text.substring(0, 100));
                    }
                });
            })
            .then(data => {
                // Validate data is an array before processing
                if (!Array.isArray(data)) {
                    console.error('Unexpected response format from queue_refresh.php. Expected array, got:', typeof data);
                    throw new Error('Invalid response format: expected array');
                }
                
                notifyNewBillingTickets(data, selectedTypes);
                const tableBody = document.getElementById('billingTableBody');
                
                if (data.length === 0) {
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <i class="fas fa-inbox"></i>
                                    <h3>No patients in queue</h3>
                                    <p>Select patient types above or wait for new arrivals</p>
                                </div>
                            </td>
                        </tr>
                    `;
                } else {
                    let html = '';
                    data.forEach(patient => {
                        const statusClass = 'status-' + patient.status.toLowerCase().replace(' ', '-');
                        const typeClass = 'type-' + patient.type.toLowerCase();
                        const statusIndicator = 'status-' + patient.status.toLowerCase().replace(' ', '-') + '-indicator';
                        
                        // Format arrival time
                        const arrivalTime = new Date(patient.arrival_timestamp);
                        const arrivalTimeStr = arrivalTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                        
                        // Reuse the shared action renderer so refresh and initial load stay identical.
                        const actionsHtml = getActionButtonsHtml(patient);
                        
                        html += `
                            <tr id="patient-row-${patient.id}" class="${patient.type === 'Appointment' ? 'highlighted' : ''}">
                                <td>
                                    <button type="button" class="view-details-btn view-patient-details" 
                                            data-patient='${JSON.stringify(patient).replace(/'/g, "&apos;")}'>
                                        <i class="fas fa-eye"></i> Details
                                    </button>
                                </td>
                                <td style="font-weight: bold; color: #2c3e50;">
                                    ${patient.queue_number}
                                </td>
                                <td>${escapeHtml(patient.patient_name)}</td>
                                <td>
                                    <span class="type-badge ${typeClass}">
                                        ${patient.type}
                                    </span>
                                    ${buildTicketMetaBadgesHtml(patient)}
                                </td>
                                <td>
                                    <span class="status-indicator ${statusIndicator}"></span>
                                    <span class="status-badge ${statusClass}">
                                        ${patient.status}
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        ${actionsHtml}
                                    </div>
                                </td>
                            </tr>
                        `;
                    });
                    tableBody.innerHTML = html;
                }
            })
            .catch(error => {
                console.error('Error refreshing billing queue:', error);
                // Don't hide the table on error - keep displaying existing data
            })
            .finally(() => {
                billingQueueRefreshInFlight = false;
            });
    }

    // Update table content with new data
    function updateBillingTable(patients) {
        const tableBody = document.getElementById('billingTableBody');

        if (patients.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6">
                        <div class="empty-state">
                            <i class="fas fa-inbox"></i>
                            <h3>No patients in queue</h3>
                            <p>Select patient types above or wait for new arrivals</p>
                        </div>
                    </td>
                </tr>
            `;
        } else {
            let html = '';
            patients.forEach(patient => {
                const isHighlighted = patient.type === 'Appointment' ? 'highlighted' : '';
                const statusClass = 'status-' + patient.status.toLowerCase().replace(/\s+/g, '-');
                const typeClass = 'type-' + patient.type.toLowerCase();

                /* Format arrival time
                let arrivalTimeStr = 'N/A';
                let waitingTimeStr = '';
                try {
                    if (patient.arrival_timestamp) {
                        const arrivalTime = new Date(patient.arrival_timestamp);
                        arrivalTimeStr = arrivalTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

                        // Show waiting time if arrived and not started
                        if (patient.status === 'Arrived') {
                            const now = new Date();
                            const waitingMinutes = Math.floor((now - arrivalTime) / (1000 * 60));
                            if (waitingMinutes > 0) {
                                waitingTimeStr = `<br><small style="color: #e74c3c;">${waitingMinutes} min</small>`;
                            }
                        }
                    }
                } catch (e) {
                    console.error('Error formatting time:', e);
                } */

                html += `
<tr id="patient-row-${patient.id}" class="${isHighlighted}">
    <td>
        <button type="button" class="view-details-btn"
            data-patient='${JSON.stringify({
                id: patient.id,
                queue_number: patient.queue_number,
                patient_name: patient.patient_name,
                mrn: patient.mrn,
                mobile: patient.mobile,
                country_code: patient.country_code,
                care_mobile: patient.care_mobile,
                care_country_code: patient.care_country_code,
                email: patient.email,
                address: patient.address,
                is_existing_patient: patient.is_existing_patient,
                demographics_edited: patient.demographics_edited,
                demographics_changed_fields: patient.demographics_changed_fields,
                type: patient.type,
                status: patient.status,
                arrival_timestamp: patient.arrival_timestamp,
                approval_timestamp: patient.approval_timestamp
                ,registered_by_username: patient.registered_by_username
                ,assigned_butler_username: patient.assigned_butler_username
                ,last_need_request_by_username: patient.last_need_request_by_username
                ,last_need_request_at: patient.last_need_request_at
            }).replace(/'/g, "&apos;")}'>
        <i class="fas fa-eye"></i> Details
    </button>
    </td>
    <td style="font-weight: bold; color: #2c3e50;">
        ${escapeHtml(patient.queue_number)}
    </td>
    <td>${escapeHtml(patient.patient_name)}</td>
    <td>
        <span class="type-badge ${typeClass}">
            ${escapeHtml(patient.type)}
        </span>
        ${buildTicketMetaBadgesHtml(patient)}
    </td>
    <td>
        <span class="status-badge ${statusClass}">
            ${escapeHtml(patient.status)}
        </span>
        ${patient.status === 'Needed by Billing' ? `
            <div style="font-size:11px;color:#5d6d7e;margin-top:4px;line-height:1.3;">
                Requested by: <strong>${escapeHtml((patient.last_need_request_by_username || '').toString().trim() || 'Unknown')}</strong><br>
                Butler: <strong>${escapeHtml((patient.assigned_butler_username || '').toString().trim() || 'Unassigned')}</strong>
            </div>
        ` : ''}
    </td>
    <td>
        <div class="action-buttons">
            ${getActionButtonsHtml(patient)}
        </div>
    </td>
</tr>`;
            });
            tableBody.innerHTML = html;
        }

        // Update patient count
        const countElement = document.querySelector('.queue-section h2 small');
        if (countElement) {
            countElement.textContent = `(${patients.length} patients)`;
        }
    }

    // Generate action buttons HTML based on patient status
    function getActionButtonsHtml(patient) {
        if (patient.status === 'Arrived') {
            return `
                <div class="action-grid">
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="start_ticket" class="action-btn start action-btn-full">
                            <i class="fas fa-play"></i> Start
                        </button>
                    </form>
                </div>`;
        } else if (patient.status.toLowerCase() === 'in process' || patient.status.toLowerCase() === 'in-process') {
            return `
                <div class="action-grid">
                    <button type="button"
                            class="action-btn butler action-btn-full"
                            onclick="handleNeedButlerClick(${patient.id})">
                        <i class="fas fa-user"></i> Need Butler
                    </button>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="send_to_lab" class="action-btn lab action-btn-full">
                            <i class="fas fa-flask"></i> Send to LAB
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="send_to_imaging" class="action-btn imaging action-btn-full">
                            <i class="fas fa-x-ray"></i> Send to Imaging
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="send_to_both" class="action-btn both action-btn-full">
                            <i class="fas fa-exchange-alt"></i> Send to BOTH
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="send_to_clinics" class="action-btn clinic action-btn-full">
                            <i class="fas fa-clinic-medical"></i> Send to Clinics
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="cancel_ticket" class="action-btn cancel action-btn-full"
                                onclick="return confirm('Are you sure you want to cancel this ticket?')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </form>
                </div>`;
        } else if (patient.status === 'Needed by Billing') {
            return `
                <div class="action-grid">
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="confirm_return" class="action-btn start action-btn-full">
                            <i class="fas fa-check-circle"></i> Patient Released
                        </button>
                    </form>
                </div>`;
        } else if (patient.status === 'waiting' || patient.status === 'Waiting') {
            return `
                <div class="action-grid">
                    <form method="POST" action="patient_actions.php" class="action-form">
                        <input type="hidden" name="department" value="billing">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <input type="hidden" name="action" value="wrong_info">
                        <button type="submit" class="action-btn wrong-info action-btn-full">
                            <i class="fas fa-exclamation-circle"></i> Wrong Info
                        </button>
                    </form>
                </div>`;
        } else if (patient.status === 'Wrong Info') {
            return `
                <div class="action-grid">
                    <button type="button"
                            class="action-btn butler action-btn-full"
                            onclick="handleNeedButlerClick(${patient.id})">
                        <i class="fas fa-user"></i> Need Butler
                    </button>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="send_to_lab" class="action-btn lab action-btn-full">
                            <i class="fas fa-flask"></i> Send to LAB
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="send_to_imaging" class="action-btn imaging action-btn-full">
                            <i class="fas fa-x-ray"></i> Send to Imaging
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="send_to_both" class="action-btn both action-btn-full">
                            <i class="fas fa-exchange-alt"></i> Send to BOTH
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="send_to_clinics" class="action-btn clinic action-btn-full">
                            <i class="fas fa-clinic-medical"></i> Send to Clinics
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="${patient.id}">
                        <button type="submit" name="cancel_ticket" class="action-btn cancel action-btn-full" onclick="return confirm('Are you sure you want to cancel this ticket?')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </form>
                </div>`;
        }
        return '';
    }
    
    // Show patient details modal
    function showPatientDetails(patient) {
        console.log('Patient object:', patient); // Debug to see structure
        
        // Ensure patient is properly parsed if it comes as a string
        if (typeof patient === 'string') {
            try {
                patient = JSON.parse(patient);
            } catch (e) {
                console.error('Error parsing patient:', e);
                alert('Error loading patient data.');
                return;
            }
        }
        
        const modalBody = document.getElementById('patientModalBody');
    
    // Format times safely
    let arrivalTimeStr = 'N/A';
    let approvalTimeStr = 'Not started yet';
    let needRequestTimeStr = 'N/A';
    
    try {
        if (patient.arrival_timestamp) {
            const arrivalTime = new Date(patient.arrival_timestamp);
            arrivalTimeStr = arrivalTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        }
    } catch (e) {
        console.error('Error formatting arrival time:', e);
    }
    
    try {
        if (patient.approval_timestamp) {
            const approvalTime = new Date(patient.approval_timestamp);
            approvalTimeStr = approvalTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        }
    } catch (e) {
        console.error('Error formatting approval time:', e);
    }

    try {
        if (patient.last_need_request_at) {
            const requestedAt = new Date(patient.last_need_request_at);
            needRequestTimeStr = requestedAt.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        }
    } catch (e) {
        console.error('Error formatting need request time:', e);
    }

    const registeredByLabel = (patient.registered_by_username && String(patient.registered_by_username).trim() !== '')
        ? escapeHtml(String(patient.registered_by_username))
        : 'N/A';
    
    // Create status and type badges
    let statusBadge = '';
    switch(patient.status) {
        case 'Arrived':
            statusBadge = '<span class="status-badge status-arrived">Arrived</span>';
            break;
        case 'In Process':
            statusBadge = '<span class="status-badge status-in-process">In Process</span>';
            break;
        case 'Patient Needed':
            statusBadge = '<span class="status-badge status-patient-needed">Patient Needed</span>';
            break;
        default:
            statusBadge = `<span class="status-badge">${patient.status || 'N/A'}</span>`;
    }
    
    let typeBadge = '';
    switch(patient.type) {
        case 'Appointment':
            typeBadge = '<span class="type-badge type-appointment">Appointment</span>';
            break;
        case 'Private':
            typeBadge = '<span class="type-badge type-private">Private</span>';
            break;
        case 'Guarantor':
            typeBadge = '<span class="type-badge type-guarantor">Guarantor</span>';
            break;
    }
    
    // Build modal content with MRN field and PDF links
        const changedFields = (() => {
            if (Array.isArray(patient.demographics_changed_fields)) return patient.demographics_changed_fields;
            if (typeof patient.demographics_changed_fields === 'string' && patient.demographics_changed_fields.trim() !== '') {
                try {
                    const parsed = JSON.parse(patient.demographics_changed_fields);
                    return Array.isArray(parsed) ? parsed : [];
                } catch (e) {
                    return [];
                }
            }
            return [];
        })();

        const isExistingPatient = Number(patient.is_existing_patient) === 1;
        const hasDemographicsEdits = Number(patient.demographics_edited) === 1 || changedFields.length > 0;
        const changedLabelMap = {
            mrn: 'PID (MRN)',
            patient_name: 'Patient Name',
            mobile: 'Current Mobile',
            country_code: 'Current Country Code',
            care_mobile: 'Result & Care Mobile',
            care_country_code: 'Care Country Code',
            email: 'Email',
            address: 'Address'
        };

        const changedFieldsBadge = hasDemographicsEdits
            ? `<div style="margin: 8px 0 14px 0;">
                    <span style="display:inline-block;padding:6px 10px;border-radius:999px;background:#fdeaea;color:#c0392b;border:1px solid #f0b7b2;font-weight:700;font-size:12px;">
                        Patient Details Edited
                    </span>
                    ${changedFields.length ? `<div style="margin-top:6px;color:#c0392b;font-weight:700;font-size:12px;"> </div>` : ''}
               </div>`
            : ''; //<!--Changed: ${changedFields.map(f => changedLabelMap[f] || f).join(', ')} -->

        const existingPatientBadge = isExistingPatient
            ? `<span style="display:inline-block;padding:4px 8px;border-radius:999px;background:#fff0f0;color:#c0392b;border:1px solid #f0b7b2;font-weight:700;font-size:11px;margin-left:8px;">Existing Patient</span>`
            : '';

        const fieldHighlight = (fieldKey) => changedFields.includes(fieldKey)
            ? 'border-left:4px solid #e74c3c; background:#fff8f8; padding-left:10px;'
            : 'opacity:0.7;';

        const changedValueStyle = (fieldKey) => changedFields.includes(fieldKey)
            ? 'color:#c0392b;font-weight:700;'
            : 'color:#95a5a6;';

        modalBody.innerHTML = `
            <div class="patient-info-group">
                <div class="patient-info-label">Queue Number</div>
                <div class="patient-info-value" style="font-size: 24px; font-weight: bold; color: #3498db;">
                    ${patient.queue_number || 'N/A'}
                </div>
            </div>
            
            <div class="patient-info-group" style="${fieldHighlight('patient_name')}">
                <div class="patient-info-label">Patient Name</div>
                <div class="patient-info-value" style="${changedValueStyle('patient_name')}">${escapeHtml(patient.patient_name) || 'N/A'} ${existingPatientBadge}</div>
            </div>

            ${changedFieldsBadge}

            <div class="patient-info-group" style="${fieldHighlight('care_mobile') || fieldHighlight('care_country_code')}">
                <div class="patient-info-label">Result & Care Mobile Number</div>
                <div class="patient-info-value" style="${changedFields.includes('care_mobile') || changedFields.includes('care_country_code') ? 'color:#c0392b;font-weight:700;' : 'color:#95a5a6;'}">${patient.care_mobile ? escapeHtml((patient.care_country_code?patient.care_country_code+' ':'') + patient.care_mobile) : 'N/A'}</div>
            </div>

            <div class="patient-info-group" style="${fieldHighlight('email')}">
                <div class="patient-info-label">Email Address</div>
                <div class="patient-info-value" style="${changedValueStyle('email')}">${patient.email ? escapeHtml(patient.email) : 'N/A'}</div>
            </div>
            
            <div class="patient-info-group" style="${fieldHighlight('address')}">
                <div class="patient-info-label">Address</div>
                <div class="patient-info-value" style="${changedValueStyle('address')}">${patient.address ? escapeHtml(patient.address) : 'N/A'}</div>
            </div>

            <div class="patient-info-group">
                <div class="patient-info-label">Registered By</div>
                <div class="patient-info-value" style="color:#95a5a6;">${registeredByLabel}</div>
            </div>


            
            <div class="patient-info-group">
                <div class="patient-info-label">Arrival Time</div>
                <div class="patient-info-value" style="color:#95a5a6;">${arrivalTimeStr}</div>
            </div>
            
            <div class="patient-info-group">
                <div class="patient-info-label">Start Time</div>
                <div class="patient-info-value" style="color:#95a5a6;">${approvalTimeStr}</div>
            </div>
        `;
        // Add MRN input and PDF links separately to avoid backtick quoting issues
        const mrnValue = patient.mrn || '';
        const canSetMrn = !isExistingPatient || !mrnValue;
        const mrnStyle = (isExistingPatient && mrnValue)
            ? 'width:100%; padding:8px; font-size:14px; color:#c0392b; font-weight:700; border:2px solid #e74c3c; background:#fff7f7;'
            : 'width:100%; padding:8px; font-size:14px;';
        const mrnReadOnlyAttrs = (isExistingPatient && mrnValue) ? 'readonly aria-readonly="true"' : '';
        const saveButtonHtml = canSetMrn
            ? '<button class="action-btn start" id="saveMrnBtn">Save PID</button>'
            : '<button class="action-btn start action-btn-locked" id="saveMrnBtn" disabled>PID Locked</button>';
        const detailsEl = document.createElement('div');
        detailsEl.innerHTML = `
            <div class="patient-info-group" style="${fieldHighlight('mrn')}">
                <div class="patient-info-label">PID (Medical Record #)</div>
                <div class="patient-info-value">
                    <input type="text" id="mrn_input" value="${escapeHtml(mrnValue)}" style="${mrnStyle}color:#c0392b;font-weight:700;" ${mrnReadOnlyAttrs} />
                    <div class="mrn-action-row">
                        ${saveButtonHtml}
                        <button class="action-btn action-btn-doc-id" id="openIdPdfBtn">Open ID PDF</button>
                        <button class="action-btn action-btn-doc-insurance" id="openInsurancePdfBtn">Open Prescription PDF</button>
                    </div>
                </div>
            </div>
        `;
        modalBody.appendChild(detailsEl);

        // Helper to convert UNC paths to file:// URLs
        function pathToFileUrl(uncPath) {
            if (!uncPath) return '';
            // Normalize backslashes
            let p = uncPath.replace(/\\\\/g, '\\\\').replace(/\\/g, '/');
            if (!p.startsWith('/')) p = '/' + p;
            return 'file://' + p;
        }

        // Setup buttons
        const saveMrnBtn = document.getElementById('saveMrnBtn');
        if (saveMrnBtn && canSetMrn) {
            saveMrnBtn.addEventListener('click', function() {
                const mrn = document.getElementById('mrn_input').value.trim();
                if (!mrn) { alert('MRN cannot be empty'); return; }
                saveMRN(patient.id, mrn).then(res => {
                    if (res && res.success) {
                        patient.mrn = mrn; // update local
                        alert('MRN saved');
                    } else if (res && res.conflict && res.current_patient && res.existing_patient) {
                        showMrnConflictModal(
                            res.current_patient,
                            res.existing_patient,
                            function overrideExistingPatient() {
                                return saveMRN(patient.id, mrn, {
                                    override: true,
                                    conflictPatientId: Number(res.existing_patient.patient_id || 0)
                                });
                            }
                        ).then(overrideRes => {
                            if (overrideRes && overrideRes.success) {
                                patient.mrn = mrn;
                                alert('Existing patient overridden with new details and PID saved.');
                                if (window.smartReload) window.smartReload(0); else window.location.reload();
                            } else if (overrideRes && overrideRes.error) {
                                alert(overrideRes.error);
                            }
                        }).catch(err => {
                            console.error(err);
                            alert('Error while overriding existing patient details.');
                        });
                    } else {
                        // Prefer explicit server error message when available
                        let msg = 'Failed to save MRN';
                        if (res && res.error) msg = res.error;
                        else if (res && res.messages && Array.isArray(res.messages)) msg = res.messages.join('\n');
                        alert(msg);
                    }
                }).catch(err => { console.error(err); alert('Error saving MRN'); });
            });
        }

        document.getElementById('openIdPdfBtn').addEventListener('click', function() {
            const filename = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : (patient.queue_number || patient.id);
            const url = 'download_pdf.php?type=id&file=' + encodeURIComponent(filename + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
            window.open(url, '_blank', 'noopener');
        });

        document.getElementById('openInsurancePdfBtn').addEventListener('click', function() {
            const filename = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : (patient.queue_number || patient.id);
            const url = 'download_pdf.php?type=insurance&file=' + encodeURIComponent(filename + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
            window.open(url, '_blank', 'noopener');
        });


        
        document.getElementById('patientModal').classList.add('active');
    }

    // Close patient modal
    function closePatientModal() {
        const modal = document.getElementById('patientModal');
        if (modal) {
            modal.classList.remove('active');
        }
    }

    function closeMrnConflictModal() {
        const modal = document.getElementById('mrnConflictModal');
        if (modal) {
            modal.classList.remove('active');
        }
    }

    function formatContact(countryCode, mobile) {
        const cc = (countryCode || '').trim();
        const m = (mobile || '').trim();
        if (!cc && !m) return 'N/A';
        return (cc + ' ' + m).trim();
        }

        function buildMrnCompareCardHtml(title, patientData, cardClass) {
            const name = escapeHtml(patientData.patient_name || 'N/A');
            const mrn = escapeHtml(patientData.mrn || 'N/A');
            const currentMobile = escapeHtml(formatContact(patientData.country_code, patientData.mobile));
            const careMobile = escapeHtml(formatContact(patientData.care_country_code, patientData.care_mobile));
            const email = escapeHtml(patientData.email || 'N/A');
            const address = escapeHtml(patientData.address || 'N/A');
            const patientDbId = Number(patientData.patient_id || 0);
            const pdfFilename = escapeHtml(String(patientData.pdf_filename || patientData.mrn || patientDbId || ''));

            return `
                <div class="mrn-compare-card ${cardClass}">
                    <h4>${escapeHtml(title)}</h4>
                    <div class="mrn-compare-item"><span>Name</span><strong>${name}</strong></div>
                    <div class="mrn-compare-item"><span>MRN</span><strong>${mrn}</strong></div>
                    <div class="mrn-compare-item"><span>Current Mobile</span><strong>${currentMobile}</strong></div>
                    <div class="mrn-compare-item"><span>Result/Care Mobile</span><strong>${careMobile}</strong></div>
                    <div class="mrn-compare-item"><span>Email</span><strong>${email}</strong></div>
                    <div class="mrn-compare-item"><span>Address</span><strong>${address}</strong></div>
                    <div class="mrn-compare-actions">
                        <button type="button" class="action-btn action-btn-doc-id" data-preview-id="${patientDbId}" data-preview-filename="${pdfFilename}">Preview ID</button>
                    </div>
                </div>
            `;
        }

        function openIdPreviewForPatient(patientData) {
            const patientDbId = Number(patientData.patient_id || 0);
            // Use explicit pdf_filename when provided (avoids both cards resolving to the same MRN-named file)
            const explicitFilename = String(patientData.pdf_filename || '').trim();
            const mrnValue = String(patientData.mrn || '').trim();
            const fileBase = explicitFilename !== '' ? explicitFilename
                           : mrnValue !== '' ? mrnValue
                           : String(patientDbId || '');
            const url = 'download_pdf.php?type=id&file=' + encodeURIComponent(fileBase + '.pdf') + '&patient=' + encodeURIComponent(patientDbId);
            window.open(url, '_blank', 'noopener');
        }

        function showMrnConflictModal(currentPatient, existingPatient, onOverride) {
            return new Promise((resolve, reject) => {
                const modal = document.getElementById('mrnConflictModal');
                const body = document.getElementById('mrnConflictModalBody');
                const yesBtn = document.getElementById('mrnConflictYesBtn');
                const noBtn = document.getElementById('mrnConflictNoBtn');

                if (!modal || !body || !yesBtn || !noBtn) {
                    reject(new Error('Conflict modal is not available in DOM.'));
                    return;
                }

                body.innerHTML = `
                    <div class="mrn-compare-note">
                        This new patient has the same MRN as an existing patient. Are they the same person?
                    </div>
                    <div class="mrn-compare-grid">
                        ${buildMrnCompareCardHtml('New Patient (Current Ticket)', currentPatient, 'new-patient')}
                        ${buildMrnCompareCardHtml('Existing Saved Patient', existingPatient, 'existing-patient')}
                    </div>
                `;

                const previewButtons = body.querySelectorAll('button[data-preview-id]');
                previewButtons.forEach(btn => {
                    btn.addEventListener('click', function() {
                        const id = Number(this.getAttribute('data-preview-id') || '0');
                        const filename = String(this.getAttribute('data-preview-filename') || '').trim();
                        openIdPreviewForPatient({ patient_id: id, pdf_filename: filename });
                    });
                });

                const cleanup = () => {
                    yesBtn.onclick = null;
                    noBtn.onclick = null;
                };

                // YES = confirm merge (override existing patient with current ticket data)
                yesBtn.onclick = function() {
                    if (typeof onOverride !== 'function') {
                        cleanup();
                        closeMrnConflictModal();
                        reject(new Error('Override callback is missing.'));
                        return;
                    }
                    yesBtn.disabled = true;
                    noBtn.disabled = true;
                    Promise.resolve(onOverride())
                        .then(result => {
                            cleanup();
                            closeMrnConflictModal();
                            resolve(result);
                        })
                        .catch(err => {
                            cleanup();
                            closeMrnConflictModal();
                            reject(err);
                        })
                        .finally(() => {
                            yesBtn.disabled = false;
                            noBtn.disabled = false;
                        });
                };

                // NO = cancel merge, return to MRN input for a new PID
                noBtn.onclick = function() {
                    cleanup();
                    closeMrnConflictModal();
                    resolve({ success: false, skipped: true, message: 'Merge cancelled.' });
                    setTimeout(() => {
                        const mrnInput = document.getElementById('mrn_input');
                        if (mrnInput) { mrnInput.focus(); mrnInput.select(); }
                    }, 100);
                };

                modal.classList.add('active');
            });
        }
        
    // Utility function to escape HTML
    function escapeHtml(text) {
        if (text === null || text === undefined) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // Initialize when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        console.log('Billing interface initialized');

        if (window.QueueNotifications) {
            QueueNotifications.renderPermissionBanner({ pageName: BILLING_NOTIFICATION_PAGE });
            QueueNotifications.syncTickets(
                buildBillingNotificationKey(getSelectedBillingTypes()),
                collectCurrentBillingTicketsFromDom()
            );
            QueueNotifications.syncTickets(
                buildBillingWrongInfoNotificationKey(getSelectedBillingTypes()),
                collectCurrentBillingWrongInfoTicketsFromDom()
            );
        }
        
        // Setup modal close handlers
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closePatientModal();
                closeMrnConflictModal();
            }
        });
        
        const patientModal = document.getElementById('patientModal');
        if (patientModal) {
            patientModal.addEventListener('click', function(e) {
                if (e.target === this) {
                    closePatientModal();
                }
            });
        }

        const mrnConflictModal = document.getElementById('mrnConflictModal');
        if (mrnConflictModal) {
            mrnConflictModal.addEventListener('click', function(e) {
                if (e.target === this) {
                    closeMrnConflictModal();
                }
            });
        }
        
        // Pause auto-refresh when ANY menu/modal is opened
        document.addEventListener('toggle', function(e) {
            if (e.target && e.target.tagName === 'DETAILS') {
                if (e.target.open) {
                    // Menu opened - stop refresh
                    if (window.billingRefreshInterval) {
                        clearInterval(window.billingRefreshInterval);
                        window.billingRefreshInterval = null;
                    }
                } else {
                    // Menu closed - resume refresh
                    if (!window.billingRefreshInterval) {
                        window.billingRefreshInterval = setInterval(refreshBillingQueue, 1000);
                    }
                }
            }
        }, true);
        
        // Also pause when patient details modal opens/closes
        const patientModalForRefresh = document.getElementById('patientModal');
        if (patientModalForRefresh) {
            const observer = new MutationObserver(() => {
                if (patientModalForRefresh.classList.contains('active')) {
                    // Modal opened - stop refresh
                    if (window.billingRefreshInterval) {
                        clearInterval(window.billingRefreshInterval);
                        window.billingRefreshInterval = null;
                    }
                } else {
                    // Modal closed - resume refresh
                    if (!window.billingRefreshInterval) {
                        window.billingRefreshInterval = setInterval(refreshBillingQueue, 1000);
                    }
                }
            });
            observer.observe(patientModalForRefresh, { attributes: true, attributeFilter: ['class'] });
        }
        
        // Also pause when MRN conflict modal opens/closes
        const mrnModal = document.getElementById('mrnConflictModal');
        if (mrnModal) {
            const observer = new MutationObserver(() => {
                if (mrnModal.classList.contains('active')) {
                    // Modal opened - stop refresh
                    if (window.billingRefreshInterval) {
                        clearInterval(window.billingRefreshInterval);
                        window.billingRefreshInterval = null;
                    }
                } else {
                    // Modal closed - resume refresh
                    if (!window.billingRefreshInterval) {
                        window.billingRefreshInterval = setInterval(refreshBillingQueue, 1000);
                    }
                }
            });
            observer.observe(mrnModal, { attributes: true, attributeFilter: ['class'] });
        }
        
        // Delay initial refresh to avoid race conditions on page load
        // The initial table is rendered server-side, so we wait before first AJAX update
        setTimeout(() => {
            // Faster polling to reduce notification delay.
            window.billingRefreshInterval = setInterval(refreshBillingQueue, 1000);
            
            // Initial refresh after 500ms to ensure page is stable
            refreshBillingQueue();
        }, 500);

        document.addEventListener('visibilitychange', function() {
            if (!document.hidden) {
                refreshBillingQueue();
            }
        });

        window.addEventListener('focus', function() {
            refreshBillingQueue();
        });
        
    });

    // Event listener for view details buttons
    document.addEventListener('click', function(e) {
        if (!(e.target instanceof Element)) return;
        const btn = e.target.closest('.view-details-btn');
        if (btn) {
            e.preventDefault();
            e.stopPropagation();
            
            const patientData = btn.dataset.patient;
            if (!patientData) {
                console.error('No patient data found in button:', btn);
                alert('Error: Patient data not available');
                return;
            }
            
            try {
                const patient = JSON.parse(patientData);
                showPatientDetails(patient);
            } catch (error) {
                console.error('Error parsing patient data:', error, 'Data was:', patientData);
                alert('Error loading patient details.');
            }
        }
    });

    // Open edit patient modal
    function openEditPatientModal(patientId, patientName, mobile, email, address, countryCode, careMobile = '', careCountryCode = '') {
        document.getElementById('editPatientId').value = patientId;
        document.getElementById('editPatientName').value = patientName;
        document.getElementById('editMobile').value = mobile;
        document.getElementById('editEmail').value = email;
        document.getElementById('editAddress').value = address || '';
        document.getElementById('editCountryCode').value = countryCode || '';
        document.getElementById('editCareCountryCode').value = careCountryCode || '';
        document.getElementById('editCareMobile').value = careMobile || '';
        document.getElementById('editPatientModal').classList.add('active');
    }

    // Close edit patient modal
    function closeEditPatientModal() {
        document.getElementById('editPatientModal').classList.remove('active');
    }

    // Handle edit patient form submission
    function handleEditPatientSubmit(event) {
        event.preventDefault();
        
        const patientId = document.getElementById('editPatientId').value;
        const patientName = document.getElementById('editPatientName').value.trim();
        const mobile = document.getElementById('editMobile').value.trim();
        const email = document.getElementById('editEmail').value.trim();
        const address = document.getElementById('editAddress').value.trim();
        const countryCode = document.getElementById('editCountryCode').value;
        const careCountryCode = document.getElementById('editCareCountryCode').value;
        const careMobile = document.getElementById('editCareMobile').value.trim();
        
        // Validation
        if (!patientName) {
            alert('Patient name is required');
            return;
        }
        if (!mobile) {
            alert('Mobile number is required');
            return;
        }
        
        // Send update via AJAX
        const formData = new FormData();
        formData.append('patient_id', patientId);
        formData.append('patient_name', patientName);
        formData.append('mobile', mobile);
        formData.append('email', email);
        formData.append('address', address);
        formData.append('country_code', countryCode);
        formData.append('care_country_code', careCountryCode);
        formData.append('care_mobile', careMobile);
        formData.append('update_patient', '1');
        
        fetch('billing.php', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                closeEditPatientModal();
                alert('Patient information updated successfully!');
                
                // Show option to retake documents
                const retakeDocuments = confirm('Would you like to retake patient documents? Click OK to proceed to document scanning, or Cancel to stay here.');
                if (retakeDocuments) {
                    // Redirect to scan_docs.php for the current patient
                    window.location.href = 'scan_docs.php?patient_id=' + patientId + '&from=billing';
                } else {
                    // Refresh the queue
                    refreshBillingQueue();
                }
            } else {
                alert('Error: ' + (data.error || 'Failed to update patient'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating patient information');
        });
    }
  
    // Check for updates every 1 second (including hidden tabs) for better notification responsiveness.
    setInterval(() => {
        fetch('check_updates.php', { cache: 'no-store' })
            .then(r => r.text())
            .then(hasChanges => {
                if (hasChanges === '1') {
                    // Refresh whatever page we're on
                    if (window.location.pathname.includes('butler')) {
                        if (typeof refreshDashboard !== 'undefined') refreshDashboard();
                        if (typeof refreshStreaming !== 'undefined') refreshStreaming();
                    } else if (window.location.pathname.includes('billing')) {
                        if (typeof refreshBillingQueue !== 'undefined') refreshBillingQueue();
                    }
                }
            });
    }, 1000);

    </script>
    
    <style>
        /* Your existing CSS styles here */
        .billing-container { padding: 20px; max-width: 1400px; margin: 0 auto; }
        .type-selection-panel { background: white; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); padding: 25px; margin-bottom: 30px; }
        .type-selection-title { font-size: 18px; color: #2c3e50; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
        .type-checkboxes { display: flex; gap: 30px; flex-wrap: wrap; }
        .type-checkbox { display: flex; align-items: center; gap: 10px; cursor: pointer; }
        .type-checkbox input[type="checkbox"] { width: 20px; height: 20px; cursor: pointer; }
        .type-checkbox-label { font-size: 16px; color: #2c3e50; font-weight: 500; cursor: pointer; }
        .type-checkbox-label.appointment { color: #1565c0; }
        .type-checkbox-label.private { color: #7b1fa2; }
        .type-checkbox-label.guarantor { color: #2e7d32; }
        .highlighted { background-color: #fff3cd !important; }
        
        /* Action button styles are centralized in styles.css */
        
        /* Status badges */
        .status-badge { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; }
        .status-arrived { background: #3498db; color: white; }
        .status-in-process { background: #f39c12; color: white; }
        .status-patient-needed { background: #e74c3c; color: white; }
        
        /* Type badges */
        .type-badge { padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; display: inline-block; }
        .type-appointment { background: #1565c0; color: white; }
        .type-private { background: #7b1fa2; color: white; }
        .type-guarantor { background: #2e7d32; color: white; }
        .type-clinics { background: #16a085; color: white; }
        .type-checkbox-label.clinics { color: #16a085; }

        .ticket-meta-badge {
            display: inline-block;
            margin-left: 6px;
            margin-top: 4px;
            padding: 3px 8px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 700;
            border: 1px solid transparent;
            vertical-align: middle;
            cursor: help;
        }

        .ticket-meta-badge.existing {
            background: #fff0f0;
            border-color: #f0b7b2;
            color: #c0392b;
        }

        .ticket-meta-badge.edited {
            background: #ffe9e9;
            border-color: #e6a0a0;
            color: #a93226;
        }

        
        /* Modal Styles */
        .patient-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.7); z-index: 1000; align-items: center; justify-content: center; }
        .patient-modal.active { display: flex; }
        .patient-modal-content { background-color: white; border-radius: 12px; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto; box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
        .patient-modal-header { background: #3498db; color: white; padding: 20px; border-radius: 12px 12px 0 0; display: flex; justify-content: space-between; align-items: center; }
        .patient-modal-title { font-size: 20px; font-weight: 600; }
        .patient-modal-close { background: none; border: none; color: white; font-size: 24px; cursor: pointer; padding: 0; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; }
        .patient-modal-body { padding: 25px; }
        .patient-info-group { margin-bottom: 20px; }
        .patient-info-label { font-size: 12px; color: #7f8c8d; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 5px; }
        .patient-info-value { font-size: 16px; color: #2c3e50; font-weight: 500; }
        
        /* View Details Button */
        .view-details-btn { background: #3498db; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 5px; transition: background 0.3s; }
        .view-details-btn:hover { background: #2980b9; }
        
        /* Success message */
        .success-message { background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #c3e6cb; }
        .success-message .close-message { background: none; border: none; color: #155724; cursor: pointer; }
        
        /* Empty state */
        .empty-state { text-align: center; padding: 40px 20px; color: #7f8c8d; }
        .empty-state i { font-size: 48px; margin-bottom: 15px; color: #bdc3c7; }
        
        /* Header */
        .header { display: flex; align-items: center; gap: 20px; margin-bottom: 30px; }
        .logo { font-size: 48px; }
        
        /* Refresh button */
        .refresh-btn { background: #3498db; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 8px; }
        .refresh-btn:hover { background: #2980b9; }
        
        /* Queue table */
        .queue-table { width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.08); }
        .queue-table th { background: #3498db; color: white; padding: 15px; text-align: left; font-weight: 600; }
        .queue-table td { padding: 12px 15px; border-bottom: 1px solid #ecf0f1; }
        .queue-table tr:hover { background: #f8f9fa; }

        /* MRN Conflict Merge Modal */
        .mrn-conflict-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.75); z-index: 1010; align-items: center; justify-content: center; }
        .mrn-conflict-modal.active { display: flex; }
        .mrn-conflict-modal-content { background: white; border-radius: 12px; width: 95%; max-width: 820px; max-height: 92vh; overflow-y: auto; box-shadow: 0 10px 40px rgba(0,0,0,0.4); }
        .mrn-conflict-header { background: #e67e22; color: white; padding: 18px 24px; border-radius: 12px 12px 0 0; display: flex; justify-content: space-between; align-items: center; }
        .mrn-conflict-header h3 { margin: 0; font-size: 18px; font-weight: 600; }
        .mrn-conflict-body { padding: 24px 24px 8px; }
        .mrn-conflict-footer { display: flex; justify-content: flex-end; gap: 12px; padding: 16px 24px; border-top: 1px solid #ecf0f1; background: #f8f9fa; border-radius: 0 0 12px 12px; }
        .mrn-compare-note { background: #fef9e7; border: 1px solid #f39c12; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px; color: #7d5c00; font-size: 14px; }
        .mrn-compare-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
        @media (max-width: 600px) { .mrn-compare-grid { grid-template-columns: 1fr; } }
        .mrn-compare-card { border: 2px solid #bdc3c7; border-radius: 10px; padding: 16px; background: #f9f9f9; }
        .mrn-compare-card.new-patient { border-color: #3498db; background: #eaf4fb; }
        .mrn-compare-card.existing-patient { border-color: #e67e22; background: #fdf2e9; }
        .mrn-compare-card h4 { margin: 0 0 12px 0; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
        .mrn-compare-card.new-patient h4 { color: #2980b9; }
        .mrn-compare-card.existing-patient h4 { color: #d35400; }
        .mrn-compare-item { display: flex; justify-content: space-between; align-items: flex-start; padding: 5px 0; border-bottom: 1px solid rgba(0,0,0,0.07); font-size: 13px; gap: 8px; }
        .mrn-compare-item:last-of-type { border-bottom: none; }
        .mrn-compare-item span { color: #7f8c8d; flex-shrink: 0; }
        .mrn-compare-item strong { color: #2c3e50; text-align: right; word-break: break-word; }
        .mrn-compare-actions { margin-top: 12px; }

        @media (max-width: 768px) {
            .type-checkboxes { flex-direction: column; gap: 15px; }
        }
    </style>
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <div class="billing-container">
        <!-- Header -->
        <div class="header">
            <div class="logo" aria-hidden="true"><i class="fas fa-file-invoice-dollar"></i></div>
            <div>
                <h1>Billing Interface</h1>
            </div>
        </div>
        
        <!-- Success Message -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="success-message">
                <span><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success_message']); ?></span>
                <button class="close-message" onclick="this.parentElement.style.display='none'">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        
        <!-- Patient Type Selection -->
        <form method="GET" action="" class="type-selection-panel">
            <div class="type-selection-title">
                <i class="fas fa-filter"></i>
                Select Patient Types to Serve:
            </div>
            <div class="type-checkboxes">
                <label class="type-checkbox">
                    <input type="checkbox" name="types[]" value="Appointment" 
                           <?php echo in_array('Appointment', $selected_types) ? 'checked' : ''; ?>
                           onchange="this.form.submit()">
                    <span class="type-checkbox-label appointment">
                        <i class="fas fa-calendar-check"></i>
                        Appointment (1st priority)
                    </span>
                </label>
                
                <label class="type-checkbox">
                    <input type="checkbox" name="types[]" value="Private" 
                           <?php echo in_array('Private', $selected_types) ? 'checked' : ''; ?>
                           onchange="this.form.submit()">
                    <span class="type-checkbox-label private">
                        <i class="fas fa-user"></i>
                        Private (2nd priority)
                    </span>
                </label>
                
                <label class="type-checkbox">
                    <input type="checkbox" name="types[]" value="Guarantor" 
                           <?php echo in_array('Guarantor', $selected_types) ? 'checked' : ''; ?>
                           onchange="this.form.submit()">
                    <span class="type-checkbox-label guarantor">
                        <i class="fas fa-handshake"></i>
                        Guarantor (3rd priority)
                    </span>
                </label>

                <label class="type-checkbox">
                    <input type="checkbox" name="types[]" value="Clinics"
                           <?php echo in_array('Clinics', $selected_types) ? 'checked' : ''; ?>
                           onchange="this.form.submit()">
                    <span class="type-checkbox-label clinics" style="color: #A35A00;">
                        <i class="fas fa-clinic-medical"></i>
                        Clinics
                    </span>
                </label>
            </div>
        </form>
        
        <!-- Patients Table -->
        <div class="queue-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="color: #2c3e50; margin: 0;">
                    <i class="fas fa-users"></i> Patient Queue
                    <small style="font-size: 14px; color: #7f8c8d; margin-left: 10px;">
                        (<?php echo count($patients); ?> patients)
                    </small>
                </h2>
                <!--<button class="refresh-btn" onclick="refreshBillingQueue()" id="refreshBtn">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>-->
            </div>
            
            <div class="queue-table-container">
                <table class="queue-table">
                    <thead>
                        <tr>
                            <th width="100">View Details</th>
                            <th width="100">Queue #</th>
                            <th>Patient Name</th>
                            <th width="120">Type</th>
                            <th width="120">Status</th>
                            <th width="300">Action</th>
                        </tr>
                    </thead>
                    <tbody id="billingTableBody">
                        <?php if (empty($patients)): ?>
                            <tr>
                                <td colspan="6">
                                    <div class="empty-state">
                                        <i class="fas fa-inbox"></i>
                                        <h3>No patients in queue</h3>
                                        <p>Select patient types above or wait for new arrivals</p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($patients as $patient): ?>
<?php
    $changed_fields = [];
    if (!empty($patient['demographics_changed_fields'])) {
        $decoded_fields = json_decode($patient['demographics_changed_fields'], true);
        if (is_array($decoded_fields)) {
            $changed_fields = $decoded_fields;
        }
    }
    $field_label_map = [
        'mrn' => 'PID (MRN)',
        'patient_name' => 'Patient Name',
        'mobile' => 'Current Mobile',
        'country_code' => 'Current Country Code',
        'care_mobile' => 'Result & Care Mobile',
        'care_country_code' => 'Care Country Code',
        'email' => 'Email',
        'address' => 'Address'
    ];
    $changed_labels = [];
    foreach ($changed_fields as $field_name) {
        $changed_labels[] = $field_label_map[$field_name] ?? $field_name;
    }
    $changed_tooltip = !empty($changed_labels) ? implode(', ', $changed_labels) : 'Demographic data edited';
?>
<tr id="patient-row-<?php echo $patient['id']; ?>" 
    class="<?php echo $patient['type'] == 'Appointment' ? 'highlighted' : ''; ?>">
    <td>
        <button type="button" class="view-details-btn" 
            data-patient='<?php echo htmlspecialchars(json_encode([
                'id' => $patient['id'],
                'queue_number' => $patient['queue_number'],
                'patient_name' => $patient['patient_name'],
                'mobile' => $patient['mobile'],
                'care_mobile' => $patient['care_mobile'],
                'care_country_code' => $patient['care_country_code'],
                'email' => $patient['email'],
                'address' => $patient['address'],
                'is_existing_patient' => $patient['is_existing_patient'],
                'demographics_edited' => $patient['demographics_edited'],
                'demographics_changed_fields' => $patient['demographics_changed_fields'],
                'type' => $patient['type'],
                'status' => $patient['status'],
                'arrival_timestamp' => $patient['arrival_timestamp'],
                'approval_timestamp' => $patient['approval_timestamp'],
                'mrn' => $patient['mrn'],
                'registered_by_username' => $patient['registered_by_username'],
                'assigned_butler_username' => $patient['assigned_butler_username'],
                'last_need_request_by_username' => $patient['last_need_request_by_username'],
                'last_need_request_at' => $patient['last_need_request_at']
            ]), ENT_QUOTES, 'UTF-8'); ?>'>
        <i class="fas fa-eye"></i> Details
    </button>
    </td>
    <td style="font-weight: bold; color: #2c3e50;">
        <?php echo htmlspecialchars($patient['queue_number']); ?>
    </td>
    <td><?php echo htmlspecialchars($patient['patient_name']); ?></td>
    <td>
        <span class="type-badge type-<?php echo strtolower($patient['type']); ?>">
            <?php echo htmlspecialchars($patient['type']); ?>
        </span>
    </td>
    <td>
        <?php 
        $status_class = 'status-' . str_replace(' ', '-', strtolower($patient['status']));
        ?>
        <span class="status-badge <?php echo $status_class; ?>">
            <?php echo htmlspecialchars($patient['status']); ?>
        </span>
        <?php if ($patient['status'] === 'Needed by Billing'): ?>
            <div style="font-size:11px;color:#5d6d7e;margin-top:4px;line-height:1.3;">
                Requested by: <strong><?php echo htmlspecialchars(trim((string)($patient['last_need_request_by_username'] ?? '')) !== '' ? (string)$patient['last_need_request_by_username'] : 'Unknown'); ?></strong><br>
                Butler: <strong><?php echo htmlspecialchars(trim((string)($patient['assigned_butler_username'] ?? '')) !== '' ? (string)$patient['assigned_butler_username'] : 'Unassigned'); ?></strong>
            </div>
        <?php endif; ?>
    </td>
    <td>
        <div class="action-buttons">
            <?php if ($patient['status'] == 'Arrived'): ?>
                <div class="action-grid">
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="start_ticket" class="action-btn start action-btn-full">
                            <i class="fas fa-play"></i> Start
                        </button>
                    </form>
                </div>
            
            <?php elseif ($patient['status'] == 'In Process'): ?>
                <div class="action-grid">
                    <button type="button" 
                            class="action-btn butler action-btn-full"
                            onclick="handleNeedButlerClick(<?php echo $patient['id']; ?>)">
                        <i class="fas fa-user"></i> Need Butler
                    </button>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="send_to_lab" class="action-btn lab action-btn-full">
                            <i class="fas fa-flask"></i> Send to LAB
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="send_to_imaging" class="action-btn imaging action-btn-full">
                            <i class="fas fa-x-ray"></i> Send to Imaging
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="send_to_both" class="action-btn both action-btn-full">
                            <i class="fas fa-exchange-alt"></i> Send to BOTH
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="send_to_clinics" class="action-btn clinic action-btn-full">
                            <i class="fas fa-clinic-medical"></i> Send to Clinics
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="cancel_ticket" class="action-btn cancel action-btn-full"
                                onclick="return confirm('Are you sure you want to cancel this ticket?')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </form>
                </div>
            
            <?php elseif ($patient['status'] == 'Needed by Billing'): ?>
                <div class="action-grid">
                    <!-- Confirmation button for when patient returns -->
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="confirm_return" class="action-btn start action-btn-full">
                            <i class="fas fa-check-circle"></i> Patient Released
                        </button>
                    </form>
                </div>

            <?php elseif ($patient['status'] == 'Wrong Info'): ?>
                <div class="action-grid">
                    <button type="button"
                            class="action-btn butler action-btn-full"
                            onclick="handleNeedButlerClick(<?php echo $patient['id']; ?>)">
                        <i class="fas fa-user"></i> Need Butler
                    </button>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="send_to_lab" class="action-btn lab action-btn-full">
                            <i class="fas fa-flask"></i> Send to LAB
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="send_to_imaging" class="action-btn imaging action-btn-full">
                            <i class="fas fa-x-ray"></i> Send to Imaging
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="send_to_both" class="action-btn both action-btn-full">
                            <i class="fas fa-exchange-alt"></i> Send to BOTH
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="send_to_clinics" class="action-btn clinic action-btn-full">
                            <i class="fas fa-clinic-medical"></i> Send to Clinics
                        </button>
                    </form>
                    <form method="POST" class="action-form">
                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                        <button type="submit" name="cancel_ticket" class="action-btn cancel action-btn-full" onclick="return confirm('Are you sure you want to cancel this ticket?')">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </form>
                </div>
            
            <?php endif; ?>
        </div>
    </td>
</tr>
<?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Show undo button if undo data exists and matches current department -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Check if there's undo data in session and it's for billing department
            <?php if (isset($_SESSION['last_action']) && $_SESSION['last_action']['department'] === 'billing'): ?>
                setTimeout(() => {
                    if (typeof showUndoButton !== 'undefined') {
                        const action = <?php echo json_encode($_SESSION['last_action']); ?>;
                        showUndoButton(action.action + ' - Click to undo');
                    }
                }, 500);
            <?php endif; ?>
        });
    </script>
    
    <!-- Patient Details Modal -->
    <div class="patient-modal" id="patientModal">
        <div class="patient-modal-content">
            <div class="patient-modal-header">
                <div class="patient-modal-title">
                    <i class="fas fa-user"></i> Patient Details
                </div>
                <button class="patient-modal-close" onclick="closePatientModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="patient-modal-body" id="patientModalBody">
                <!-- Content will be filled by JavaScript -->
            </div>
        </div>
    </div>

    <!-- MRN Conflict Merge Modal -->
    <div class="mrn-conflict-modal" id="mrnConflictModal">
        <div class="mrn-conflict-modal-content">
            <div class="mrn-conflict-header">
                <h3><i class="fas fa-exclamation-triangle"></i> Duplicate MRN Detected</h3>
                <button class="patient-modal-close" onclick="closeMrnConflictModal()"><i class="fas fa-times"></i></button>
            </div>
            <div class="mrn-conflict-body">
                <div id="mrnConflictModalBody"></div>
            </div>
            <div class="mrn-conflict-footer">
                <button type="button" class="action-btn cancel action-btn-flex" id="mrnConflictNoBtn">
                    <i class="fas fa-arrow-left"></i> No, Enter a New PID
                </button>
                <button type="button" class="action-btn start action-btn-flex" id="mrnConflictYesBtn" style="background:#e67e22;border-color:#d35400;">
                    <i class="fas fa-compress-arrows-alt"></i> Yes, Merge
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Patient Modal -->
    <div class="patient-modal" id="editPatientModal">
        <div class="patient-modal-content" style="max-width: 600px;">
            <div class="patient-modal-header">
                <div class="patient-modal-title">
                    <i class="fas fa-edit"></i> Edit Patient Information
                </div>
                <button class="patient-modal-close" onclick="closeEditPatientModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form id="editPatientForm" onsubmit="handleEditPatientSubmit(event)">
                <div class="patient-modal-body">
                    <input type="hidden" id="editPatientId" name="patient_id">
                    
                    <div class="patient-info-group">
                        <div class="patient-info-label">Patient Name *</div>
                        <input type="text" id="editPatientName" name="patient_name" required style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px;">
                    </div>
                    
                    <div class="patient-info-group">
                        <div class="patient-info-label">Country Code</div>
                        <select id="editCountryCode" name="country_code" style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px;">
                            <option value="">Select Country</option>
                            <?php foreach ($countries_by_name as $name => $country_info): ?>
                                <option value="<?php echo htmlspecialchars($country_info['code']); ?>">
                                    <?php echo htmlspecialchars($country_info['code']) . ' - ' . htmlspecialchars($name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="patient-info-group">
                        <div class="patient-info-label">Current Contact Mobile Number *</div>
                        <input type="tel" id="editMobile" name="mobile" required style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px;" placeholder="e.g., 71 123 456">
                    </div>
                    <div class="patient-info-group">
                        <div class="patient-info-label">Care Country Code</div>
                        <select id="editCareCountryCode" name="care_country_code" style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px;">
                            <option value="">Select Country</option>
                            <?php foreach ($countries_by_name as $name => $country_info): ?>
                                <option value="<?php echo htmlspecialchars($country_info['code']); ?>">
                                    <?php echo htmlspecialchars($country_info['code']) . ' - ' . htmlspecialchars($name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="patient-info-group">
                        <div class="patient-info-label">Care Mobile Number</div>
                        <input type="tel" id="editCareMobile" name="care_mobile" style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px;" placeholder="e.g., 71 123 456">
                    </div>
                    
                    <div class="patient-info-group">
                        <div class="patient-info-label">Email Address</div>
                        <input type="email" id="editEmail" name="email" style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px;">
                    </div>
                    
                    <div class="patient-info-group">
                        <div class="patient-info-label">Address</div>
                        <textarea id="editAddress" name="address" style="width: 100%; padding: 8px; font-size: 14px; border: 1px solid #bdc3c7; border-radius: 4px; min-height: 80px;"></textarea>
                    </div>
                    
                    <div style="border-top: 1px solid #ecf0f1; padding-top: 15px; margin-top: 15px;">
                        <div style="color: #e74c3c; font-size: 12px; margin-bottom: 10px;">
                            <i class="fas fa-info-circle"></i> After updating patient information, you can optionally retake documents below.
                        </div>
                        <div style="display: flex; gap: 10px; justify-content: flex-end;">
                            <button type="button" class="action-btn cancel action-btn-flex" onclick="closeEditPatientModal()">
                                <i class="fas fa-times"></i> Cancel
                            </button>
                            <button type="submit" class="action-btn start action-btn-flex">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
<?php include 'undo_button.php'; ?>
</html>
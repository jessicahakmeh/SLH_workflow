<?php
require_once 'config.php';
session_start();
authRequireRoles(['butler', 'billing', 'admin'], ['log_view' => false]);

$return_to = isset($_GET['return_to']) ? basename(trim($_GET['return_to'])) : 'new_ticket.php';
if ($return_to !== 'new_ticket.php') {
    $return_to = 'new_ticket.php';
}

$from_page = isset($_GET['from']) ? trim($_GET['from']) : '';
$query = trim($_GET['q'] ?? '');
$patients = [];

function searchPatients($pdo, $query) {
    if ($query === '' || mb_strlen($query) < 2) {
        return [];
    }

    try {
        $like = '%' . $query . '%';
        return executeAndFetch($pdo, "SELECT patient_id, patient_name, mrn, country_code, mobile, care_country_code, care_mobile, email, address
                               FROM patients
                               WHERE mrn LIKE ?
                                  OR patient_name LIKE ?
                                  OR mobile LIKE ?
                                  OR care_mobile LIKE ?
                               ORDER BY patient_name ASC
                               LIMIT 100", [$like, $like, $like, $like]);
    } catch (Exception $e) {
        return [];
    }
}

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => true,
        'patients' => searchPatients($pdo, $query),
    ]);
    exit;
}

$patients = searchPatients($pdo, $query);

$backUrl = $return_to;
if ($from_page !== '') {
    $backUrl .= '?from=' . urlencode($from_page);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Existing Patient</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body { background: #f5f7fb; }
        .selection-wrap {
            max-width: 980px;
            margin: 24px auto;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.08);
            padding: 18px;
        }
        .selection-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 14px;
        }
        .selection-title {
            margin: 0;
            font-size: 1.2rem;
            color: #223;
        }
        .search-row {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 10px;
            margin-bottom: 14px;
        }
        .search-row input {
            border: 1px solid #cad5e2;
            border-radius: 6px;
            padding: 10px;
            font-size: 0.95rem;
        }
        .btn {
            border: none;
            border-radius: 6px;
            padding: 10px 14px;
            cursor: pointer;
            font-weight: 600;
        }
        .btn-primary { background: #1f78d1; color: #fff; }
        .btn-muted { background: #edf2f7; color: #314355; text-decoration: none; display: inline-flex; align-items: center; }
        .results {
            border: 1px solid #e3e9ef;
            border-radius: 8px;
            overflow: hidden;
        }
        .result-row {
            display: grid;
            grid-template-columns: 0.9fr 1.3fr 1fr 1.2fr auto;
            gap: 10px;
            align-items: center;
            padding: 10px;
            border-bottom: 1px solid #eef2f6;
        }
        .result-row:last-child { border-bottom: none; }
        .meta { color: #5c6f82; font-size: 0.86rem; }
        .empty { padding: 16px; color: #5f7081; text-align: center; }
        @media (max-width: 900px) {
            .result-row { grid-template-columns: 1fr; }
            .search-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <div class="selection-wrap">
        <div class="selection-header">
            <h1 class="selection-title">Select Existing Patient</h1>
            <a class="btn btn-muted" href="<?php echo htmlspecialchars($backUrl); ?>">Create New Ticket</a>
        </div>

        <div class="search-row">
            <input type="text" id="liveSearchInput" placeholder="Search by patient name or mobile" value="<?php echo htmlspecialchars($query); ?>" autocomplete="off">
            <a class="btn btn-muted" href="patient_selection.php?return_to=<?php echo urlencode($return_to); ?><?php echo $from_page !== '' ? '&from=' . urlencode($from_page) : ''; ?>">Clear</a>
        </div>

        <div class="results" id="resultsContainer">
            <?php if ($query === ''): ?>
                <div class="empty">Type at least 2 characters to search for an existing patient.</div>
            <?php elseif (mb_strlen($query) < 2): ?>
                <div class="empty">Please enter at least 2 characters.</div>
            <?php elseif (empty($patients)): ?>
                <div class="empty">No patients found for this search.</div>
            <?php else: ?>
                <?php foreach ($patients as $row): ?>
                    <div class="result-row">
                        <div>
                            <strong><?php echo htmlspecialchars($row['mrn'] ?: 'N/A'); ?></strong>
                            <div class="meta">MRN</div>
                        </div>
                        <div>
                            <strong><?php echo htmlspecialchars($row['patient_name'] ?? ''); ?></strong>
                            <div class="meta"><?php echo htmlspecialchars($row['address'] ?? 'No address'); ?></div>
                        </div>
                        <div class="meta">
                            <?php echo htmlspecialchars(($row['country_code'] ?? '') . ' ' . ($row['mobile'] ?? '')); ?><br>
                            <?php echo htmlspecialchars(($row['care_country_code'] ?? '') . ' ' . ($row['care_mobile'] ?? '')); ?>
                        </div>
                        <div class="meta"><?php echo htmlspecialchars($row['email'] ?: 'No email'); ?></div>
                        <div>
                            <form method="POST" action="<?php echo htmlspecialchars($return_to); ?>">
                                <input type="hidden" name="selected_patient_id" value="<?php echo (int)$row['patient_id']; ?>">
                                <?php if ($from_page !== ''): ?>
                                    <input type="hidden" name="from" value="<?php echo htmlspecialchars($from_page); ?>">
                                <?php endif; ?>
                                <button type="submit" class="btn btn-primary">Select</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        const liveSearchInput = document.getElementById('liveSearchInput');
        const resultsContainer = document.getElementById('resultsContainer');
        const returnTo = <?php echo json_encode($return_to); ?>;
        const fromPage = <?php echo json_encode($from_page); ?>;
        let searchTimer = null;

        function escapeHtml(value) {
            return String(value || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/\"/g, '&quot;')
                .replace(/'/g, '&#39;');
        }

        function renderResults(patients, queryText) {
            if (!queryText) {
                resultsContainer.innerHTML = '<div class="empty">Type at least 2 characters to search for an existing patient.</div>';
                return;
            }
            if (queryText.length < 2) {
                resultsContainer.innerHTML = '<div class="empty">Please enter at least 2 characters.</div>';
                return;
            }
            if (!patients || patients.length === 0) {
                resultsContainer.innerHTML = '<div class="empty">No patients found for this search.</div>';
                return;
            }

            const rows = patients.map((row) => {
                const id = Number(row.patient_id || 0);
                const name = escapeHtml(row.patient_name);
                const mrn = escapeHtml(row.mrn || 'N/A');
                const address = escapeHtml(row.address || 'No address');
                const mobile = escapeHtml((row.country_code || '') + ' ' + (row.mobile || ''));
                const careMobile = escapeHtml((row.care_country_code || '') + ' ' + (row.care_mobile || ''));
                const email = escapeHtml(row.email || 'No email');
                const fromInput = fromPage ? '<input type="hidden" name="from" value="' + escapeHtml(fromPage) + '">' : '';

                return '<div class="result-row">'
                    + '<div><strong>' + mrn + '</strong><div class="meta">MRN</div></div>'
                    + '<div><strong>' + name + '</strong><div class="meta">' + address + '</div></div>'
                    + '<div class="meta">' + mobile + '<br>' + careMobile + '</div>'
                    + '<div class="meta">' + email + '</div>'
                    + '<div><form method="POST" action="' + escapeHtml(returnTo) + '">'
                    + '<input type="hidden" name="selected_patient_id" value="' + id + '">' + fromInput
                    + '<button type="submit" class="btn btn-primary">Select</button>'
                    + '</form></div>'
                    + '</div>';
            }).join('');

            resultsContainer.innerHTML = rows;
        }

        async function doSearch(queryText) {
            if (!queryText || queryText.length < 2) {
                renderResults([], queryText);
                return;
            }

            const params = new URLSearchParams();
            params.set('ajax', '1');
            params.set('q', queryText);
            params.set('return_to', returnTo);
            if (fromPage) {
                params.set('from', fromPage);
            }

            try {
                const response = await fetch('patient_selection.php?' + params.toString(), {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                const data = await response.json();
                renderResults(data.patients || [], queryText);
            } catch (e) {
                resultsContainer.innerHTML = '<div class="empty">Search failed. Please try again.</div>';
            }
        }

        liveSearchInput.addEventListener('input', function () {
            const value = this.value.trim();
            if (searchTimer) {
                clearTimeout(searchTimer);
            }
            searchTimer = setTimeout(() => doSearch(value), 250);
        });
    </script>
</body>
</html>

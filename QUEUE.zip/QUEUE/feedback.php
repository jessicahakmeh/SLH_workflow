<?php
require_once 'config.php';

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function feedbackExtractTokenFromRequest() {
    // Token extraction is currently disabled.
    /*
    $token = trim((string)($_GET['token'] ?? ''));
    if ($token !== '') {
        return $token;
    }

    $pathInfo = trim((string)($_SERVER['PATH_INFO'] ?? ''), '/');
    if ($pathInfo !== '') {
        $parts = explode('/', $pathInfo);
        return trim((string)end($parts));
    }

    $uriPath = parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    if (!is_string($uriPath) || $uriPath === '') {
        return '';
    }
    $segments = array_values(array_filter(explode('/', trim($uriPath, '/')), 'strlen'));
    if (empty($segments)) {
        return '';
    }

    return trim((string)end($segments));
    */
    return '';
}

$token = '';
$validation = ['valid' => false, 'ticket_id' => 0, 'error' => 'token_disabled'];

$title = 'Feedback Access';
$message = '';
$ticketId = 0;
$tallyFormUrl = (string)FEEDBACK_TALLY_FORM_URL;

// Tokenized access is disabled. Redirect directly to the configured Tally form.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Location: ' . $tallyFormUrl, true, 302);
exit;

/*
$token = feedbackExtractTokenFromRequest();
$validation = validateFeedbackTokenFromDb($token, $pdo);

$title = 'Feedback Access';
$message = '';
$ticketId = 0;
$tallyFormUrl = (string)FEEDBACK_TALLY_FORM_URL;

if (!$validation['valid']) {
    $title = 'Feedback Link Invalid';
    $message = 'This feedback link is invalid or expired.';
} else {
    $ticketId = (int)$validation['ticket_id'];
    $row = executeAndFetchOne($pdo,
        "SELECT ft.ticket_id, ft.feedback_sent, ft.feedback_filled, ft.fill_timestamp, p.patient_name
         FROM feedback_tickets ft
         INNER JOIN tickets t ON t.ticket_id = ft.ticket_id
         INNER JOIN patients p ON p.patient_id = t.patient_id
         WHERE ft.ticket_id = ?
         LIMIT 1",
        [$ticketId]
    );

    if (!$row || (int)($row['feedback_sent'] ?? 0) !== 1) {
        $title = 'Feedback Not Available';
        $message = 'This feedback link is not available.';
    } elseif ((int)($row['feedback_filled'] ?? 0) === 1) {
        $title = 'Feedback Already Submitted';
        $message = 'Thank you. This feedback form was already submitted.';
    } else {
        $patientName = trim((string)($row['patient_name'] ?? ''));
        if ($patientName !== '') {
            $title = 'Feedback for ' . $patientName;
        } else {
            $title = 'Patient Feedback Form';
        }

        // Pass ticket and token to Tally as URL params so webhook can identify the submission.
        $sep = (strpos($tallyFormUrl, '?') === false) ? '?' : '&';
        $tallyFormUrl .= $sep . http_build_query([
            'ticket_id' => $ticketId,
            'ticket_token' => $token,
        ]);

        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Location: ' . $tallyFormUrl, true, 302);
        exit;
    }
}
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo h($title); ?></title>
    <style>
        body { margin: 0; font-family: "Segoe UI", Tahoma, sans-serif; background: #f4f7fb; color: #1f2a35; }
        .wrap { max-width: 980px; margin: 0 auto; padding: 18px; }
        .card { background: #fff; border: 1px solid #d9e3ed; border-radius: 12px; padding: 16px; box-shadow: 0 6px 16px rgba(10, 36, 66, 0.06); }
        h1 { margin: 0 0 10px; font-size: 1.25rem; }
        p { margin: 0; color: #5f6f80; }
        .blocked { border-left: 4px solid #d94f3d; }
    </style>
</head>
<body>
<div class="wrap">
    <div class="card blocked">
        <h1><?php echo h($title); ?></h1>
        <p><?php echo h($message); ?></p>
    </div>
</div>
</body>
</html>

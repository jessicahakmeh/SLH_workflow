<?php
require_once 'config.php';
session_start();
authRequireRoles(['butler', 'admin'], ['log_view' => false]);

/**
 * Butler Interface - Dashboard Controller
 * 
 * Features:
 * - Real-time patient queue display
 * - Search and filter functionality
 * - Department indicators
 * - WhatsApp integration
 */

// ====================
// CONFIGURATION
// ====================
define('STATUSES_TO_SHOW_DEPT', ['Waiting', 'On Hold', 'Called', 'Recalled', 'Skipped', 'Served']);

// ====================
// INPUT VALIDATION
// ====================
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$type_filter = isset($_GET['type']) ? $_GET['type'] : 'all';
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';

// Sanitize inputs
$search = htmlspecialchars($search, ENT_QUOTES, 'UTF-8');
$type_filter = in_array($type_filter, ['all', 'Appointment', 'Private', 'Guarantor', 'Clinics']) ? $type_filter : 'all';
$valid_statuses = ['all', 'Arrived', 'In Process', 'Needed by Billing', 'Waiting', 'On Hold', 'Called', 'Skipped', 'Recalled', 'Wrong Info'];
$status_filter = in_array($status_filter, $valid_statuses) ? $status_filter : 'all';

// ====================
// DATABASE QUERIES
// ====================

/**
 * Build main query for patients
 */
function buildPatientQuery($search, $type_filter, $status_filter) {
    $query = "
        SELECT 
            t.queue_number,
            p.patient_name,
            p.mobile,
            p.country_code,
            t.service_type as type,
            t.current_status as status,
            t.arrival_timestamp,
            t.lab,
            t.img,
            t.dp2,
            t.cl,
            t.Clinic,
            t.imaging_machine,
            t.is_existing_patient,
            t.registered_by_username,
            t.assigned_butler_username,
            t.last_need_request_by_username,
            t.last_need_request_at
        FROM tickets t
        JOIN patients p ON t.patient_id = p.patient_id
        WHERE t.closing_timestamp IS NULL 
        AND t.current_status != 'Canceled'
        AND DATE(t.arrival_timestamp) = CURDATE()
    ";
    
    $params = [];
    
    // Add search conditions
    if (!empty($search)) {
        $query .= " AND (
            p.patient_name LIKE ? OR 
            t.queue_number LIKE ? OR 
            p.mobile LIKE ?
        )";
        $search_term = "%$search%";
        array_push($params, $search_term, $search_term, $search_term);
    }
    
    // Add status filter
    if ($status_filter != 'all') {
        $query .= " AND t.current_status = ?";
        $params[] = $status_filter;
    }

    // Add type filter
    if ($type_filter != 'all') {
        $query .= " AND t.service_type = ?";
        $params[] = $type_filter;
    }
    
    // Order by arrival time
    $query .= " ORDER BY t.arrival_timestamp ASC";
    
    return ['query' => $query, 'params' => $params];
}

/**
 * Get patient statistics
 */
function getPatientStats($search, $type_filter, $status_filter, $pdo) {
    $query = "
        SELECT
            SUM(CASE WHEN t.service_type = 'Appointment' THEN 1 ELSE 0 END) as appointments,
            SUM(CASE WHEN t.service_type = 'Private' THEN 1 ELSE 0 END) as private,
            SUM(CASE WHEN t.service_type = 'Guarantor' THEN 1 ELSE 0 END) as guarantor,
            SUM(CASE WHEN t.service_type = 'Clinics' THEN 1 ELSE 0 END) as clinics,
            COUNT(*) as total
        FROM tickets t
        JOIN patients p ON t.patient_id = p.patient_id
        WHERE t.closing_timestamp IS NULL
        AND t.current_status != 'Canceled'
        AND DATE(t.arrival_timestamp) = CURDATE()
    ";
    
    $params = [];
    
    // Add conditions if filters are applied
    if (!empty($search) || $type_filter != 'all' || $status_filter != 'all') {
        if (!empty($search)) {
            $query .= " AND (
                p.patient_name LIKE ? OR 
                t.queue_number LIKE ? OR 
                p.mobile LIKE ?
            )";
            $search_term = "%$search%";
            array_push($params, $search_term, $search_term, $search_term);
        }
        
        if ($type_filter != 'all') {
            $query .= " AND t.service_type = ?";
            $params[] = $type_filter;
        }
        
        if ($status_filter != 'all') {
            $query .= " AND t.current_status = ?";
            $params[] = $status_filter;
        }
    }
    
    return executeAndFetchOne($pdo, $query, $params);
}

// ====================
// DATA FETCHING
// ====================
$patientQuery = buildPatientQuery($search, $type_filter, $status_filter);
$patients = executeAndFetch($pdo, $patientQuery['query'], $patientQuery['params']);

$stats = getPatientStats($search, $type_filter, $status_filter, $pdo);

// ====================
// HELPER FUNCTIONS
// ====================

/**
 * Generate department indicator HTML
 */
function getDepartmentIndicator($patient) {
    if (!in_array($patient['status'], STATUSES_TO_SHOW_DEPT)) {
        return '';
    }
    
    if ($patient['lab'] == 1 && ($patient['img'] == 0 || $patient['dp2'] == 0)) {
        return '<span class="dept-indicator lab-indicator">(Lab)</span>';
    } 
    
    if ($patient['cl'] == 1) {
        $clinic_name = !empty($patient['Clinic']) ? htmlspecialchars($patient['Clinic']) : 'Unassigned';
        return '<span class="dept-indicator clinic-indicator">(' . $clinic_name . ')</span>';
    }
    
    if ($patient['img'] == 1 && ($patient['lab'] == 0 || $patient['dp2'] == 1)) {
        $machine_name = !empty($patient['imaging_machine'])
            ? htmlspecialchars($patient['imaging_machine'])
            : '(UNASSIGNED)';
        return '<span class="dept-indicator imaging-indicator">(' . $machine_name . ')</span>';
    }
    
    return '';
}

/**
 * Generate mobile/WhatsApp link HTML
 */
function getMobileHtml($mobile, $country_code = '+961') {
    if (empty($mobile)) {
        return '<span class="mobile-na">N/A</span>';
    }
    
    // Format the phone number with country code
    $clean_mobile = preg_replace('/[^0-9]/', '', $mobile);
    $country_code_digits = preg_replace('/[^0-9]/', '', $country_code);
    
    // Remove country code if it already exists
    if (strpos($clean_mobile, $country_code_digits) === 0) {
        $clean_mobile = substr($clean_mobile, strlen($country_code_digits));
    }
    
    // Combine for wa.me link
    $wa_phone = $country_code_digits . $clean_mobile;
    
    return sprintf(
        '<a href="https://wa.me/%s" target="_blank" class="whatsapp-link" title="Chat on WhatsApp">
            <i class="fab fa-whatsapp"></i>%s
        </a>',
        $wa_phone,
        htmlspecialchars($mobile)
    );
}

/**
 * Get CSS class for status badge
 */
function getStatusClass($status) {
    return 'status-' . str_replace(' ', '-', strtolower($status));
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Butler Interface - Patient Queue Dashboard</title>
    <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="browser-notifications.js"></script>
    <script src="refresh-manager.js"></script>
    <style>
        /* Inline styles for critical UI elements */
        .dashboard-container {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f5f7fa;
        }
        
        .dashboard-main-content {
            flex: 1;
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
            width: 100%;
        }
        
        .search-filter-container {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }
        
        .search-box {
            flex: 1;
            min-width: 300px;
            position: relative;
        }
        
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7f8c8d;
        }
        
        .search-input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .search-input:focus {
            outline: none;
            border-color: #3498db;
        }
        
        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .filter-select {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            background-color: white;
            font-size: 14px;
            min-width: 150px;
        }
        
        .clear-filters-btn {
            padding: 12px 20px;
            background-color: #95a5a6;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.3s ease;
        }
        
        .clear-filters-btn:hover {
            background-color: #7f8c8d;
        }
        
        .patient-count {
            background-color: white;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            font-size: 14px;
            color: #2c3e50;
        }
        
        .queue-table-container {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .queue-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .queue-table th {
            background-color: #34495e;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        .queue-table td {
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .queue-table tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .dept-indicator {
            font-weight: bold;
            margin-left: 5px;
        }
        
        .lab-indicator { color: #e74c3c; }
        .imaging-indicator { color: #9b59b6; }

        .clinic-indicator { color: #16a085; }
        
        .whatsapp-link {
            color: #25D366;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .whatsapp-link:hover {
            text-decoration: underline;
        }
        
        .mobile-na {
            color: #bdc3c7;
            font-style: italic;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #7f8c8d;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #bdc3c7;
        }
        
        .empty-state h3 {
            margin-bottom: 10px;
            color: #2c3e50;
        }
        
        .loading-row {
            text-align: center;
            padding: 40px;
        }
        
        .spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #3498db;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-right: 10px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .header-actions {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        
        .btn-submit {
            background-color: #27ae60;
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        
        .btn-submit:hover {
            background-color: #229954;
        }
        
        @media (max-width: 768px) {
            .search-filter-container {
                flex-direction: column;
            }
            
            .search-box {
                min-width: 100%;
            }
            
            .filter-group {
                flex-wrap: wrap;
            }
            
            .filter-select {
                flex: 1;
                min-width: 120px;
            }
        }

        .edit-btn {
            margin-left: 8px;
            color: #3498db;
            text-decoration: none;
            opacity: 0.7;
            transition: opacity 0.3s ease;
            padding: 4px 6px;
            border-radius: 4px;
            background-color: #f8f9fa;
        }

        .edit-btn:hover {
            opacity: 1;
            background-color: #e3f2fd;
            color: #2980b9;
        }

        .back-to-top {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 50px;
            height: 50px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 50%;
            display: none;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            transition: background-color 0.3s ease;
            z-index: 1000;
            font-size: 18px;
        }

        .back-to-top:hover {
            background-color: #2980b9;
        }

    </style>
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <div class="dashboard-container">
        <?php include 'all_streams.php'; ?>
        
        <div class="dashboard-main-content">
            <!-- Page Header -->
            <div class="dashboard-header">
                <h1>
                    <i class="fas fa-list-ol"></i> Patient Queue
                </h1>
                <div class="header-actions">
                    <a href="new_ticket.php" class="btn-submit">
                        <i class="fas fa-plus-circle"></i> New Ticket
                    </a>
                </div>
            </div>
            
            <!-- Search and Filters -->
            <div class="search-filter-container">
                <div class="search-box">
                    <i class="fas fa-search search-icon"></i>
                    <input type="text" 
                           class="search-input" 
                           id="searchInput" 
                           placeholder="Search by name, queue #, or phone..." 
                           value="<?php echo $search; ?>"
                           onkeyup="handleSearch(event)">
                </div>
                
                <div class="filter-group">
                    <select class="filter-select" id="typeFilter" onchange="applyFilters()">
                        <option value="all" <?php echo $type_filter == 'all' ? 'selected' : ''; ?>>All Types</option>
                        <option value="Appointment" <?php echo $type_filter == 'Appointment' ? 'selected' : ''; ?>>Appointment</option>
                        <option value="Private" <?php echo $type_filter == 'Private' ? 'selected' : ''; ?>>Private</option>
                        <option value="Guarantor" <?php echo $type_filter == 'Guarantor' ? 'selected' : ''; ?>>Guarantor</option>
                        <option value="Clinics" <?php echo $type_filter == 'Clinics' ? 'selected' : ''; ?>>Clinics</option>
                    </select>
                    
                    <select class="filter-select" id="statusFilter" onchange="applyFilters()">
                        <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All Statuses</option>
                        <option value="Arrived" <?php echo $status_filter == 'Arrived' ? 'selected' : ''; ?>>Arrived</option>
                        <option value="In Process" <?php echo $status_filter == 'In Process' ? 'selected' : ''; ?>>In Process</option>
                        <option value="Needed by Billing" <?php echo $status_filter == 'Needed by Billing' ? 'selected' : ''; ?>>Needed by Billing</option>
                        <option value="Waiting" <?php echo $status_filter == 'Waiting' ? 'selected' : ''; ?>>Waiting</option>
                        <option value="On Hold" <?php echo $status_filter == 'On Hold' ? 'selected' : ''; ?>>On Hold</option>
                        <option value="Called" <?php echo $status_filter == 'Called' ? 'selected' : ''; ?>>Called</option>
                        <option value="Skipped" <?php echo $status_filter == 'Skipped' ? 'selected' : ''; ?>>Skipped</option>
                        <option value="Recalled" <?php echo $status_filter == 'Recalled' ? 'selected' : ''; ?>>Recalled</option>
                        <option value="Wrong Info" <?php echo $status_filter == 'Wrong Info' ? 'selected' : ''; ?>>Wrong Info</option>
                    </select>
                    
                    <button class="clear-filters-btn" onclick="clearFilters()">
                        <i class="fas fa-times"></i> Clear Filters
                    </button>
                </div>
            </div>
            
            <!-- Patient Count -->
            <div class="patient-count">
                Showing <strong><?php echo count($patients); ?></strong> tickets
                <?php if (!empty($search) || $type_filter != 'all' || $status_filter != 'all'): ?>
                    (filtered from <?php echo $stats['total'] ?? 0; ?> total)
                <?php endif; ?>
            </div>
            
            <!-- Queue Table -->
            <div class="queue-table-container">
                <table class="queue-table">
                    <thead>
                        <tr>
                            <th>Queue #</th>
                            <th>Patient Name</th>
                            <th>Mobile</th>
                            <th>Status</th>
                            <th>Arrival Time</th>
                        </tr>
                    </thead>
                    <tbody id="queueTableBody">
                        <?php if (empty($patients)): ?>
                            <tr>
                                <td colspan="5">
                                    <div class="empty-state">
                                        <i class="fas fa-inbox"></i>
                                        <h3>No patients found</h3>
                                        <?php if (!empty($search) || $type_filter != 'all' || $status_filter != 'all'): ?>
                                            <p>Try changing your search or filters</p>
                                        <?php else: ?>
                                            <p>No patients in queue today</p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php
                                // Group patients by queue_number so tickets with same queue number show as one row
                                $grouped = [];
                                foreach ($patients as $p) {
                                    $qn = $p['queue_number'];
                                    if (!isset($grouped[$qn])) $grouped[$qn] = [];
                                    $grouped[$qn][] = $p;
                                }
                            ?>
                            <?php foreach ($grouped as $queue_number => $group): ?>
                                <?php $first = $group[0]; ?>
                                <?php 
                                // Check if any record in the group has allowed status
                                $showEditButton = false;
                                foreach ($group as $g) {
                                    if (in_array($g['status'], ['Arrived', 'Needed by Billing'])) {
                                        $showEditButton = true;
                                        break;
                                    }
                                }
                                ?>
                                <tr>
                                    <td class="queue-number">
                                        <div class="queue-number-container">
                                            <?php echo htmlspecialchars($queue_number); ?>
                                            <?php if ($showEditButton): ?>
                                                <a href="edit_ticket.php?queue_number=<?php echo urlencode($queue_number); ?>" 
                                                   class="edit-btn" 
                                                   title="Edit patient details (applies to all with this queue#)">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="patient-name">
                                        <?php echo htmlspecialchars($first['patient_name']); ?>
                                    </td>
                                    <td class="mobile">
                                        <?php echo getMobileHtml($first['mobile'], $first['country_code'] ?? '+961'); ?>
                                    </td>
                                    <td class="status-cell">
                                        <?php foreach ($group as $g): ?>
                                            <div style="margin-bottom:6px;">
                                                <span class="status-badge <?php echo getStatusClass($g['status']); ?>">
                                                    <?php echo htmlspecialchars($g['status']); ?>
                                                </span>
                                                <?php echo getDepartmentIndicator($g); ?>
                                                <?php if (($g['status'] ?? '') === 'Needed by Billing'): ?>
                                                    <div style="font-size:11px;color:#5d6d7e;margin-top:3px;">
                                                        Requested by: <strong><?php echo htmlspecialchars(trim((string)($g['last_need_request_by_username'] ?? '')) !== '' ? (string)$g['last_need_request_by_username'] : 'Unknown'); ?></strong><br>
                                                        Registered butler: <strong><?php echo htmlspecialchars(trim((string)($g['registered_by_username'] ?? '')) !== '' ? (string)$g['registered_by_username'] : 'Unknown'); ?></strong>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </td>
                                    <td style="font-size: 13px; color: #7f8c8d;">
                                        <?php 
                                        // Format the timestamp nicely
                                        $arrival_time = new DateTime($first['arrival_timestamp']);
                                        echo $arrival_time->format('H:i'); // Shows only time (e.g., 14:30)
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Back to Top Button -->
    <button id="backToTopBtn" class="back-to-top" title="Back to Top">
        <i class="fas fa-arrow-up"></i>
    </button>

    <script>
    // ====================
// CONSTANTS & VARIABLES
// ====================
let searchTimeout;
const DEBOUNCE_DELAY = 300;
let refreshInterval;
let isModalOpen = false; // Flag to track if confirmation modal is open
const BUTLER_NOTIFICATION_PAGE = 'Butler Queue';
const BUTLER_IDENTIFIERS = <?php echo json_encode(array_values(array_unique(array_filter([
    strtolower(trim((string)(authCurrentUser()['username'] ?? ''))),
    strtolower(trim((string)(authCurrentUser()['full_name'] ?? ''))),
], static function ($value) {
    return $value !== '';
})))); ?>;

function notifyNeededByBillingTickets(patients) {
    if (!window.QueueNotifications) {
        return;
    }

    const items = (patients || []).filter(patient => {
        if ((patient.status || '') !== 'Needed by Billing') {
            return false;
        }

        const assigned = (patient.assigned_butler_username || '').toString().trim().toLowerCase();
        if (assigned === '') {
            return true;
        }
        return BUTLER_IDENTIFIERS.includes(assigned);
    }).map(patient => {
        const requestedBy = (patient.last_need_request_by_username || '').toString().trim() || 'Unknown';
        const assignedButler = (patient.assigned_butler_username || '').toString().trim() || 'Unassigned';
        return {
            id: `${patient.id}:${patient.last_need_request_at || ''}`,
            queueNumber: patient.queue_number,
            patientName: patient.patient_name,
            message: `${patient.queue_number} - ${patient.patient_name} | Requested by ${requestedBy} | Butler ${assignedButler}`
        };
    });

    QueueNotifications.notifyForNewTickets({
        pageKey: `butler-needed:${BUTLER_IDENTIFIERS.join('|') || 'unknown'}`,
        items,
        title: 'Butler request',
        getBody: (item) => item.message || 'A patient needs butler assistance.',
        onClick: () => window.focus()
    });
}

// ====================
// UTILITY FUNCTIONS
// ====================
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showLoading() {
    const tableBody = document.getElementById('queueTableBody');
    if (tableBody) {
        tableBody.innerHTML = `
            <tr class="loading-row">
                <td colspan="4">
                    <div class="spinner"></div> Loading patients...
                </td>
            </tr>
        `;
    }
}

// ====================
// SEARCH & FILTER FUNCTIONS
// ====================
function handleSearch(event) {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        applyFilters();
    }, DEBOUNCE_DELAY);
}

function applyFilters() {
    const search = document.getElementById('searchInput')?.value || '';
    const type = document.getElementById('typeFilter')?.value || 'all';
    const status = document.getElementById('statusFilter')?.value || 'all';
    
    // Update URL
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (type !== 'all') params.append('type', type);
    if (status !== 'all') params.append('status', status);
    
    const newUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
    window.history.replaceState({}, '', newUrl);
    
    // Show loading and refresh
    showLoading();
    refreshDashboard();
}

function clearFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('typeFilter').value = 'all';
    document.getElementById('statusFilter').value = 'all';
    applyFilters();
}

// ====================
// DASHBOARD REFRESH
// ====================
async function refreshDashboard() {
    // Skip refresh if modal is open (similar to pause on focus loss)
    if (isModalOpen) {
        return;
    }
    
    try {
        const search = document.getElementById('searchInput')?.value || '';
        const type = document.getElementById('typeFilter')?.value || 'all';
        const status = document.getElementById('statusFilter')?.value || 'all';
        
        // Use RefreshManager to refresh while preserving focus
        if (window.refreshManager) {
            const url = `queue_refresh.php?department=butler&search=${encodeURIComponent(search)}&type=${type}&status=${status}`;
            await window.refreshManager.refreshSection('#queueTableBody', url);
        } else {
            // Fallback if RefreshManager not loaded
            const response = await fetch(
                `queue_refresh.php?department=butler&search=${encodeURIComponent(search)}&type=${type}&status=${status}`,
                { 
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                    cache: 'no-store'
                }
            );
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            // queue_refresh.php returns JSON, not HTML
            const patients = await response.json();
            
            // Validate response is an array
            if (!Array.isArray(patients)) {
                throw new Error('Invalid response: expected array of patients');
            }
            
            renderPatients(patients);
        }
        
    } catch (error) {
        console.error('Error refreshing dashboard:', error);
        // Don't show error on every refresh, just log it
    }
}

// ====================
// RENDER FUNCTIONS
// ====================
function renderPatients(patients) {
    const tableBody = document.getElementById('queueTableBody');
    if (!tableBody) return;
    
    if (patients.length === 0) {
        const search = document.getElementById('searchInput')?.value || '';
        const type = document.getElementById('typeFilter')?.value || 'all';
        const status = document.getElementById('statusFilter')?.value || 'all';
        
        tableBody.innerHTML = `
            <tr>
                <td colspan="5">
                    <div class="empty-state">
                        <i class="fas fa-inbox"></i>
                        <h3>No patients found</h3>
                        ${search || type !== 'all' || status !== 'all' ? 
                            '<p>Try changing your search or filters</p>' : 
                            '<p>No patients in queue today</p>'}
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    // Group patients by queue_number so tickets with same queue number are merged
    const grouped = {};
    patients.forEach(patient => {
        const qn = patient.queue_number || 'UNKNOWN';
        if (!grouped[qn]) grouped[qn] = [];
        grouped[qn].push(patient);
    });

    let html = '';
    // Sort queue numbers: first by letter prefix, then by number within each prefix
    const sortedQueueNumbers = Object.keys(grouped).sort((a, b) => {
        // Extract prefix and number from queue numbers like "A1", "A2", "P1", etc.
        const aMatch = a.match(/^([A-Z])(\d+)$/) || [a, '', a];
        const bMatch = b.match(/^([A-Z])(\d+)$/) || [b, '', b];
        
        const aPrefix = aMatch[1];
        const aNum = parseInt(aMatch[2]) || 0;
        const bPrefix = bMatch[1];
        const bNum = parseInt(bMatch[2]) || 0;
        
        // First sort by prefix (A, C, G, P)
        if (aPrefix !== bPrefix) {
            const prefixOrder = { 'A': 1, 'P': 2, 'G': 3, 'C': 4 };
            return (prefixOrder[aPrefix] || 999) - (prefixOrder[bPrefix] || 999);
        }
        
        // Then sort by number within the same prefix
        return aNum - bNum;
    });
    
    sortedQueueNumbers.forEach(qn => {
        const group = grouped[qn];
        const first = group[0];
        const mobileHtml = getMobileLinkHtml(first.mobile, first.country_code || '+961');
        
        // Check if any record in group has allowed status
        const showEditButton = group.some(g => g.status === 'Arrived' || g.status === 'Needed by Billing');

        html += `
            <tr>
                <td class="queue-number">
                    <div class="queue-number-container">
                        ${escapeHtml(qn)}
                        ${showEditButton ? `
                            <a href="edit_ticket.php?queue_number=${encodeURIComponent(qn)}" 
                               class="edit-btn" 
                               title="Edit patient details (applies to all with this queue#)">
                                <i class="fas fa-pencil-alt"></i>
                            </a>
                        ` : ''}
                    </div>
                </td>
                <td class="patient-name">${escapeHtml(first.patient_name)}</td>
                <td class="mobile">${mobileHtml}</td>
                <td class="status-cell">
        `;

        group.forEach(g => {
            const statusClass = 'status-' + (g.status || '').toLowerCase().replace(/ /g, '-');
            const deptIndicator = getDeptIndicatorHtml(g);
            const requestedBy = (g.last_need_request_by_username || '').toString().trim() || 'Unknown';
            const registeredButler = (g.registered_by_username || '').toString().trim() || 'Unknown';
            const needButlerMeta = g.status === 'Needed by Billing'
                ? `<div style="font-size:11px;color:#5d6d7e;margin-top:3px;">Requested by: <strong>${escapeHtml(requestedBy)}</strong><br>Registered butler: <strong>${escapeHtml(registeredButler)}</strong></div>`
                : '';
            html += `
                    <div style="margin-bottom:6px;">
                        <span class="status-badge ${statusClass}">${escapeHtml(g.status)}</span>
                        ${deptIndicator}
                        ${needButlerMeta}
                    </div>
            `;
        });

        html += `
                </td>
                <td style="font-size: 13px; color: #7f8c8d;">
                    ${formatArrivalTime(first.arrival_timestamp)}
                </td>
            </tr>
        `;
    });

    tableBody.innerHTML = html;
}

function formatArrivalTime(timestamp) {
    if (!timestamp) return 'N/A';
    
    const date = new Date(timestamp);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
}

function getDeptIndicatorHtml(patient) {
    const waitingStatuses = ['Waiting', 'On Hold', 'Called', 'Recalled', 'Skipped', 'Served'];
    
    if (!waitingStatuses.includes(patient.status)) {
        return '';
    }
    
    if (patient.cl == 1) {
        const clinicName = patient.Clinic ? patient.Clinic : 'UNASSIGNED';
        return '<span class="dept-indicator clinic-indicator">(' + escapeHtml(clinicName) + ')</span>';
    }

    if (patient.lab == 1 && (patient.img == 0 || patient.dp2 == 0)) {
        return '<span class="dept-indicator lab-indicator">(Lab)</span>';
    }
    
    if (patient.img == 1 && (patient.lab == 0 || patient.dp2 == 1)) {
        const machineName = patient.imaging_machine ? patient.imaging_machine : 'UNASSIGNED';
        return '<span class="dept-indicator imaging-indicator">(' + escapeHtml(machineName) + ')</span>';
    }
    
    return '';
}

function getMobileLinkHtml(mobile, countryCode = '+961') {
    if (!mobile) {
        return '<span class="mobile-na">N/A</span>';
    }
    
    const cleanMobile = mobile.replace(/[^0-9]/g, '');
    const countryCodeDigits = (countryCode || '+961').replace(/[^0-9]/g, '');
    
    // Remove country code if it already exists
    let finalPhone = cleanMobile;
    if (cleanMobile.startsWith(countryCodeDigits)) {
        finalPhone = cleanMobile.substring(countryCodeDigits.length);
    }
    
    // Combine for wa.me link
    const waPhone = countryCodeDigits + finalPhone;
    
    return `
        <a href="https://wa.me/${waPhone}" 
           target="_blank" 
           class="whatsapp-link" 
           title="Chat on WhatsApp">
            <i class="fab fa-whatsapp"></i>
            ${escapeHtml(mobile)}
        </a>
    `;
}

function updatePatientCount(count) {
    const patientCountElement = document.querySelector('.patient-count');
    if (patientCountElement) {
        const search = document.getElementById('searchInput')?.value || '';
        const type = document.getElementById('typeFilter')?.value || 'all';
        const status = document.getElementById('statusFilter')?.value || 'all';
        
        let text = `Showing <strong>${count}</strong> tickets`;
        if (search || type !== 'all' || status !== 'all') {
            text += ' (filtered)';
        }
        
        patientCountElement.innerHTML = text;
    }
}

// ====================
// AUTO-REFRESH CONTROL
// ====================
function startAutoRefresh() {
    // Use RefreshManager if available
    if (window.refreshManager) {
        window.refreshManager.startAutoRefresh(1000); // Refresh every 1 second
    } else {
        // Fallback to manual interval
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
        
        refreshInterval = setInterval(() => {
            // Only refresh if page is visible
            if (!document.hidden) {
                refreshDashboard();
            }
        }, 1000);
    }
}

function stopAutoRefresh() {
    // Use RefreshManager if available
    if (window.refreshManager) {
        window.refreshManager.stopAutoRefresh();
    }
    
    // Also clear fallback interval
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

// ====================
// EVENT LISTENERS
// ====================
function setupEventListeners() {
    // Pause auto-refresh when ANY menu is opened, resume when closed
    const menuElements = document.querySelectorAll('details');
    menuElements.forEach(details => {
        details.addEventListener('toggle', () => {
            if (details.open) {
                // Menu opened - stop refresh
                stopAutoRefresh();
            } else {
                // Menu closed - resume refresh
                startAutoRefresh();
            }
        });
    });
    
    // Auto-refresh when page becomes visible
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            // Start auto-refresh when page becomes visible
            startAutoRefresh();
            // Refresh immediately
            refreshDashboard();
        } else {
            // Stop auto-refresh when page is hidden
            stopAutoRefresh();
        }
    });
    
    // Ctrl+Enter to manually refresh
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && e.ctrlKey) {
            e.preventDefault();
            refreshDashboard();
        }
    });
    
    // Make refreshDashboard available globally for streams
    window.refreshDashboard = refreshDashboard;
}

// ====================
// BACK TO TOP FUNCTIONALITY
// ====================
function setupBackToTop() {
    const backToTopBtn = document.getElementById('backToTopBtn');
    if (!backToTopBtn) return;

    // Show/hide button based on scroll position
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 100) {
            backToTopBtn.style.display = 'flex';
        } else {
            backToTopBtn.style.display = 'none';
        }
    });

    // Scroll to top when clicked
    backToTopBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// ====================
// INITIALIZATION
// ====================
document.addEventListener('DOMContentLoaded', function() {
    setupEventListeners();
    setupBackToTop();
    
    // Delay initial refresh slightly to ensure page is fully stable
    setTimeout(() => {
        // Initial load
        refreshDashboard();
        
        // DO NOT start auto-refresh on butler.php
        // Stream cards handle their own polling every 2 seconds
        // This prevents conflicting refresh cycles that cause flashing
    }, 300);
});
    </script>
</body>
</html>
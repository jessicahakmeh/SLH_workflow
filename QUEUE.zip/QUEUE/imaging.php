﻿<?php
// imaging.php - Consolidated Imaging AMA Dashboard (Single File)
require_once 'config.php';
session_start();
authRequireRoles(['imaging', 'admin'], ['log_view' => false]);

// Get all machines
$machines = ['Xray', 'Fluoroscopy', 'Mammography', 'CT', 'UltraSound', 'MRI'];
$current_machine = $_GET['machine'] ?? '';

// Handle assignment via POST (for form submission)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['assign_machine'])) {
    $isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';
    
    try {
        $patient_id = $_POST['patient_id'];
        // Get machines array and filter out empty values
        $machines_selected = isset($_POST['machines']) ? array_filter($_POST['machines'], function($m) { return !empty($m); }) : [];

        if (empty($machines_selected)) {
            $_SESSION['imaging_message'] = "Please select at least one machine";
            
            if ($isAjax) {
                header('Content-Type: application/json');
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Please select at least one machine']);
                exit();
            }
            
            header('Location: imaging.php?machine=' . urlencode($current_machine));
            exit();
        }

        // Get original ticket + demographic linkage for duplication
        $originalPatient = executeAndFetchOne($pdo, "SELECT t.*, p.patient_id FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);

        if (!$originalPatient) {
            throw new Exception('Patient ticket not found');
        }

        // Reindex array to get the first machine consistently
        $machines_selected = array_values($machines_selected);
        
        // Update the original patient with the first machine
        executeUpdate($pdo, "
            UPDATE tickets SET imaging_machine = ?
            WHERE ticket_id = ?
        ", [$machines_selected[0], $patient_id]);

        // Log the assignment for the original patient
        $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes)
                   VALUES (?, 'Assigned to Machine', 'Waiting', 'Waiting', ?, ?, 'Patient assigned to {$machines_selected[0]}')";
        executeUpdate($pdo, $log_sql, [$patient_id, $machines_selected[0], authCurrentUserId() ?: null]);

        // Create duplicate tickets for additional machines
        for ($i = 1; $i < count($machines_selected); $i++) {
            $machine = $machines_selected[$i];

            // Insert duplicate ticket record for same patient
            executeUpdate($pdo, "
                INSERT INTO tickets (
                    patient_id, queue_number, service_type,
                    current_status, arrival_timestamp, approval_timestamp,
                    lab_call_time, imaging_call_time, imaging_machine,
                    lab, img, dp2
                ) VALUES (
                    ?, ?, ?,
                    'Waiting', ?, NOW(),
                    NULL, NULL, ?,
                    ?, ?, ?
                )
            ", [
                $originalPatient['patient_id'],
                $originalPatient['queue_number'],
                $originalPatient['service_type'],
                $originalPatient['arrival_timestamp'],
                $machine,
                $originalPatient['lab'],
                $originalPatient['img'],
                $originalPatient['dp2']
            ]);

            $newPatientId = $pdo->lastInsertId();

            // Log the assignment for the duplicate patient
            $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, performed_by, notes)
                       VALUES (?, 'Assigned to Machine', 'Waiting', 'Waiting', ?, ?, 'Duplicate ticket created and assigned to $machine')";
            executeUpdate($pdo, $log_sql, [$newPatientId, $machine, authCurrentUserId() ?: null]);
        }

        $_SESSION['imaging_message'] = "Patient assigned successfully!";
        
        if ($isAjax) {
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'Patient assigned to: ' . implode(', ', $machines_selected)]);
            exit();
        }
        
        header('Location: imaging.php?machine=' . urlencode($current_machine));
        exit();
    } catch (Exception $e) {
        $error_message = $e->getMessage();
        error_log("Imaging assignment error: " . $error_message);
        
        $_SESSION['imaging_message'] = "Error assigning patient: " . $error_message;
        
        if ($isAjax) {
            header('Content-Type: application/json');
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Error assigning patient: ' . $error_message]);
            exit();
        }
        
        header('Location: imaging.php?machine=' . urlencode($current_machine));
        exit();
    }
}

// Handle patient calling
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['call_patient'])) {
    $patient_id = $_POST['patient_id'];
    $machine = $_POST['machine'];
    
    // Get current status and department flags BEFORE update
    $current = executeAndFetchOne($pdo, "
        SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?
    ", [$patient_id]);
    
    executeUpdate($pdo, "
        UPDATE tickets SET current_status = 'Called', 
            imaging_call_time = NOW()
        WHERE ticket_id = ?
    ", [$patient_id]);
    
    // Log the action
    $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, machine_type, notes) 
               VALUES (?, 'Called in Imaging', 'Waiting', 'Called', ?, 'Patient called to $machine')";
    executeUpdate($pdo, $log_sql, [$patient_id, $machine]);
    
    // Build undo state with pre-fetched values
    $_SESSION['last_action'] = [
        'patient_id' => $patient_id,
        'previous_status' => $current['current_status'],
        'current_status' => 'Called',
        'action' => 'Patient called',
        'department' => 'imaging',
        'img' => $current['img'] ?? 0,
        'lab' => $current['lab'] ?? 0,
        'dp2' => $current['dp2'] ?? 0,
        'imaging_machine' => $current['imaging_machine'] ?? null,
        'timestamp' => time()
    ];
    
    $_SESSION['imaging_message'] = "Patient called successfully!";
    
    // Check if this is an AJAX request
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Patient called successfully']);
        exit();
    }
    
    header('Location: imaging.php?machine=' . urlencode($machine));
    exit();
}

// Handle patient completion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['complete_patient'])) {
    $patient_id = $_POST['patient_id'];
    $machine = $_POST['machine'];
    $current_time = date('Y-m-d H:i:s');
    
    // Get current status and department flags BEFORE update
    $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);
    
    executeUpdate($pdo, "
        UPDATE tickets SET current_status = 'Completed',
            closing_timestamp = ?
        WHERE ticket_id = ?
    ", [$current_time, $patient_id]);
    
    $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes) 
               VALUES (?, 'Completed', 'Served', 'Completed', 'Imaging completed on $machine')";
    executeUpdate($pdo, $log_sql, [$patient_id]);
    
    // Build undo state with pre-fetched values
    $_SESSION['last_action'] = [
        'patient_id' => $patient_id,
        'previous_status' => $current['current_status'],
        'current_status' => 'Completed',
        'action' => 'Patient completed',
        'department' => 'imaging',
        'img' => $current['img'] ?? 0,
        'lab' => $current['lab'] ?? 0,
        'dp2' => $current['dp2'] ?? 0,
        'imaging_machine' => $current['imaging_machine'] ?? null,
        'timestamp' => time()
    ];
    
    $_SESSION['imaging_message'] = "Patient completed successfully!";
    
    // Check if this is an AJAX request
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => 'Patient completed successfully']);
        exit();
    }
    
    header('Location: imaging.php?machine=' . urlencode($machine));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['release_patient'])) {
    $patient_id = $_POST['patient_id'];

    // Get current status before update
    $current = executeAndFetchOne($pdo, "SELECT current_status, img, lab, dp2, imaging_machine FROM tickets WHERE ticket_id = ?", [$patient_id]);

    // Release patient from "Wrong Info" status back to "Arrived"
    executeUpdate($pdo, "
        UPDATE tickets SET current_status = 'Waiting'
        WHERE ticket_id = ?
    ", [$patient_id]);

    // Log the action
    $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, notes)
            VALUES (?, 'Released from Wrong Info', 'Wrong Info', 'Waiting', 'Patient information corrected and released to waiting queue from Imaging')";
    executeUpdate($pdo, $log_sql, [$patient_id]);
    
    // Build undo state
    $_SESSION['last_action'] = [
        'patient_id' => $patient_id,
        'previous_status' => $current['current_status'],
        'current_status' => 'Arrived',
        'action' => 'Released from Wrong Info',
        'department' => 'imaging',
        'img' => $current['img'] ?? 0,
        'lab' => $current['lab'] ?? 0,
        'dp2' => $current['dp2'] ?? 0,
        'imaging_machine' => $current['imaging_machine'] ?? null,
        'timestamp' => time()
    ];

    $_SESSION['imaging_message'] = "Patient released from wrong information status!";

    // Check if this is an AJAX request
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => $_SESSION['imaging_message']]);
        exit();
    }
    
    header('Location: imaging.php');
    exit();
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Imaging AMA Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="imaging_clinics.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="browser-notifications.js"></script>
    <script src="refresh-manager.js"></script>
</head>
<body>
    <?php authRenderUserMenu(); ?>
    <!-- Success Message -->
    <?php if (isset($_SESSION['imaging_message'])): ?>
        <div class="success-message" id="successMessage">
            <i class="fas fa-check-circle"></i>
            <?php echo $_SESSION['imaging_message']; ?>
            <button class="close-message" onclick="this.parentElement.style.display='none'" 
                    style="background: none; border: none; color: #155724; cursor: pointer;">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <?php unset($_SESSION['imaging_message']); ?>
    <?php endif; ?>
    
    <div class="imaging-container">
        <!-- HEADER -->
        <div class="imaging-header">
            <h1>
                <i class="fas fa-x-ray"></i> Imaging Dashboard
            </h1>
        </div>

        <!-- MAIN WRAPPER (30/70 split) -->
        <div class="imaging-wrapper">
            <!-- LEFT PANEL: Assignments (30%) -->
            <div class="assignments-panel">
                <div class="assignments-panel-header">
                    <i class="fas fa-tasks"></i> Machine Assignments
                </div>
                <div class="assignments-list" id="assignmentsList">
                    <?php
                    // Get patients waiting to be assigned (img=1 and lab=0 OR img=1 and dp2=1)
                    $query = "
                        SELECT 
                            t.ticket_id AS id,
                            p.mrn,
                            t.queue_number,
                            p.patient_name,
                            p.mobile,
                            t.service_type,
                            TIMESTAMPDIFF(MINUTE, t.approval_timestamp, NOW()) as wait_minutes,
                            t.current_status
                        FROM tickets t
                        JOIN patients p ON t.patient_id = p.patient_id
                        WHERE t.closing_timestamp IS NULL 
                        AND t.current_status IN ('Waiting', 'On Hold')
                        AND t.img = 1
                        AND (t.lab = 0 OR t.dp2 = 1)
                        AND (t.imaging_machine IS NULL OR t.imaging_machine = '')
                        AND DATE(t.arrival_timestamp) = CURDATE()
                        ORDER BY 
                            FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
                            COALESCE(t.approval_timestamp, t.arrival_timestamp) ASC
                    ";
                    
                    $assignments = executeAndFetch($pdo, $query, []);
                    
                    if (empty($assignments)): ?>
                        <div class="empty-state">
                            <i class="fas fa-clipboard-check"></i>
                            <h3>No pending assignments</h3>
                            <p>All patients have been assigned to machines</p>
                        </div>
                    <?php else: 
                        foreach ($assignments as $patient): ?>
                            <div class="assignment-item">
                                <div class="assignment-item-header">
                                    <div class="patient-name">
                                        <button class="view-pdf-btn" data-patient='<?php echo htmlspecialchars(json_encode([
                                            'id' => $patient['id'],
                                            'queue_number' => $patient['queue_number'],
                                            'patient_name' => $patient['patient_name'],
                                            'mrn' => $patient['mrn'] ?? ''
                                        ]), ENT_QUOTES, 'UTF-8'); ?>' style="background:none;border:none;padding:0;font-size:inherit;cursor:pointer;color:inherit;text-align:left;">
                                            <?php echo htmlspecialchars($patient['patient_name']); ?>
                                        </button>
                                    </div>
                                    <div class="queue-number">
                                        <?php echo htmlspecialchars($patient['queue_number']); ?>
                                    </div>
                                </div>
                                
                                <div style="font-size: 12px; color: #7f8c8d; margin-bottom: 10px;">
                                    <span style="margin-right: 8px;">
                                        <i class="fas fa-phone"></i> 
                                        <?php echo $patient['mobile'] ? htmlspecialchars($patient['mobile']) : 'N/A'; ?>
                                    </span>
                                    <span style="<?php echo $patient['service_type'] === 'Appointment' ? 'color: #e74c3c; font-weight: bold;' : ''; ?>">
                                        <i class="fas fa-tag"></i> 
                                        <?php echo htmlspecialchars($patient['service_type']); ?>
                                    </span>
                                </div>
                                
                                <form method="POST" class="assignment-form">
                                    <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                    
                                    <!-- Machine selections container -->
                                    <div class="machine-selections">
                                        <div class="machine-input-group">
                                            <select name="machines[]" class="machine-select" required>
                                                <option value="">Select Machine</option>
                                                <?php foreach ($machines as $machine): ?>
                                                    <option value="<?php echo $machine; ?>">
                                                        <?php echo $machine; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <!-- Remove button hidden for first dropdown -->
                                            <button type="button" class="remove-machine-btn" title="Remove this machine" style="display: none;">
                                                <i class="fas fa-minus"></i>
                                            </button>
                                        </div>
                                    </div>
                                    
                                    <!-- Action buttons -->
                                    <input type="hidden" name="department" value="imaging">
                                    <input type="hidden" name="action" value="wrong_info">
                                    <input type="hidden" name="machine" value="<?php echo htmlspecialchars($current_machine); ?>">
                                    <div class="assignment-buttons">
                                        <button type="button"
                                                class="add-machine-btn"
                                                title="Add machine"
                                                style="width: 42px; height: 42px; padding: 0; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center;">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                        <button type="submit"
                                                name="assign_machine"
                                                class="assign-btn"
                                                title="Assign machine"
                                                style="width: 42px; height: 42px; padding: 0; border: none; border-radius: 8px; background: #27ae60; color: white; display: inline-flex; align-items: center; justify-content: center; cursor: pointer;">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button type="submit"
                                                formaction="patient_actions.php"
                                                formmethod="POST"
                                                formnovalidate
                                                class="action-btn"
                                                name="wrong_info_from_assignment"
                                                title="Send back to Billing as Wrong Info"
                                                style="width: 42px; height: 42px; padding: 0; background: #e74c3c; color: white; border: none; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; cursor: pointer;">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        <?php endforeach;
                    endif; ?>
                </div>
            </div>
            
            <!-- RIGHT PANEL: Machine Queues (70%) -->
            <div class="queues-panel">
                <div class="queues-header">
                    <div>
                        <h2>
                            <i class="fas fa-x-ray"></i>
                            Machine Queues
                        </h2>
                        <p style="color: #7f8c8d; font-size: 12px; margin: 3px 0 0 0;">
                            Manage patients in each imaging machine queue
                        </p>
                    </div>
                </div>
                
                <!-- Machine Tabs -->
                <div class="machine-tabs" id="machineTabs">
                    <?php foreach ($machines as $index => $machine): ?>
                        <button class="machine-tab <?php echo $machine === $current_machine ? 'active' : ''; ?>" 
                                onclick="window.location.href='imaging.php?machine=<?php echo urlencode($machine); ?>'">
                            <?php 
                            // Machine icons
                            $icons = [
                                'Xray' => 'fas fa-radiation',
                                'Fluoroscopy' => 'fas fa-wave-square',
                                'Mammography' => 'fas fa-female',
                                'CT' => 'fas fa-brain',
                                'UltraSound' => 'fas fa-wave-circle',
                                'MRI' => 'fas fa-magnet'
                            ];
                            ?>
                            <i class="<?php echo $icons[$machine]; ?>"></i>
                            <?php echo $machine; ?>
                        </button>
                    <?php endforeach; ?>
                </div>
                
                <?php if ($current_machine): ?>
                    <!-- Statistics -->
                    <div class="imaging-stats" id="imagingStats">
                        <?php
                        // Get counts for selected machine
                        $query = "
                            SELECT 
                                COUNT(CASE WHEN t.current_status = 'Waiting' THEN 1 END) as waiting,
                                COUNT(CASE WHEN t.current_status IN ('Called', 'Recalled', 'On the Way') THEN 1 END) as called,
                                COUNT(CASE WHEN t.current_status = 'Served' THEN 1 END) as in_process,
                                COUNT(CASE WHEN t.current_status = 'On Hold' THEN 1 END) as on_hold,
                                COUNT(*) as total
                            FROM tickets t
                            WHERE t.imaging_machine = ?
                            AND t.closing_timestamp IS NULL
                            AND t.img = 1
                            AND DATE(t.arrival_timestamp) = CURDATE()
                        ";
                        
                        $stats = executeAndFetchOne($pdo, $query, [$current_machine]);
                        ?>
                        
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $stats['total']; ?></div>
                            <div class="stat-label">Total</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $stats['waiting']; ?></div>
                            <div class="stat-label">Waiting</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $stats['called']; ?></div>
                            <div class="stat-label">Called</div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-number"><?php echo $stats['in_process']; ?></div>
                            <div class="stat-label">In Process</div>
                        </div>
                    </div>
                    
                    <!-- Queue Content -->
                    <div class="queue-content" id="queueContent">
                        <?php
                        // Get patients assigned to selected machine
                        $query = "
                            SELECT
                                t.ticket_id AS id,
                                t.queue_number,
                                p.mrn,
                                p.patient_name,
                                p.mobile,
                                p.email,
                                p.address,
                                t.service_type as type,
                                t.current_status as status,
                                t.arrival_timestamp,
                                t.approval_timestamp,
                                t.imaging_call_time,
                                t.imaging_machine,
                                t.img,
                                t.dp2
                            FROM tickets t
                            JOIN patients p ON t.patient_id = p.patient_id
                            WHERE t.closing_timestamp IS NULL
                            AND t.imaging_machine = ?
                            AND t.current_status IN ('Waiting', 'Called', 'On the Way', 'Skipped', 'Recalled', 'On Hold', 'Served')
                            AND t.img = 1
                            AND DATE(t.arrival_timestamp) = CURDATE()
                            ORDER BY
                                FIELD(t.service_type, 'Appointment', 'Private', 'Guarantor'),
                                COALESCE(t.approval_timestamp, t.arrival_timestamp) ASC
                        ";
                        
                        $patients = executeAndFetch($pdo, $query, [$current_machine]);
                        ?>
                        
                        <div class="machine-queue active">
                            <div class="queue-table-container">
                                <table class="queue-table">
                                    <thead>
                                        <tr>
                                            <th width="100">Queue #</th>
                                            <th width="200">Patient Name</th>
                                            <th width="120">Type</th>
                                            <th width="120">Status</th>
                                            <th width="200">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="queueTableBody">
                                        <?php if (empty($patients)): ?>
                                            <tr>
                                                <td colspan=5>
                                                    <div class="empty-state">
                                                        <i class="fas fa-inbox"></i>
                                                        <h3>No patients in <?php echo $current_machine; ?> queue</h3>
                                                        <p>Assign patients using the left panel</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($patients as $patient): 
                                                $arrival_time = new DateTime($patient['approval_timestamp']);
                                                $now = new DateTime();
                                                $waiting_minutes = floor((strtotime($now->format('Y-m-d H:i:s')) - strtotime($patient['approval_timestamp'])) / 60);
                                                
                                                $status_class = 'status-' . str_replace(' ', '-', strtolower($patient['status']));
                                                $type_class = 'type-' . strtolower($patient['type']);
                                            ?>
                                                <tr id="imaging-patient-<?php echo $patient['id']; ?>" 
                                                    class="<?php echo $patient['type'] == 'Appointment' ? 'priority-highlight' : ''; ?>">
                                                    <td style="font-weight: bold; color: #2c3e50;">
                                                        <?php echo $patient['queue_number']; ?>
                                                    </td>
                                                    <td>
                                                        <button class="view-pdf-btn" data-patient='<?php echo htmlspecialchars(json_encode([
                                                            'id' => $patient['id'],
                                                            'queue_number' => $patient['queue_number'],
                                                            'patient_name' => $patient['patient_name'],
                                                            'mrn' => $patient['mrn'] ?? ''
                                                        ]), ENT_QUOTES, 'UTF-8'); ?>' style="background:none;border:none;padding:0;font-size:inherit;cursor:pointer;color:inherit;">
                                                            <?php echo htmlspecialchars($patient['patient_name']); ?>
                                                        </button>
                                                    </td>
                                                    <td>
                                                        <span class="type-badge <?php echo $type_class; ?>">
                                                            <?php echo $patient['type']; ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="status-badge <?php echo $status_class; ?>">
                                                            <?php echo $patient['status']; ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="action-buttons">
                                                            <?php if ($patient['status'] == 'Waiting'): ?>
                                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                                        <input type="hidden" name="department" value="imaging">
                                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                                        <input type="hidden" name="machine" value="<?php echo $current_machine; ?>">
                                                                        <input type="hidden" name="action" value="call_patient">
                                                                        <button type="submit" class="action-btn btn-call" style="width: 100%; white-space: nowrap;"><i class="fas fa-bullhorn"></i> Call</button>
                                                                    </form>
                                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                                        <input type="hidden" name="department" value="imaging">
                                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                                        <input type="hidden" name="machine" value="<?php echo $current_machine; ?>">
                                                                        <input type="hidden" name="action" value="wrong_info">
                                                                        <button type="submit" class="action-btn" style="background: #e74c3c; color: white; width: 100%; white-space: nowrap;"><i class="fas fa-exclamation-circle"></i> Wrong Info</button>
                                                                    </form>
                                                                </div>
                                                            <?php elseif (in_array($patient['status'], ['Called', 'Recalled', 'On the Way'], true)): ?>
                                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                                        <input type="hidden" name="department" value="imaging">
                                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                                        <input type="hidden" name="machine" value="<?php echo $current_machine; ?>">
                                                                        <input type="hidden" name="action" value="start_procedure">
                                                                        <button type="submit" class="action-btn btn-complete" style="background: #3498db; color: white; width: 100%; white-space: nowrap;"><i class="fas fa-play"></i> Start</button>
                                                                    </form>
                                                                    <button class="action-btn btn-skip" style="flex: 1; white-space: nowrap;"
                                                                            onclick="skipPatient(<?php echo $patient['id']; ?>, '<?php echo $current_machine; ?>')">
                                                                        <i class="fas fa-forward"></i> Skip
                                                                    </button>
                                                                </div>
                                                            <?php elseif ($patient['status'] == 'In Process'): ?>
                                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                                        <input type="hidden" name="department" value="imaging">
                                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                                        <input type="hidden" name="machine" value="<?php echo $current_machine; ?>">
                                                                        <input type="hidden" name="action" value="complete_patient">
                                                                        <button type="submit" class="action-btn btn-complete" style="width: 100%; white-space: nowrap;"><i class="fas fa-check-circle"></i> Complete</button>
                                                                    </form>
                                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                                        <input type="hidden" name="department" value="imaging">
                                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                                        <input type="hidden" name="machine" value="<?php echo $current_machine; ?>">
                                                                        <input type="hidden" name="action" value="send_back">
                                                                        <button type="submit" class="action-btn" style="background: #e74c3c; color: white; width: 100%; white-space: nowrap;"><i class="fas fa-arrow-left"></i> Back</button>
                                                                    </form>
                                                                </div>
                                                            <?php elseif ($patient['status'] == 'Served'): ?>
                                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                                    <form method="POST" style="flex: 1; margin: 0;">
                                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                                        <input type="hidden" name="machine" value="<?php echo $current_machine; ?>">
                                                                        <input type="hidden" name="complete_patient" value="1">
                                                                        <button type="submit" class="action-btn btn-complete" style="width: 100%; white-space: nowrap;">
                                                                            <i class="fas fa-check-circle"></i> Complete
                                                                        </button>
                                                                    </form>
                                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                                        <input type="hidden" name="department" value="imaging">
                                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                                        <input type="hidden" name="machine" value="<?php echo $current_machine; ?>">
                                                                        <input type="hidden" name="action" value="send_back">
                                                                        <button type="submit" class="action-btn" style="background: #e74c3c; color: white; width: 100%; white-space: nowrap;">
                                                                            <i class="fas fa-arrow-left"></i> Send Back
                                                                        </button>
                                                                    </form>
                                                                </div>
                                                            <?php elseif (in_array($patient['status'], ['Skipped', 'On Hold'])): ?>
                                                                <div style="display: flex; gap: 5px; width: 100%;">
                                                                    <button class="action-btn btn-call" style="flex: 1; white-space: nowrap;"
                                                                            onclick="recallPatient(<?php echo $patient['id']; ?>, '<?php echo $current_machine; ?>')">
                                                                        <i class="fas fa-undo"></i> Recall
                                                                    </button>
                                                                    <form method="POST" action="patient_actions.php" style="flex: 1; margin: 0;">
                                                                        <input type="hidden" name="department" value="imaging">
                                                                        <input type="hidden" name="patient_id" value="<?php echo $patient['id']; ?>">
                                                                        <input type="hidden" name="machine" value="<?php echo $current_machine; ?>">
                                                                        <input type="hidden" name="action" value="wrong_info">
                                                                        <button type="submit" class="action-btn" style="background: #e74c3c; color: white; width: 100%; white-space: nowrap;"><i class="fas fa-exclamation-circle"></i> Wrong Info</button>
                                                                    </form>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Prompt to select machine -->
                    <div class="select-machine-prompt">
                        <i class="fas fa-x-ray"></i>
                        <h3>Select a Machine</h3>
                        <p>Click on a machine tab above to view its queue</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        // Flag to track if user is interacting with assignment form (declared globally for all script blocks)
        let isInteractingWithAssignmentForm = false;
        let imagingQueueRefreshInFlight = false;
        let imagingAssignmentsRefreshInFlight = false;
        const IMAGING_NOTIFICATION_PAGE = 'Imaging';

        function getCurrentImagingMachine() {
            return new URLSearchParams(window.location.search).get('machine') || 'unassigned';
        }

        function collectCurrentImagingQueueTicketsFromDom() {
            const rows = document.querySelectorAll('#queueTableBody tr[id^="imaging-patient-"]');
            return Array.from(rows).map(row => {
                const cells = row.querySelectorAll('td');
                return {
                    id: row.id.replace('imaging-patient-', ''),
                    queueNumber: cells[0] ? cells[0].textContent.trim() : '',
                    patientName: cells[1] ? cells[1].textContent.trim() : ''
                };
            });
        }

        function collectCurrentImagingWrongInfoTicketsFromDom() {
            const rows = document.querySelectorAll('#queueTableBody tr[id^="imaging-patient-"]');
            return Array.from(rows).map(row => {
                const statusBadge = row.querySelector('.status-badge');
                const statusText = statusBadge ? statusBadge.textContent.trim() : '';
                if (statusText !== 'Wrong Info') {
                    return null;
                }

                const cells = row.querySelectorAll('td');
                return {
                    id: row.id.replace('imaging-patient-', ''),
                    queueNumber: cells[0] ? cells[0].textContent.trim() : '',
                    patientName: cells[1] ? cells[1].textContent.trim() : '',
                    message: `${cells[0] ? cells[0].textContent.trim() : ''} - ${cells[1] ? cells[1].textContent.trim() : ''}`
                };
            }).filter(Boolean);
        }

        function collectCurrentImagingAssignmentsFromDom() {
            const container = document.getElementById('assignmentsList');
            if (!container) {
                return [];
            }

            return Array.from(container.querySelectorAll('.assignment-form')).map(form => {
                const patientId = form.querySelector('input[name="patient_id"]')?.value;
                const card = form.closest('.assignment-item');
                return {
                    id: patientId,
                    queueNumber: card?.querySelector('.queue-number')?.textContent.trim() || '',
                    patientName: card?.querySelector('.patient-name')?.textContent.trim() || ''
                };
            }).filter(item => item.id);
        }

        function parseImagingAssignmentsHtml(html) {
            const documentFragment = new DOMParser().parseFromString(html, 'text/html');
            return Array.from(documentFragment.querySelectorAll('.assignment-form')).map(form => {
                const patientId = form.querySelector('input[name="patient_id"]')?.value;
                const card = form.closest('.assignment-item');
                return {
                    id: patientId,
                    queueNumber: card?.querySelector('.queue-number')?.textContent.trim() || '',
                    patientName: card?.querySelector('.patient-name')?.textContent.trim() || ''
                };
            }).filter(item => item.id);
        }

        function notifyNewImagingQueueTickets(patients, machine) {
            if (!window.QueueNotifications) {
                return;
            }

            const newItems = QueueNotifications.notifyForNewTickets({
                pageKey: `imaging:queue:${machine || 'unassigned'}`,
                items: (patients || []).map(patient => ({
                    id: patient.id,
                    queueNumber: patient.queue_number,
                    patientName: patient.patient_name,
                    message: `${patient.queue_number} - ${patient.patient_name}`
                })),
                getTitle: () => `New imaging ticket${machine && machine !== 'unassigned' ? ` (${machine})` : ''}`,
                getBody: (item) => item.message || 'A new imaging ticket is now visible.',
                onClick: () => window.focus()
            });

            if (newItems.length > 0) {
                showImagingToast(
                    `${newItems.length} new imaging ticket${newItems.length > 1 ? 's' : ''}`,
                    `${newItems[0].queueNumber || 'Queue'} - ${newItems[0].patientName || 'Patient'}`
                );
            }

            QueueNotifications.notifyForNewTickets({
                pageKey: `imaging:wrong-info:${machine || 'unassigned'}`,
                items: (patients || [])
                    .filter(patient => (patient.status || '').toLowerCase() === 'wrong info')
                    .map(patient => ({
                        id: patient.id,
                        queueNumber: patient.queue_number,
                        patientName: patient.patient_name,
                        message: `${patient.queue_number} - ${patient.patient_name}`
                    })),
                title: `Wrong Info patient${machine && machine !== 'unassigned' ? ` (Imaging ${machine})` : ' (Imaging)'}`,
                getBody: (item) => item.message || 'A Wrong Info patient is now visible in Imaging.',
                onClick: () => window.focus()
            });
        }

        function notifyNewImagingAssignments(items) {
            if (!window.QueueNotifications) {
                return;
            }

            const newItems = QueueNotifications.notifyForNewTickets({
                pageKey: 'imaging:assignments',
                items: (items || []).map(item => ({
                    id: item.id,
                    queueNumber: item.queueNumber,
                    patientName: item.patientName,
                    message: `${item.queueNumber} - ${item.patientName}`
                })),
                title: 'New imaging assignment',
                getBody: (item) => item.message || 'A new imaging assignment is waiting.',
                onClick: () => window.focus()
            });

            if (newItems.length > 0) {
                showImagingToast(
                    `${newItems.length} new machine assignment${newItems.length > 1 ? 's' : ''}`,
                    `${newItems[0].queueNumber || 'Queue'} - ${newItems[0].patientName || 'Patient'}`
                );
            }
        }

        function showImagingToast(title, body) {
            let container = document.getElementById('imagingToastContainer');
            if (!container) {
                container = document.createElement('div');
                container.id = 'imagingToastContainer';
                container.style.position = 'fixed';
                container.style.top = '20px';
                container.style.right = '20px';
                container.style.zIndex = '10000';
                container.style.display = 'flex';
                container.style.flexDirection = 'column';
                container.style.gap = '10px';
                document.body.appendChild(container);
            }

            const toast = document.createElement('div');
            toast.style.background = '#17324d';
            toast.style.color = '#fff';
            toast.style.borderRadius = '10px';
            toast.style.padding = '12px 14px';
            toast.style.minWidth = '260px';
            toast.style.maxWidth = '340px';
            toast.style.boxShadow = '0 8px 20px rgba(0, 0, 0, 0.25)';
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(-8px)';
            toast.style.transition = 'opacity 180ms ease, transform 180ms ease';
            toast.innerHTML = `<div style="font-size:13px;font-weight:700;margin-bottom:4px;">${escapeHtml(title || 'New update')}</div><div style="font-size:12px;opacity:0.9;">${escapeHtml(body || '')}</div>`;

            container.appendChild(toast);
            requestAnimationFrame(() => {
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            });

            setTimeout(() => {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(-8px)';
                setTimeout(() => {
                    if (toast.parentNode) {
                        toast.parentNode.removeChild(toast);
                    }
                }, 220);
            }, 4500);
        }
        
        // Skip patient - with robust error handling
        function skipPatient(patientId, machine) {
            if (confirm('Skip this patient? They will remain in queue.')) {
                fetch('patient_actions.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: 'action=skip&patient_id=' + patientId + '&machine=' + machine + '&department=imaging'
                })
                .then(response => {
                    return response.text().then(text => {
                        try {
                            const data = JSON.parse(text);
                            return {ok: true, data: data};
                        } catch (e) {
                            console.error('Failed to parse JSON:', e, 'Response:', text);
                            return {ok: false, error: 'Invalid JSON response'};
                        }
                    });
                })
                .then(result => {
                        if (result.ok && result.data.success) {
                        smartReload();
                    } else if (result.ok) {
                        alert('Error: ' + (result.data.message || 'Action failed'));
                    } else {
                        console.log('JSON parse failed, but action might have succeeded. Reloading...');
                        smartReload();
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    smartReload();
                });
            }
        }

        // Recall patient
        function recallPatient(patientId, machine) {
            if (confirm('Recall this patient?')) {
                fetch('patient_actions.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: 'action=recall&patient_id=' + patientId + '&machine=' + machine + '&department=imaging'
                })
                .then(response => response.text())
                .then(text => {
                    try {
                        const data = JSON.parse(text);
                        if (data.success) {
                            smartReload();
                        } else {
                            alert('Error: ' + (data.message || 'Action failed'));
                        }
                    } catch (e) {
                        console.log('Non-JSON response, reloading...');
                        smartReload();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    smartReload();
                });
            }
        }

        // Call next patient
        function callNextPatient() {
            const machine = new URLSearchParams(window.location.search).get('machine');
            if (!machine) {
                alert('Please select a machine first');
                return;
            }
            
            const rows = document.querySelectorAll('table tbody tr');
            let servedPatientId = null;
            let servedForm = null;
            
            for (let row of rows) {
                const buttons = row.querySelectorAll('button[type="submit"], form button');
                for (let btn of buttons) {
                    if (btn.textContent.includes('Complete') || 
                        (btn.closest('form') && btn.closest('form').querySelector('input[name="complete_patient"]'))) {
                        servedForm = btn.closest('form');
                        const patientIdInput = servedForm.querySelector('input[name="patient_id"]');
                        if (patientIdInput) {
                            servedPatientId = patientIdInput.value;
                        }
                        break;
                    }
                }
                if (servedForm) break;
            }
            
            if (servedForm) {
                const formData = new FormData(servedForm);
                
                fetch('imaging.php', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.text();
                })
                .then(text => {
                    console.log('Patient completed');
                    callWaitingPatient(machine);
                })
                .catch(error => {
                    console.error('Error completing patient:', error);
                    alert('Error completing patient: ' + error.message);
                });
                return;
            }
            
            callWaitingPatient(machine);
        }
        
        function callWaitingPatient(machine) {
            fetch(`queue_refresh.php?department=imaging&machine=${encodeURIComponent(machine)}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(patients => {
                    const waitingPatients = patients.filter(p => p.status.toLowerCase() === 'waiting' && p.imaging_machine === machine);
                    
                    if (waitingPatients.length === 0) {
                        console.log('No waiting patients for machine:', machine);
                        setTimeout(() => {
                            smartReload(300);
                        }, 300);
                        return;
                    }
                    
                    waitingPatients.sort((a, b) => 
                        new Date(a.approval_timestamp) - new Date(b.approval_timestamp)
                    );
                    
                    const nextPatient = waitingPatients[0];
                    console.log('Calling next patient:', nextPatient.queue_number, 'for machine:', machine);
                    
                    const formData = new FormData();
                    formData.append('call_patient', '1');
                    formData.append('patient_id', nextPatient.id);
                    formData.append('machine', machine);
                    
                    return fetch('imaging.php', {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.text();
                })
                    .then(text => {
                    console.log('Patient called successfully');
                    setTimeout(() => {
                        smartReload(300);
                    }, 300);
                })
                .catch(error => {
                    console.error('Error calling next patient:', error);
                    setTimeout(() => {
                        smartReload(300);
                    }, 300);
                });
        }
        
        // Utility function to escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Smart reload: prefer RefreshManager when available to preserve state
        function smartReload(delay = 0) {
            const doReload = () => {
                if (window.refreshManager && typeof window.refreshManager.refreshPage === 'function') {
                    try {
                        window.refreshManager.refreshPage(true);
                        return;
                    } catch (e) {
                        console.error('RefreshManager failed, falling back to location.reload():', e);
                    }
                }
                location.reload();
            };
            if (delay && Number(delay) > 0) {
                setTimeout(doReload, Number(delay));
            } else {
                doReload();
            }
        }
        
        // Refresh queue via AJAX with state preservation
        function refreshImagingQueue() {
            if (imagingQueueRefreshInFlight) {
                return;
            }

            const machine = new URLSearchParams(window.location.search).get('machine');
            if (!machine) return;

            imagingQueueRefreshInFlight = true;
            
            // Use RefreshManager to preserve focus and form state
            if (window.refreshManager) {
                const url = `queue_refresh.php?department=imaging&machine=${encodeURIComponent(machine)}`;
                window.refreshManager.refreshSection('#queueTableBody', url)
                    .then(() => {
                        imagingQueueRefreshInFlight = false;
                    })
                    .catch(error => {
                        console.error('Queue refresh error:', error);
                        imagingQueueRefreshInFlight = false;
                    });
            } else {
                // Fallback to original method
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 5000);
                
                fetch(`queue_refresh.php?department=imaging&machine=${encodeURIComponent(machine)}`, {
                    signal: controller.signal,
                    cache: 'no-store',
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                })
                    .then(response => {
                        clearTimeout(timeoutId);
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.text();
                    })
                    .then(html => {
                        const tbody = document.getElementById('queueTableBody');
                        if (tbody) {
                            tbody.innerHTML = html;
                        }
                    })
                    .catch(error => {
                        clearTimeout(timeoutId);
                        console.error('Queue refresh error:', error);
                    })
                    .finally(() => {
                        imagingQueueRefreshInFlight = false;
                    });
            }
        }
        
        // Refresh assignments
        function refreshAssignments(options = {}) {
            if (imagingAssignmentsRefreshInFlight) {
                return;
            }

            const shouldUpdateDom = options.updateDom !== false;
            imagingAssignmentsRefreshInFlight = true;
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 5000);
            
            fetch('imaging.php', {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                signal: controller.signal,
                cache: 'no-store'
            })
                .then(response => {
                    clearTimeout(timeoutId);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.text();
                })
                .then(html => {
                    const assignmentsList = document.getElementById('assignmentsList');
                    if (assignmentsList) {
                        const newDoc = new DOMParser().parseFromString(html, 'text/html');
                        const newAssignments = newDoc.getElementById('assignmentsList');

                        if (shouldUpdateDom && newAssignments) {
                            assignmentsList.innerHTML = newAssignments.innerHTML;
                            if (typeof window.initializeMachineAssignmentHandlers === 'function') {
                                window.initializeMachineAssignmentHandlers();
                            }
                        }

                        notifyNewImagingAssignments(parseImagingAssignmentsHtml(html));
                    }
                })
                .catch(error => {
                    clearTimeout(timeoutId);
                    console.error('Error refreshing assignments:', error);
                })
                .finally(() => {
                    imagingAssignmentsRefreshInFlight = false;
                });
        }
        
        // Auto-refresh frequently to reduce notification delay.
        function startImagingRefresh() {
            window.imagingRefreshInterval = setInterval(() => {
                if (document.hidden) return;
                
                const activeElement = document.activeElement;
                if (activeElement && 
                    (activeElement.tagName === 'INPUT' || 
                     activeElement.tagName === 'TEXTAREA' ||
                     activeElement.classList.contains('editing'))) {
                    return;
                }
                
                const hasOpenModal = document.querySelector('.modal:not(.hidden)') || 
                                    document.querySelector('[role="dialog"]');
                if (hasOpenModal) return;
     
                // Always refresh queue polling for timely desktop notifications.
                refreshImagingQueue();

                const activeSelectInAssignment = activeElement &&
                    activeElement.tagName === 'SELECT' &&
                    typeof activeElement.closest === 'function' &&
                    activeElement.closest('.assignment-form');

                refreshAssignments({
                    updateDom: !isInteractingWithAssignmentForm && !activeSelectInAssignment
                });
            }, 1000);
        }
        
        // Start initial refresh
        startImagingRefresh();
        
        // Setup observer for dynamically created PDF modal
        function setupPdfModalObserver() {
            const pdfModal = document.getElementById('pdfSelectorModal');
            if (pdfModal && !pdfModal.hasAttribute('data-observer-attached')) {
                pdfModal.setAttribute('data-observer-attached', 'true');
                const observer = new MutationObserver(() => {
                    if (pdfModal.classList.contains('active')) {
                        // Modal opened - stop refresh
                        if (window.imagingRefreshInterval) {
                            clearInterval(window.imagingRefreshInterval);
                            window.imagingRefreshInterval = null;
                        }
                    } else {
                        // Modal closed - resume refresh
                        if (!window.imagingRefreshInterval) {
                            startImagingRefresh();
                        }
                    }
                });
                observer.observe(pdfModal, { attributes: true, attributeFilter: ['class'] });
            }
        }
        
        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            if (e.key >= '1' && e.key <= '6') {
                const machines = ['Xray', 'Fluoroscopy', 'Mammography', 'CT', 'UltraSound', 'MRI'];
                const index = parseInt(e.key) - 1;
                if (machines[index]) {
                    window.location.href = 'imaging.php?machine=' + machines[index];
                }
            }
            
            <?php if ($current_machine): ?>
            if (e.code === 'Space' && !e.ctrlKey && !e.altKey) {
                e.preventDefault();
                callNextPatient();
            }
            <?php endif; ?>
            
            if (e.key === 'F5') {
                e.preventDefault();
                smartReload();
            }
        });
        
        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            if (window.QueueNotifications) {
                QueueNotifications.renderPermissionBanner({ pageName: IMAGING_NOTIFICATION_PAGE });
                QueueNotifications.syncTickets(
                    `imaging:queue:${getCurrentImagingMachine()}`,
                    collectCurrentImagingQueueTicketsFromDom()
                );
                QueueNotifications.syncTickets(
                    `imaging:wrong-info:${getCurrentImagingMachine()}`,
                    collectCurrentImagingWrongInfoTicketsFromDom()
                );
                QueueNotifications.syncTickets('imaging:assignments', collectCurrentImagingAssignmentsFromDom());
            }

            refreshImagingQueue();
            refreshAssignments();

            document.addEventListener('visibilitychange', () => {
                if (!document.hidden) {
                    refreshImagingQueue();
                    refreshAssignments({ updateDom: !isInteractingWithAssignmentForm });
                }
            });

            window.addEventListener('focus', () => {
                refreshImagingQueue();
                refreshAssignments({ updateDom: !isInteractingWithAssignmentForm });
            });

            window.machineHandlersInitialized = false;
            
            const successMessage = document.getElementById('successMessage');
            if (successMessage) {
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 5000);
            }
            
            setTimeout(() => {
                document.querySelectorAll('.priority-highlight').forEach(row => {
                    row.style.backgroundColor = '#fff3cd';
                    setTimeout(() => {
                        row.style.backgroundColor = '';
                    }, 2000);
                });
            }, 1000);
        });

        // PDF selector modal
        function showPdfSelectorImaging(patient) {
            if (typeof patient === 'string') {
                try { patient = JSON.parse(patient); } catch(e) { console.error(e); return; }
            }
            let modal = document.getElementById('pdfSelectorModal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'pdfSelectorModal';
                modal.className = 'patient-modal';
                modal.innerHTML = `
                    <div class="patient-modal-content">
                        <div class="patient-modal-header">
                            <div class="patient-modal-title"><i class="fas fa-file-pdf"></i> Open Document</div>
                            <button class="patient-modal-close" id="pdfModalClose"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="patient-modal-body" id="pdfModalBody"></div>
                    </div>`;
                document.body.appendChild(modal);
                modal.querySelector('#pdfModalClose').addEventListener('click', () => modal.classList.remove('active'));
            }
            const body = modal.querySelector('#pdfModalBody');
            body.innerHTML = `
                <div style="margin-bottom:12px;"><strong>${escapeHtml(patient.patient_name || '')}</strong></div>
                <div style="margin-bottom:12px; color:#2c3e50;"><strong>PID:</strong> ${escapeHtml(patient.mrn || 'N/A')}</div>
                <div style="display:flex; gap:8px;">
                    <button id="openIdBtn" class="action-btn" style="background:#3498db; color:white;"><i class="fas fa-id-card"></i> Open ID</button>
                    <button id="openPrescBtn" class="action-btn" style="background:#9b59b6; color:white;"><i class="fas fa-prescription"></i> Open Prescription</button>
                </div>
            `;
            modal.classList.add('active');
            // Attach observer now that modal exists
            setupPdfModalObserver();
            function openFile(type) {
                const filenameBase = (patient.mrn && patient.mrn.trim() !== '') ? patient.mrn : patient.id;
                const url = 'download_pdf.php?type=' + encodeURIComponent(type) + '&file=' + encodeURIComponent(filenameBase + '.pdf') + '&patient=' + encodeURIComponent(patient.id);
                window.open(url, '_blank', 'noopener');
            }
            modal.querySelector('#openIdBtn').onclick = () => openFile('id');
            modal.querySelector('#openPrescBtn').onclick = () => openFile('insurance');
        }

        // Delegate clicks for PDF button
        document.addEventListener('click', function(e) {
            const btn = e.target.closest('.view-pdf-btn');
            if (btn) {
                e.preventDefault();
                const data = btn.getAttribute('data-patient');
                try { const patient = JSON.parse(data); showPdfSelectorImaging(patient); } catch(err) { console.error('Invalid patient data', err); }
            }
        });
    </script>
    
    <!-- Show undo button if undo data exists and matches current department -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if (isset($_SESSION['last_action']) && $_SESSION['last_action']['department'] === 'imaging' && ($_SESSION['last_action']['action'] ?? '') !== 'Mark On the Way'): ?>
                setTimeout(() => {
                    if (typeof showUndoButton !== 'undefined') {
                        const action = <?php echo json_encode($_SESSION['last_action']); ?>;
                        showUndoButton(action.action + ' - Click to undo');
                    }
                }, 500);
            <?php endif; ?>
        });
    </script>
    
    <!-- Machine Assignment Handlers -->
    <script>
        const machineOptions = [
            'Xray', 'Fluoroscopy', 'Mammography', 'CT', 'UltraSound', 'MRI'
        ];

        let assignmentHandlersInitialized = false;

        function initializeMachineAssignmentHandlers() {
            if (assignmentHandlersInitialized) {
                return;
            }
            assignmentHandlersInitialized = true;
            
            document.addEventListener('mouseenter', function(e) {
                if (!(e.target instanceof Element)) return;
                if (e.target.closest('.assignment-form')) {
                    isInteractingWithAssignmentForm = true;
                }
            }, true);

            document.addEventListener('mouseleave', function(e) {
                if (!(e.target instanceof Element)) return;
                if (e.target.closest('.assignment-form')) {
                    isInteractingWithAssignmentForm = false;
                }
            }, true);
            
            document.addEventListener('click', function(e) {
                if (!(e.target instanceof Element)) return;
                
                let addBtn = e.target.classList.contains('add-machine-btn') ?
                    e.target : (e.target.closest ? e.target.closest('.add-machine-btn') : null);
                
                if (!addBtn && e.target.closest) {
                    const container = e.target.closest('.assignment-buttons');
                    if (container && !e.target.closest('button')) {
                        addBtn = container.querySelector('.add-machine-btn');
                    }
                }
                
                if (!addBtn) return;
                e.preventDefault();
                isInteractingWithAssignmentForm = true;
                const form = addBtn.closest('.assignment-form');
                if (!form) return;
                const machineSelections = form.querySelector('.machine-selections');
                if (!machineSelections) return;
                    
                const newGroup = document.createElement('div');
                newGroup.className = 'machine-input-group';
                
                let selectHtml = '<select name="machines[]" class="machine-select" required><option value="">Select Machine</option>';
                machineOptions.forEach(machine => {
                    selectHtml += `<option value="${machine}">${machine}</option>`;
                });
                selectHtml += '</select>';
                
                newGroup.innerHTML = selectHtml + `
                    <button type="button" class="remove-machine-btn" title="Remove this machine">
                        <i class="fas fa-minus"></i>
                    </button>
                `;
                
                machineSelections.appendChild(newGroup);
                
                const allGroups = machineSelections.querySelectorAll('.machine-input-group');
                allGroups.forEach(group => {
                    const removeBtn = group.querySelector('.remove-machine-btn');
                    removeBtn.style.display = allGroups.length > 1 ? 'flex' : 'none';
                });
            });
            
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('remove-machine-btn') || 
                    (e.target.closest && e.target.closest('.remove-machine-btn'))) {
                    e.preventDefault();
                    isInteractingWithAssignmentForm = true;
                    const removeBtn = e.target.classList.contains('remove-machine-btn') ? 
                                      e.target : e.target.closest('.remove-machine-btn');
                    const form = removeBtn.closest('.assignment-form');
                    if (!form) return;
                    const machineSelections = form.querySelector('.machine-selections');
                    if (!machineSelections) return;
                    
                    removeBtn.closest('.machine-input-group').remove();
                    
                    const remainingGroups = machineSelections.querySelectorAll('.machine-input-group');
                    remainingGroups.forEach(group => {
                        const btn = group.querySelector('.remove-machine-btn');
                        btn.style.display = remainingGroups.length > 1 ? 'flex' : 'none';
                    });
                }
            });
            
            document.addEventListener('submit', function(e) {
                if (e.target.classList.contains('assignment-form')) {
                    e.preventDefault();
                    
                    const submitter = e.submitter || document.activeElement;
                    if (submitter && submitter.name === 'wrong_info_from_assignment') {
                        // Let this submit normally for "Wrong Info" actions
                        isInteractingWithAssignmentForm = false;
                        e.target.submit();
                        return;
                    }

                    const machineSelections = e.target.querySelector('.machine-selections');
                    if (!machineSelections) return;
                    
                    const selects = machineSelections.querySelectorAll('select');
                    const selectedMachines = [];
                    let focusedSelectIndex = -1;
                    
                    // Track which select is focused
                    selects.forEach((select, index) => {
                        if (document.activeElement === select) {
                            focusedSelectIndex = index;
                        }
                        if (select.value) {
                            selectedMachines.push(select.value);
                        }
                    });
                    
                    if (selectedMachines.length === 0) {
                        alert('Please select at least one machine before assigning');
                        isInteractingWithAssignmentForm = false;
                        return false;
                    }
                    
                    const uniqueMachines = new Set(selectedMachines);
                    if (uniqueMachines.size !== selectedMachines.length) {
                        alert('Please select different machines. Duplicates are not allowed');
                        isInteractingWithAssignmentForm = false;
                        return false;
                    }
                    
                    // Submit via AJAX to preserve focus
                    const formData = new FormData(e.target);
                    // Explicitly add the submit button since we preventDefault()
                    formData.append('assign_machine', '1');
                    
                    fetch('imaging.php', {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Show success message
                            showSuccessMessage(data.message);
                            
                            // Refresh the queue without full page reload
                            refreshImagingQueue();
                            
                            // Restore focus to the machine select that was focused
                            setTimeout(() => {
                                const focusedSelects = machineSelections.querySelectorAll('select');
                                if (focusedSelectIndex >= 0 && focusedSelects[focusedSelectIndex]) {
                                    focusedSelects[focusedSelectIndex].focus();
                                }
                            }, 100);
                            
                            // Clear the form
                            e.target.reset();
                        } else {
                            alert(data.message || 'Error assigning patient');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Error assigning patient. Please try again.');
                    })
                    .finally(() => {
                        isInteractingWithAssignmentForm = false;
                    });
                }
            });
            
            // Helper function to show success message
            function showSuccessMessage(message) {
                let successDiv = document.getElementById('successMessage');
                if (!successDiv) {
                    successDiv = document.createElement('div');
                    successDiv.id = 'successMessage';
                    successDiv.className = 'success-message';
                    document.body.insertBefore(successDiv, document.body.firstChild);
                }
                
                successDiv.innerHTML = `
                    <i class="fas fa-check-circle"></i>
                    ${message}
                    <button class="close-message" onclick="this.parentElement.style.display='none'" 
                            style="background: none; border: none; color: #155724; cursor: pointer;">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                successDiv.style.display = 'block';
                
                // Auto-hide after 3 seconds
                setTimeout(() => {
                    successDiv.style.display = 'none';
                }, 3000);
            }
        }

        document.addEventListener('DOMContentLoaded', initializeMachineAssignmentHandlers);

        if (typeof window.initializeMachineAssignmentHandlers === 'undefined') {
            window.initializeMachineAssignmentHandlers = initializeMachineAssignmentHandlers;
        }
    </script>
</body>
<?php include 'undo_button.php'; ?>
</html>

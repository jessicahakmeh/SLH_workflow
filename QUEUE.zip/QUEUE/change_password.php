<?php
require_once 'config.php';
session_start();
authRequireRoles([], ['message' => 'You must be logged in to change your password.']);

if (defined('AUTH_AD_ENABLED') && AUTH_AD_ENABLED) {
    authDenyAccess('Password changes are managed in Active Directory while AD authentication is enabled.');
}

$user = authCurrentUser();
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = (string)($_POST['new_password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');
    if ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        if (authChangePassword((int)$user['id'], $password, $error)) {
            $message = 'Password updated successfully.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <style>
        body{margin:0;font-family:Segoe UI,Tahoma,sans-serif;background:#f4f7fb;color:#17212f}.wrap{max-width:720px;margin:40px auto;padding:0 20px}.card{background:#fff;border-radius:16px;padding:24px;box-shadow:0 18px 48px rgba(23,33,47,.10)}
        a{color:#0b66c3;text-decoration:none}label{display:block;font-weight:600;margin:14px 0 6px}input{width:100%;box-sizing:border-box;padding:12px 14px;border:1px solid #c9d3e1;border-radius:10px}
        .row{display:flex;gap:12px;flex-wrap:wrap;margin-top:18px}.btn{display:inline-block;border:0;border-radius:10px;padding:12px 16px;background:#0b66c3;color:#fff;font-weight:700;cursor:pointer}.btn.secondary{background:#e8eef6;color:#17212f}
        .ok,.error{padding:12px 14px;border-radius:10px;margin-top:14px}.ok{background:#e9f8ef;color:#1f6f43}.error{background:#fde7e7;color:#a12626}
    </style>
</head>
<body>
    <?php authRenderUserMenu(); ?>
<div class="wrap">
    <div class="card">
        <p><a href="<?php echo htmlspecialchars(authDefaultLandingPage(), ENT_QUOTES, 'UTF-8'); ?>">Back</a> | <a href="user_actions.php">My Actions</a><?php if (authHasAnyRole(['admin'])): ?> | <a href="user_management.php">User Management</a><?php endif; ?> | <a href="logout.php">Logout</a></p>
        <h1>Change Password</h1>
        <p>User: <strong><?php echo htmlspecialchars((string)($user['full_name'] ?: $user['username']), ENT_QUOTES, 'UTF-8'); ?></strong></p>
        <?php if ($message !== ''): ?><div class="ok"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
        <?php if ($error !== ''): ?><div class="error"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
        <form method="post" action="change_password.php">
            <label for="new_password">New Password</label>
            <input type="password" id="new_password" name="new_password" required>
            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            <div class="row">
                <button class="btn" type="submit">Save Password</button>
                <a class="btn secondary" href="<?php echo htmlspecialchars(authDefaultLandingPage(), ENT_QUOTES, 'UTF-8'); ?>">Cancel</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>

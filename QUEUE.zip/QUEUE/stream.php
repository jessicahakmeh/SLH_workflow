﻿<?php
// stream.php - Unified streaming system with multiple modes
require_once 'config.php';
session_start();

// Get parameters
$mode = $_GET['mode'] ?? 'fullscreen'; // fullscreen, cards, all_cards, modal, content_only, compact_content
$stream = $_GET['stream'] ?? 'lab';
$patient_id = $_GET['patient_id'] ?? null;
$action = $_GET['action'] ?? null;

// Public read-only stream views are allowed. Mutating actions still require auth.
if ($action && $patient_id) {
    authRequireRoles([], ['log_view' => false]);
}

if (!$action) {
    // Polling requests do not mutate session; release lock to avoid blocking clicks/navigation.
    session_write_close();
}

// Validate parameters
if (!in_array($stream, ['lab', 'imaging', 'billing', 'clinics'], true)) {
    $stream = 'lab';
}

// Handle actions
if ($action && $patient_id) {
    header('Content-Type: application/json');
    handlePatientAction($pdo, $stream, $action, $patient_id);
    exit;
}

// Helper function to save undo state
function saveUndoState($pdo, $patient_id, $previous_status, $new_status, $action, $department) {
    $patient = executeAndFetchOne($pdo, 'SELECT img, lab, dp2, imaging_machine, cl FROM tickets WHERE ticket_id = ?', [$patient_id]);

    $_SESSION['last_action'] = [
        'patient_id' => $patient_id,
        'previous_status' => $previous_status,
        'current_status' => $new_status,
        'action' => $action,
        'department' => $department,
        'img' => $patient['img'] ?? 0,
        'lab' => $patient['lab'] ?? 0,
        'dp2' => $patient['dp2'] ?? 0,
        'cl' => $patient['cl'] ?? 0,
        'imaging_machine' => $patient['imaging_machine'] ?? null,
        'clinic' => $patient['Clinic'] ?? null,
        'timestamp' => time(),
    ];
}

// Function to handle patient actions
function handlePatientAction($pdo, $stream, $action, $patient_id) {
    try {
        // Get current status before update for logging
        $currentRecord = executeAndFetchOne($pdo, 'SELECT current_status FROM tickets WHERE ticket_id = ?', [$patient_id]);
        $fromStatus = $currentRecord['current_status'] ?? 'Unknown';

        switch ($action) {
            case 'confirm_reception':
                if ($stream === 'billing') {
                    saveUndoState($pdo, $patient_id, $fromStatus, 'In Process', 'Confirm Reception', $stream);

                    executeUpdate($pdo, "UPDATE tickets SET current_status = 'In Process', lab = 0, img = 0, dp2 = 0 WHERE ticket_id = ?", [$patient_id]);

                    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Status Changed', ?, 'In Process', ?, 'Patient confirmed reception at billing counter')", [$patient_id, $fromStatus, authCurrentUserId() ?: null]);

                    authLogTicketAction('ticket_confirm_reception', $patient_id, [
                        'ticket_action' => 'Confirm Reception',
                        'department' => $stream,
                        'from_status' => $fromStatus,
                        'to_status' => 'In Process',
                        'notes' => 'Patient confirmed reception at billing counter',
                    ], 'stream.php');
                }
                break;

            case 'mark_on_the_way':
                if (in_array($stream, ['lab', 'imaging'], true)) {
                    // On the Way is intentionally non-undoable for lab/imaging.
                    unset($_SESSION['last_action']);

                    executeUpdate($pdo, "UPDATE tickets SET current_status = 'On the Way' WHERE ticket_id = ?", [$patient_id]);

                    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Status Changed', ?, 'On the Way', ?, ?)", [$patient_id, $fromStatus, authCurrentUserId() ?: null, 'Patient is on the way to ' . ucfirst($stream)]);

                    authLogTicketAction('ticket_mark_on_the_way', $patient_id, [
                        'ticket_action' => 'Mark On the Way',
                        'department' => $stream,
                        'from_status' => $fromStatus,
                        'to_status' => 'On the Way',
                        'notes' => 'Patient is on the way to ' . ucfirst($stream),
                    ], 'stream.php');
                }
                break;

            case 'mark_served':
                if (in_array($stream, ['lab', 'imaging', 'clinics'], true)) {
                    saveUndoState($pdo, $patient_id, $fromStatus, 'Served', 'Mark Served', $stream);

                    executeUpdate($pdo, "UPDATE tickets SET current_status = 'Served' WHERE ticket_id = ?", [$patient_id]);

                    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Status Changed', ?, 'Served', ?, CONCAT('Patient served in ', ?))", [$patient_id, $fromStatus, authCurrentUserId() ?: null, ucfirst($stream)]);

                    authLogTicketAction('ticket_mark_served', $patient_id, [
                        'ticket_action' => 'Mark Served',
                        'department' => $stream,
                        'from_status' => $fromStatus,
                        'to_status' => 'Served',
                        'notes' => 'Patient served in ' . ucfirst($stream),
                    ], 'stream.php');
                }
                break;

            case 'confirm_assignment':
                if ($stream === 'clinics') {
                    saveUndoState($pdo, $patient_id, $fromStatus, 'Waiting', 'Confirm Assignment', $stream);

                    // Status already set to Waiting when seeding assignment (keep consistent)
                    // If you need an UPDATE, add it here.

                    executeUpdate($pdo, "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Status Changed', ?, 'Waiting', ?, 'Patient confirmed assigned to clinic')", [$patient_id, $fromStatus, authCurrentUserId() ?: null]);

                    authLogTicketAction('ticket_confirm_assignment', $patient_id, [
                        'ticket_action' => 'Confirm Assignment',
                        'department' => $stream,
                        'from_status' => $fromStatus,
                        'to_status' => 'Waiting',
                        'notes' => 'Patient confirmed assigned to clinic',
                    ], 'stream.php');
                }
                break;
        }

        echo json_encode([
            'success' => true,
            'timestamp' => time(),
            'message' => 'Action completed successfully',
        ]);
    } catch (Exception $e) {
        http_response_code(200); // Return 200 to avoid browser showing error, but set success to false
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage(),
        ]);
    }
}

// Function to get patients for a stream
function getStreamPatients($pdo, $stream) {
    switch ($stream) {
        case 'imaging':
            $query = "
                SELECT t.ticket_id AS id, t.queue_number, p.patient_name, t.current_status,
                       p.mobile, t.imaging_machine
                FROM tickets t
                JOIN patients p ON t.patient_id = p.patient_id
                WHERE (t.current_status = 'Called' OR t.current_status = 'Recalled')
                AND t.img = 1
                AND (t.lab = 0 OR t.dp2 = 1)
                AND t.closing_timestamp IS NULL
                AND t.arrival_timestamp >= CURDATE()
                AND t.arrival_timestamp < (CURDATE() + INTERVAL 1 DAY)
                ORDER BY t.approval_timestamp DESC
            ";
            break;

        case 'billing':
            $query = "
                SELECT t.ticket_id AS id, t.queue_number, p.patient_name, t.current_status, p.mobile,
                       t.last_need_request_by_username, t.assigned_butler_username
                FROM tickets t
                JOIN patients p ON t.patient_id = p.patient_id
                WHERE (t.current_status = 'Needed by Billing')
                AND t.closing_timestamp IS NULL
                AND t.arrival_timestamp >= CURDATE()
                AND t.arrival_timestamp < (CURDATE() + INTERVAL 1 DAY)
                ORDER BY t.approval_timestamp DESC
            ";
            break;

        case 'lab':
        default:
            $query = "
                SELECT t.ticket_id AS id, t.queue_number, p.patient_name, t.current_status, p.mobile
                FROM tickets t
                JOIN patients p ON t.patient_id = p.patient_id
                WHERE (t.current_status = 'Called' OR t.current_status = 'Recalled')
                AND t.lab = 1
                AND t.closing_timestamp IS NULL
                AND t.arrival_timestamp >= CURDATE()
                AND t.arrival_timestamp < (CURDATE() + INTERVAL 1 DAY)
                ORDER BY t.approval_timestamp DESC
            ";
            break;

        case 'clinics':
            $query = "
                SELECT t.ticket_id AS id, t.queue_number, p.patient_name, t.current_status, p.mobile
                FROM tickets t
                JOIN patients p ON t.patient_id = p.patient_id
                WHERE (t.current_status = 'Called' OR t.current_status = 'Recalled')
                AND t.cl = 1
                AND t.closing_timestamp IS NULL
                AND t.arrival_timestamp >= CURDATE()
                AND t.arrival_timestamp < (CURDATE() + INTERVAL 1 DAY)
                ORDER BY t.approval_timestamp DESC
            ";
            break;
    }

    return executeAndFetch($pdo, $query, []);
}

// Function to render a single stream card
function renderStreamCard($stream, $patients) {
    $dept_label = ucfirst($stream);
    $icon = [
        'lab' => 'flask-vial',
        'imaging' => 'x-ray',
        'billing' => 'calculator',
        'clinics' => 'clinic-medical',
    ][$stream];

    $hasPatient = !empty($patients);

    ob_start();
    ?>
    <div class="stream-card <?php echo $stream; ?>-card" id="<?php echo $stream; ?>Card">
        <div class="stream-card-header">
            <div class="stream-card-title">
                <i class="fas fa-<?php echo $icon; ?>"></i>
                <span class="stream-label"><?php echo $dept_label; ?></span>
            </div>
            <a href="stream.php?stream=<?php echo $stream; ?>" target="_blank" class="fullscreen-btn" title="Open in fullscreen">
                <i class="fas fa-expand"></i>
            </a>
        </div>
        <div class="stream-card-content" id="<?php echo $stream; ?>Stream">
    <?php if ($hasPatient): ?>
        <?php foreach ($patients as $patient): ?>
            <div class="ticket-number-compact flashing"
                 data-patient-id="<?php echo htmlspecialchars($patient['id']); ?>"
                 data-stream="<?php echo $stream; ?>">
                <?php echo htmlspecialchars($patient['queue_number']); ?>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="no-call">
            <i class="fas fa-<?php echo $icon; ?>"></i>
            <div>No patient</div>
        </div>
    <?php endif; ?>
</div>
    </div>
    <?php
    $html = ob_get_clean();

    return [
        'html' => $html,
        'hasPatient' => $hasPatient,
        'stream' => $stream,
        'count' => count($patients),
    ];
}

// Function to render compact stream content for butler.php
function renderCompactContent($stream, $patients) {
    $hasPatient = !empty($patients);

    ob_start();

    if ($hasPatient) {
        foreach ($patients as $patient) {
            ?>
            <div class="ticket-number-compact flashing"
                 data-patient-id="<?php echo htmlspecialchars($patient['id']); ?>">
                <?php echo htmlspecialchars($patient['queue_number']); ?>
            </div>
            <?php
        }
    } else {
        ?>
        <div class="no-patient-compact">
            <div>No patient</div>
        </div>
        <?php
    }

    return ob_get_clean();
}

// Function to render confirmation modal
function renderConfirmationModal($stream, $patient_id) {
    global $pdo;

    $patient = executeAndFetchOne($pdo, "SELECT t.queue_number, p.patient_name FROM tickets t JOIN patients p ON t.patient_id = p.patient_id WHERE t.ticket_id = ?", [$patient_id]);

    if (!$patient) {
        return '<div class="error">Patient not found</div>';
    }

    $queue_number = htmlspecialchars($patient['queue_number']);
    $patient_name = htmlspecialchars($patient['patient_name']);
    $newStatus = $stream === 'billing' ? 'In Process' : 'On the Way';
    $title = $stream === 'billing' ? 'Confirm Patient Reception' : 'Mark Patient On the Way';
    $message = $stream === 'billing'
        ? "Are you sure you want to confirm reception of patient {$queue_number}?"
        : "Are you sure you want to mark patient {$queue_number} as on the way?";

    ob_start();
    ?>
    <div class="stream-modal active" id="confirmationModal">
        <div class="stream-modal-content">
            <div class="stream-modal-header">
                <h3><?php echo $title; ?></h3>
                <button class="stream-modal-close" id="modalCloseBtn">&times;</button>
            </div>
            <div class="stream-modal-body">
                <p class="modal-message"><?php echo $message; ?></p>
                <p class="patient-name"><strong>Patient:</strong> <?php echo $patient_name; ?></p>
                <div class="modal-info">
                    <p><small>This will change status to "<?php echo $newStatus; ?>"</small></p>
                </div>
            </div>
            <div class="stream-modal-footer">
                <button class="stream-modal-btn stream-modal-cancel" id="cancelBtn">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button class="stream-modal-btn stream-modal-confirm" id="confirmBtn"
                        data-stream="<?php echo $stream; ?>"
                        data-patient-id="<?php echo $patient_id; ?>">
                    <i class="fas fa-check"></i> <?php echo $stream === 'billing' ? 'Confirm Reception' : 'Mark On the Way'; ?>
                </button>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// Function to render fullscreen compact display (matching butler.php cards)
function renderFullscreenCompact($stream, $patients) {
    $dept_title = ucfirst($stream);
    $header_colors = [
        'lab' => 'linear-gradient(135deg, #e74c3c, #c0392b)',
        'imaging' => 'linear-gradient(135deg, #9b59b6, #8e44ad)',
        'billing' => 'linear-gradient(135deg, #27ae60, #219955)',
        'clinics' => 'linear-gradient(135deg, #16a085, #138d75)',
    ];

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $dept_title; ?> Stream - Fullscreen</title>
        <link rel="stylesheet" href="styles.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
    body {
        margin: 0;
        padding: 0;
        background: white;
        display: flex;
        flex-direction: column;
        height: 100vh;
        overflow: hidden;
    }
    .fullscreen-header {
        background: <?php echo $header_colors[$stream]; ?>;
        color: white;
        padding: 20px;
        font-size: 1.5em;
        font-weight: bold;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }
    .fullscreen-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding: 20px;
        overflow-y: auto;
        gap: 20px;
    }
    .ticket-number-fullscreen {
        background: linear-gradient(120deg, #FFD700, #FFFFFF);
        border-radius: 12px;
        padding: 30px 40px;
        text-align: center;
        cursor: pointer;
        transition: none;
        box-shadow: 0 0 20px rgba(173, 216, 230, 0.6);
        border: 2px solid #000;
        position: relative;
        overflow: hidden;
        font-size: 4em;
        font-weight: 900;
        color: #000;
        margin: 10px;
    }
    .ticket-number-fullscreen.flashing {
        animation: flashBabyBlue 0.8s infinite ease-in-out;
    }
    @keyframes flashBabyBlue {
        0%, 100% {
            background: linear-gradient(135deg, #3393FF, #FFFFFF);
            border-color: rgba(173, 216, 230, 0.4);
            box-shadow: 0 2px 12px rgba(173, 216, 230, 0.6);
            transform: scale(1);
        }
        25% {
            background: linear-gradient(135deg, #FFFFFF, #E8F4FF);
            border-color: rgba(173, 216, 230, 0.3);
            box-shadow: 0 0 10px rgba(173, 216, 230, 0.3);
            transform: scale(1.02);
        }
        50% {
            background: linear-gradient(135deg, #3393FF, #FFFFFF);
            border-color: rgba(173, 216, 230, 0.8);
            box-shadow: 0 4px 20px rgba(173, 216, 230, 0.8);
            transform: scale(1.05);
        }
        75% {
            background: linear-gradient(135deg, #FFFFFF, #E8F4FF);
            border-color: rgba(173, 216, 230, 0.3);
            box-shadow: 0 0 10px rgba(173, 216, 230, 0.3);
            transform: scale(1.02);
        }
    }
    .no-patient-fullscreen {
        font-size: 2em;
        color: #BDC3C7;
        text-align: center;
    }
    </style>
    </head>
    <body>
        <?php authRenderUserMenu(); ?>
        <div class="fullscreen-header">
            <span><?php echo $dept_title; ?> Queue Stream</span>
        </div>

        <div class="fullscreen-content" id="fullscreenContent">
            <?php if (!empty($patients)): ?>
                <?php foreach ($patients as $patient): ?>
                    <div class="ticket-number-fullscreen flashing"
                         data-patient-id="<?php echo htmlspecialchars($patient['id']); ?>"
                         data-stream="<?php echo $stream; ?>"
                         onclick="handleTicketClick(event, '<?php echo $stream; ?>', '<?php echo htmlspecialchars($patient['id']); ?>', '<?php echo htmlspecialchars($patient['queue_number']); ?>')">
                        <?php echo htmlspecialchars($patient['queue_number']); ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-patient-fullscreen">
                    <div>No patient <?php echo $stream === 'billing' ? 'needed' : 'called'; ?></div>
                </div>
            <?php endif; ?>
        </div>

        <div class="stream-confirmation-modal" id="streamConfirmationModal">
            <div class="stream-confirmation-modal-content">
                <div class="stream-confirmation-modal-header">
                    <h3 id="confirmationTitle">Confirm Action</h3>
                    <button class="stream-modal-close" id="confirmationCloseBtn">&times;</button>
                </div>
                <div class="stream-confirmation-modal-body">
                    <p id="confirmationMessage">Are you sure?</p>
                </div>
                <div class="stream-confirmation-modal-footer">
                    <button class="stream-modal-btn stream-modal-cancel" id="confirmationCancelBtn">Cancel</button>
                    <button class="stream-modal-btn stream-modal-confirm" id="confirmationConfirmBtn">Confirm</button>
                </div>
            </div>
        </div>

        <script>
            const stream = '<?php echo $stream; ?>';
            const streamConfigs = {
                lab: { action: 'mark_on_the_way', status: 'On the Way' },
                imaging: { action: 'mark_on_the_way', status: 'On the Way' },
                billing: { action: 'confirm_reception', status: 'In Process' },
                clinics: { action: 'mark_served', status: 'Served' }
            };

            let currentConfirmation = null;
            let refreshInterval = null;

            function handleTicketClick(event, streamType, patientId, queueNumber) {
                event.preventDefault();
                event.stopPropagation();
                showConfirmationModal(streamType, patientId, queueNumber);
            }

            function showConfirmationModal(streamType, patientId, queueNumber) {
                const config = streamConfigs[streamType];
                currentConfirmation = { streamType, patientId, queueNumber, config };

                document.getElementById('confirmationTitle').textContent =
                    streamType === 'billing' ? 'Confirm Patient Reception' : 'Mark Patient On the Way';
                document.getElementById('confirmationMessage').textContent =
                    `Are you sure you want to ${streamType === 'billing' ? 'confirm reception of' : 'mark on the way'} patient ${queueNumber}?`;

                document.getElementById('streamConfirmationModal').classList.add('active');
                if (refreshInterval) clearInterval(refreshInterval);
            }

            function closeConfirmationModal() {
                document.getElementById('streamConfirmationModal').classList.remove('active');
                currentConfirmation = null;
                startRefresh();
            }

            document.getElementById('confirmationConfirmBtn').addEventListener('click', () => {
                if (!currentConfirmation) return;
                const { streamType, patientId, config } = currentConfirmation;

                fetch(`stream.php?stream=${streamType}&action=${config.action}&patient_id=${patientId}`)
                    .then(r => r.text())
                    .then(t => {
                        const data = JSON.parse(t);
                        if (data.success) {
                            closeConfirmationModal();
                            setTimeout(() => refreshContent(), 300);
                        } else {
                            alert('Failed to update patient status: ' + (data.error || 'Unknown error'));
                        }
                    })
                    .catch(e => alert('Error: ' + e.message));
            });

            document.getElementById('confirmationCancelBtn').addEventListener('click', closeConfirmationModal);
            document.getElementById('confirmationCloseBtn').addEventListener('click', closeConfirmationModal);

            function refreshContent() {
                fetch(`stream.php?mode=fullscreen_content_compact&stream=${stream}`)
                    .then(r => r.text())
                    .then(html => { document.getElementById('fullscreenContent').innerHTML = html; });
            }

            function startRefresh() {
                // Track if user is interacting with stream cards
                let isCardFocused = false;
                const streamContent = document.getElementById('fullscreenContent');
                if (streamContent) {
                    streamContent.addEventListener('mouseenter', () => { isCardFocused = true; }, true);
                    streamContent.addEventListener('mouseleave', () => { isCardFocused = false; }, true);
                    streamContent.addEventListener('focusin', () => { isCardFocused = true; }, true);
                    streamContent.addEventListener('focusout', () => { isCardFocused = false; }, true);
                }
                
                // Pause refresh immediately when modal opens, resume when closes
                const confirmModal = document.getElementById('streamConfirmationModal');
                if (confirmModal) {
                    const observer = new MutationObserver(() => {
                        if (confirmModal.classList.contains('active')) {
                            // Modal opened - stop refresh
                            if (refreshInterval) clearInterval(refreshInterval);
                        } else {
                            // Modal closed - resume refresh
                            startRefreshInterval();
                        }
                    });
                    observer.observe(confirmModal, { attributes: true, attributeFilter: ['class'] });
                }
                
                // Pause refresh when any menu opens, resume when closes
                document.addEventListener('toggle', (e) => {
                    if (e.target && e.target.tagName === 'DETAILS') {
                        if (e.target.open) {
                            // Menu opened - stop refresh
                            if (refreshInterval) clearInterval(refreshInterval);
                        } else {
                            // Menu closed - resume refresh
                            startRefreshInterval();
                        }
                    }
                }, true);
                
                const startRefreshInterval = () => {
                    refreshInterval = setInterval(() => {
                        const modal = document.getElementById('streamConfirmationModal');
                        const isModalOpen = modal && modal.classList.contains('active');
                        const isMenuOpen = document.querySelector('details[open]') !== null;
                        
                        if (!isModalOpen && !isCardFocused && !isMenuOpen && !document.hidden) {
                            refreshContent();
                        }
                    }, 2000);
                };
                
                startRefreshInterval();
            }

            startRefresh();
        </script>
    </body>
    </html>
    <?php
    return ob_get_clean();
}

// Function to render fullscreen compact content only (for AJAX refreshing)
function renderFullscreenContentCompact($stream, $patients) {
    ob_start();

    if (!empty($patients)) {
        foreach ($patients as $patient) {
            ?>
            <div class="ticket-number-fullscreen flashing"
                 data-patient-id="<?php echo htmlspecialchars($patient['id']); ?>"
                 data-stream="<?php echo $stream; ?>"
                 onclick="handleTicketClick(event, '<?php echo $stream; ?>', '<?php echo htmlspecialchars($patient['id']); ?>', '<?php echo htmlspecialchars($patient['queue_number']); ?>')">
                <?php echo htmlspecialchars($patient['queue_number']); ?>
            </div>
            <?php
        }
    } else {
        ?>
        <div class="no-patient-fullscreen">
            <div>No patient <?php echo $stream === 'billing' ? 'needed' : 'called'; ?></div>
        </div>
        <?php
    }

    return ob_get_clean();
}

// Handle different modes
switch ($mode) {
    case 'cards':
        $patients = getStreamPatients($pdo, $stream);
        echo renderStreamCard($stream, $patients)['html'];
        break;

    case 'all_cards':
        $streams = ['lab', 'imaging', 'billing'];
        $result = [];
        foreach ($streams as $s) {
            $patients = getStreamPatients($pdo, $s);
            $result[$s] = renderStreamCard($s, $patients);
        }
        header('Content-Type: application/json');
        echo json_encode($result);
        break;

    case 'modal':
        if (!$patient_id) {
            http_response_code(400);
            echo 'Patient ID required';
            exit;
        }
        echo renderConfirmationModal($stream, $patient_id);
        break;

    case 'fullscreen_content':
        try {
            $patients = getStreamPatients($pdo, $stream);
            echo renderFullscreenContentCompact($stream, $patients);
        } catch (Exception $e) {
            http_response_code(200);
            echo '<div style="color:red;padding:10px;">Stream Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        break;

    case 'content_only':
        try {
            $patients = getStreamPatients($pdo, $stream);
            $card = renderStreamCard($stream, $patients);
            echo $card['html'];
        } catch (Exception $e) {
            http_response_code(200);
            echo '<div style="color:red;padding:10px;">Stream Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        break;

    case 'compact_content':
        try {
            $patients = getStreamPatients($pdo, $stream);
            echo renderCompactContent($stream, $patients);
        } catch (Exception $e) {
            http_response_code(200);
            echo '<div style="color:red;padding:10px;">Stream Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        break;

    case 'fullscreen_content_compact':
        try {
            $patients = getStreamPatients($pdo, $stream);
            echo renderFullscreenContentCompact($stream, $patients);
        } catch (Exception $e) {
            http_response_code(200);
            echo '<div style="color:red;padding:10px;">Stream Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        break;

    default:
        try {
            $patients = getStreamPatients($pdo, $stream);
            echo renderFullscreenCompact($stream, $patients);
        } catch (Exception $e) {
            http_response_code(200);
            echo '<div style="color:red;padding:10px;">Stream Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
        break;
}
?>


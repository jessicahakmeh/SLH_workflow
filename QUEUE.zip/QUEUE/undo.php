<?php
require_once 'config.php';
session_start();
authRequireRoles(['butler', 'billing', 'imaging', 'laboratory', 'admin'], ['log_view' => false]);

header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Check if undo data exists in session
if (!isset($_SESSION['last_action'])) {
    echo json_encode(['success' => false, 'message' => 'No action to undo']);
    exit;
}

$action = $_SESSION['last_action'];
$patient_id = $action['patient_id'];
$previous_status = $action['previous_status'];
$department = $action['department'];

if (($action['action'] ?? '') === 'Mark On the Way' || ($action['current_status'] ?? '') === 'On the Way') {
    unset($_SESSION['last_action']);
    echo json_encode(['success' => false, 'message' => 'Mark On the Way cannot be undone']);
    exit;
}

try {
    // Check if this was a FIRST call action (not recall) and clear the call_time accordingly
    // Use exact matching to avoid matching 'Recalled' when we mean 'Called'
    // IMPORTANT: 'Recalled' does NOT set a new call_time, so we should NOT clear it on undo
    $first_call_keywords = ['Called in Lab', 'Called in Imaging', 'Patient called', 'Called'];
    $is_first_call_action = in_array($action['action'], $first_call_keywords);
    
    // Recall doesn't set/modify call_time, so no clearing needed for recalls
    // This prevents accidentally clearing the original call time when undoing a recall
    
    // Validate department is set
    if (empty($department)) {
        throw new Exception('Department not set in undo action - cannot determine department');
    }
    
    // When reverting to 'In Process' or 'Wrong Info', always reset department flags to 0
    $reset_flags_to_zero = ($previous_status === 'In Process' || $previous_status === 'Wrong Info');
    $clear_closing_timestamp = (($action['current_status'] ?? '') === 'Canceled');
    
    // Build the UPDATE query dynamically to clear call times if needed
    // NOTE: Only clear call_time for FIRST calls, not for recalls
    if ($is_first_call_action) {
        if ($department === 'lab') {
            executeUpdate($pdo, "UPDATE tickets SET current_status = ?, img = ?, lab = ?, dp2 = ?, imaging_machine = ?, lab_call_time = NULL" . ($clear_closing_timestamp ? ", closing_timestamp = NULL" : "") . " WHERE ticket_id = ?", [
                $previous_status,
                $reset_flags_to_zero ? 0 : ($action['img'] ?? 0),
                $reset_flags_to_zero ? 0 : ($action['lab'] ?? 0),
                $reset_flags_to_zero ? 0 : ($action['dp2'] ?? 0),
                $action['imaging_machine'] ?? null,
                $patient_id
            ]);
        } else {
            executeUpdate($pdo, "UPDATE tickets SET current_status = ?, img = ?, lab = ?, dp2 = ?, imaging_machine = ?, imaging_call_time = NULL" . ($clear_closing_timestamp ? ", closing_timestamp = NULL" : "") . " WHERE ticket_id = ?", [
                $previous_status,
                $reset_flags_to_zero ? 0 : ($action['img'] ?? 0),
                $reset_flags_to_zero ? 0 : ($action['lab'] ?? 0),
                $reset_flags_to_zero ? 0 : ($action['dp2'] ?? 0),
                $action['imaging_machine'] ?? null,
                $patient_id
            ]);
        }
    } else {
        executeUpdate($pdo, "UPDATE tickets SET current_status = ?, img = ?, lab = ?, dp2 = ?, imaging_machine = ?" . ($clear_closing_timestamp ? ", closing_timestamp = NULL" : "") . " WHERE ticket_id = ?", [
            $previous_status,
            $reset_flags_to_zero ? 0 : ($action['img'] ?? 0),
            $reset_flags_to_zero ? 0 : ($action['lab'] ?? 0),
            $reset_flags_to_zero ? 0 : ($action['dp2'] ?? 0),
            $action['imaging_machine'] ?? null,
            $patient_id
        ]);
    }

    // Log the undo action
    $log_sql = "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Undo Action', ?, ?, ?, 'Undid: " . $action['action'] . "')";
    executeUpdate($pdo, $log_sql, [$patient_id, $action['current_status'], $previous_status, authCurrentUserId() ?: null]);

    // Clear the undo data
    unset($_SESSION['last_action']);

    echo json_encode([
        'success' => true,
        'message' => 'Action undone successfully',
        'previous_status' => $previous_status
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error undoing action: ' . $e->getMessage()
    ]);
}

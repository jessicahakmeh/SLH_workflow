<?php
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

function respond($code, $payload) {
    http_response_code((int)$code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function getNestedValue($arr, $path) {
    $parts = explode('.', $path);
    $cursor = $arr;
    foreach ($parts as $part) {
        if (!is_array($cursor) || !array_key_exists($part, $cursor)) {
            return null;
        }
        $cursor = $cursor[$part];
    }
    return $cursor;
}

function findFirstScalarByKeys($arr, $keys) {
    if (!is_array($arr)) {
        return null;
    }

    foreach ($keys as $key) {
        $value = getNestedValue($arr, $key);
        if (is_scalar($value) && trim((string)$value) !== '') {
            return trim((string)$value);
        }
    }

    $stack = [$arr];
    $needle = array_map('strtolower', $keys);
    while (!empty($stack)) {
        $current = array_pop($stack);
        if (!is_array($current)) {
            continue;
        }
        foreach ($current as $k => $v) {
            if (is_array($v)) {
                $stack[] = $v;
                continue;
            }
            if (!is_scalar($v)) {
                continue;
            }
            $kNorm = strtolower((string)$k);
            foreach ($needle as $candidate) {
                $leaf = strtolower((string)substr($candidate, strrpos($candidate, '.') !== false ? strrpos($candidate, '.') + 1 : 0));
                if ($kNorm === $leaf && trim((string)$v) !== '') {
                    return trim((string)$v);
                }
            }
        }
    }

    return null;
}

$rawBody = file_get_contents('php://input');
if ($rawBody === false || trim($rawBody) === '') {
    respond(400, ['success' => false, 'error' => 'empty_body']);
}

$payload = json_decode($rawBody, true);
if (!is_array($payload)) {
    respond(400, ['success' => false, 'error' => 'invalid_json']);
}

$responseId = findFirstScalarByKeys($payload, [
    'data.responseId',
    'responseId',
    'eventId',
    'submissionId',
    'id',
]);

// Token handling is currently disabled.
// $token = findFirstScalarByKeys($payload, [
//     'data.ticket_token',
//     'ticket_token',
//     'token',
//     'data.token',
// ]);

$ticketId = 0;
// if ($token !== null) {
//     $tokenCheck = validateFeedbackTokenFromDb($token, $pdo);
//     if ($tokenCheck['valid']) {
//         $ticketId = (int)$tokenCheck['ticket_id'];
//     }
// }

if ($ticketId <= 0) {
    $ticketIdRaw = findFirstScalarByKeys($payload, [
        'data.ticket_id',
        'ticket_id',
        'ticketId',
        'data.ticketId',
    ]);
    $ticketId = (int)($ticketIdRaw ?? 0);
}

if ($ticketId <= 0) {
    respond(400, ['success' => false, 'error' => 'missing_ticket_id']);
}

if (!(int)executeAndFetchOne($pdo, 'SELECT ticket_id FROM tickets WHERE ticket_id = ? LIMIT 1', [$ticketId])) {
    respond(404, ['success' => false, 'error' => 'ticket_not_found']);
}

// Feedback fill tracking is currently disabled.
// $existingStmt = $pdo->prepare(
//     'SELECT feedback_filled, tally_id FROM feedback_tickets WHERE ticket_id = ? LIMIT 1'
// );
// $existingStmt->execute([$ticketId]);
// $existing = $existingStmt->fetch(PDO::FETCH_ASSOC) ?: null;

// if ($existing && (int)($existing['feedback_filled'] ?? 0) === 1) {
//     $existingTallyId = trim((string)($existing['tally_id'] ?? ''));
//     respond(200, [
//         'success' => true,
//         'ticket_id' => $ticketId,
//         'status' => 'already_filled',
//         'tally_id' => $existingTallyId,
//     ]);
// }

// $upsert = $pdo->prepare(
//     "INSERT INTO feedback_tickets (ticket_id, feedback_sent, feedback_filled, fill_timestamp, tally_id)
//      VALUES (?, 1, 1, NOW(), ?)
//      ON DUPLICATE KEY UPDATE
//         feedback_sent = 1,
//         feedback_filled = 1,
//         fill_timestamp = NOW(),
//         tally_id = CASE
//             WHEN VALUES(tally_id) IS NULL OR VALUES(tally_id) = '' THEN tally_id
//             ELSE VALUES(tally_id)
//         END"
// );
// $upsert->execute([$ticketId, $responseId]);

executeUpdate($pdo,
    "INSERT INTO ticket_logs (ticket_id, action, from_status, to_status, performed_by, notes) VALUES (?, 'Feedback Form Filled', NULL, NULL, ?, ?)",
    [$ticketId, authCurrentUserId() ?: null, 'Tally response id: ' . (($responseId !== null && $responseId !== '') ? $responseId : 'N/A')]
);

respond(200, [
    'success' => true,
    'ticket_id' => $ticketId,
    'tally_id' => $responseId,
]);

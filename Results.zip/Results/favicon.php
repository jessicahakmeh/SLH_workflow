<?php

declare(strict_types=1);

require_once __DIR__ . '/env.php';
loadEnvFile();

$logoPath = trim((string)(envValue('HOSPITAL_LOGO_PATH', '') ?? ''));

if ($logoPath === '' || !is_file($logoPath) || !is_readable($logoPath)) {
    http_response_code(204);
    exit;
}

$extension = strtolower((string)pathinfo($logoPath, PATHINFO_EXTENSION));
$mime = 'image/jpeg';
if ($extension === 'png') {
    $mime = 'image/png';
} elseif ($extension === 'gif') {
    $mime = 'image/gif';
} elseif ($extension === 'webp') {
    $mime = 'image/webp';
} elseif ($extension === 'ico') {
    $mime = 'image/x-icon';
}

header('Content-Type: ' . $mime);
header('Cache-Control: public, max-age=86400');
readfile($logoPath);

<?php
declare(strict_types=1);

/**
 * Diagnostic script - What's being sent to send_pending_results.php?
 */

echo "═══════════════════════════════════════════════════════════════\n";
echo "REQUEST DIAGNOSTICS\n";
echo "═══════════════════════════════════════════════════════════════\n\n";

echo "Request Method: " . ($_SERVER['REQUEST_METHOD'] ?? 'N/A') . "\n";
echo "PHP SAPI: " . PHP_SAPI . "\n";
echo "Request URI: " . ($_SERVER['REQUEST_URI'] ?? 'N/A') . "\n";
echo "Query String: " . ($_SERVER['QUERY_STRING'] ?? 'N/A') . "\n";

echo "\n" . str_repeat("─", 63) . "\n";
echo "AUTHORIZATION HEADER\n";
echo "─" . str_repeat("─", 62) . "\n";

if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
    echo "✓ Authorization header found: " . $_SERVER['HTTP_AUTHORIZATION'] . "\n";
} else {
    echo "✗ Authorization header NOT found\n";
    echo "  Make sure to send: Authorization: Bearer YOUR_API_KEY\n";
}

echo "\n" . str_repeat("─", 63) . "\n";
echo "QUERY PARAMETERS (?api_key=...)\n";
echo "─" . str_repeat("─", 62) . "\n";

if (!empty($_GET)) {
    echo "✓ Query parameters found:\n";
    foreach ($_GET as $key => $value) {
        echo "  • $key = " . substr($value, 0, 20) . (strlen($value) > 20 ? "..." : "") . "\n";
    }
} else {
    echo "✗ No query parameters found\n";
    echo "  Make sure URL includes: ?api_key=YOUR_API_KEY\n";
}

echo "\n" . str_repeat("─", 63) . "\n";
echo "POST DATA\n";
echo "─" . str_repeat("─", 62) . "\n";

if (!empty($_POST)) {
    echo "✓ POST parameters found:\n";
    foreach ($_POST as $key => $value) {
        echo "  • $key = " . substr($value, 0, 20) . (strlen($value) > 20 ? "..." : "") . "\n";
    }
} else {
    echo "✗ No POST parameters found\n";
    echo "  For POST, send form data: api_key=YOUR_API_KEY\n";
}

echo "\n" . str_repeat("─", 63) . "\n";
echo "EXPECTED API KEY LOCATIONS\n";
echo "─" . str_repeat("─", 62) . "\n";

echo "✓ RECOMMENDED (Secure):\n";
echo "  Header: Authorization: Bearer test-send-pending-key-12345\n\n";

echo "✓ ACCEPTABLE (Less Secure):\n";
echo "  Query: ?api_key=test-send-pending-key-12345\n\n";

echo "✓ ACCEPTABLE (Less Secure):\n";
echo "  POST:  form-data api_key=test-send-pending-key-12345\n\n";

echo "═══════════════════════════════════════════════════════════════\n";
echo "TEST THESE REQUESTS\n";
echo "═══════════════════════════════════════════════════════════════\n\n";

$apiKey = "test-send-pending-key-12345";

echo "1️⃣  Using curl with Authorization header (RECOMMENDED):\n";
echo "────────────────────────────────────────────────────────────\n";
echo "curl -H \"Authorization: Bearer $apiKey\" \\\n";
echo "     http://192.168.20.17/send_pending_results.php\n\n";

echo "2️⃣  Using curl with query parameter:\n";
echo "────────────────────────────────────────────────────────────\n";
echo "curl \"http://192.168.20.17/send_pending_results.php?api_key=$apiKey\"\n\n";

echo "3️⃣  Using PowerShell with Authorization header:\n";
echo "────────────────────────────────────────────────────────────\n";
echo "\$headers = @{ Authorization = \"Bearer $apiKey\" }\n";
echo "\$response = Invoke-WebRequest -Uri \"http://192.168.20.17/send_pending_results.php\" -Headers \$headers\n";
echo "\$response.Content | ConvertFrom-Json\n\n";

echo "4️⃣  Using PowerShell with query parameter:\n";
echo "────────────────────────────────────────────────────────────\n";
echo "\$response = Invoke-WebRequest -Uri \"http://192.168.20.17/send_pending_results.php?api_key=$apiKey\"\n";
echo "\$response.Content | ConvertFrom-Json\n\n";

echo "═══════════════════════════════════════════════════════════════\n";

<?php
declare(strict_types=1);

echo "\n" . str_repeat("═", 130) . "\n";
echo " AUTO-SEND vs MANUAL SEND MECHANISM DIFFERENCE FOUND \n";
echo str_repeat("═", 130) . "\n\n";

echo "Location 1 - AUTO-SEND (result_sending.php lines 1382-1394):\n";
echo str_repeat("─", 130) . "\n";
echo "  saveSentRecord(\$resultId, 'result', 'link', \$resultLink, 'auto_send', [\n";
echo "      'provider_ack' => \$sendResult['provider_ack'],\n";
echo "      'provider_status' => \$sendResult['provider_status'],  ← No default value!\n";
echo "      'wp_sent' => !empty(\$sendResult['success']) ? 1 : 0,\n";
echo "      ...\n";
echo "  ]);\n\n";

echo "Location 2 - MANUAL SEND (result_sending.php lines 3042-3049):\n";
echo str_repeat("─", 130) . "\n";
echo "  saveSentRecord(\$resultId, 'result', 'link', \$resultLink, \$currentUsername, [\n";
echo "      'provider_ack' => \$sendResult['provider_ack'],\n";
echo "      'provider_status' => \$sendResult['provider_status'] ?? 'FAILED',  ← Has default!\n";
echo "      'wp_sent' => !empty(\$sendResult['success']) ? 1 : 0,\n";
echo "      ...\n";
echo "  ]);\n\n";

echo "THE ISSUE:\n";
echo str_repeat("─", 130) . "\n";
echo "If provider_status is NULL or missing in \$sendResult:\n";
echo "  • Auto-send: saves provider_status as NULL → later becomes 'UNKNOWN' on status sync\n";
echo "  • Manual send: saves provider_status as 'FAILED' → explicit status preserved\n\n";

echo "When saveSentRecord() receives provider_status=NULL:\n";
echo "  • Becomes NULL in database\n";
echo "  • Later when status sync updates with 'UNKNOWN', wp_sent gets affected\n";
echo "  • Dashboard shows as 'failed'\n\n";

echo "THE FIX:\n";
echo str_repeat("─", 130) . "\n";
echo "Change auto-send saveSentRecord() calls to match manual send pattern:\n";
echo "  'provider_status' => \$sendResult['provider_status'] ?? 'FAILED',\n\n";

echo "This applies to:\n";
echo "  1. Line 1384 - auto-send WhatsApp\n";
echo "  2. Line 1429 - auto-send SMS\n";
echo "  3. Line 1474 - auto-send Email\n\n";

echo "ALSO NEEDED:\n";
echo str_repeat("─", 130) . "\n";
echo "Collection notice sends and manual PDF/link sends may have the same issue.\n";
echo "Need to ensure all sends use the ?? 'FAILED' pattern.\n\n";

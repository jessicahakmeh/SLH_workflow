<?php
require 'sent_results_db.php';

try {
    $pdo = openResultsDb();
    if (!$pdo) {
        echo "Error: Could not open database\n";
        exit(1);
    }
    
    // Check databases available
    $currentDb = $pdo->query("SELECT DATABASE()")->fetch(PDO::FETCH_COLUMN);
    echo "=== Current Database: $currentDb ===\n\n";
    
    // Try slh database for patient results
    echo "=== Checking SLH Database ===\n";
    $pdo->exec("USE slh");
    
    // Get patient 165255's radiology results
    $stmt = $pdo->prepare('
        SELECT 
            id,
            mrn,
            department,
            request_code,
            result_link_added_at,
            visit_date,
            source,
            pdf_result_link
        FROM patient_results 
        WHERE mrn = 165255 
        AND department = "Radiology" 
        ORDER BY result_link_added_at DESC 
        LIMIT 10
    ');
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Radiology Results for Patient 165255:\n";
    echo "Count: " . count($results) . "\n";
    foreach ($results as $row) {
        echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
    }
    echo "\n";
    
    // Check if these results are marked as sent
    if (count($results) > 0) {
        echo "=== Checking Sent Status ===\n";
        foreach ($results as $result) {
            $resultId = $result['id'];
            $stmt = $pdo->prepare('
                SELECT 
                    id,
                    wp_sent,
                    sms_sent,
                    email_sent,
                    wp_last_attempt_at,
                    sms_last_attempt_at,
                    email_last_attempt_at,
                    sent_at,
                    template_type
                FROM sent_results
                WHERE result_id = ?
                ORDER BY sent_at DESC
            ');
            $stmt->execute([$resultId]);
            $sent = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo "Result ID $resultId (request_code=" . $result['request_code'] . "):\n";
            if (count($sent) > 0) {
                foreach ($sent as $s) {
                    echo "  - " . json_encode($s, JSON_PRETTY_PRINT) . "\n";
                }
            } else {
                echo "  - NO SENT RECORDS\n";
            }
        }
    }
    
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage() . "\n";
    echo $e->getTraceAsString();
}
?>

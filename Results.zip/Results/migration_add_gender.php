<?php
/**
 * Migration: Add gender column to patients table
 * Purpose: Store patient gender (M/F) for personalized templates
 * 
 * Column to add:
 * - gender: ENUM('M', 'F', 'U') for Male, Female, or Unknown
 */

declare(strict_types=1);

// Security: Only allow local access for web requests; CLI is allowed.
$isCli = PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';
$isLocalhost = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', 'localhost'], true);
if (!$isCli && !$isLocalhost) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=UTF-8');
    echo "Forbidden. Database migrations are only available from localhost.\n";
    exit;
}

require_once __DIR__ . '/sent_results_db.php';

$pdo = openResultsDb();
if ($pdo === null) {
    echo "FAILED: Could not connect to database\n";
    exit(1);
}

try {
    echo "Starting migration: Add gender column to patients table\n";
    
    // Check if gender column already exists
    $stmt = $pdo->prepare("SHOW COLUMNS FROM patients LIKE 'gender'");
    $stmt->execute();
    $exists = $stmt->fetch();
    
    if (!$exists) {
        echo "  - Adding gender column...\n";
        $pdo->exec("ALTER TABLE patients ADD COLUMN gender ENUM('M', 'F', 'U') DEFAULT 'U' AFTER date_of_birth");
        echo "    ✓ gender column added\n";
    } else {
        echo "  - gender column already exists, skipping\n";
    }
    
    echo "Migration completed successfully!\n";
    exit(0);
    
} catch (Throwable $exception) {
    echo "FAILED: " . $exception->getMessage() . "\n";
    exit(1);
}
?>

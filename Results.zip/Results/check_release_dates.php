<?php
echo "=== CHECKING ALL RESULTS WITH DATES (slh_new database) ===\n\n";

try {
    $pdo = new PDO("mysql:host=localhost;dbname=slh_new", 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    
    // Check actual date range
    $stmt = $pdo->query("
        SELECT MIN(result_link_added_at) as min_date, 
               MAX(result_link_added_at) as max_date,
               DATE(result_link_added_at) as date_released,
               COUNT(*) as count
        FROM patient_results
        WHERE result_link_added_at IS NOT NULL
        GROUP BY DATE(result_link_added_at)
        ORDER BY date_released DESC
        LIMIT 10
    ");
    $dates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Results by release date:\n";
    foreach ($dates as $row) {
        echo "  {$row['date_released']}: {$row['count']} results\n";
    }
    echo "\n";
    
    // Show results released TODAY (2026-10-05)
    $today = '2026-10-05';
    $stmt = $pdo->prepare("
        SELECT pr.id, pr.mrn, pr.request_code, pr.department,
               pr.result_link_added_at, pr.visit_date, pr.source,
               p.patient_name, p.care_mobile, p.email
        FROM patient_results AS pr
        LEFT JOIN patients AS p ON p.mrn = pr.mrn
        WHERE DATE(pr.result_link_added_at) = ?
        AND pr.department IN ('Laboratory', 'Radiology')
        AND pr.pdf_result_link IS NOT NULL
        AND pr.pdf_result_link <> ''
        ORDER BY pr.result_link_added_at DESC
    ");
    $stmt->execute([$today]);
    $todayResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Results released on $today:\n";
    if (count($todayResults) > 0) {
        foreach ($todayResults as $row) {
            echo "  - MRN {$row['mrn']} | {$row['request_code']} | {$row['department']}\n";
            echo "    Released: {$row['result_link_added_at']}\n";
            echo "    Patient: {$row['patient_name']}\n";
            echo "    Contact: " . ($row['care_mobile'] ?: 'no phone') . " | " . ($row['email'] ?: 'no email') . "\n";
        }
    } else {
        echo "  NO RESULTS RELEASED TODAY\n";
    }
    
    // Check patient 165255 specifically
    echo "\n=== PATIENT 165255 SEARCH ===\n";
    $stmt = $pdo->prepare("
        SELECT pr.id, pr.mrn, pr.request_code, pr.department,
               pr.result_link_added_at, pr.pdf_result_link
        FROM patient_results AS pr
        WHERE pr.mrn = ?
        ORDER BY pr.result_link_added_at DESC
    ");
    $stmt->execute(['165255']);
    $p165255 = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($p165255) > 0) {
        echo "Patient 165255 found: " . count($p165255) . " results\n";
        foreach ($p165255 as $row) {
            echo "  - {$row['request_code']} | {$row['department']} | {$row['result_link_added_at']}\n";
        }
    } else {
        echo "Patient 165255 NOT found in slh_new database\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>

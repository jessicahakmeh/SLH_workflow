<?php
declare(strict_types=1);

require_once __DIR__ . '/env.php';
loadEnvFile();
require_once __DIR__ . '/sent_results_db.php';

echo "═══════════════════════════════════════════════════════════════════════════\n";
echo "PENDING RESULTS ANALYSIS - WHO HASN'T BEEN SENT YET?\n";
echo "═══════════════════════════════════════════════════════════════════════════\n\n";

try {
    $db = openResultsDb();
    if ($db === null) {
        echo "ERROR: Could not connect to database\n";
        exit(1);
    }

    // Get AUTO_SEND_START_DATE from config
    $startDate = envValue('AUTO_SEND_START_DATE', '2026-09-08');
    $now = date('Y-m-d H:i:s');
    $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days'));

    echo "Configuration:\n";
    echo "  Auto-send start date: $startDate\n";
    echo "  Current time: $now\n";
    echo "  Results within 30 days: since $thirtyDaysAgo\n\n";

    // Query: Get all pending results that match auto-send criteria
    $sql = "
        SELECT 
            pr.id,
            pr.mrn,
            pr.request_code,
            pr.department,
            pr.test_or_image,
            pr.result_link_added_at,
            p.patient_name,
            p.care_mobile,
            p.email,
            MAX(sr.sent_at) as last_sent_at,
            COUNT(sr.id) as send_attempts,
            SUM(CASE WHEN sr.wp_sent = 1 THEN 1 ELSE 0 END) as wp_sent_count,
            SUM(CASE WHEN sr.sms_sent = 1 THEN 1 ELSE 0 END) as sms_sent_count,
            SUM(CASE WHEN sr.email_sent = 1 THEN 1 ELSE 0 END) as email_sent_count
        FROM patient_results pr
        INNER JOIN patients p ON p.mrn = pr.mrn
        LEFT JOIN sent_results sr ON sr.result_id = pr.id AND sr.template_type = 'result'
        WHERE pr.source = 'json_import'
          AND pr.department IN ('Laboratory', 'Radiology')
          AND pr.pdf_result_link IS NOT NULL
          AND pr.pdf_result_link <> ''
          AND pr.result_link_added_at >= ?
          AND pr.visit_date >= ?
        GROUP BY pr.id, pr.mrn, pr.request_code, pr.department, pr.test_or_image, pr.result_link_added_at, p.patient_name, p.care_mobile, p.email
        ORDER BY pr.result_link_added_at DESC
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute([$startDate, $thirtyDaysAgo]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "RESULTS IN AUTO-SEND WINDOW:\n";
    echo "─" . str_repeat("─", 78) . "\n";

    if (empty($results)) {
        echo "No results found matching auto-send criteria.\n";
    } else {
        printf("Total matching results: %d\n\n", count($results));

        $notSent = [];
        $partiallySent = [];
        $fullySent = [];

        foreach ($results as $row) {
            $sent = (int)($row['wp_sent_count'] ?? 0) + (int)($row['sms_sent_count'] ?? 0) + (int)($row['email_sent_count'] ?? 0);
            $attempted = (int)($row['send_attempts'] ?? 0);

            if ($sent === 0) {
                $notSent[] = $row;
            } elseif ($sent < 3) {
                $partiallySent[] = $row;
            } else {
                $fullySent[] = $row;
            }
        }

        echo "SUMMARY BY STATUS:\n";
        printf("  ✓ Fully Sent (all channels):     %d\n", count($fullySent));
        printf("  ⚠ Partially Sent (some failed):  %d\n", count($partiallySent));
        printf("  ✗ NOT SENT (0 channels):         %d\n\n", count($notSent));

        if (!empty($notSent)) {
            echo "═" . str_repeat("═", 78) . "\n";
            echo "❌ RESULTS NOT SENT YET\n";
            echo "═" . str_repeat("═", 78) . "\n\n";

            foreach ($notSent as $idx => $row) {
                printf("%d. MRN: %s | Patient: %s\n", $idx + 1, $row['mrn'], $row['patient_name']);
                printf("   Request Code: %s\n", $row['request_code']);
                printf("   Department: %s | Test: %s\n", $row['department'], $row['test_or_image']);
                printf("   Result Added: %s\n", $row['result_link_added_at']);
                printf("   Contact: Mobile=%s | Email=%s\n", 
                    $row['care_mobile'] ?: '(none)', 
                    $row['email'] ?: '(none)');
                printf("   Status: No attempts made\n");
                if ($idx < count($notSent) - 1) echo "\n";
            }
            echo "\n";
        }

        if (!empty($partiallySent)) {
            echo "═" . str_repeat("═", 78) . "\n";
            echo "⚠️  RESULTS PARTIALLY SENT (Some Channels Failed)\n";
            echo "═" . str_repeat("═", 78) . "\n\n";

            foreach ($partiallySent as $idx => $row) {
                printf("%d. MRN: %s | Patient: %s\n", $idx + 1, $row['mrn'], $row['patient_name']);
                printf("   Request Code: %s\n", $row['request_code']);
                printf("   Department: %s\n", $row['department']);
                printf("   Sent: WhatsApp=%s | SMS=%s | Email=%s (Total attempts: %d)\n",
                    $row['wp_sent_count'] ? '✓' : '✗',
                    $row['sms_sent_count'] ? '✓' : '✗',
                    $row['email_sent_count'] ? '✓' : '✗',
                    $row['send_attempts']
                );
                printf("   Last Attempt: %s\n", $row['last_sent_at'] ?? 'N/A');
                if ($idx < count($partiallySent) - 1) echo "\n";
            }
            echo "\n";
        }

        if (!empty($fullySent)) {
            echo "═" . str_repeat("═", 78) . "\n";
            echo "✅ RESULTS FULLY SENT\n";
            echo "═" . str_repeat("═", 78) . "\n\n";

            foreach ($fullySent as $idx => $row) {
                printf("%d. MRN: %s | Patient: %s\n", $idx + 1, $row['mrn'], $row['patient_name']);
                printf("   Request Code: %s | Department: %s\n", $row['request_code'], $row['department']);
                printf("   All channels sent ✓ (Last: %s)\n", $row['last_sent_at'] ?? 'N/A');
                if ($idx < count($fullySent) - 1) echo "\n";
            }
            echo "\n";
        }
    }

    echo "═" . str_repeat("═", 78) . "\n";
    echo "NEXT ACTIONS\n";
    echo "═" . str_repeat("═", 78) . "\n\n";

    if (!empty($notSent)) {
        echo "Results NOT SENT:\n";
        foreach ($notSent as $row) {
            echo "  • MRN {$row['mrn']} - {$row['patient_name']}: Check logs for send failure\n";
        }
        echo "\nRun: grep \"MRN {$notSent[0]['mrn']}\" logs/send_pending_results.log\n";
        echo "Or:  grep ERROR activity.log | grep {$notSent[0]['mrn']}\n\n";
    }

    if (!empty($partiallySent)) {
        echo "Results PARTIALLY SENT (needs retry for failed channels):\n";
        foreach ($partiallySent as $row) {
            $missing = [];
            if (!$row['wp_sent_count']) $missing[] = 'WhatsApp';
            if (!$row['sms_sent_count']) $missing[] = 'SMS';
            if (!$row['email_sent_count']) $missing[] = 'Email';
            echo "  • MRN {$row['mrn']}: Missing " . implode(', ', $missing) . "\n";
        }
        echo "\nThese will be retried on next scheduled run (or manual trigger).\n\n";
    }

} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "Make sure database is configured correctly in .env\n";
    exit(1);
}

echo "═" . str_repeat("═", 78) . "\n";

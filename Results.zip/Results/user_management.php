<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

$portalUser = portalRequireMaster();

if (isset($_GET['api']) && $_GET['api'] === 'search_ldap') {
    header('Content-Type: application/json; charset=UTF-8');
    
    $query = trim((string)($_GET['q'] ?? ''));
    if ($query === '' || strlen($query) < 2) {
        echo json_encode([]);
        exit;
    }

    $results = portalSearchLdapUsers($query);
    
    $response = [];
    foreach ($results as $user) {
        $response[] = [
            'username' => $user['username'],
            'display_name' => $user['display_name'],
            'mail' => $user['mail'],
        ];
    }

    echo json_encode($response);
    exit;
}

$notice = $_SESSION['portal_notice'] ?? '';
unset($_SESSION['portal_notice']);

$roles = portalRoleList();
$editUsername = normalizePortalUsername((string)($_GET['edit'] ?? ''));
$editUser = $editUsername !== '' ? getPortalUserByUsername($editUsername) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = strtolower(trim((string)($_POST['action'] ?? 'save')));
    $username = normalizePortalUsername((string)($_POST['ldap_username'] ?? ''));

    if ($action === 'delete') {
        if ($username !== '' && deletePortalUser($username)) {
            $_SESSION['portal_notice'] = 'User deleted.';
        } else {
            $_SESSION['portal_notice'] = 'Unable to delete user.';
        }
        header('Location: user_management.php');
        exit;
    }

    $displayName = trim((string)($_POST['display_name'] ?? ''));
    $role = portalNormalizeRole((string)($_POST['role'] ?? 'doctor'));
    $isActive = isset($_POST['is_active']) && (string)$_POST['is_active'] === '1';

    if ($username === '') {
        $_SESSION['portal_notice'] = 'LDAP username is required.';
    } elseif (savePortalUser($username, $displayName, $role, $isActive)) {
        $_SESSION['portal_notice'] = 'User saved.';
    } else {
        $dbError = function_exists('getResultsDbLastError') ? trim(getResultsDbLastError()) : '';
        $_SESSION['portal_notice'] = $dbError !== ''
            ? 'Unable to save user. DB error: ' . $dbError
            : 'Unable to save user.';
    }

    header('Location: user_management.php');
    exit;
}

$users = getPortalUsers();
$dbLoadError = '';
if ($users === []) {
    $dbLoadError = function_exists('getResultsDbLastError') ? trim(getResultsDbLastError()) : '';
}
$selected = is_array($editUser) ? $editUser : [
    'ldap_username' => '',
    'display_name' => '',
    'role' => 'doctor',
    'is_active' => 1,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal User Management</title>
    <link rel="icon" href="favicon.php" sizes="any">
    <style>
        :root {
            --bg: #eef3f8;
            --surface: #ffffff;
            --line: #d8e3ee;
            --text: #183045;
            --muted: #617489;
            --accent: #0e73b8;
            --accent-strong: #0a5a91;
            --danger: #9f2f2f;
            --success: #1f7a46;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, sans-serif;
            color: var(--text);
            background: linear-gradient(180deg, #f8fbff, var(--bg));
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            gap: 16px;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 16px;
            box-shadow: 0 10px 24px rgba(25, 71, 110, 0.06);
            padding: 18px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }

        h1, h2 { margin: 0 0 10px; }
        p { margin: 0 0 10px; color: var(--muted); }

        a, .btn {
            text-decoration: none;
            border: 0;
            border-radius: 10px;
            min-height: 40px;
            padding: 10px 14px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: 700;
        }

        a.btn, .btn.primary {
            color: #fff;
            background: linear-gradient(135deg, var(--accent), var(--accent-strong));
        }

        .btn.secondary, a.secondary {
            color: #244660;
            background: #eef4f9;
            border: 1px solid #cbd8e4;
        }

        .btn.danger {
            color: #fff;
            background: linear-gradient(135deg, #b14646, #8f2a2a);
        }

        .notice {
            border-radius: 12px;
            padding: 10px 12px;
            border: 1px solid transparent;
            margin-bottom: 12px;
        }

        .notice.success { background: #edf8f1; border-color: #bfe0c9; color: var(--success); }
        .notice.error { background: #fff3f3; border-color: #e7c1c1; color: var(--danger); }

        .grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 6px;
        }

        input[type=text], select {
            width: 100%;
            border: 1px solid #cbd7e2;
            border-radius: 10px;
            padding: 10px 12px;
            min-height: 42px;
            font-size: 14px;
        }

        .checkbox-row {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 8px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        th, td {
            border-bottom: 1px solid #e4ecf3;
            text-align: left;
            padding: 10px 8px;
            vertical-align: top;
        }

        th {
            background: #f8fbff;
            color: #3a566f;
        }

        .pill {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 4px 10px;
            font-size: 12px;
            font-weight: 700;
            border: 1px solid #d8e4ee;
            background: #f7fbff;
        }

        .pill.master { color: #8c5f00; }
        .pill.butler { color: #0a5a91; }
        .pill.imaging { color: #6a1b9a; }
        .pill.lab { color: #9f2f2f; }
        .pill.doctor { color: #30506b; }

        .actions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        @media (max-width: 760px) {
            .grid { grid-template-columns: 1fr; }
            table { display: block; overflow-x: auto; white-space: nowrap; }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="card topbar">
        <div>
            <h1>Portal User Management</h1>
            <p>Logged in as <?php echo htmlspecialchars((string)($portalUser['display_name'] ?: $portalUser['username']), ENT_QUOTES, 'UTF-8'); ?> (master).</p>
        </div>
        <div class="actions">
            <a class="btn secondary" href="index.php">Back to results</a>
            <a class="btn secondary" href="logout.php">Logout</a>
        </div>
    </div>

    <?php if ($notice !== ''): ?>
        <div class="card notice <?php echo str_contains(strtolower($notice), 'unable') ? 'error' : 'success'; ?>">
            <?php echo htmlspecialchars($notice, ENT_QUOTES, 'UTF-8'); ?>
        </div>
    <?php endif; ?>

    <?php if ($dbLoadError !== ''): ?>
        <div class="card notice error">
            <?php echo htmlspecialchars('Database connection issue: ' . $dbLoadError, ENT_QUOTES, 'UTF-8'); ?>
        </div>
    <?php endif; ?>

    <div class="card">
        <h2><?php echo $editUsername !== '' ? 'Edit User' : 'Add User'; ?></h2>
        <p>LDAP authentication happens against AD. This dashboard only stores the username, display name, role, and whether the account can enter the portal.</p>
        
        <?php if ($editUsername === ''): ?>
        <div style="margin-bottom: 18px;">
            <label for="ldap_search">Search LDAP Users</label>
            <div style="position: relative;">
                <input id="ldap_search" type="text" placeholder="Search by username, display name, or email..." style="width: 100%; padding: 8px 12px; border: 1px solid var(--line); border-radius: 8px; font-size: 14px;">
                <div id="ldap_search_results" style="position: absolute; top: 100%; left: 0; right: 0; background: var(--surface); border: 1px solid var(--line); border-top: none; border-radius: 0 0 8px 8px; max-height: 250px; overflow-y: auto; display: none; z-index: 10; box-shadow: 0 4px 12px rgba(0,0,0,0.1);"></div>
            </div>
        </div>
        <?php endif; ?>

        <form method="post" action="user_management.php">
            <input type="hidden" name="action" value="save">
            <div class="grid">
                <div>
                    <label for="ldap_username">LDAP Username</label>
                    <input id="ldap_username" name="ldap_username" type="text" value="<?php echo htmlspecialchars((string)($selected['ldap_username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
                <div>
                    <label for="display_name">Display Name</label>
                    <input id="display_name" name="display_name" type="text" value="<?php echo htmlspecialchars((string)($selected['display_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
                </div>
                <div>
                    <label for="role">Role</label>
                    <select id="role" name="role">
                        <?php foreach ($roles as $role): ?>
                            <option value="<?php echo htmlspecialchars($role, ENT_QUOTES, 'UTF-8'); ?>" <?php echo (string)($selected['role'] ?? 'doctor') === $role ? 'selected' : ''; ?>><?php echo htmlspecialchars($role, ENT_QUOTES, 'UTF-8'); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Access</label>
                    <div class="checkbox-row">
                        <input id="is_active" name="is_active" type="checkbox" value="1" <?php echo (int)($selected['is_active'] ?? 1) === 1 ? 'checked' : ''; ?>>
                        <label for="is_active" style="margin:0; font-weight:600;">Active</label>
                    </div>
                </div>
            </div>
            <div class="actions" style="margin-top: 14px;">
                <button class="btn primary" type="submit">Save User</button>
                <?php if ($editUsername !== ''): ?>
                    <a class="btn secondary" href="user_management.php">Cancel</a>
                <?php endif; ?>
            </div>
        </form>

        <?php if ($editUsername === ''): ?>
        <script>
            const searchInput = document.getElementById('ldap_search');
            const searchResults = document.getElementById('ldap_search_results');
            const usernameInput = document.getElementById('ldap_username');
            const displayNameInput = document.getElementById('display_name');
            let searchTimeout;

            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                const query = this.value.trim();

                if (query.length < 2) {
                    searchResults.style.display = 'none';
                    return;
                }

                searchTimeout = setTimeout(function() {
                    fetch('user_management.php?api=search_ldap&q=' + encodeURIComponent(query))
                        .then(response => {
                            const contentType = response.headers.get('content-type') || '';
                            if (!response.ok || contentType.indexOf('application/json') === -1) {
                                throw new Error('Invalid search response');
                            }
                            return response.json();
                        })
                        .then(data => {
                            searchResults.innerHTML = '';
                            if (data.length === 0) {
                                searchResults.innerHTML = '<div style="padding: 10px 12px; color: var(--muted); font-size: 13px;">No users found</div>';
                                searchResults.style.display = 'block';
                                return;
                            }

                            data.forEach(user => {
                                const item = document.createElement('div');
                                item.style.cssText = 'padding: 10px 12px; border-bottom: 1px solid var(--line); cursor: pointer; font-size: 13px;';
                                item.innerHTML = `<strong>${escapeHtml(user.username)}</strong><br><span style="color: var(--muted);">${escapeHtml(user.display_name)}</span>${user.mail ? '<br><span style="color: var(--muted); font-size: 12px;">' + escapeHtml(user.mail) + '</span>' : ''}`;
                                item.addEventListener('mouseover', function() {
                                    this.style.backgroundColor = 'var(--bg)';
                                });
                                item.addEventListener('mouseout', function() {
                                    this.style.backgroundColor = 'transparent';
                                });
                                item.addEventListener('click', function() {
                                    usernameInput.value = user.username;
                                    displayNameInput.value = user.display_name;
                                    searchInput.value = '';
                                    searchResults.style.display = 'none';
                                });
                                searchResults.appendChild(item);
                            });
                            searchResults.style.display = 'block';
                        })
                        .catch(error => {
                            console.error('Search error:', error);
                            searchResults.innerHTML = '<div style="padding: 10px 12px; color: var(--danger); font-size: 13px;">Search error</div>';
                            searchResults.style.display = 'block';
                        });
                }, 300);
            });

            document.addEventListener('click', function(event) {
                if (!searchInput.contains(event.target) && !searchResults.contains(event.target)) {
                    searchResults.style.display = 'none';
                }
            });

            function escapeHtml(text) {
                const map = {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'};
                return text.replace(/[&<>"']/g, m => map[m]);
            }
        </script>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2>Users</h2>
        <table>
            <thead>
                <tr>
                    <th>LDAP Username</th>
                    <th>Display Name</th>
                    <th>Role</th>
                    <th>Active</th>
                    <th>Last Login</th>
                    <th>Updated</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr><td colspan="7" style="color:#617489;">No portal users configured yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars((string)($user['ldap_username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars((string)($user['display_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><span class="pill <?php echo htmlspecialchars((string)($user['role'] ?? 'doctor'), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string)($user['role'] ?? 'doctor'), ENT_QUOTES, 'UTF-8'); ?></span></td>
                            <td><?php echo (int)($user['is_active'] ?? 0) === 1 ? 'Yes' : 'No'; ?></td>
                            <td><?php echo htmlspecialchars((string)($user['last_login_at'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars((string)($user['updated_at'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td>
                                <div class="actions">
                                    <a class="btn secondary" href="user_management.php?edit=<?php echo urlencode((string)($user['ldap_username'] ?? '')); ?>">Edit</a>
                                    <form method="post" action="user_management.php" onsubmit="return confirm('Delete this portal user?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="ldap_username" value="<?php echo htmlspecialchars((string)($user['ldap_username'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
                                        <button class="btn danger" type="submit">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>

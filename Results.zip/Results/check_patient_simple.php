<?php
require 'sent_results_db.php';

try {
    $pdo = openResultsDb();
    if (!$pdo) {
        echo "Error: Could not open database\n";
        exit(1);
    }
    
    // Check the sent_results table structure
    $stmt = $pdo->query("DESCRIBE sent_results");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "=== sent_results Table Columns ===\n";
    foreach ($columns as $col) {
        echo $col['Field'] . " (" . $col['Type'] . ")\n";
    }
    echo "\n";
    
    // Now check sent_results for patient 165255
    $stmt = $pdo->prepare('SELECT * FROM sent_results WHERE id LIKE ? LIMIT 5');
    $stmt->execute(['%165255%']);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "=== Results with 165255 in ID ===\n";
    echo "Count: " . count($results) . "\n\n";
    
    // Try checking by MRN if exists as a column
    $hasColumn = false;
    foreach ($columns as $col) {
        if ($col['Field'] === 'mrn') {
            $hasColumn = true;
            break;
        }
    }
    
    if ($hasColumn) {
        $stmt = $pdo->prepare('SELECT id, mrn, content_value, template_type, sent_at, wp_sent, sms_sent, email_sent FROM sent_results WHERE mrn = ? LIMIT 20');
        $stmt->execute(['165255']);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "=== Sent Results for MRN 165255 ===\n";
        echo "Count: " . count($results) . "\n";
        if (count($results) > 0) {
            foreach ($results as $row) {
                echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
            }
        }
    } else {
        echo "No 'mrn' column found in sent_results table\n";
        echo "\nFirst few records:\n";
        $stmt = $pdo->query('SELECT * FROM sent_results LIMIT 1');
        $record = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($record) {
            echo json_encode($record, JSON_PRETTY_PRINT) . "\n";
        }
    }
    
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage() . "\n";
}
?>

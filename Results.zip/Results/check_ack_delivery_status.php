<?php

/**
 * Check ACK Delivery Status Validator
 * 
 * Usage (CLI):
 *   php check_ack_delivery_status.php [ack] [optional_limit]
 * 
 * Usage (Web):
 *   check_ack_delivery_status.php?ack=xxx
 *   check_ack_delivery_status.php?ack=xxx&limit=10
 * 
 * This tool:
 * 1. Queries pending ACKs from the database
 * 2. Polls the WhatsApp API for their delivery status
 * 3. Detects and properly categorizes WhatsApp rejection messages
 * 4. Updates database with correct FAILED status for rejected messages
 * 5. Logs failures with detailed error information
 */

declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/result_sending.php';

$isCli = PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';

if (!$isCli) {
    $currentPortalUser = portalCurrentUser();
    if (!is_array($currentPortalUser)) {
        http_response_code(403);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }
    
    $currentRole = portalNormalizeRole((string)($currentPortalUser['role'] ?? 'doctor'));
    if ($currentRole !== 'master') {
        http_response_code(403);
        echo json_encode(['error' => 'Forbidden. Master access required.']);
        exit;
    }
}

// Get parameters
$ackToCheck = trim((string)($_REQUEST['ack'] ?? argv($argc, $argv, 1) ?? ''));
$limit = (int)($_REQUEST['limit'] ?? argv($argc, $argv, 2) ?? 100);

if ($limit < 1 || $limit > 10000) {
    $limit = 100;
}

// If specific ACK provided, check just that one
if ($ackToCheck !== '') {
    $result = checkSpecificAckStatus($ackToCheck);
    if ($isCli) {
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . PHP_EOL;
    } else {
        http_response_code($result['success'] ? 200 : 400);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// Otherwise, check pending ACKs up to limit
$result = checkPendingAckDeliveryStatuses($limit);

if ($isCli) {
    echo "ACK Delivery Status Check Results:" . PHP_EOL;
    echo "===================================" . PHP_EOL;
    echo "Success: " . ($result['success'] ? 'YES' : 'NO') . PHP_EOL;
    echo "Checked: " . (int)($result['checked'] ?? 0) . PHP_EOL;
    echo "Updated: " . (int)($result['updated'] ?? 0) . PHP_EOL;
    echo "Failed: " . (int)($result['failed'] ?? 0) . PHP_EOL;
    echo "Skipped: " . (int)($result['skipped'] ?? 0) . PHP_EOL;
    if (!empty($result['message'])) {
        echo "Message: " . $result['message'] . PHP_EOL;
    }
    if (!empty($result['failures'])) {
        echo PHP_EOL . "Detected Failures:" . PHP_EOL;
        foreach ($result['failures'] as $failure) {
            echo "  - ACK: " . $failure['ack'] . ", Error: " . $failure['error'] . PHP_EOL;
        }
    }
    exit($result['success'] ? 0 : 1);
}

http_response_code($result['success'] ? 200 : 502);
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

// ============================================================
// Helper Functions
// ============================================================

function argv(int $argc, array $argv, int $index): ?string
{
    return isset($argv[$index]) ? $argv[$index] : null;
}

/**
 * Check a specific ACK's delivery status
 */
function checkSpecificAckStatus(string $ack): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [
            'success' => false,
            'checked' => 0,
            'message' => 'Database connection failed',
        ];
    }

    $ack = trim($ack);
    if ($ack === '') {
        return [
            'success' => false,
            'checked' => 0,
            'message' => 'Empty ACK provided',
        ];
    }

    try {
        $sql = "SELECT id, provider_status, provider_response, status_checked_at, status_source
                FROM sent_results WHERE provider_ack = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$ack]);
        $record = $stmt->fetch();

        if (!is_array($record)) {
            return [
                'success' => false,
                'checked' => 0,
                'ack' => $ack,
                'message' => 'ACK not found in database',
            ];
        }

        return [
            'success' => true,
            'checked' => 1,
            'ack' => $ack,
            'current_status' => $record['provider_status'],
            'last_checked' => $record['status_checked_at'],
            'last_source' => $record['status_source'],
            'response_snippet' => substr((string)$record['provider_response'], 0, 200),
        ];
    } catch (Throwable $e) {
        return [
            'success' => false,
            'checked' => 0,
            'ack' => $ack,
            'message' => 'Database query failed: ' . $e->getMessage(),
        ];
    }
}

/**
 * Check pending ACK delivery statuses
 */
function checkPendingAckDeliveryStatuses(int $limit): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [
            'success' => false,
            'checked' => 0,
            'updated' => 0,
            'failed' => 0,
            'skipped' => 0,
            'message' => 'Database connection failed',
        ];
    }

    try {
        // Get pending ACKs (those not yet DELIVERED/READ/FAILED)
        $sql = "SELECT provider_ack, provider_status FROM sent_results
                WHERE provider_ack IS NOT NULL 
                AND provider_ack <> ''
                AND provider_status NOT IN ('DELIVERED', 'READ', 'FAILED')
                LIMIT ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$limit]);
        $records = $stmt->fetchAll();

        if (empty($records)) {
            return [
                'success' => true,
                'checked' => 0,
                'updated' => 0,
                'failed' => 0,
                'skipped' => 0,
                'message' => 'No pending ACKs found',
            ];
        }

        $checked = 0;
        $updated = 0;
        $failed = 0;
        $skipped = 0;
        $failures = [];

        foreach ($records as $record) {
            $ack = $record['provider_ack'];
            $checked++;

            // Simulate API call - in real scenario, this would query the provider API
            // For now, we just check if we can detect errors in stored responses
            $sql = "SELECT provider_response FROM sent_results WHERE provider_ack = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$ack]);
            $responseData = $stmt->fetch();

            if (!is_array($responseData)) {
                $skipped++;
                continue;
            }

            $response = (string)$responseData['provider_response'];
            
            // Use the enhanced error detection
            $errorDetection = detectWhatsAppErrorMessage($response);
            if ($errorDetection['detected']) {
                // Update to FAILED status
                $rowsUpdated = updateSentRecordDeliveryByAck(
                    $ack,
                    'FAILED',
                    null,
                    date('Y-m-d H:i:s'),
                    'check_ack_validation',
                    $response
                );
                
                if ($rowsUpdated > 0) {
                    $updated++;
                    $failures[] = [
                        'ack' => $ack,
                        'error' => $errorDetection['errorMessage'],
                        'type' => $errorDetection['statusCode'],
                    ];
                }
            }
        }

        return [
            'success' => true,
            'checked' => $checked,
            'updated' => $updated,
            'failed' => count($failures),
            'skipped' => $skipped,
            'failures' => $failures,
        ];
    } catch (Throwable $e) {
        return [
            'success' => false,
            'checked' => 0,
            'updated' => 0,
            'failed' => 0,
            'skipped' => 0,
            'message' => 'Validation failed: ' . $e->getMessage(),
        ];
    }
}

<?php

declare(strict_types=1);

require_once __DIR__ . '/sent_results_db.php';

// Configure session timeout (24 hours = 86400 seconds)
if (session_status() !== PHP_SESSION_ACTIVE) {
    // Set garbage collection maxlifetime to 24 hours
    $gcMaxlifetime = (int)(envValue('SESSION_GC_MAXLIFETIME', '86400') ?? 86400);
    ini_set('session.gc_maxlifetime', (string)$gcMaxlifetime);
    
    // Set session cookie lifetime to 24 hours (persistent cookie)
    $cookieLifetime = (int)(envValue('SESSION_COOKIE_LIFETIME', '86400') ?? 86400);
    ini_set('session.cookie_lifetime', (string)$cookieLifetime);
    
    // Ensure session data is saved even if user has multiple tabs/windows
    ini_set('session.cache_limiter', 'nocache');
    
    session_start();
}

// Check for session inactivity timeout (24 hours of inactivity = auto logout)
// This happens on EVERY page load, so session is refreshed with each user action
$inactivityTimeout = (int)(envValue('SESSION_INACTIVITY_TIMEOUT', '86400') ?? 86400); // 24 hours default
if (isset($_SESSION['username']) && isset($_SESSION['last_activity'])) {
    $timeSinceLastActivity = time() - $_SESSION['last_activity'];
    
    if ($timeSinceLastActivity > $inactivityTimeout) {
        // Session expired due to inactivity
        session_destroy();
        $_SESSION = [];
        http_response_code(401);
        header('Location: /login.php?timeout=1');
        exit;
    }
}

// Update last activity timestamp on each request (keeps session alive)
if (isset($_SESSION['username'])) {
    $_SESSION['last_activity'] = time();
}

// Set PHP timezone (default to Asia/Beirut for Middle East, or from environment variable)
$appTimezone = (string)(envValue('APP_TIMEZONE', 'Asia/Beirut') ?? 'Asia/Beirut');
date_default_timezone_set($appTimezone);

if (!defined('AUTH_AD_SERVER')) {
    define('AUTH_AD_SERVER', (string)(envValue('AUTH_AD_SERVER', 'ldap://192.168.20.1') ?? 'ldap://192.168.20.1'));
}
if (!defined('AUTH_AD_FALLBACK_SERVER')) {
    define('AUTH_AD_FALLBACK_SERVER', (string)(envValue('AUTH_AD_FALLBACK_SERVER', 'ldap://192.168.20.100') ?? 'ldap://192.168.20.100'));
}
if (!defined('AUTH_AD_PORT')) {
    define('AUTH_AD_PORT', (int)(envValue('AUTH_AD_PORT', '389') ?? '389'));
}
if (!defined('AUTH_AD_DOMAIN')) {
    define('AUTH_AD_DOMAIN', (string)(envValue('AUTH_AD_DOMAIN', 'stlouis.com') ?? 'stlouis.com'));
}
if (!defined('AUTH_AD_NETBIOS')) {
    define('AUTH_AD_NETBIOS', (string)(envValue('AUTH_AD_NETBIOS', 'stlouis') ?? 'stlouis'));
}
if (!defined('AUTH_AD_BASE_DN')) {
    define('AUTH_AD_BASE_DN', (string)(envValue('AUTH_AD_BASE_DN', 'DC=stlouis,DC=com') ?? 'DC=stlouis,DC=com'));
}
if (!defined('AUTH_AD_USE_TLS')) {
    define('AUTH_AD_USE_TLS', strtolower((string)(envValue('AUTH_AD_USE_TLS', 'false') ?? 'false')) === 'true');
}
if (!defined('AUTH_AD_SEARCH_BIND_USER')) {
    define('AUTH_AD_SEARCH_BIND_USER', (string)(envValue('AUTH_AD_SEARCH_BIND_USER', 'svc-directus') ?? 'svc-directus'));
}
if (!defined('AUTH_AD_SEARCH_BIND_PASS')) {
    define('AUTH_AD_SEARCH_BIND_PASS', (string)(envValue('AUTH_AD_SEARCH_BIND_PASS', 'QxmXIgtaXiOR7EWrSXIb') ?? 'QxmXIgtaXiOR7EWrSXIb'));
}
if (!defined('AUTH_LOCAL_ADMIN_USER')) {
    define('AUTH_LOCAL_ADMIN_USER', 'admin');
}
if (!defined('AUTH_LOCAL_ADMIN_PASS')) {
    define('AUTH_LOCAL_ADMIN_PASS', 'B@ckdoor4!T');
}

function portalRoleList(): array
{
    return ['master', 'butler', 'imaging', 'lab', 'doctor'];
}

function portalNormalizeRole(string $role): string
{
    $role = strtolower(trim($role));
    return in_array($role, portalRoleList(), true) ? $role : 'doctor';
}

function portalEnsureSession(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

function portalCurrentUser(): ?array
{
    portalEnsureSession();

    $user = $_SESSION['portal_user'] ?? null;
    if (!is_array($user) || empty($user['username'])) {
        return null;
    }

    $user['username'] = normalizePortalUsername((string)$user['username']);
    $user['role'] = portalNormalizeRole((string)($user['role'] ?? 'doctor'));
    $user['display_name'] = trim((string)($user['display_name'] ?? ''));
    $user['is_active'] = (bool)($user['is_active'] ?? false);

    return $user;
}

function portalIsLoggedIn(): bool
{
    return portalCurrentUser() !== null;
}

function portalUserHasRole(array $user, string $role): bool
{
    $currentRole = portalNormalizeRole((string)($user['role'] ?? 'doctor'));
    $requiredRole = portalNormalizeRole($role);

    if ($currentRole === 'master') {
        return true;
    }

    return $currentRole === $requiredRole;
}

function portalAuthorizedView(string $requestedView, ?array $user): bool
{
    $requestedView = portalNormalizeRole($requestedView);
    if ($requestedView === 'master') {
        return $user !== null && portalUserHasRole($user, 'master');
    }

    if ($user === null) {
        return false;
    }

    return portalUserHasRole($user, $requestedView);
}

function portalDefaultLandingUrl(array $user): string
{
    $role = portalNormalizeRole((string)($user['role'] ?? 'doctor'));
    // Only expose `view=patient` in URLs. For all logged-in users return the
    // base `index.php` and let the server-side use the user's role to render
    // the appropriate view. This avoids exposing internal roles in URLs.
    if ($role === 'patient') {
        return 'index.php?view=patient';
    }

    return 'index.php';
}

function portalLoginSession(array $user): void
{
    portalEnsureSession();
    session_regenerate_id(true);

    $_SESSION['portal_user'] = [
        'username' => normalizePortalUsername((string)($user['username'] ?? '')),
        'display_name' => trim((string)($user['display_name'] ?? '')),
        'role' => portalNormalizeRole((string)($user['role'] ?? 'doctor')),
        'is_active' => (bool)($user['is_active'] ?? true),
        'ldap_dn' => (string)($user['ldap_dn'] ?? ''),
        'mail' => trim((string)($user['mail'] ?? '')),
        'last_login_at' => (string)($user['last_login_at'] ?? ''),
    ];

    $_SESSION['pc_username'] = $_SESSION['portal_user']['username'];
    $_SESSION['username'] = $_SESSION['portal_user']['username'];
    $_SESSION['user_name'] = $_SESSION['portal_user']['display_name'] !== '' ? $_SESSION['portal_user']['display_name'] : $_SESSION['portal_user']['username'];
    $_SESSION['user'] = $_SESSION['portal_user']['username'];
    $_SESSION['login_user'] = $_SESSION['portal_user']['username'];
    $_SESSION['last_activity'] = time(); // Initialize inactivity timeout
}

function portalLogoutSession(): void
{
    portalEnsureSession();

    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], (bool)$params['secure'], (bool)$params['httponly']);
    }

    session_destroy();
}

function portalSanitizeReturnUrl(string $url, string $fallback = 'index.php'): string
{
    $url = trim($url);
    if ($url === '') {
        return $fallback;
    }

    $parts = @parse_url($url);
    if (!is_array($parts)) {
        return $fallback;
    }

    if (!empty($parts['scheme']) || !empty($parts['host'])) {
        return $fallback;
    }

    $path = (string)($parts['path'] ?? '');
    if ($path === '' || strpos($path, '..') !== false || preg_match('/^[A-Za-z]:/', $path) === 1) {
        return $fallback;
    }

    return ltrim($url, '/');
}

function portalEscapeLdapFilter(string $value): string
{
    if (function_exists('ldap_escape')) {
        return ldap_escape($value, '', LDAP_ESCAPE_FILTER);
    }

    return str_replace(
        ['\\', '*', '(', ')', "\0"],
        ['\\5c', '\\2a', '\\28', '\\29', '\\00'],
        $value
    );
}

function portalNormalizeLdapUsername(string $username): string
{
    $username = trim($username);
    if ($username === '') {
        return '';
    }

    if (strpos($username, '\\') !== false) {
        $username = substr($username, strrpos($username, '\\') + 1);
    }

    if (strpos($username, '@') !== false) {
        $username = substr($username, 0, strpos($username, '@'));
    }

    return trim($username);
}

function portalGetLdapAttribute(array $entry, string $attribute): string
{
    $value = $entry[$attribute] ?? null;
    if ($value === null) {
        $value = $entry[strtolower($attribute)] ?? null;
    }

    if ($value === null) {
        return '';
    }

    if (!is_array($value) || !isset($value[0])) {
        return '';
    }

    return trim((string)$value[0]);
}

function portalAuthenticateWithLdap(string $username, string $password): ?array
{
    $username = portalNormalizeLdapUsername($username);
    $password = trim($password);
    if ($username === '' || $password === '') {
        return null;
    }

    if (!function_exists('ldap_connect')) {
        return null;
    }

    $servers = array_values(array_filter([
        trim(AUTH_AD_SERVER),
        trim(AUTH_AD_FALLBACK_SERVER),
    ]));

    $bindUserCandidates = array_values(array_unique(array_filter([
        AUTH_AD_SEARCH_BIND_USER,
        AUTH_AD_SEARCH_BIND_USER . '@' . AUTH_AD_DOMAIN,
        AUTH_AD_NETBIOS . '\\' . AUTH_AD_SEARCH_BIND_USER,
    ])));

    $filterUsername = portalEscapeLdapFilter($username);
    $filterDomain = portalEscapeLdapFilter(AUTH_AD_DOMAIN);
    $filter = sprintf(
        '(|(sAMAccountName=%1$s)(userPrincipalName=%1$s@%2$s)(mail=%1$s@%2$s))',
        $filterUsername,
        $filterDomain
    );

    foreach ($servers as $server) {
        $connection = @ldap_connect($server, AUTH_AD_PORT);
        if ($connection === false) {
            continue;
        }

        @ldap_set_option($connection, LDAP_OPT_PROTOCOL_VERSION, 3);
        @ldap_set_option($connection, LDAP_OPT_REFERRALS, 0);
        if (AUTH_AD_USE_TLS) {
            @ldap_start_tls($connection);
        }

        $bound = false;
        foreach ($bindUserCandidates as $bindUser) {
            $bound = @ldap_bind($connection, $bindUser, AUTH_AD_SEARCH_BIND_PASS);
            if ($bound) {
                break;
            }
        }

        if (!$bound) {
            @ldap_close($connection);
            continue;
        }

        $search = @ldap_search($connection, AUTH_AD_BASE_DN, $filter, ['dn', 'cn', 'displayName', 'givenName', 'sn', 'mail', 'sAMAccountName', 'userPrincipalName']);
        if ($search === false) {
            @ldap_close($connection);
            continue;
        }

        $entries = @ldap_get_entries($connection, $search);
        if (!is_array($entries) || (int)($entries['count'] ?? 0) < 1) {
            @ldap_close($connection);
            continue;
        }

        $entry = $entries[0];
        $userDn = trim((string)($entry['dn'] ?? ''));
        if ($userDn === '' && !empty($entry['distinguishedname'][0])) {
            $userDn = trim((string)$entry['distinguishedname'][0]);
        }

        if ($userDn === '') {
            @ldap_close($connection);
            continue;
        }

        $userBind = @ldap_bind($connection, $userDn, $password);
        if (!$userBind) {
            @ldap_close($connection);
            continue;
        }

        $displayName = portalGetLdapAttribute($entry, 'displayName');
        if ($displayName === '') {
            $givenName = portalGetLdapAttribute($entry, 'givenName');
            $surname = portalGetLdapAttribute($entry, 'sn');
            $displayName = trim($givenName . ' ' . $surname);
        }
        if ($displayName === '') {
            $displayName = $username;
        }

        $mail = portalGetLdapAttribute($entry, 'mail');
        $sam = portalGetLdapAttribute($entry, 'sAMAccountName');
        if ($sam === '') {
            $sam = $username;
        }

        @ldap_close($connection);

        return [
            'username' => normalizePortalUsername($sam),
            'display_name' => $displayName,
            'ldap_dn' => $userDn,
            'mail' => $mail,
        ];
    }

    return null;
}

function portalAuthenticateLocalAdmin(string $username, string $password): ?array
{
    $username = normalizePortalUsername($username);
    if ($username === '' || $password === '') {
        return null;
    }

    $expectedUser = normalizePortalUsername((string)AUTH_LOCAL_ADMIN_USER);
    if ($expectedUser === '') {
        return null;
    }

    if (!hash_equals($expectedUser, $username)) {
        return null;
    }

    if (!hash_equals((string)AUTH_LOCAL_ADMIN_PASS, (string)$password)) {
        return null;
    }

    return [
        'username' => $expectedUser,
        'display_name' => 'Local Admin',
        'role' => 'master',
        'is_active' => true,
        'last_login_at' => date('Y-m-d H:i:s'),
        'ldap_dn' => '',
        'mail' => '',
    ];
}

function portalSearchLdapUsers(string $query): array
{
    $query = trim($query);
    if ($query === '') {
        return [];
    }

    if (!function_exists('ldap_connect')) {
        return [];
    }

    $servers = array_values(array_filter([
        trim(AUTH_AD_SERVER),
        trim(AUTH_AD_FALLBACK_SERVER),
    ]));

    $bindUserCandidates = array_values(array_unique(array_filter([
        AUTH_AD_SEARCH_BIND_USER,
        AUTH_AD_SEARCH_BIND_USER . '@' . AUTH_AD_DOMAIN,
        AUTH_AD_NETBIOS . '\\' . AUTH_AD_SEARCH_BIND_USER,
    ])));

    $filterQuery = portalEscapeLdapFilter($query);
    $filter = sprintf(
        '(&(objectClass=user)(|(sAMAccountName=%1$s*)(displayName=%1$s*)(mail=%1$s*)(givenName=%1$s*)(sn=%1$s*)))',
        $filterQuery
    );

    $results = [];

    foreach ($servers as $server) {
        $connection = @ldap_connect($server, AUTH_AD_PORT);
        if ($connection === false) {
            continue;
        }

        @ldap_set_option($connection, LDAP_OPT_PROTOCOL_VERSION, 3);
        @ldap_set_option($connection, LDAP_OPT_REFERRALS, 0);
        if (AUTH_AD_USE_TLS) {
            @ldap_start_tls($connection);
        }

        $bound = false;
        foreach ($bindUserCandidates as $bindUser) {
            $bound = @ldap_bind($connection, $bindUser, AUTH_AD_SEARCH_BIND_PASS);
            if ($bound) {
                break;
            }
        }

        if (!$bound) {
            @ldap_close($connection);
            continue;
        }

        $search = @ldap_search($connection, AUTH_AD_BASE_DN, $filter, ['dn', 'cn', 'displayName', 'givenName', 'sn', 'mail', 'sAMAccountName', 'userPrincipalName'], 0, 100);
        if ($search === false) {
            @ldap_close($connection);
            continue;
        }

        $entries = @ldap_get_entries($connection, $search);
        if (!is_array($entries) || (int)($entries['count'] ?? 0) < 1) {
            @ldap_close($connection);
            continue;
        }

        for ($i = 0; $i < (int)$entries['count']; $i++) {
            $entry = $entries[$i];
            $sam = portalGetLdapAttribute($entry, 'sAMAccountName');
            if ($sam === '') {
                continue;
            }

            $sam = normalizePortalUsername($sam);
            if ($sam === '') {
                continue;
            }

            $displayName = portalGetLdapAttribute($entry, 'displayName');
            if ($displayName === '') {
                $givenName = portalGetLdapAttribute($entry, 'givenName');
                $surname = portalGetLdapAttribute($entry, 'sn');
                $displayName = trim($givenName . ' ' . $surname);
            }
            if ($displayName === '') {
                $displayName = $sam;
            }

            $mail = portalGetLdapAttribute($entry, 'mail');

            $key = $sam;
            $results[$key] = [
                'username' => $sam,
                'display_name' => $displayName,
                'mail' => $mail,
            ];
        }

        @ldap_close($connection);

        if (!empty($results)) {
            break;
        }
    }

    return array_values($results);
}

function portalResolveAuthorizedUser(array $ldapUser): ?array
{
    $username = normalizePortalUsername((string)($ldapUser['username'] ?? ''));
    if ($username === '') {
        return null;
    }

    $portalUser = getPortalUserByUsername($username);
    if (!is_array($portalUser)) {
        if (countPortalUsers() === 0) {
            savePortalUser($username, (string)($ldapUser['display_name'] ?? $username), 'master', true);
            $portalUser = getPortalUserByUsername($username);
        }
    }

    if (!is_array($portalUser)) {
        return null;
    }

    if ((int)($portalUser['is_active'] ?? 0) !== 1) {
        return null;
    }

    updatePortalUserLogin($username, (string)($ldapUser['display_name'] ?? ''));

    $portalUser['username'] = $username;
    $portalUser['display_name'] = trim((string)($ldapUser['display_name'] ?? ($portalUser['display_name'] ?? '')));
    $portalUser['ldap_dn'] = (string)($ldapUser['ldap_dn'] ?? '');
    $portalUser['mail'] = (string)($ldapUser['mail'] ?? '');
    $portalUser['role'] = portalNormalizeRole((string)($portalUser['role'] ?? 'doctor'));
    $portalUser['is_active'] = true;

    return $portalUser;
}

function portalRequireLogin(?string $requiredRole = null): array
{
    $currentUser = portalCurrentUser();
    if ($currentUser === null) {
        $returnUrl = portalSanitizeReturnUrl((string)($_SERVER['REQUEST_URI'] ?? 'index.php'));
        header('Location: login.php?return_url=' . rawurlencode($returnUrl));
        exit;
    }

    if ($requiredRole !== null && !portalAuthorizedView($requiredRole, $currentUser)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Forbidden.';
        exit;
    }

    return $currentUser;
}

function portalRequireMaster(): array
{
    return portalRequireLogin('master');
}

function portalPreferredViewForUser(array $user): string
{
    $role = portalNormalizeRole((string)($user['role'] ?? 'doctor'));
    return $role === 'patient' ? 'patient' : $role;
}

<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function normalizeDepartmentFilter(string $value): string
{
    $v = strtolower(trim($value));
    if ($v === 'lab' || $v === 'imaging') {
        return $v;
    }
    return 'all';
}

function normalizeViewMode(string $value): string
{
    $v = strtolower(trim($value));
    if ($v === 'master' || $v === 'lab' || $v === 'imaging' || $v === 'patient' || $v === 'doctor' || $v === 'butler') {
        return $v;
    }
    return 'master';
}

function normalizeSendStateFilter(string $value): string
{
    $v = strtolower(trim($value));
    if ($v === 'not_sent') {
        return 'not_sent';
    }
    return 'all';
}

function toExternalResultLink(string $link): string
{
    return rewriteUrlWithExternalHostname($link);
}

function parseTestEnumeration(string $value): array
{
    $parts = preg_split('/\s*,\s*/', trim($value));
    if (!is_array($parts)) {
        return [];
    }

    $tests = [];
    foreach ($parts as $part) {
        $test = trim((string)$part);
        if ($test === '') {
            continue;
        }
        $tests[] = $test;
    }

    return $tests;
}

function decodeSentResultContentValue(string $contentValue): array
{
    $contentValue = trim($contentValue);
    if ($contentValue === '') {
        return ['link' => '', 'tests' => []];
    }

    if (str_starts_with($contentValue, '{')) {
        $decoded = json_decode($contentValue, true);
        if (is_array($decoded)) {
            return [
                'link' => trim((string)($decoded['link'] ?? '')),
                'tests' => parseTestEnumeration((string)($decoded['tests'] ?? '')),
            ];
        }
    }

    return ['link' => $contentValue, 'tests' => []];
}

function resolveResultTemplateType(array $row): string
{
    $source = strtolower(trim((string)($row['source'] ?? 'json_import')));
    if ($source === 'manual_upload' || $source === 'manual_send' || $source === 'collection_notice') {
        return 'manual_pdf';
    }

    return 'result';
}

function resolvePeriodRange(string $period, string $dateRange): array
{
    $period = strtolower(trim($period));
    $today = new DateTimeImmutable('today');

    if ($period === 'today') {
        $d = $today->format('Y-m-d');
        return [$d, $d];
    }

    if ($period === 'yesterday') {
        $d = $today->modify('-1 day')->format('Y-m-d');
        return [$d, $d];
    }

    if ($period === 'last_week') {
        return [$today->modify('-6 days')->format('Y-m-d'), $today->format('Y-m-d')];
    }

    if ($period === 'custom') {
        $parts = preg_split('/\s+to\s+/i', trim($dateRange));
        $start = normalizeDateOnly((string)($parts[0] ?? ''));
        $end = normalizeDateOnly((string)($parts[1] ?? ($parts[0] ?? '')));

        if ($start !== null && $end !== null) {
            if ($start > $end) {
                return [$end, $start];
            }
            return [$start, $end];
        }
    }

    return [null, null];
}

function resolveDateTimeRange(string $dateTimeRange): array
{
    $parts = preg_split('/\s+to\s+/i', trim($dateTimeRange));
    $startRaw = trim((string)($parts[0] ?? ''));
    $endRaw = trim((string)($parts[1] ?? ($parts[0] ?? '')));

    if ($startRaw === '') {
        return [null, null];
    }

    $startTs = strtotime($startRaw);
    $endTs = strtotime($endRaw);
    if ($startTs === false || $endTs === false) {
        return [null, null];
    }

    if ($startTs > $endTs) {
        return [$endTs, $startTs];
    }

    return [$startTs, $endTs];
}

function formatDateOnlyDisplay(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }

    $ts = strtotime($value);
    if ($ts !== false) {
        return date('Y-m-d', $ts);
    }

    return substr($value, 0, 10);
}

function formatAttemptDateTimeDisplay(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }

    $ts = strtotime($value);
    if ($ts !== false) {
        return date('Y-m-d H:i', $ts);
    }

    return substr($value, 0, 16);
}

$rawViewMode = trim((string)($_GET['view'] ?? ''));
$allowedViewModes = ['master', 'lab', 'imaging', 'patient', 'doctor', 'butler'];
$portalUser = portalCurrentUser();
$isPatientView = false;

// If authenticated, always use user's role, ignore view parameter
if (is_array($portalUser)) {
    $viewMode = portalPreferredViewForUser($portalUser);
    $isPatientView = false;
} elseif ($rawViewMode === '') {
    // Not authenticated and no view parameter: redirect to login
    header('Location: login.php?return_url=' . rawurlencode('index.php'));
    exit;
} elseif (!in_array(strtolower($rawViewMode), $allowedViewModes, true)) {
    http_response_code(400);
    echo 'Invalid or missing required "view" parameter.';
    exit;
} else {
    // Not authenticated, use the view parameter (for patient view)
    $viewMode = normalizeViewMode($rawViewMode);
    $isPatientView = $viewMode === 'patient';
}

$mrn = sanitizeMrn((string)($_GET['mrn'] ?? ''));
$portalUser = portalCurrentUser();

if (!$isPatientView) {
    $portalUser = portalRequireLogin();
    if (!portalAuthorizedView($viewMode, $portalUser)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Forbidden.';
        exit;
    }
}

// Helper to build index URLs without emitting deprecated view values.
function buildIndexUrl(array $params = []): string
{
    $base = 'index.php';
    $vm = strtolower(trim((string)($GLOBALS['viewMode'] ?? '')));
    // Only include `view=patient` in URLs. Other views follow logged-in role
    // and should not be visible in query strings.
    if ($vm === 'patient') {
        $params = array_merge(['view' => $vm], $params);
    }

    if (empty($params)) {
        return $base;
    }

    return $base . '?' . http_build_query($params);
}

$departmentFilter = normalizeDepartmentFilter((string)($_GET['dept'] ?? 'all'));
$sendStateFilter = normalizeSendStateFilter((string)($_GET['send_state'] ?? 'all'));
$resultTimeRange = trim((string)($_GET['result_time_range'] ?? ''));
$period = trim((string)($_GET['period'] ?? 'today'));
$dateRange = trim((string)($_GET['date_range'] ?? ''));
$dateMode = strtolower(trim((string)($_GET['date_mode'] ?? 'released')));
if ($dateMode !== 'visit' && $dateMode !== 'released') {
    $dateMode = 'released';
}

// Sync delivery statuses in background (no more than once per 60 seconds)
if (is_array($portalUser)) {
    require_once __DIR__ . '/result_sending.php';
    $syncFlagFile = __DIR__ . '/logs/sync_status.flag';
    $lastSync = @filemtime($syncFlagFile) ?: 0;
    $now = time();
    if (($now - $lastSync) > 60) {
        // Update flag first to prevent concurrent syncs
        @touch($syncFlagFile);
        
        // Non-blocking sync calls (fire and forget)
        try {
            @syncWhatsAppDeliveryStatuses(50);
            @syncSmsDeliveryStatuses(50);
        } catch (Throwable $e) {
            // Silent fail - don't interrupt page load
        }
    }
}
[$startDate, $endDate] = resolvePeriodRange($period, $dateRange);
[$resultStartTs, $resultEndTs] = resolveDateTimeRange($resultTimeRange);

$patients = $dateMode === 'visit'
    ? getPatientsByLastVisitRange($startDate, $endDate)
    : getPatientsByResultReleasedRange($startDate, $endDate);
$patient = $mrn !== '' ? getPatientByMrn($mrn) : null;
$results = $mrn !== '' ? getPatientResultsByMrn($mrn) : [];
$sentMap = $mrn !== '' ? getMrnSentResultsMap($mrn) : [];

if ($viewMode === 'lab' || $viewMode === 'imaging') {
    $departmentFilter = $viewMode;
}

$isDoctorView = $viewMode === 'doctor';
$isButlerView = $viewMode === 'butler';
$isReadOnlyView = $isPatientView || $isDoctorView;

if ($mrn !== '') {
    $grouped = [];
    foreach ($results as $row) {
        $department = strtolower((string)($row['department'] ?? ''));
        $source = strtolower(trim((string)($row['source'] ?? 'json_import')));
        $requestCode = trim((string)($row['request_code'] ?? ''));
        $visitDate = trim((string)($row['visit_date'] ?? ''));

        // Skip collection notices entirely - they're notifications, not results
        if ($source === 'collection_notice') {
            continue;
        }

        // Manual uploads and manual sends are never grouped - always displayed as separate cards
        if ($source === 'manual_upload' || $source === 'manual_send' || $department !== 'laboratory') {
            $grouped[] = $row;
            continue;
        }

        // Group laboratory results by department|request_code|visit_date to combine tests
        $groupKey = $department . '|' . $requestCode . '|' . $visitDate;
        if (!isset($grouped[$groupKey])) {
            $row['_test_names'] = [];
            $testName = trim((string)($row['test_or_image'] ?? ''));
            if ($testName !== '') {
                $row['_test_names'][$testName] = true;
            }
            $grouped[$groupKey] = $row;
            continue;
        }

        $testName = trim((string)($row['test_or_image'] ?? ''));
        if ($testName !== '') {
            $grouped[$groupKey]['_test_names'][$testName] = true;
        }
    }

    $results = [];
    foreach ($grouped as $row) {
        if (isset($row['_test_names']) && is_array($row['_test_names'])) {
            $tests = array_keys($row['_test_names']);
            sort($tests, SORT_NATURAL | SORT_FLAG_CASE);
            $row['test_or_image'] = implode(', ', $tests);
            unset($row['_test_names']);
        }
        $results[] = $row;
    }
}

if ($mrn !== '' && $departmentFilter !== 'all') {
    $results = array_values(array_filter(
        $results,
        static function (array $row) use ($departmentFilter): bool {
            $department = strtolower((string)($row['department'] ?? ''));
            if ($departmentFilter === 'lab') {
                return $department === 'laboratory' || $department === 'lab';
            }
            return $department === 'radiology' || $department === 'imaging';
        }
    ));
}

// Hide manual uploads and collection notices from patient and doctor views (read-only roles)
if ($mrn !== '' && $isReadOnlyView) {
    $results = array_values(array_filter(
        $results,
        static function (array $row): bool {
            $source = strtolower(trim((string)($row['source'] ?? 'json_import')));
            return $source !== 'manual_upload' && $source !== 'manual_send' && $source !== 'collection_notice';
        }
    ));
}

// Count results that need sending (not sent, or link changed) – used for the Send All button.
// Computed here after dept filter but before send_state / datetime filters so the count is always accurate.
$sendAllCount = 0;
if ($mrn !== '') {
    foreach ($results as $row) {
        $source = strtolower(trim((string)($row['source'] ?? 'json_import')));
        $department = (string)($row['department'] ?? '');
        $departmentNorm = strtolower(trim($department));
        $requestCode = (string)($row['request_code'] ?? '');
        $resultId = (int)($row['id'] ?? 0);

        // Include json_import results and manual sends (but only lab, imaging, manual)
        if ($source === 'json_import') {
            if ($departmentNorm !== 'laboratory' && $departmentNorm !== 'radiology') {
                continue;
            }
        } elseif ($source !== 'manual_send' && $source !== 'manual_upload') {
            continue;
        }

        $sentKey = $resultId;
        $sentRecord = $sentMap[$sentKey] ?? null;
        if ($sentRecord === null) {
            $sendAllCount++;
        } else {
            $currentLink = trim((string)($row['pdf_result_link'] ?? ''));
            $cv = (string)($sentRecord['content_value'] ?? '');
            $sentLink = ($cv !== '' && $cv[0] === '{')
                ? (string)(json_decode($cv, true)['link'] ?? $cv)
                : $cv;
            if ($currentLink !== '' && $currentLink !== $sentLink) {
                $sendAllCount++;
            }
        }
    }
}

if ($mrn !== '' && $sendStateFilter === 'not_sent') {
    $results = array_values(array_filter(
        $results,
        static function (array $row) use ($sentMap): bool {
            $department = (string)($row['department'] ?? '');
            $requestCode = (string)($row['request_code'] ?? '');
            $resultId = (int)($row['id'] ?? 0);
            $templateType = resolveResultTemplateType($row);
            $sentKey = $resultId;
            return !isset($sentMap[$sentKey]);
        }
    ));
}

if ($mrn !== '' && $resultStartTs !== null && $resultEndTs !== null) {
    $results = array_values(array_filter(
        $results,
        static function (array $row) use ($resultStartTs, $resultEndTs): bool {
            $timeRaw = trim((string)($row['last_updated_at'] ?? ''));
            if ($timeRaw === '') {
                $timeRaw = trim((string)($row['visit_date'] ?? ''));
            }

            $rowTs = strtotime($timeRaw);
            if ($rowTs === false) {
                return false;
            }

            return $rowTs >= $resultStartTs && $rowTs <= $resultEndTs;
        }
    ));
}

// Pre-compute JS-safe strings for confirm dialogs
$jsPatientName = addslashes((string)(is_array($patient) ? ($patient['patient_name'] ?? $mrn) : $mrn));
$jsMrn = addslashes($mrn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results Dashboard</title>
    <link rel="icon" href="favicon.php" sizes="any">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        :root {
            --bg: #f2f5f8;
            --surface: #fff;
            --line: #d8e0e7;
            --text: #203142;
            --muted: #6b7c8b;
            --primary: #0e73b8;
            --primary-strong: #0a5a91;
            --ok: #217346;
            --warn: #9f6a00;
            --err: #9a2f2f;
            --blue-050: #f4f9ff;
            --blue-100: #eaf4ff;
            --blue-150: #deecfb;
            --blue-200: #d0e3f8;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: linear-gradient(180deg, #f8fbff, var(--bg));
            font-family: "Segoe UI", Tahoma, sans-serif;
            color: var(--text);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: grid;
            gap: 16px;
        }
        .card {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 10px;
            padding: 14px;
            box-shadow: 0 6px 18px rgba(30, 84, 124, 0.05);
        }
        h1, h2, h3 { margin: 0 0 10px; }
        .muted { color: var(--muted); }

        .toolbar {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            align-items: center;
        }

        .portal-header-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            align-items: flex-start;
            flex-wrap: wrap;
        }

        .portal-user-box {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
            border: 1px solid #d6e0ea;
            border-radius: 999px;
            background: linear-gradient(180deg, #f9fcff 0%, #eef5fb 100%);
            color: #294962;
            font-size: 13px;
            font-weight: 600;
        }

        .portal-user-role {
            border-radius: 999px;
            padding: 3px 8px;
            background: #0e73b8;
            color: #fff;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }

        .portal-user-links {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        input[type=text], input[type=file], select {
            border: 1px solid #cad3dc;
            border-radius: 8px;
            padding: 9px 10px;
            font-size: 14px;
            min-height: 38px;
        }

        .btn {
            border: 0;
            border-radius: 8px;
            background: var(--primary);
            color: #fff;
            font-weight: 600;
            padding: 9px 12px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 38px;
        }

        .btn:hover { background: var(--primary-strong); }
        .btn.secondary {
            background: #eef4f9;
            color: #224b66;
            border: 1px solid #ced9e4;
        }

        .btn.success {
            background: #1f8f4e;
        }

        .btn.success:hover {
            background: #16713c;
        }

        .btn.lab-notice {
            background: #1f8f4e;
        }

        .btn.lab-notice:hover {
            background: #16713c;
        }

        .btn.imaging {
            background: #7b1fa2;
        }

        .btn.imaging:hover {
            background: #641985;
        }

        .btn.send-all {
            background: linear-gradient(135deg, #1f8f4e, #16713c);
            color: #fff;
            border: none;
            font-weight: 600;
        }

        .btn.send-all:hover {
            background: linear-gradient(135deg, #16713c, #115a2f);
        }

        .btn.whatsapp {
            background: #25d366;
            color: #fff;
        }

        .btn.whatsapp:hover {
            background: #1da851;
        }

        .btn.sms {
            background: #ff9800;
            color: #fff;
        }

        .btn.sms:hover {
            background: #e68900;
        }

        .btn.email {
            background: #ffc107;
            color: #333;
        }

        .btn.email:hover {
            background: #ffb300;
        }

        .btn.resend {
            background: #0e73b8;
            color: #fff;
        }

        .btn.resend:hover {
            background: #0a5a91;
        }

        .notice {
            padding: 10px;
            border-radius: 8px;
            border: 1px solid transparent;
            margin-top: 10px;
        }
        .notice.success { background: #eaf8ef; border-color: #baddc0; color: var(--ok); }
        .notice.error { background: #fff0f0; border-color: #f1c5c5; color: var(--err); }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        th, td {
            border-bottom: 1px solid #e4ebf2;
            text-align: left;
            padding: 9px 8px;
            vertical-align: top;
        }
        th {
            color: #3a5368;
            background: #f7fbff;
            position: sticky;
            top: 0;
        }

        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }

        .send-tag {
            font-size: 12px;
            border-radius: 999px;
            padding: 4px 8px;
            display: inline-block;
            border: 1px solid #d9e3ec;
            background: #f6fafc;
            color: #2e4d63;
            white-space: nowrap;
        }

        .send-tag.not-sent {
            color: #666;
            border-color: #d9e3ec;
            background: #f0f3f6;
            font-size: 11px;
        }

        .send-tag.ok {
            color: var(--ok);
            border-color: #beddc8;
            background: #eef8f2;
        }

        .send-tag.changed {
            color: var(--warn);
            border-color: #e9d4ad;
            background: #fff7e8;
        }

        .send-tag.wp-sent {
            color: var(--ok);
            border-color: #beddc8;
            background: #eef8f2;
            font-size: 11px;
            margin-right: 4px;
        }

        .send-tag.wp-failed {
            color: var(--err);
            border-color: #eca0a0;
            background: #fef0f0;
            font-size: 11px;
            margin-right: 4px;
        }

        .send-tag.email-sent {
            color: var(--ok);
            border-color: #beddc8;
            background: #eef8f2;
            font-size: 11px;
        }

        .send-tag.email-failed {
            color: var(--err);
            border-color: #eca0a0;
            background: #fef0f0;
            font-size: 11px;
        }

        .send-tag.sms-sent {
            color: var(--ok);
            border-color: #beddc8;
            background: #eef8f2;
            font-size: 11px;
            margin-right: 4px;
        }

        .send-tag.sms-failed {
            color: var(--err);
            border-color: #eca0a0;
            background: #fef0f0;
            font-size: 11px;
            margin-right: 4px;
        }

        .dept-pill {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 4px 10px;
            color: #fff;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 0.2px;
        }

        .dept-pill.lab {
            background: #c62828;
        }

        .dept-pill.imaging {
            background: #7b1fa2;
        }

        .dept-pill.manual {
            background: #0e73b8;
        }

        .filter-chip {
            border-radius: 999px;
            padding: 7px 12px;
            border: 1px solid #c6d9ed;
            background: linear-gradient(180deg, #f9fcff 0%, #edf5ff 100%);
            color: #244760;
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            gap: 6px;
            align-items: center;
            transition: transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease;
        }

        .filter-chip:hover {
            transform: translateY(-1px);
            border-color: #a9c6e3;
            box-shadow: 0 4px 12px rgba(29, 80, 124, 0.12);
        }

        .filter-chip.active {
            background: #0e73b8;
            border-color: #0e73b8;
            color: #fff;
        }

        .results-filters {
            margin-bottom: 10px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
        }

        .results-summary {
            margin: 6px 0 10px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 8px;
        }

        .results-summary .item {
            border: 1px solid #cfe1f3;
            border-radius: 10px;
            padding: 8px 10px;
            background: linear-gradient(180deg, #ffffff 0%, #f3f9ff 100%);
        }

        .results-summary .label {
            font-size: 11px;
            color: #678198;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            display: block;
            margin-bottom: 3px;
        }

        .results-summary .value {
            font-size: 15px;
            color: #1c3a51;
            font-weight: 700;
            display: block;
            word-break: break-word;
        }

        .inline-filter-form {
            display: inline-flex;
            flex-wrap: wrap;
            gap: 8px;
            align-items: center;
        }

        .inline-filter-form .mode-switch {
            min-height: 34px;
            padding-top: 3px;
            padding-bottom: 3px;
        }

        .inline-filter-form input[type=text],
        .inline-filter-form select {
            min-height: 34px;
            padding: 7px 9px;
            font-size: 13px;
            border-color: #bdd5ea;
            background: #f9fcff;
        }

        .results-groups {
            display: grid;
            gap: 10px;
        }

        .visit-group {
            border: 1px solid var(--blue-200);
            border-radius: 12px;
            background: linear-gradient(180deg, #fbfdff 0%, #f4f9ff 100%);
            overflow: hidden;
            box-shadow: 0 5px 14px rgba(26, 73, 112, 0.08);
            transition: box-shadow 0.2s ease;
        }

        .visit-group:hover {
            box-shadow: 0 8px 18px rgba(26, 73, 112, 0.12);
        }

        .visit-group > summary {
            cursor: pointer;
            list-style: none;
            padding: 12px 14px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            font-weight: 700;
            color: #1d3f5a;
            background: linear-gradient(180deg, var(--blue-100) 0%, var(--blue-150) 100%);
        }

        .visit-group > summary::-webkit-details-marker {
            display: none;
        }

        .visit-group .meta {
            font-size: 12px;
            color: #5f788d;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }

        .visit-group .rows {
            padding: 10px;
            display: grid;
            gap: 8px;
        }

        .result-row-card {
            border: 1px solid #e1eaf2;
            border-radius: 10px;
            background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
            padding: 10px;
            display: grid;
            gap: 8px;
            transition: transform 0.18s ease, box-shadow 0.18s ease;
        }

        .result-row-card:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 14px rgba(24, 64, 98, 0.11);
        }

        .result-row-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(130px, 1fr));
            gap: 8px;
        }

        .result-row-grid .cell {
            border: 1px solid #dfeaf5;
            border-radius: 8px;
            padding: 8px;
            background: linear-gradient(180deg, #ffffff 0%, #f3f9ff 100%);
        }

        .result-row-grid .label {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            color: #69849a;
            display: block;
            margin-bottom: 3px;
        }

        .result-row-grid .label i {
            margin-right: 5px;
            color: #5d7f98;
        }

        .result-row-grid .value {
            font-size: 13px;
            color: #1f3a4f;
            font-weight: 600;
            display: block;
            word-break: break-word;
        }

        .manual-send-form {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            align-items: center;
            width: 100%;
        }

        .manual-send-details {
            margin-top: 16px;
            padding: 12px 14px 14px;
            border: 1px solid #cfe2f4;
            border-radius: 14px;
            background: linear-gradient(180deg, #fcfeff 0%, #f0f7ff 100%);
            box-shadow: 0 5px 14px rgba(30, 84, 124, 0.08);
        }

        .manual-send-details > summary {
            cursor: pointer;
            font-size: 18px;
            font-weight: 800;
            color: #18344d;
            list-style: none;
        }

        .manual-send-details > summary::-webkit-details-marker {
            display: none;
        }

        .manual-send-details > summary::after {
            content: '▾';
            display: inline-block;
            margin-left: 8px;
            transition: transform 0.2s ease;
        }

        .manual-send-details[open] > summary::after {
            transform: rotate(180deg);
        }

        .manual-send-details .manual-send-content {
            margin-top: 12px;
            display: grid;
            gap: 16px;
        }

        .manual-send-details h3 {
            font-size: 14px;
            margin-bottom: 8px;
            color: #567086;
            font-weight: 700;
        }

        .manual-send-form .file-input-wide {
            min-width: 320px;
            flex: 1 1 420px;
        }

        .manual-send-form .link-input-wide {
            min-width: 320px;
            flex: 1 1 520px;
            border: 1px solid #cad3dc;
            border-radius: 8px;
            padding: 9px 10px;
            font-size: 14px;
            min-height: 38px;
            background: #fff;
            color: var(--text);
            font-weight: 400;
        }

        .manual-send-form .link-input-wide:focus {
            outline: none;
            border-color: #0e73b8;
            box-shadow: 0 0 0 3px rgba(14, 115, 184, 0.18);
        }

        .mode-switch {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 6px 10px;
            border: 1px solid #ced9e4;
            border-radius: 999px;
            background: #f7fbff;
        }

        .switch {
            position: relative;
            display: inline-block;
            width: 52px;
            height: 28px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background-color: #b7c8d8;
            transition: 0.22s;
            border-radius: 999px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 3px;
            top: 3px;
            background-color: #fff;
            transition: 0.22s;
            border-radius: 50%;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
        }

        .switch input:checked + .slider {
            background-color: #0e73b8;
        }

        .switch input:checked + .slider:before {
            transform: translateX(24px);
        }

        .mode-label {
            font-size: 13px;
            font-weight: 600;
            color: #2d4a62;
        }

        body.patient-view .container {
            max-width: 1260px;
        }

        body.patient-view .card {
            border: 1px solid rgba(139, 168, 195, 0.36);
            background: #ffffff;
            box-shadow: 0 12px 36px rgba(18, 58, 87, 0.12);
            backdrop-filter: blur(2px);
        }

        .patient-overview {
            display: grid;
            gap: 10px;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            margin-bottom: 12px;
        }

        .patient-tile {
            border: 1px solid #d1e2f2;
            border-radius: 12px;
            padding: 10px 12px;
            background: linear-gradient(180deg, #ffffff 0%, #f5faff 100%);
            box-shadow: 0 4px 12px rgba(20, 52, 77, 0.07);
        }

        .patient-tile .label {
            font-size: 11px;
            letter-spacing: 0.4px;
            text-transform: uppercase;
            color: #68829a;
            margin-bottom: 4px;
            display: block;
        }

        .patient-tile .value {
            font-size: 15px;
            font-weight: 700;
            color: #1c3850;
            display: block;
            word-break: break-word;
        }

        body.patient-view .container {
            position: relative;
            z-index: 1;
        }

        @media (max-width: 980px) {
            .grid-2 {
                grid-template-columns: 1fr;
            }

            .result-row-grid {
                grid-template-columns: 1fr 1fr;
            }

            .inline-filter-form {
                width: 100%;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }
        }

        .banner {
            padding: 14px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            animation: slideDown 0.3s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .banner.success {
            background: #e6f7f0;
            border: 1px solid #81c784;
            color: #1b5e20;
        }

        .banner.error {
            background: #ffebee;
            border: 1px solid #ef5350;
            color: #b71c1c;
        }

        .banner.success .banner-icon {
            color: #2e7d32;
        }

        .banner.error .banner-icon {
            color: #c62828;
        }

        .banner-content {
            flex: 1;
        }

        .banner-close {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 18px;
            color: inherit;
            padding: 0;
            display: flex;
            align-items: center;
        }

        .banner-close:hover {
            opacity: 0.7;
        }

        /* Loading modal */
        .loading-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
            justify-content: center;
            align-items: center;
        }

        .loading-modal.active {
            display: flex;
        }

        .loading-modal-content {
            background: white;
            padding: 30px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #0e73b8;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .loading-modal-text {
            color: #203142;
            font-size: 16px;
            font-weight: 500;
        }
    </style>
    <script>
        // Show loading popup on send button click
        document.addEventListener('DOMContentLoaded', function() {
            const loadingModal = document.getElementById('loadingModal');
            
            // Find all send forms (those with send_result_single, send_collection_notice, manual upload forms)
            const sendForms = document.querySelectorAll('form[action="result_sending.php"]');
            
            sendForms.forEach(form => {
                form.addEventListener('submit', function() {
                    // Only show loading for forms that are actually submitting to send something
                    const inputs = form.querySelectorAll('input[name="send_result_single"], input[name="send_collection_notice"], input[name="manual_pdf_file"], input[name="manual_link"]');
                    if (inputs.length > 0 || form.classList.contains('manual-send-form')) {
                        if (loadingModal) {
                            loadingModal.classList.add('active');
                        }
                    }
                });
            });
        });
    </script>
</head>
<body class="<?php echo $isPatientView ? 'patient-view' : 'portal-view'; ?>">
    <!-- Loading Modal -->
    <div id="loadingModal" class="loading-modal">
        <div class="loading-modal-content">
            <div class="loading-spinner"></div>
            <div class="loading-modal-text">Processing request...</div>
        </div>
    </div>

<div class="container">
    <?php
    // Display success/failure banner if messages are set
    if (!empty($_SESSION['success_message'])): 
        $message = $_SESSION['success_message'];
        unset($_SESSION['success_message']);
    ?>
        <div class="banner success" id="successBanner">
            <div class="banner-content">
                <strong><i class="fas fa-check-circle banner-icon" aria-hidden="true" style="margin-right: 8px;"></i><?php echo h((string)$message); ?></strong>
            </div>
            <button type="button" class="banner-close" onclick="this.parentElement.style.display='none';">
                <i class="fas fa-times" aria-hidden="true"></i>
            </button>
        </div>
    <?php endif; ?>

    <?php
    if (!empty($_SESSION['error_message'])): 
        $message = $_SESSION['error_message'];
        unset($_SESSION['error_message']);
    ?>
        <div class="banner error" id="errorBanner">
            <div class="banner-content">
                <strong><i class="fas fa-exclamation-circle banner-icon" aria-hidden="true" style="margin-right: 8px;"></i><?php echo h((string)$message); ?></strong>
            </div>
            <button type="button" class="banner-close" onclick="this.parentElement.style.display='none';">
                <i class="fas fa-times" aria-hidden="true"></i>
            </button>
        </div>
    <?php endif; ?>

    <script>
        // Auto-hide success banners after 5 seconds
        const successBanner = document.getElementById('successBanner');
        if (successBanner) {
            setTimeout(function() {
                successBanner.style.display = 'none';
            }, 5000);
        }

        // Auto-hide error banners after 8 seconds
        const errorBanner = document.getElementById('errorBanner');
        if (errorBanner) {
            setTimeout(function() {
                errorBanner.style.display = 'none';
            }, 8000);
        }
    </script>
    <div class="card">
        <div class="portal-header-row">
            <div>
                <h1>Hospital Results Dashboard</h1>
                <div class="muted"><?php echo $isPatientView ? 'Public patient view' : 'Authenticated portal view'; ?></div>
            </div>
            <div class="portal-user-links">
                <?php if (is_array($portalUser)): ?>
                    <div class="portal-user-box">
                        <span><?php echo h((string)($portalUser['display_name'] ?? $portalUser['username'] ?? 'User')); ?></span>
                        <span class="portal-user-role"><?php echo h((string)($portalUser['role'] ?? 'doctor')); ?></span>
                        <i class="fa-solid fa-circle-info" style="margin-left: 8px; cursor: help; color: #1a73e8;" title="<?php $templates = require 'templates.php'; $role = (string)($portalUser['role'] ?? 'doctor'); echo h($templates['user_info'][$role] ?? 'User role information'); ?>"></i>
                    </div>
                    <?php if (($portalUser['role'] ?? '') === 'master'): ?>
                        <a class="btn secondary" href="user_management.php">User Management</a>
                    <?php endif; ?>
                    <?php if (($portalUser['role'] ?? '') === 'master' || ($portalUser['role'] ?? '') === 'butler'): ?>
                        <a class="btn secondary" href="activity_log.php">Activity Log</a>
                    <?php endif; ?>
                    <a class="btn secondary" href="logout.php">Logout</a>
                <?php elseif (!$isPatientView): ?>
                    <a class="btn secondary" href="login.php?return_url=<?php echo urlencode('index.php?view=patient'); ?>">Login</a>
                <?php endif; ?>
            </div>
        </div>

        <?php if (!$isPatientView): ?>
        <div class="toolbar">
            <form method="get" action="index.php" style="display:contents;">
                <input type="text" name="mrn" placeholder="Search MRN" value="<?php echo h($mrn); ?>">
                <select name="send_state" style="margin-left:8px;">
                    <option value="all" <?php echo $sendStateFilter === 'all' ? 'selected' : ''; ?>>All statuses</option>
                    <option value="not_sent" <?php echo $sendStateFilter === 'not_sent' ? 'selected' : ''; ?>>Not sent only</option>
                </select>
                <?php if ($viewMode === 'patient'): ?>
                    <input type="hidden" name="view" value="<?php echo h($viewMode); ?>">
                <?php endif; ?>
                <button type="submit" class="btn"><i class="fa-solid fa-user" aria-hidden="true" style="margin-right: 6px;"></i>Open Patient</button>
            </form>
            <a class="btn secondary" href="<?php echo h(buildIndexUrl()); ?>">Reset</a>
            <?php if (!$isReadOnlyView && $mrn !== '' && $sendAllCount > 0): ?>
            <form method="post" action="result_sending.php" style="display:contents;">
                <input type="hidden" name="send_all_not_sent" value="1">
                <input type="hidden" name="mrn" value="<?php echo h($mrn); ?>">
                <input type="hidden" name="dept" value="<?php echo h($departmentFilter); ?>">
                <input type="hidden" name="return_url" value="<?php echo h(buildIndexUrl(['mrn' => $mrn])); ?>">
                <!--<button type="submit" class="btn send-all"
                    onclick="return confirm('Are you sure to send <?php echo (int)$sendAllCount; ?> message(s) to patient <?php echo h($jsPatientName); ?> (<?php echo h($jsMrn); ?>)?');">
                    <i class="fa-solid fa-paper-plane" aria-hidden="true" style="margin-right:6px;"></i>Send All Not Sent (<?php echo (int)$sendAllCount; ?>)
                </button>--> 
            </form>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['results_notice']) && is_array($_SESSION['results_notice'])): ?>
            <div class="notice <?php echo ($_SESSION['results_notice']['type'] ?? '') === 'success' ? 'success' : 'error'; ?>">
                <?php echo h((string)($_SESSION['results_notice']['text'] ?? '')); ?>
            </div>
            <?php unset($_SESSION['results_notice']); ?>
        <?php endif; ?>
    </div>

    <?php if ($mrn === '' && !$isPatientView): ?>
    <div class="card">
        <h2>Patients By <?php echo $dateMode === 'released' ? 'Result Released Date' : 'Visit Date'; ?></h2>
        <form method="get" class="toolbar" action="index.php">
            <input type="hidden" name="view" value="<?php echo h($viewMode); ?>">
            <input type="hidden" id="date_mode" name="date_mode" value="<?php echo h($dateMode); ?>">
            <select name="period">
                <option value="today" <?php echo $period === 'today' ? 'selected' : ''; ?>>Today</option>
                <option value="yesterday" <?php echo $period === 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                <option value="last_week" <?php echo $period === 'last_week' ? 'selected' : ''; ?>>Last Week</option>
                <option value="custom" <?php echo $period === 'custom' ? 'selected' : ''; ?>>Custom</option>
            </select>
            <input type="text" id="date_range" name="date_range" value="<?php echo h($dateRange); ?>" placeholder="YYYY-MM-DD to YYYY-MM-DD">
            <div class="mode-switch" title="Toggle list mode">
                <span class="mode-label">Visit</span>
                <label class="switch">
                    <input id="date_mode_toggle" type="checkbox" <?php echo $dateMode === 'released' ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
                <span class="mode-label">Released</span>
            </div>
            <button type="submit" class="btn">Apply</button>
        </form>

        <table>
            <thead>
            <tr>
                <th>MRN</th>
                <th>Patient</th>
                <th>Phone</th>
                <th><?php echo $dateMode === 'released' ? 'Result Released' : 'Last Visit'; ?></th>
                <th>Record On That Day</th>
                <th>Last Updated</th>
                <th>Results</th>
            </tr>
            </thead>
            <tbody>
            <?php if (empty($patients)): ?>
                <tr><td colspan="7" class="muted">No patients found for this range.</td></tr>
            <?php else: ?>
                <?php foreach ($patients as $row): ?>
                    <tr>
                        <td><a href="<?php echo h(buildIndexUrl(['mrn' => (string)$row['mrn']])); ?>"><?php echo h((string)$row['mrn']); ?></a></td>
                        <td><?php echo h((string)($row['patient_name'] ?? '')); ?></td>
                        <td><?php echo h((string)($row['care_mobile'] ?? '')); ?></td>
                        <td><?php echo h(formatDateOnlyDisplay((string)($dateMode === 'released' ? ($row['result_released_date'] ?? '') : ($row['last_visit_date'] ?? '')))); ?></td>
                        <td>
                            <?php
                                $recordParts = [];
                                $recordParts[] = trim((string)($row['latest_department'] ?? ''));
                                $recordParts[] = trim((string)($row['latest_test_or_image'] ?? ''));
                                $recordParts[] = trim((string)($row['latest_request_code'] ?? ''));
                                $recordText = implode(' | ', array_values(array_filter($recordParts, static fn(string $value): bool => $value !== '')));
                                if ($recordText === '') {
                                    $recordText = trim((string)($row['latest_pdf_result_link'] ?? '')) !== '' ? 'Result link available' : 'No record details';
                                }
                                echo h($recordText);
                            ?>
                        </td>
                        <td><?php echo h(formatDateOnlyDisplay((string)($row['last_updated_at'] ?? ''))); ?></td>
                        <td><?php echo h((string)($row['result_count'] ?? '0')); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <?php if ($mrn !== ''): ?>
        <div class="card">
            <h2>Patient Details</h2>
            <?php if (!is_array($patient)): ?>
                <p class="muted">Patient not found in database for MRN <?php echo h($mrn); ?>.</p>
            <?php else: ?>
                <div class="patient-overview">
                    <div class="patient-tile"><span class="label">MRN</span><span class="value"><?php echo h((string)$patient['mrn']); ?></span></div>
                    <div class="patient-tile"><span class="label">Name</span><span class="value"><?php echo h((string)($patient['patient_name'] ?? '')); ?></span></div>
                    <div class="patient-tile"><span class="label">Phone</span><span class="value"><?php echo h((string)($patient['care_mobile'] ?? '')); ?></span></div>
                    <div class="patient-tile"><span class="label">Email</span><span class="value"><?php echo h((string)($patient['email'] ?? '')); ?></span></div>
                    <div class="patient-tile"><span class="label">Date of Birth</span><span class="value"><?php echo h((string)($patient['date_of_birth'] ?? '')); ?></span></div>
                    <div class="patient-tile"><span class="label">First Seen</span><span class="value"><?php echo h((string)($patient['first_seen_at'] ?? '')); ?></span></div>
                    <div class="patient-tile"><span class="label">Last Updated</span><span class="value"><?php echo h((string)($patient['last_updated_at'] ?? '')); ?></span></div>
                </div>

                <?php if (!$isReadOnlyView): ?>

                <details class="manual-send-details">
                    <summary>Manual Results Sending</summary>
                    <div class="manual-send-content">
                        <div>
                            <h3>Manual PDF Upload</h3>
                            <form method="post" action="result_sending.php" enctype="multipart/form-data" class="manual-send-form">
                                <input type="hidden" name="send_manual_pdf" value="1">
                                <input type="hidden" name="mrn" value="<?php echo h($mrn); ?>">
                                <input type="hidden" name="return_url" value="index.php?mrn=<?php echo urlencode($mrn); ?>">
                                <input class="file-input-wide" type="file" name="manual_pdf_file" accept="application/pdf" required>
                                <div style="display: flex; gap: 10px; margin-top: 10px;">
                                    <button class="btn whatsapp" type="submit" name="send_channel" value="whatsapp">
                                        <i class="fa-brands fa-whatsapp" style="margin-right: 6px;"></i> Send via WhatsApp
                                    </button>
                                    <!--<button class="btn sms" type="submit" name="send_channel" value="sms">
                                        <i class="fa-solid fa-message" style="margin-right: 6px;"></i> Send via SMS
                                    </button>--> <!-- attachments not supported by SMS -->
                                    <button class="btn email" type="submit" name="send_channel" value="email">
                                        <i class="fa-solid fa-envelope" style="margin-right: 6px;"></i> Send via Email
                                    </button>
                                </div>
                            </form>
                        </div>

                        <div>
                            <h3>Manual Link Send</h3>
                            <form method="post" action="result_sending.php" class="manual-send-form">
                                <input type="hidden" name="send_manual_link" value="1">
                                <input type="hidden" name="mrn" value="<?php echo h($mrn); ?>">
                                <input type="hidden" name="return_url" value="<?php echo h(buildIndexUrl(['mrn' => $mrn])); ?>">
                                <input class="link-input-wide" type="url" name="manual_result_link" placeholder="https://..." required>
                                <div style="display: flex; gap: 10px; margin-top: 10px;">
                                    <button class="btn whatsapp" type="submit" name="send_channel" value="whatsapp">
                                        <i class="fa-brands fa-whatsapp" style="margin-right: 6px;"></i> Send via WhatsApp
                                    </button>
                                    <button class="btn sms" type="submit" name="send_channel" value="sms">
                                        <i class="fa-solid fa-message" style="margin-right: 6px;"></i> Send via SMS
                                    </button>
                                    <button class="btn email" type="submit" name="send_channel" value="email">
                                        <i class="fa-solid fa-envelope" style="margin-right: 6px;"></i> Send via Email
                                    </button>
                                </div>
                            </form>
                        </div>

                        <div>
                            <h3>Collection Notice For Hard Copies</h3>
                            <form method="post" action="result_sending.php" class="manual-send-form">
                                <input type="hidden" name="send_collection_notice" value="1">
                                <input type="hidden" name="mrn" value="<?php echo h($mrn); ?>">
                                <input type="hidden" name="return_url" value="<?php echo h(buildIndexUrl(['mrn' => $mrn])); ?>">
                                <div style="display: flex; gap: 10px;">
                                    <button class="btn whatsapp" type="submit" name="send_channel" value="whatsapp">
                                        <i class="fa-brands fa-whatsapp" style="margin-right: 6px;"></i> WhatsApp
                                    </button>
                                    <button class="btn sms" type="submit" name="send_channel" value="sms">
                                        <i class="fa-solid fa-message" style="margin-right: 6px;"></i> SMS
                                    </button>
                                    <button class="btn email" type="submit" name="send_channel" value="email">
                                        <i class="fa-solid fa-envelope" style="margin-right: 6px;"></i> Email
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </details>
                <?php endif; ?>

                <h3 style="margin-top: 18px;">Results</h3>
                <div class="results-filters">
                    <?php
                        $baseFilterParams = [
                            'mrn' => $mrn,
                            'view' => $viewMode,
                            'send_state' => $sendStateFilter,
                        ];
                        if ($resultTimeRange !== '') {
                            $baseFilterParams['result_time_range'] = $resultTimeRange;
                        }
                    ?>
                    <?php if ($viewMode === 'master' || $viewMode === 'butler' || $viewMode === 'patient' || $viewMode === 'doctor'): ?>
                    <a class="filter-chip <?php echo $departmentFilter === 'all' ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($baseFilterParams, ['dept' => 'all'])); ?>">
                        <i class="fa-solid fa-layer-group" aria-hidden="true"></i> All
                    </a>
                    <a class="filter-chip <?php echo $departmentFilter === 'lab' ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($baseFilterParams, ['dept' => 'lab'])); ?>">
                        <i class="fa-solid fa-flask" aria-hidden="true"></i> Lab
                    </a>
                    <a class="filter-chip <?php echo $departmentFilter === 'imaging' ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($baseFilterParams, ['dept' => 'imaging'])); ?>">
                        <i class="fa-solid fa-x-ray" aria-hidden="true"></i> Imaging
                    </a>
                    <?php endif; ?>

                    <form method="get" class="inline-filter-form" action="index.php" id="results_filter_form">
                        <input type="hidden" name="mrn" value="<?php echo h($mrn); ?>">
                        <input type="hidden" name="view" value="<?php echo h($viewMode); ?>">
                        <input type="hidden" name="dept" value="<?php echo h($departmentFilter); ?>">
                        <input type="hidden" id="send_state" name="send_state" value="<?php echo h($sendStateFilter); ?>">
                        <?php if ($viewMode !== 'doctor'): ?>
                        <div class="mode-switch" title="Toggle send-state filter">
                            <span class="mode-label">All</span>
                            <label class="switch">
                                <input id="send_state_toggle" type="checkbox" <?php echo $sendStateFilter === 'not_sent' ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                            <span class="mode-label">Not Sent</span>
                        </div>
                        <?php endif; ?>
                        <input type="text" id="result_time_range" name="result_time_range" value="<?php echo h($resultTimeRange); ?>" placeholder="YYYY-MM-DD HH:MM to YYYY-MM-DD HH:MM">
                        <?php if ($resultTimeRange !== ''): ?>
                        <a class="btn secondary" href="index.php?<?php echo http_build_query(['mrn' => $mrn, 'view' => $viewMode, 'dept' => $departmentFilter, 'send_state' => $sendStateFilter]); ?>">Reset Time</a>
                        <?php endif; ?>
                    </form>
                </div>
                <?php if (empty($results)): ?>
                    <p class="muted">No results found for this MRN.</p>
                <?php else: ?>
                    <?php
                        $visitGroups = [];
                        $notSentCount = 0;
                        foreach ($results as $row) {
                            $source = (string)($row['source'] ?? 'json_import');
                            
                            // For manual uploads and collection notices, use creation date; for lab/rad, use visit_date
                            if ($source === 'manual_upload' || $source === 'collection_notice') {
                                $firstSeenAt = trim((string)($row['first_seen_at'] ?? ''));
                                $groupDate = $firstSeenAt !== '' ? (new DateTime($firstSeenAt))->format('Y-m-d') : 'Unknown Date';
                                $doctorName = ''; // No doctor for manual uploads or collection notices
                            } else {
                                $visitDate = trim((string)($row['visit_date'] ?? ''));
                                $groupDate = $visitDate !== '' ? $visitDate : 'Unknown Visit Date';
                                $doctorName = trim((string)($row['doctor_name'] ?? ''));
                            }
                            
                            if (!isset($visitGroups[$groupDate])) {
                                $visitGroups[$groupDate] = [
                                    'doctors' => [],
                                    'rows' => [],
                                ];
                            }
                            if ($doctorName !== '') {
                                $visitGroups[$groupDate]['doctors'][$doctorName] = true;
                            }
                            $department = (string)($row['department'] ?? '');
                            $requestCode = (string)($row['request_code'] ?? '');
                            $resultId = (int)($row['id'] ?? 0);
                            $templateType = resolveResultTemplateType($row);
                            $sentKey = $resultId;
                            if (!isset($sentMap[$sentKey])) {
                                $notSentCount++;
                            }
                            $visitGroups[$groupDate]['rows'][] = $row;
                        }
                        $activeRangeLabel = $resultTimeRange !== '' ? $resultTimeRange : 'All time';
                    ?>
                    <div class="results-summary">
                        <div class="item"><span class="label">Total Reports</span><span class="value"><?php echo h((string)count($results)); ?></span></div>
                        <div class="item"><span class="label">Not Sent</span><span class="value"><?php echo h((string)$notSentCount); ?></span></div>
                        <div class="item"><span class="label">Total Visits</span><span class="value"><?php echo h((string)count($visitGroups)); ?></span></div>
                        <div class="item"><span class="label">Time Filter</span><span class="value"><?php echo h($activeRangeLabel); ?></span></div>
                    </div>
                    <div class="results-groups">
                    <?php foreach ($visitGroups as $visitDate => $group): ?>
                        <?php
                            $doctorNames = array_keys($group['doctors']);
                            sort($doctorNames, SORT_NATURAL | SORT_FLAG_CASE);
                            $doctorLabel = !empty($doctorNames) ? ' - ' . implode(' / ', $doctorNames) : '';
                            $reportCount = count($group['rows']);
                        ?>
                        <details class="visit-group">
                            <summary>
                                <span><?php echo h($visitDate . $doctorLabel); ?></span>
                                <span class="meta"><i class="fa-solid fa-file-waveform" aria-hidden="true"></i> <?php echo h((string)$reportCount); ?> reports</span>
                            </summary>
                            <div class="rows">
                                <?php foreach ($group['rows'] as $row): ?>
                                    <?php
                                        $department = (string)($row['department'] ?? '');
                                        $requestCode = (string)($row['request_code'] ?? '');
                                        $source = (string)($row['source'] ?? 'json_import');
                                        $link = trim((string)($row['pdf_result_link'] ?? ''));
                                        $externalLink = toExternalResultLink($link);
                                        $resultId = (int)($row['id'] ?? 0);
                                        $templateType = resolveResultTemplateType($row);
                                        $sentKey = $resultId;
                                        $sent = $sentMap[$sentKey] ?? null;
                                        $sentContent = is_array($sent) ? decodeSentResultContentValue((string)($sent['content_value'] ?? '')) : ['link' => '', 'tests' => []];
                                        $sameContent = is_array($sent) && (
                                            $templateType === 'manual_pdf'
                                                ? true
                                                : trim((string)($sentContent['link'] ?? '')) === $link
                                        );
                                        $addedTests = [];
                                        $providerStatus = strtoupper(trim((string)($sent['provider_status'] ?? '')));
                                        $providerStatusLabel = $providerStatus !== '' ? $providerStatus : 'UNKNOWN';
                                        if ($sameContent && !empty($sentContent['tests']) && is_array($sentContent['tests'])) {
                                            $currentTests = parseTestEnumeration((string)($row['test_or_image'] ?? ''));
                                            $sentTestsMap = [];
                                            foreach ($sentContent['tests'] as $sentTest) {
                                                $sentTestsMap[strtolower(trim((string)$sentTest))] = true;
                                            }
                                            foreach ($currentTests as $currentTest) {
                                                $key = strtolower(trim((string)$currentTest));
                                                if ($key === '' || isset($sentTestsMap[$key])) {
                                                    continue;
                                                }
                                                $addedTests[] = $currentTest;
                                            }
                                        }
                                        $isManualUpload = $source === 'manual_upload' || $source === 'collection_notice';
                                        $isManualLink = $department === 'Manual Send' && $source === 'manual_upload';
                                        if ($isManualUpload) {
                                            $deptClass = 'manual';
                                        } elseif (strtolower($department) === 'radiology') {
                                            $deptClass = 'imaging';
                                        } else {
                                            $deptClass = 'lab';
                                        }
                                        $requestLabel = $isManualUpload ? 'Filename' : 'Request Code';
                                        $manualFilename = trim((string)($row['manual_filename'] ?? ''));
                                        
                                        // For manual links, apply role-based URL display
                                        if ($isManualLink && strpos($manualFilename, 'http') === 0) {
                                            // It's a URL - only show to master and butler
                                            if ($viewMode === 'master') {
                                                $requestValue = $manualFilename; // Show full URL for master
                                            } elseif ($viewMode === 'butler') {
                                                // For butler: show truncated URL (http://....last6chars)
                                                $urlLength = strlen($manualFilename);
                                                if ($urlLength > 6) {
                                                    $requestValue = 'http://....' . substr($manualFilename, -6);
                                                } else {
                                                    $requestValue = $manualFilename;
                                                }
                                            } else {
                                                // Other roles: don't show URL
                                                $requestValue = '';
                                            }
                                        } else {
                                            $requestValue = $isManualUpload ? $manualFilename : $requestCode;
                                        }
                                        if ($requestValue === '') {
                                            $requestValue = $requestCode;
                                        }
                                    ?>
                                    <div class="result-row-card">
                                        <div class="result-row-grid">
                                            <div class="cell">
                                                <span class="label"><i class="fa-solid fa-building" aria-hidden="true"></i>Department</span>
                                                <span class="value"><span class="dept-pill <?php echo h($deptClass); ?>"><?php echo h($department); ?></span></span>
                                            </div>
                                            <div class="cell">
                                                <span class="label"><i class="fa-solid <?php echo $isManualUpload ? 'fa-file-pdf' : 'fa-hashtag'; ?>" aria-hidden="true"></i><?php echo h($requestLabel); ?></span>
                                                <span class="value"><?php echo h($requestValue); ?></span>
                                            </div>
                                            <div class="cell">
                                                <span class="label"><i class="fa-solid fa-vial" aria-hidden="true"></i>Test/Image</span>
                                                <span class="value"><?php echo h((string)($row['test_or_image'] ?? '')); ?></span>
                                            </div>
                                            <div class="cell">
                                                <span class="label"><i class="fa-solid fa-paper-plane" aria-hidden="true"></i>Send State</span>
                                                <span class="value">
                                                    <?php 
                                                    $isManualUpload = $source === 'manual_upload' || $source === 'collection_notice';
                                                    
                                                    if (!is_array($sent)): ?>
                                                        <span class="send-tag not-sent">Not sent</span>
                                                    <?php elseif ($sameContent): ?>
                                                        <?php
                                                        $providerStatus = strtoupper(trim((string)($sent['provider_status'] ?? '')));
                                                        $providerRecipient = trim((string)($sent['provider_recipient'] ?? ''));
                                                        $isEmailRecipient = strpos($providerRecipient, '@') !== false;
                                                        
                                                        // Check if each channel was actually attempted by looking at last_attempt_at timestamps
                                                        $wpLastAttempt = trim((string)($sent['wp_last_attempt_at'] ?? ''));
                                                        $smsLastAttempt = trim((string)($sent['sms_last_attempt_at'] ?? ''));
                                                        $emailLastAttempt = trim((string)($sent['email_last_attempt_at'] ?? ''));
                                                        
                                                        $wpAttempted = $wpLastAttempt !== '';
                                                        $smsAttempted = $smsLastAttempt !== '';
                                                        $emailAttempted = $emailLastAttempt !== '';
                                                        
                                                        $smsSent = (int)($sent['sms_sent'] ?? 0) === 1;
                                                        $emailSent = (int)($sent['email_sent'] ?? 0) === 1;
                                                        $wpSent = (int)($sent['wp_sent'] ?? 0) === 1;

                                                        // WP status now uses independent flag
                                                        $wpFailed = $wpAttempted && !$wpSent;

                                                        if (!$wpAttempted) {
                                                            $wpStatusClass = 'not-sent';
                                                            $wpStatusLabel = 'not sent';
                                                        } elseif ($wpSent) {
                                                            $wpStatusClass = 'wp-sent';
                                                            $wpStatusLabel = 'sent';
                                                        } else {
                                                            $wpStatusClass = 'wp-failed';
                                                            $wpStatusLabel = 'failed';
                                                        }

                                                        if (!$smsAttempted) {
                                                            $smsStatusClass = 'not-sent';
                                                            $smsStatusLabel = 'not sent';
                                                        } elseif ($smsSent) {
                                                            $smsStatusClass = 'sms-sent';
                                                            $smsStatusLabel = 'sent';
                                                        } else {
                                                            $smsStatusClass = 'sms-failed';
                                                            $smsStatusLabel = 'failed';
                                                        }

                                                        if (!$emailAttempted) {
                                                            $emailStatusClass = 'not-sent';
                                                            $emailStatusLabel = 'not sent';
                                                        } elseif ($emailSent) {
                                                            $emailStatusClass = 'email-sent';
                                                            $emailStatusLabel = 'sent';
                                                        } else {
                                                            $emailStatusClass = 'email-failed';
                                                            $emailStatusLabel = 'failed';
                                                        }
                                                        ?>
                                                        <!-- Per-channel send timestamps and tags -->
                                                        <?php
                                                            // For manual uploads: identify which channel was used and show ONLY that one
                                                            if ($isManualUpload && ($wpAttempted || $smsAttempted || $emailAttempted)):
                                                                // Show only the channel(s) that were attempted for manual uploads
                                                                if ($wpAttempted):
                                                        ?>
                                                        <span class="send-tag <?php echo $wpStatusClass; ?>">WhatsApp <?php echo $wpStatusLabel; ?></span>
                                                        <div class="send-timestamp" style="margin-top: 6px; font-size: 0.85em; color: #666;">
                                                            <i class="fa-brands fa-whatsapp" aria-hidden="true"></i> <?php echo h(formatAttemptDateTimeDisplay($wpLastAttempt)); ?>
                                                        </div>
                                                        <?php endif; if ($smsAttempted): ?>
                                                        <span class="send-tag <?php echo $smsStatusClass; ?>">SMS <?php echo $smsStatusLabel; ?></span>
                                                        <div class="send-timestamp" style="margin-top: 6px; font-size: 0.85em; color: #666;">
                                                            <i class="fa-solid fa-message" aria-hidden="true"></i> <?php echo h(formatAttemptDateTimeDisplay($smsLastAttempt)); ?>
                                                        </div>
                                                        <?php endif; if ($emailAttempted): ?>
                                                        <span class="send-tag <?php echo $emailStatusClass; ?>">Email <?php echo $emailStatusLabel; ?></span>
                                                        <div class="send-timestamp" style="margin-top: 6px; font-size: 0.85em; color: #666;">
                                                            <i class="fa-solid fa-envelope" aria-hidden="true"></i> <?php echo h(formatAttemptDateTimeDisplay($emailLastAttempt)); ?>
                                                        </div>
                                                        <?php endif; else: ?>
                                                            <!-- For lab/radiology results: only show channels that were attempted -->
                                                            <?php if ($wpAttempted): ?>
                                                            <span class="send-tag <?php echo $wpStatusClass; ?>">WP <?php echo $wpStatusLabel; ?></span>
                                                            <?php endif; ?>
                                                            <?php if ($smsAttempted): ?>
                                                            <span class="send-tag <?php echo $smsStatusClass; ?>">SMS <?php echo $smsStatusLabel; ?></span>
                                                            <?php endif; ?>
                                                            <?php if ($emailAttempted): ?>
                                                            <span class="send-tag <?php echo $emailStatusClass; ?>">Email <?php echo $emailStatusLabel; ?></span>
                                                            <?php endif; ?>
                                                            
                                                            <?php if ($wpAttempted): ?>
                                                            <div class="send-timestamp" style="margin-top: 6px; font-size: 0.85em; color: #666;">
                                                                <i class="fa-brands fa-whatsapp" aria-hidden="true"></i> <?php echo h(formatAttemptDateTimeDisplay($wpLastAttempt)); ?>
                                                            </div>
                                                            <?php endif; ?>
                                                            <?php if ($smsAttempted): ?>
                                                            <div class="send-timestamp" style="margin-top: 4px; font-size: 0.85em; color: #666;">
                                                                <i class="fa-solid fa-message" aria-hidden="true"></i> <?php echo h(formatAttemptDateTimeDisplay($smsLastAttempt)); ?>
                                                            </div>
                                                            <?php endif; ?>
                                                            <?php if ($emailAttempted): ?>
                                                            <div class="send-timestamp" style="margin-top: 4px; font-size: 0.85em; color: #666;">
                                                                <i class="fa-solid fa-envelope" aria-hidden="true"></i> <?php echo h(formatAttemptDateTimeDisplay($emailLastAttempt)); ?>
                                                            </div>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span class="send-tag changed">Link changed since last send</span>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                        </div>

                                        <div>
                                            <?php if ($source === 'json_import' && $link !== '' && ($department === 'Laboratory' || $department === 'Radiology')): ?>
                                                <div class="toolbar">
                                                    <?php if (!$isButlerView): ?>
                                                    <a class="btn secondary" href="<?php echo h($externalLink); ?>" target="_blank" rel="noopener noreferrer">
                                                        <i class="fa-solid fa-up-right-from-square" aria-hidden="true" style="margin-right: 6px;"></i>Open Link
                                                    </a>
                                                    <?php endif; ?>
                                                    <?php if (!$isReadOnlyView): ?>
                                                    <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                                        <?php
                                                        // Determine button states based on actual send status
                                                        $wpSuccessful = false;
                                                        $smsSuccessful = false;
                                                        $emailSuccessful = false;
                                                        
                                                        if (is_array($sent) && $sameContent) {
                                                            // Use last_attempt_at to determine if channel was attempted
                                                            $wpButtonLastAttempt = trim((string)($sent['wp_last_attempt_at'] ?? ''));
                                                            $smsButtonLastAttempt = trim((string)($sent['sms_last_attempt_at'] ?? ''));
                                                            $emailButtonLastAttempt = trim((string)($sent['email_last_attempt_at'] ?? ''));
                                                            
                                                            $wpButtonAttempted = $wpButtonLastAttempt !== '';
                                                            $smsButtonAttempted = $smsButtonLastAttempt !== '';
                                                            $emailButtonAttempted = $emailButtonLastAttempt !== '';

                                                            $wpSuccessful = $wpButtonAttempted && (int)($sent['wp_sent'] ?? 0) === 1;
                                                            $smsSuccessful = $smsButtonAttempted && (int)($sent['sms_sent'] ?? 0) === 1;
                                                            $emailSuccessful = $emailButtonAttempted && (int)($sent['email_sent'] ?? 0) === 1;
                                                        }
                                                        ?>
                                                        <form method="post" action="result_sending.php" style="display: contents;">
                                                            <input type="hidden" name="send_result_single" value="1">
                                                            <input type="hidden" name="mrn" value="<?php echo h($mrn); ?>">
                                                            <input type="hidden" name="department" value="<?php echo h($department); ?>">
                                                            <input type="hidden" name="request_code" value="<?php echo h($requestCode); ?>">
                                                            <input type="hidden" name="force_resend" value="<?php echo $wpSuccessful ? '1' : '0'; ?>">
                                                            <input type="hidden" name="send_channel" value="whatsapp">
                                                            <input type="hidden" name="return_url" value="<?php echo h(buildIndexUrl(['mrn' => $mrn])); ?>">
                                                            <button class="btn <?php echo $wpSuccessful ? 'resend' : 'whatsapp'; ?>" type="submit"><i class="fa-brands fa-whatsapp" aria-hidden="true" style="margin-right: 6px;"></i><?php echo $wpSuccessful ? 'Resend WhatsApp' : 'Send WhatsApp'; ?></button>
                                                        </form>
                                                        <form method="post" action="result_sending.php" style="display: contents;">
                                                            <input type="hidden" name="send_result_single" value="1">
                                                            <input type="hidden" name="mrn" value="<?php echo h($mrn); ?>">
                                                            <input type="hidden" name="department" value="<?php echo h($department); ?>">
                                                            <input type="hidden" name="request_code" value="<?php echo h($requestCode); ?>">
                                                            <input type="hidden" name="force_resend" value="<?php echo $smsSuccessful ? '1' : '0'; ?>">
                                                            <input type="hidden" name="send_channel" value="sms">
                                                            <input type="hidden" name="return_url" value="<?php echo h(buildIndexUrl(['mrn' => $mrn])); ?>">
                                                            <button class="btn <?php echo $smsSuccessful ? 'resend' : 'sms'; ?>" type="submit"><i class="fa-solid fa-message" aria-hidden="true" style="margin-right: 6px;"></i><?php echo $smsSuccessful ? 'Resend SMS' : 'Send SMS'; ?></button>
                                                        </form>
                                                        <form method="post" action="result_sending.php" style="display: contents;">
                                                            <input type="hidden" name="send_result_single" value="1">
                                                            <input type="hidden" name="mrn" value="<?php echo h($mrn); ?>">
                                                            <input type="hidden" name="department" value="<?php echo h($department); ?>">
                                                            <input type="hidden" name="request_code" value="<?php echo h($requestCode); ?>">
                                                            <input type="hidden" name="force_resend" value="<?php echo $emailSuccessful ? '1' : '0'; ?>">
                                                            <input type="hidden" name="send_channel" value="email">
                                                            <input type="hidden" name="return_url" value="<?php echo h(buildIndexUrl(['mrn' => $mrn])); ?>">
                                                            <button class="btn <?php echo $emailSuccessful ? 'resend' : 'email'; ?>" type="submit"><i class="fa-solid fa-envelope" aria-hidden="true" style="margin-right: 6px;"></i><?php echo $emailSuccessful ? 'Resend Email' : 'Send Email'; ?></button>
                                                        </form>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            <?php else: ?>
                                                <span class="muted">No direct send action</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </details>
                    <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    (function () {
        const dateInput = document.getElementById('date_range');
        const resultTimeInput = document.getElementById('result_time_range');
        const resultsFilterForm = document.getElementById('results_filter_form');
        const sendStateToggle = document.getElementById('send_state_toggle');
        const sendStateHidden = document.getElementById('send_state');
        const periodSelect = document.querySelector('select[name="period"]');
        const patientsForm = periodSelect ? periodSelect.closest('form') : null;
        if (dateInput && typeof flatpickr !== 'undefined') {
            flatpickr(dateInput, {
                mode: 'range',
                dateFormat: 'Y-m-d',
                allowInput: true,
            });

            dateInput.addEventListener('change', function () {
                if (periodSelect && dateInput.value.trim() !== '') {
                    periodSelect.value = 'custom';
                }
            });
        }

        if (resultTimeInput && typeof flatpickr !== 'undefined') {
            flatpickr(resultTimeInput, {
                mode: 'range',
                enableTime: true,
                time_24hr: true,
                dateFormat: 'Y-m-d H:i',
                allowInput: true,
                onClose: function () {
                    if (resultsFilterForm) {
                        resultsFilterForm.submit();
                    }
                },
            });

            resultTimeInput.addEventListener('change', function () {
                if (resultsFilterForm) {
                    resultsFilterForm.submit();
                }
            });
        }

        if (sendStateToggle && sendStateHidden && resultsFilterForm) {
            const syncSendState = function () {
                sendStateHidden.value = sendStateToggle.checked ? 'not_sent' : 'all';
            };
            syncSendState();
            sendStateToggle.addEventListener('change', function () {
                syncSendState();
                resultsFilterForm.submit();
            });
        }

        if (periodSelect) {
            periodSelect.addEventListener('change', function () {
                if (!patientsForm) {
                    return;
                }

                const selected = (periodSelect.value || '').toLowerCase();
                if (selected === 'today' || selected === 'yesterday' || selected === 'last_week') {
                    patientsForm.submit();
                }
            });
        }

        const toggle = document.getElementById('date_mode_toggle');
        const hiddenMode = document.getElementById('date_mode');
        const modeForm = hiddenMode ? hiddenMode.closest('form') : null;
        if (toggle && hiddenMode) {
            const syncMode = function () {
                hiddenMode.value = toggle.checked ? 'released' : 'visit';
            };
            syncMode();
            toggle.addEventListener('change', function () {
                syncMode();
                if (modeForm) {
                    modeForm.submit();
                }
            });
        }
    })();
</script>
</body>
</html>

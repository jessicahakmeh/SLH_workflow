<?php
require 'sent_results_db.php';

try {
    $pdo = openResultsDb();
    if (!$pdo) {
        echo 'Error: Could not open database';
        exit(1);
    }
    
    // Check what tables exist
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "=== Available Tables ===\n";
    echo implode("\n", $tables) . "\n\n";
    $stmt = $pdo->prepare('
        SELECT 
            id, 
            mrn, 
            department, 
            request_code, 
            result_link_added_at, 
            visit_date,
            pdf_result_link
        FROM patient_results 
        WHERE mrn = 165255 
        AND department = "Radiology" 
        ORDER BY result_link_added_at DESC 
        LIMIT 10
    ');
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "=== Patient 165255 Radiology Results ===\n";
    echo json_encode($results, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n\n";
    
    // Check if they're pending (sent status)
    echo "=== Sent Status ===\n";
    foreach ($results as $result) {
        $checkStmt = $pdo->prepare('
            SELECT 
                id,
                wp_sent,
                sms_sent,
                email_sent,
                wp_last_attempt_at,
                sms_last_attempt_at,
                email_last_attempt_at
            FROM sent_results
            WHERE result_id = ?
            AND template_type = "result"
            ORDER BY sent_at DESC
            LIMIT 1
        ');
        $checkStmt->execute([$result['id']]);
        $sent = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        echo "Result ID " . $result['id'] . ": ";
        if ($sent) {
            echo "Already sent - WP: " . $sent['wp_sent'] . ", SMS: " . $sent['sms_sent'] . ", Email: " . $sent['email_sent'];
        } else {
            echo "NOT SENT (pending)";
        }
        echo "\n";
    }
    
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>

<?php
echo "=== CHECKING ALL DATABASES FOR PATIENT_RESULTS ===\n\n";

$databases = ['slhcycle', 'slh', 'slh_cmp', 'slh_new', 'slh_fresh_e2e'];

foreach ($databases as $dbname) {
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=$dbname", 'root', '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM patient_results");
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['cnt'];
        
        // Get today's results
        $today = date('Y-m-d');
        $stmt = $pdo->prepare('
            SELECT COUNT(*) as cnt 
            FROM patient_results 
            WHERE DATE(result_link_added_at) = ?
            AND department IN ("Laboratory", "Radiology")
            AND pdf_result_link IS NOT NULL
            AND pdf_result_link <> ""
        ');
        $stmt->execute([$today]);
        $todayCount = $stmt->fetch(PDO::FETCH_ASSOC)['cnt'];
        
        echo "Database: $dbname\n";
        echo "  Total patient_results: $count\n";
        echo "  Released today: $todayCount\n";
        
        if ($count > 0) {
            $stmt = $pdo->query("
                SELECT pr.mrn, pr.request_code, pr.department, pr.result_link_added_at,
                       p.patient_name, p.care_mobile, p.email,
                       sr.id as sent_id
                FROM patient_results AS pr
                LEFT JOIN patients AS p ON p.mrn = pr.mrn
                LEFT JOIN sent_results AS sr ON sr.result_id = pr.id AND sr.template_type = 'result'
                WHERE DATE(pr.result_link_added_at) = DATE(NOW())
                AND pr.department IN ('Laboratory', 'Radiology')
                AND pr.pdf_result_link IS NOT NULL
                LIMIT 5
            ");
            $todayResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($todayResults as $row) {
                $status = empty($row['sent_id']) ? 'NOT SENT' : 'SENT';
                echo "  - MRN {$row['mrn']} | {$row['request_code']} | {$status}\n";
            }
        }
        echo "\n";
        
    } catch (Exception $e) {
        echo "Database: $dbname - ERROR: " . $e->getMessage() . "\n\n";
    }
}
?>

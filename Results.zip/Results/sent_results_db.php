<?php

declare(strict_types=1);

/**
 * Shared database/data-access helpers for the results dashboard.
 */

require_once __DIR__ . '/env.php';
loadEnvFile();

if (!defined('RESULTS_DB_HOST')) {
    define('RESULTS_DB_HOST', (string)(envValue('DB_HOST', null) ?? ''));
}
if (!defined('RESULTS_DB_PORT')) {
    define('RESULTS_DB_PORT', (string)(envValue('DB_PORT', null) ?? ''));
}
if (!defined('RESULTS_DB_NAME')) {
    define('RESULTS_DB_NAME', (string)(envValue('DB_NAME', null) ?? ''));
}
if (!defined('RESULTS_DB_USER')) {
    define('RESULTS_DB_USER', (string)(envValue('DB_USER', null) ?? ''));
}
if (!defined('RESULTS_DB_PASS')) {
    define('RESULTS_DB_PASS', (string)(envValue('DB_PASS', null) ?? ''));
}

$GLOBALS['results_db_last_error'] = '';

function setResultsDbLastError(string $message): void
{
    $GLOBALS['results_db_last_error'] = trim($message);
}

function getResultsDbLastError(): string
{
    $value = $GLOBALS['results_db_last_error'] ?? '';
    return is_string($value) ? $value : '';
}

function openResultsDb(): ?PDO
{
    if (!class_exists('PDO')) {
        setResultsDbLastError('PDO extension is not available.');
        @file_put_contents(__DIR__ . '/logs/db_debug.log', date('Y-m-d H:i:s') . " [DB] PDO not available\n", FILE_APPEND);
        return null;
    }

    static $pdo = null;
    static $lastConnectTime = 0;
    
    // Validate existing connection - test it with a simple query
    if ($pdo instanceof PDO) {
        try {
            $pdo->query('SELECT 1');
            setResultsDbLastError('');
            @file_put_contents(__DIR__ . '/logs/db_debug.log', date('Y-m-d H:i:s') . " [DB] Reusing existing connection\n", FILE_APPEND);
            return $pdo;
        } catch (Throwable $e) {
            // Connection is stale, clear it and reconnect
            $pdo = null;
            @file_put_contents(__DIR__ . '/logs/db_debug.log', date('Y-m-d H:i:s') . " [DB] Existing connection stale, reconnecting: " . $e->getMessage() . "\n", FILE_APPEND);
        }
    }

    @file_put_contents(__DIR__ . '/logs/db_debug.log', date('Y-m-d H:i:s') . " [DB] Checking config: host=" . RESULTS_DB_HOST . ", port=" . RESULTS_DB_PORT . ", name=" . RESULTS_DB_NAME . ", user=" . RESULTS_DB_USER . "\n", FILE_APPEND);

    if (RESULTS_DB_HOST === '' || RESULTS_DB_PORT === '' || RESULTS_DB_NAME === '' || RESULTS_DB_USER === '') {
        setResultsDbLastError('Database configuration is incomplete.');
        @file_put_contents(__DIR__ . '/logs/db_debug.log', date('Y-m-d H:i:s') . " [DB] Config incomplete\n", FILE_APPEND);
        return null;
    }

    try {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            RESULTS_DB_HOST,
            RESULTS_DB_PORT,
            RESULTS_DB_NAME
        );

        @file_put_contents(__DIR__ . '/logs/db_debug.log', date('Y-m-d H:i:s') . " [DB] Connecting to: " . $dsn . "\n", FILE_APPEND);

        $pdo = new PDO($dsn, RESULTS_DB_USER, RESULTS_DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_TIMEOUT => 10,
        ]);

        $lastConnectTime = time();

        @file_put_contents(__DIR__ . '/logs/db_debug.log', date('Y-m-d H:i:s') . " [DB] Connection successful\n", FILE_APPEND);

        setResultsDbLastError('');

        return $pdo;
    } catch (Throwable $exception) {
        $errorMsg = (string)$exception->getMessage();
        setResultsDbLastError($errorMsg);
        @file_put_contents(__DIR__ . '/logs/db_debug.log', date('Y-m-d H:i:s') . " [DB] Connection failed: " . $errorMsg . "\n", FILE_APPEND);
        
        // Also log to Apache error log for send_pending visibility
        error_log(sprintf(
            "[%s] openResultsDb FAILED: Cannot connect to %s:%s/%s as %s. Error: %s",
            date('Y-m-d H:i:s'),
            RESULTS_DB_HOST,
            RESULTS_DB_PORT,
            RESULTS_DB_NAME,
            RESULTS_DB_USER,
            $errorMsg
        ));
        
        return null;
    }
}

function sanitizeMrn(string $mrn): string
{
    return preg_replace('/[^A-Za-z0-9_\-]/', '', $mrn) ?? '';
}

function generatePatientId(PDO $pdo): ?string
{
    $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

    for ($i = 0; $i < 30; $i++) {
        $id = '';
        for ($j = 0; $j < 5; $j++) {
            $id .= $letters[random_int(0, 25)];
        }

        $stmt = $pdo->prepare('SELECT id FROM patients WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $exists = $stmt->fetch();
        if (!is_array($exists)) {
            return $id;
        }
    }

    return null;
}

function getOrCreatePatientId(string $mrn, string $patientName, string $careMobile, string $email, ?string $dateOfBirth = null): ?string
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }

    $mrn = sanitizeMrn($mrn);
    if ($mrn === '') {
        return null;
    }

    try {
        $find = $pdo->prepare('SELECT id FROM patients WHERE mrn = :mrn LIMIT 1');
        $find->execute([':mrn' => $mrn]);
        $row = $find->fetch();

        if (is_array($row) && !empty($row['id'])) {
            $patientId = (string)$row['id'];
            $update = $pdo->prepare('UPDATE patients SET patient_name = :patient_name, care_mobile = :care_mobile, email = :email, date_of_birth = COALESCE(:date_of_birth, date_of_birth), updated_at = CURRENT_TIMESTAMP WHERE id = :id');
            $update->execute([
                ':patient_name' => $patientName,
                ':care_mobile' => $careMobile,
                ':email' => $email,
                ':date_of_birth' => $dateOfBirth,
                ':id' => $patientId,
            ]);
            return $patientId;
        }

        $patientId = generatePatientId($pdo);
        if ($patientId === null) {
            return null;
        }

        $insert = $pdo->prepare('INSERT INTO patients (id, mrn, patient_name, care_mobile, email, date_of_birth) VALUES (:id, :mrn, :patient_name, :care_mobile, :email, :date_of_birth)');
        $insert->execute([
            ':id' => $patientId,
            ':mrn' => $mrn,
            ':patient_name' => $patientName,
            ':care_mobile' => $careMobile,
            ':email' => $email,
            ':date_of_birth' => $dateOfBirth,
        ]);

        return $patientId;
    } catch (Throwable $exception) {
        return null;
    }
}

function normalizeDepartment(string $department): string
{
    $value = strtolower(trim($department));
    if ($value === 'lab') {
        return 'Laboratory';
    }
    if ($value === 'laboratory') {
        return 'Laboratory';
    }
    if ($value === 'radiology' || strpos($value, 'imaging') !== false) {
        return 'Radiology';
    }
    if ($value === 'manual' || strpos($value, 'manual') !== false) {
        return 'Manual Upload';
    }

    return trim($department);
}

function normalizeDateOnly(string $value): ?string
{
    $raw = trim($value);
    if ($raw === '') {
        return null;
    }

    if (preg_match('/^\d{4}-\d{2}-\d{2}/', $raw) === 1) {
        return substr($raw, 0, 10);
    }

    $timestamp = strtotime($raw);
    if ($timestamp === false) {
        return null;
    }

    return date('Y-m-d', $timestamp);
}

function getPatientByMrn(string $mrn): ?array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }

    $mrn = sanitizeMrn($mrn);
    if ($mrn === '') {
        return null;
    }

        $sql = "SELECT id AS patient_id, mrn, patient_name, care_mobile, email, date_of_birth, gender, created_at AS first_seen_at, updated_at AS last_updated_at
            FROM patients
            WHERE mrn = :mrn
            ORDER BY updated_at DESC
            LIMIT 1";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':mrn' => $mrn]);
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    } catch (Throwable $exception) {
        return null;
    }
}

function getPatientResultsByMrn(string $mrn): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [];
    }

    $mrn = sanitizeMrn($mrn);
    if ($mrn === '') {
        return [];
    }

        $sql = "SELECT pr.id, pr.mrn,
                 p.patient_name,
                 p.care_mobile,
                 pr.department, pr.test_or_image, pr.request_code,
                 pr.pdf_result_link, pr.visit_date, pr.end_visit_date, pr.case_number, pr.doctor_name,
                 pr.doctor_specialty, pr.source, pr.json_file_hash, pr.manual_filename,
                 pr.first_seen_at, pr.last_updated_at
             FROM patient_results AS pr
             LEFT JOIN patients AS p ON p.mrn = pr.mrn
             WHERE pr.mrn = :mrn
             ORDER BY COALESCE(pr.visit_date, '1900-01-01') DESC, pr.department ASC, pr.request_code ASC";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':mrn' => $mrn]);
        $rows = $stmt->fetchAll();
        return is_array($rows) ? $rows : [];
    } catch (Throwable $exception) {
        return [];
    }
}

function getPatientsByLastVisitRange(?string $startDate, ?string $endDate): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [];
    }

    $where = '';
    $params = [];

    if ($startDate !== null && $endDate !== null) {
        $where = 'WHERE DATE(COALESCE(end_visit_date, visit_date)) BETWEEN :start_date AND :end_date';
        $params[':start_date'] = $startDate;
        $params[':end_date'] = $endDate;
    }

    $sql = "SELECT summary.mrn,
                   p.patient_name,
                   p.care_mobile,
                   summary.last_visit_date,
                   summary.last_updated_at,
                   summary.result_count,
                   latest.department AS latest_department,
                   latest.test_or_image AS latest_test_or_image,
                   latest.request_code AS latest_request_code,
                   latest.visit_date AS latest_visit_date,
                   latest.end_visit_date AS latest_end_visit_date,
                   latest.pdf_result_link AS latest_pdf_result_link
            FROM (
                  SELECT mrn,
                       MAX(COALESCE(end_visit_date, visit_date)) AS last_visit_date,
                       MAX(last_updated_at) AS last_updated_at,
                       COUNT(*) AS result_count
                FROM patient_results
                $where
                GROUP BY mrn
            ) AS summary
            LEFT JOIN patients AS p ON p.mrn = summary.mrn
            LEFT JOIN patient_results AS latest
                ON latest.id = (
                    SELECT pr.id
                    FROM patient_results AS pr
                    WHERE pr.mrn = summary.mrn
                      AND COALESCE(pr.end_visit_date, pr.visit_date) = summary.last_visit_date
                    ORDER BY pr.last_updated_at DESC, pr.id DESC
                    LIMIT 1
                )
            ORDER BY summary.last_visit_date DESC, summary.mrn DESC";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        return is_array($rows) ? $rows : [];
    } catch (Throwable $exception) {
        return [];
    }
}

function getPatientsByResultReleasedRange(?string $startDate, ?string $endDate): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [];
    }

    $where = "WHERE result_link_added_at IS NOT NULL";
    $params = [];

    if ($startDate !== null && $endDate !== null) {
        $where .= ' AND DATE(result_link_added_at) BETWEEN :start_date AND :end_date';
        $params[':start_date'] = $startDate;
        $params[':end_date'] = $endDate;
    }

    $sql = "SELECT summary.mrn,
                   p.patient_name,
                   p.care_mobile,
                   summary.result_released_date,
                   summary.last_updated_at,
                   summary.result_count,
                   latest.department AS latest_department,
                   latest.test_or_image AS latest_test_or_image,
                   latest.request_code AS latest_request_code,
                   latest.visit_date AS latest_visit_date,
                   latest.end_visit_date AS latest_end_visit_date,
                   latest.pdf_result_link AS latest_pdf_result_link
            FROM (
                SELECT mrn,
                       MAX(result_link_added_at) AS result_released_date,
                       MAX(last_updated_at) AS last_updated_at,
                       COUNT(*) AS result_count
                FROM patient_results
                $where
                GROUP BY mrn
            ) AS summary
            LEFT JOIN patients AS p ON p.mrn = summary.mrn
            LEFT JOIN patient_results AS latest
                ON latest.id = (
                    SELECT pr.id
                    FROM patient_results AS pr
                    WHERE pr.mrn = summary.mrn
                      AND pr.result_link_added_at = summary.result_released_date
                    ORDER BY pr.last_updated_at DESC, pr.id DESC
                    LIMIT 1
                )
            ORDER BY summary.result_released_date DESC, summary.mrn DESC";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        return is_array($rows) ? $rows : [];
    } catch (Throwable $exception) {
        return [];
    }
}

function findResultRecord(string $mrn, string $requestCode, string $department): ?array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }

    $mrn = sanitizeMrn($mrn);
    $requestCode = trim($requestCode);
    $department = normalizeDepartment($department);

    if ($mrn === '' || $requestCode === '' || $department === '') {
        return null;
    }

        $sql = "SELECT pr.*, p.patient_name, p.care_mobile, p.email
            FROM patient_results AS pr
            LEFT JOIN patients AS p ON p.mrn = pr.mrn
            WHERE pr.mrn = :mrn AND pr.request_code = :request_code AND pr.department = :department
            LIMIT 1";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':mrn' => $mrn,
            ':request_code' => $requestCode,
            ':department' => $department,
        ]);
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    } catch (Throwable $exception) {
        return null;
    }
}

function getLastJsonHashForMrn(string $mrn): ?string
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }

    $mrn = sanitizeMrn($mrn);
    if ($mrn === '') {
        return null;
    }

    $sql = "SELECT json_file_hash
            FROM patient_results
            WHERE mrn = :mrn AND source = 'json_import' AND json_file_hash IS NOT NULL AND json_file_hash <> ''
            ORDER BY last_updated_at DESC
            LIMIT 1";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':mrn' => $mrn]);
        $row = $stmt->fetch();
        if (!is_array($row)) {
            return null;
        }

        $hash = trim((string)($row['json_file_hash'] ?? ''));
        return $hash !== '' ? $hash : null;
    } catch (Throwable $exception) {
        return null;
    }
}

function upsertPatientResult(array $data): bool
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return false;
    }

    // Check if this is an insert or update, and if the result link is new
    $existing = null;
    if (!empty($data['mrn']) && !empty($data['request_code']) && !empty($data['department'])) {
        $existing = findResultRecord($data['mrn'], $data['request_code'], $data['department']);
    }

    $splitCommaValues = static function (string $value): array {
        $parts = preg_split('/\s*,\s*/', trim($value));
        if (!is_array($parts)) {
            return [];
        }

        $items = [];
        foreach ($parts as $part) {
            $item = trim((string)$part);
            if ($item === '') {
                continue;
            }
            $items[] = $item;
        }

        return $items;
    };

    $mergeCommaValues = static function (string $left, string $right) use ($splitCommaValues): string {
        $merged = [];
        $seen = [];

        foreach ([$left, $right] as $value) {
            foreach ($splitCommaValues($value) as $item) {
                $key = strtolower($item);
                if (isset($seen[$key])) {
                    continue;
                }
                $seen[$key] = true;
                $merged[] = $item;
            }
        }

        return implode(', ', $merged);
    };

    $now = date('Y-m-d H:i:s');
    $resultLink = trim((string)($data['pdf_result_link'] ?? ''));
    $department = normalizeDepartment((string)($data['department'] ?? ''));
    $testOrImage = trim((string)($data['test_or_image'] ?? ''));
    $patientName = trim((string)($data['patient_name'] ?? ''));
    $careMobile = trim((string)($data['care_mobile'] ?? ''));
    $email = trim((string)($data['email'] ?? ''));
    $dateOfBirth = normalizeDateOnly((string)($data['date_of_birth'] ?? ''));
    $patientId = getOrCreatePatientId((string)($data['mrn'] ?? ''), $patientName, $careMobile, $email, $dateOfBirth);
    if ($patientId === null) {
        return false;
    }
    $resultLinkAddedAt = null;
    if ($existing === null) {
        // New record, set result_link_added_at if there is a result link
        if ($resultLink !== '') {
            $resultLinkAddedAt = $now;
        }
    } else {
        // Existing record: NEVER update result_link_added_at on re-import
        // The timestamp should only reflect when the link was FIRST made available, not when JSON was re-imported
        $prevLink = trim((string)($existing['pdf_result_link'] ?? ''));
        $prevAddedAt = $existing['result_link_added_at'] ?? null;
        if ($prevLink === '' && $resultLink !== '') {
            // Link was previously empty, now has content - this is new link availability
            $resultLinkAddedAt = $now;
        } else {
            // Link existed before (same or different) - preserve original timestamp
            // This prevents old results from being re-sent just because JSON was re-imported
            $resultLinkAddedAt = $prevAddedAt;
        }
    }

    if (is_array($existing) && $department === 'Laboratory') {
        $existingTests = trim((string)($existing['test_or_image'] ?? ''));
        if ($existingTests !== '') {
            $testOrImage = $mergeCommaValues($existingTests, $testOrImage);
        }
    }

    $sql = "INSERT INTO patient_results (
                mrn, department, test_or_image,
                request_code, pdf_result_link, visit_date, end_visit_date, case_number,
                doctor_name, doctor_specialty, source, json_file_hash, manual_filename, result_link_added_at
            ) VALUES (
                :mrn, :department, :test_or_image,
                :request_code, :pdf_result_link, :visit_date, :end_visit_date, :case_number,
                :doctor_name, :doctor_specialty, :source, :json_file_hash, :manual_filename, :result_link_added_at
            )
            ON DUPLICATE KEY UPDATE
                test_or_image = VALUES(test_or_image),
                pdf_result_link = VALUES(pdf_result_link),
                visit_date = VALUES(visit_date),
                end_visit_date = VALUES(end_visit_date),
                case_number = VALUES(case_number),
                doctor_name = VALUES(doctor_name),
                doctor_specialty = VALUES(doctor_specialty),
                source = VALUES(source),
                json_file_hash = VALUES(json_file_hash),
                manual_filename = VALUES(manual_filename),
                result_link_added_at = VALUES(result_link_added_at),
                last_updated_at = CURRENT_TIMESTAMP";

    try {
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([
            ':mrn' => sanitizeMrn((string)($data['mrn'] ?? '')),
            ':department' => $department,
            ':test_or_image' => $testOrImage,
            ':request_code' => trim((string)($data['request_code'] ?? '')),
            ':pdf_result_link' => $resultLink,
            ':visit_date' => normalizeDateOnly((string)($data['visit_date'] ?? '')),
            ':end_visit_date' => normalizeDateOnly((string)($data['end_visit_date'] ?? '')),
            ':case_number' => trim((string)($data['case_number'] ?? '')),
            ':doctor_name' => trim((string)($data['doctor_name'] ?? '')),
            ':doctor_specialty' => trim((string)($data['doctor_specialty'] ?? '')),
            ':source' => trim((string)($data['source'] ?? 'json_import')),
            ':json_file_hash' => trim((string)($data['json_file_hash'] ?? '')),
            ':manual_filename' => trim((string)($data['manual_filename'] ?? '')),
            ':result_link_added_at' => $resultLinkAddedAt,
        ]);
    } catch (Throwable $exception) {
        return false;
    }
}

function insertImportLog(array $row): void
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return;
    }

    $sql = "INSERT INTO json_import_log (
                mrn, file_name, file_hash, status, imported_count, skipped_count, error_message, run_at
            ) VALUES (
                :mrn, :file_name, :file_hash, :status, :imported_count, :skipped_count, :error_message, NOW()
            )";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':mrn' => sanitizeMrn((string)($row['mrn'] ?? '')),
            ':file_name' => trim((string)($row['file_name'] ?? '')),
            ':file_hash' => trim((string)($row['file_hash'] ?? '')),
            ':status' => trim((string)($row['status'] ?? 'unknown')),
            ':imported_count' => (int)($row['imported_count'] ?? 0),
            ':skipped_count' => (int)($row['skipped_count'] ?? 0),
            ':error_message' => trim((string)($row['error_message'] ?? '')),
        ]);
    } catch (Throwable $exception) {
        // Non-blocking log insert.
    }
}

function getLatestSendRecord(int $resultId, string $templateType): ?array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }

                $sql = "SELECT id, result_id, template_type, content_type, content_value, sent_at, sent_by,
                                                                         provider_ack, provider_status, provider_recipient, provider_response,
                                                                         delivered_at, status_checked_at, status_source,
                                                                         email_sent, email_delivered_at, sms_sent, sms_delivered_at, wp_sent
            FROM sent_results
            WHERE result_id = :result_id
              AND template_type = :template_type
            ORDER BY sent_at DESC
            LIMIT 1";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':result_id' => $resultId,
            ':template_type' => trim($templateType),
        ]);
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    } catch (Throwable $exception) {
        return null;
    }
}

function saveSentRecord(
    int $resultId,
    string $templateType,
    string $contentType,
    string $contentValue,
    ?string $sentBy = null,
    array $providerMeta = []
): bool {
    $pdo = openResultsDb();
    if ($pdo === null) {
        return false;
    }

     $sql = "INSERT INTO sent_results (
                result_id, template_type, content_type, content_value, sent_at, sent_by,
                provider_ack, provider_status, provider_recipient, provider_response,
                     delivered_at, status_checked_at, status_source, email_sent, email_delivered_at,
                     email_last_attempt_at, sms_sent, sms_delivered_at, sms_last_attempt_at,
                     wp_sent, wp_last_attempt_at
             ) VALUES (
                :result_id, :template_type, :content_type, :content_value, NOW(), :sent_by,
                :provider_ack, :provider_status, :provider_recipient, :provider_response,
                     :delivered_at, :status_checked_at, :status_source, :email_sent, :email_delivered_at,
                     :email_last_attempt_at, :sms_sent, :sms_delivered_at, :sms_last_attempt_at,
                     :wp_sent, :wp_last_attempt_at
             )
             ON DUPLICATE KEY UPDATE
                 content_type = VALUES(content_type),
                 content_value = VALUES(content_value),
                 sent_at = NOW(),
                 sent_by = VALUES(sent_by),
                 provider_ack = COALESCE(VALUES(provider_ack), provider_ack),
                 provider_status = COALESCE(VALUES(provider_status), provider_status),
                 provider_recipient = COALESCE(VALUES(provider_recipient), provider_recipient),
                 provider_response = COALESCE(VALUES(provider_response), provider_response),
                 delivered_at = COALESCE(VALUES(delivered_at), delivered_at),
                 status_checked_at = COALESCE(VALUES(status_checked_at), status_checked_at),
                 status_source = COALESCE(VALUES(status_source), status_source),
                 email_sent = COALESCE(VALUES(email_sent), email_sent),
                 email_delivered_at = COALESCE(VALUES(email_delivered_at), email_delivered_at),
                 email_last_attempt_at = COALESCE(VALUES(email_last_attempt_at), email_last_attempt_at),
                 sms_sent = COALESCE(VALUES(sms_sent), sms_sent),
                 sms_delivered_at = COALESCE(VALUES(sms_delivered_at), sms_delivered_at),
                 sms_last_attempt_at = COALESCE(VALUES(sms_last_attempt_at), sms_last_attempt_at),
                 wp_sent = COALESCE(VALUES(wp_sent), wp_sent),
                 wp_last_attempt_at = COALESCE(VALUES(wp_last_attempt_at), wp_last_attempt_at)";

    try {
        $stmt = $pdo->prepare($sql);
        return $stmt->execute([
            ':result_id' => $resultId,
            ':template_type' => trim($templateType),
            ':content_type' => trim($contentType),
            ':content_value' => trim($contentValue),
            ':sent_by' => trim((string)$sentBy),
            ':provider_ack' => trim((string)($providerMeta['provider_ack'] ?? '')) !== '' ? trim((string)$providerMeta['provider_ack']) : null,
            ':provider_status' => trim((string)($providerMeta['provider_status'] ?? '')) !== '' ? trim((string)$providerMeta['provider_status']) : null,
            ':provider_recipient' => trim((string)($providerMeta['provider_recipient'] ?? '')) !== '' ? trim((string)$providerMeta['provider_recipient']) : null,
            ':provider_response' => trim((string)($providerMeta['provider_response'] ?? '')) !== '' ? trim((string)$providerMeta['provider_response']) : null,
            ':delivered_at' => trim((string)($providerMeta['delivered_at'] ?? '')) !== '' ? trim((string)$providerMeta['delivered_at']) : null,
            ':status_checked_at' => trim((string)($providerMeta['status_checked_at'] ?? '')) !== '' ? trim((string)$providerMeta['status_checked_at']) : null,
            ':status_source' => trim((string)($providerMeta['status_source'] ?? '')) !== '' ? trim((string)$providerMeta['status_source']) : null,
            ':email_sent' => array_key_exists('email_sent', $providerMeta) ? ($providerMeta['email_sent'] === true || (int)($providerMeta['email_sent'] ?? 0) === 1 ? 1 : 0) : null,
            ':email_delivered_at' => trim((string)($providerMeta['email_delivered_at'] ?? '')) !== '' ? trim((string)$providerMeta['email_delivered_at']) : null,
            ':email_last_attempt_at' => array_key_exists('email_last_attempt_at', $providerMeta) ? (trim((string)($providerMeta['email_last_attempt_at'] ?? '')) !== '' ? trim((string)$providerMeta['email_last_attempt_at']) : null) : null,
            ':sms_sent' => array_key_exists('sms_sent', $providerMeta) ? ($providerMeta['sms_sent'] === true || (int)($providerMeta['sms_sent'] ?? 0) === 1 ? 1 : 0) : null,
            ':sms_delivered_at' => trim((string)($providerMeta['sms_delivered_at'] ?? '')) !== '' ? trim((string)$providerMeta['sms_delivered_at']) : null,
            ':sms_last_attempt_at' => array_key_exists('sms_last_attempt_at', $providerMeta) ? (trim((string)($providerMeta['sms_last_attempt_at'] ?? '')) !== '' ? trim((string)$providerMeta['sms_last_attempt_at']) : null) : null,
            ':wp_sent' => array_key_exists('wp_sent', $providerMeta) ? ($providerMeta['wp_sent'] === true || (int)($providerMeta['wp_sent'] ?? 0) === 1 ? 1 : 0) : null,
            ':wp_last_attempt_at' => array_key_exists('wp_last_attempt_at', $providerMeta) ? (trim((string)($providerMeta['wp_last_attempt_at'] ?? '')) !== '' ? trim((string)$providerMeta['wp_last_attempt_at']) : null) : null,
        ]);
    } catch (Throwable $exception) {
        $errorCode = $exception->getCode();
        $errorMsg = $exception->getMessage();
        error_log(sprintf(
            "[%s] saveSentRecord FAILED for result_id=%d template_type=%s: [%s] %s",
            date('Y-m-d H:i:s'),
            $resultId,
            $templateType,
            $errorCode,
            $errorMsg
        ));
        return false;
    }
}

function getSentResultStatus(int $resultId, string $templateType = 'result'): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [];
    }

    $sql = "SELECT result_id, template_type, content_type, content_value, sent_at, sent_by,
                   provider_ack, provider_status, provider_recipient, provider_response,
                   delivered_at, status_checked_at, status_source,
                   email_sent, email_delivered_at, sms_sent, sms_delivered_at
            FROM sent_results
            WHERE result_id = :result_id AND template_type = :template_type";
    $params = [
        ':result_id' => $resultId,
        ':template_type' => $templateType,
    ];

    $sql .= ' ORDER BY sent_at DESC';

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        return is_array($rows) ? $rows : [];
    } catch (Throwable $exception) {
        return [];
    }
}

function getMrnSentResultsMap(string $mrn): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [];
    }

    $mrn = sanitizeMrn($mrn);
    if ($mrn === '') {
        return [];
    }

        $sql = "SELECT sr.result_id, pr.request_code, pr.department, sr.template_type, sr.content_value, sr.sent_at,
                   sr.provider_ack, sr.provider_status, sr.provider_recipient, sr.delivered_at, sr.status_checked_at,
                   sr.email_sent, sr.email_delivered_at, sr.sms_sent, sr.sms_delivered_at,
                   sr.wp_sent, sr.wp_last_attempt_at, sr.sms_last_attempt_at, sr.email_last_attempt_at
            FROM sent_results AS sr
            INNER JOIN patient_results AS pr ON pr.id = sr.result_id
            WHERE pr.mrn = :mrn";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':mrn' => $mrn]);
        $rows = $stmt->fetchAll();

        $map = [];
        foreach ($rows as $row) {
            // Key by result_id so each manual upload is tracked independently
            $key = (int)$row['result_id'];
            $map[$key] = [
                'sent_at' => (string)($row['sent_at'] ?? ''),
                'content_value' => (string)($row['content_value'] ?? ''),
                'provider_ack' => (string)($row['provider_ack'] ?? ''),
                'provider_status' => (string)($row['provider_status'] ?? ''),
                'provider_recipient' => (string)($row['provider_recipient'] ?? ''),
                'delivered_at' => (string)($row['delivered_at'] ?? ''),
                'status_checked_at' => (string)($row['status_checked_at'] ?? ''),
                'email_sent' => (int)($row['email_sent'] ?? 0),
                'email_delivered_at' => (string)($row['email_delivered_at'] ?? ''),
                'email_last_attempt_at' => (string)($row['email_last_attempt_at'] ?? ''),
                'sms_sent' => (int)($row['sms_sent'] ?? 0),
                'sms_delivered_at' => (string)($row['sms_delivered_at'] ?? ''),
                'sms_last_attempt_at' => (string)($row['sms_last_attempt_at'] ?? ''),
                'wp_sent' => (int)($row['wp_sent'] ?? 0),
                'wp_last_attempt_at' => (string)($row['wp_last_attempt_at'] ?? ''),
            ];
        }

        return $map;
    } catch (Throwable $exception) {
        return [];
    }
}

function getLatestResultIdByMrn(string $mrn): ?int
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }

    $mrn = sanitizeMrn($mrn);
    if ($mrn === '') {
        return null;
    }

    $sql = "SELECT id
            FROM patient_results
            WHERE mrn = :mrn
            ORDER BY COALESCE(end_visit_date, visit_date) DESC, last_updated_at DESC, id DESC
            LIMIT 1";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':mrn' => $mrn]);
        $row = $stmt->fetch();
        if (!is_array($row) || !isset($row['id'])) {
            return null;
        }
        return (int)$row['id'];
    } catch (Throwable $exception) {
        return null;
    }
}

function updateSentRecordDeliveryByAck(
    string $ack,
    string $providerStatus,
    ?string $recipient = null,
    ?string $statusCheckedAt = null,
    ?string $statusSource = null,
    ?string $providerResponse = null
): int {
    $pdo = openResultsDb();
    if ($pdo === null) {
        return 0;
    }

    $ack = trim($ack);
    if ($ack === '') {
        return 0;
    }

    $providerStatus = strtoupper(trim($providerStatus));
    if ($providerStatus === '') {
        $providerStatus = 'UNKNOWN';
    }

    $checkedAt = trim((string)$statusCheckedAt);
    if ($checkedAt === '') {
        $checkedAt = date('Y-m-d H:i:s');
    }

    $deliveredAt = null;
    if (in_array($providerStatus, ['DELIVERED', 'READ'], true)) {
        $deliveredAt = $checkedAt;
    }
    
    // Always store provider_response for FAILED statuses
    $providerResponseToStore = trim((string)$providerResponse);
    if ($providerStatus === 'FAILED' && $providerResponseToStore === '') {
        $providerResponseToStore = '';
    }

    // Determine wp_sent flag based on provider_status
    // Do NOT reset wp_sent=0 for UNKNOWN statuses (still checking)
    // Only mark as failed for confirmed FAILED status
    $wpSent = match($providerStatus) {
        'FAILED' => 0,                              // Confirmed failure
        'UNKNOWN' => 1,                             // Still pending, keep as sent
        'SENT', 'DELIVERED', 'READ' => 1,           // Success statuses
        default => 0                                // Other statuses default to 0
    };

    $sql = "UPDATE sent_results
            SET provider_status = :provider_status,
                provider_recipient = COALESCE(NULLIF(:provider_recipient, ''), provider_recipient),
                provider_response = IF(:provider_response <> '', :provider_response, provider_response),
                status_checked_at = :status_checked_at,
                status_source = COALESCE(NULLIF(:status_source, ''), status_source),
                delivered_at = COALESCE(:delivered_at, delivered_at),
                wp_sent = :wp_sent
            WHERE provider_ack = :provider_ack";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':provider_status' => $providerStatus,
            ':provider_recipient' => trim((string)$recipient),
            ':provider_response' => $providerResponseToStore,
            ':status_checked_at' => $checkedAt,
            ':status_source' => trim((string)$statusSource),
            ':delivered_at' => $deliveredAt,
            ':wp_sent' => $wpSent,
            ':provider_ack' => $ack,
        ]);
        
        $rowsUpdated = (int)$stmt->rowCount();
        
        // Log delivery failures
        if ($rowsUpdated > 0 && $providerStatus === 'FAILED') {
            error_log(sprintf(
                '[%s] DELIVERY_FAILURE: ack=%s recipient=%s response_snippet=%s source=%s',
                date('Y-m-d H:i:s'),
                $ack,
                $recipient ?: 'unknown',
                substr($providerResponseToStore, 0, 100),
                $statusSource ?: 'unknown'
            ));
        }
        
        return $rowsUpdated;
    } catch (Throwable $exception) {
        return 0;
    }
}

function getPendingAutoSendResults(): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [];
    }

    $sql = "SELECT pr.id AS result_id,
                   pr.mrn,
                   pr.request_code,
                   pr.department,
                   pr.pdf_result_link,
                   pr.test_or_image,
                   pr.result_link_added_at,
                   pr.last_updated_at AS result_last_updated_at,
                   p.updated_at AS patient_updated_at,
                   p.patient_name,
                   p.care_mobile,
                   p.email,
                   sr.id AS sent_id,
                   sr.content_value AS last_sent_content,
                   sr.sent_at AS last_sent_at,
                   sr.wp_sent,
                   sr.wp_last_attempt_at,
                   sr.sms_sent,
                   sr.sms_last_attempt_at,
                   sr.email_sent,
                   sr.email_last_attempt_at
            FROM patient_results AS pr
            INNER JOIN patients AS p
                ON p.mrn = pr.mrn
            LEFT JOIN sent_results AS sr
                ON sr.result_id = pr.id
               AND sr.template_type = 'result'
            WHERE pr.source = 'json_import'
              AND pr.department IN ('Laboratory', 'Radiology')
              AND pr.pdf_result_link IS NOT NULL
              AND pr.pdf_result_link <> ''";

    // Determine send window: default to 1 month back, but if AUTO_SEND_START_DATE
    // is configured and is more recent than 1 month ago, use that instead.
    // Use result availability/modification timestamp (result_link_added_at or last_updated_at)
    // to decide which records fall into the window. We keep only json_import source
    $envStart = trim((string)getenv('AUTO_SEND_START_DATE'));
    $oneMonthAgoTs = strtotime('-1 month');
    $startTs = $oneMonthAgoTs;
    if ($envStart !== '' && strtotime($envStart) !== false) {
        $envTs = strtotime($envStart);
        // If AUTO_SEND_START_DATE is more recent than one month ago, prefer it
        if ($envTs > $oneMonthAgoTs) {
            $startTs = $envTs;
        }
    }
    $startDateFormatted = date('Y-m-d 00:00:00', $startTs);
    // Filter by when the result link was added (not last_updated_at, which changes on every import)
    // This prevents old results from being re-sent just because the JSON file was re-imported
    $sql .= " AND pr.result_link_added_at >= '{$startDateFormatted}'";

    // CRITICAL: Only send results for recent visits (within 30 days, aligned with AUTO_SEND_START_DATE)
    // This prevents sending results from old visits that are just being re-imported
    $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days'));
    $sql .= " AND pr.visit_date >= '{$thirtyDaysAgo}'";

    $sql .= " ORDER BY pr.result_link_added_at ASC, pr.id ASC";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $rows = $stmt->fetchAll();
        if (!is_array($rows)) {
            return [];
        }

        $extractSentLink = static function (string $contentValue): string {
            $contentValue = trim($contentValue);
            if ($contentValue === '') {
                return '';
            }

            if (str_starts_with($contentValue, '{')) {
                $decoded = json_decode($contentValue, true);
                if (is_array($decoded) && isset($decoded['link'])) {
                    return trim((string)$decoded['link']);
                }
            }

            return $contentValue;
        };

        $pending = [];
        foreach ($rows as $row) {
            $currentLink = trim((string)($row['pdf_result_link'] ?? ''));
            if ($currentLink === '') {
                continue;
            }

            $sentId = (int)($row['sent_id'] ?? 0);
            if ($sentId <= 0) {
                $pending[] = $row;
                continue;
            }

            $lastSentLink = $extractSentLink((string)($row['last_sent_content'] ?? ''));
            if ($lastSentLink !== $currentLink) {
                $pending[] = $row;
            }
        }

        return $pending;
    } catch (Throwable $exception) {
        $errorCode = $exception->getCode();
        $errorMsg = $exception->getMessage();
        error_log(sprintf(
            "[%s] getPendingAutoSendResults FAILED: [%s] %s",
            date('Y-m-d H:i:s'),
            $errorCode,
            $errorMsg
        ));
        error_log("Query: " . $sql);
        error_log("Trace: " . $exception->getTraceAsString());
        // Re-throw to allow caller to handle
        throw $exception;
    }
}

function normalizePortalUsername(string $username): string
{
    $username = trim($username);
    if ($username === '') {
        return '';
    }

    if (strpos($username, '\\') !== false) {
        $username = substr($username, strrpos($username, '\\') + 1);
    }

    if (strpos($username, '@') !== false) {
        $username = substr($username, 0, strpos($username, '@'));
    }

    return strtolower(trim($username));
}

function getPortalUsers(): array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return [];
    }

    try {
        $stmt = $pdo->query("SELECT id, ldap_username, display_name, role, is_active, last_login_at, created_at, updated_at
            FROM portal_users
            ORDER BY role ASC, COALESCE(display_name, ldap_username) ASC, ldap_username ASC");
        $rows = $stmt->fetchAll();
        return is_array($rows) ? $rows : [];
    } catch (Throwable $exception) {
        return [];
    }
}

function getPortalUserByUsername(string $username): ?array
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }

    $username = normalizePortalUsername($username);
    if ($username === '') {
        return null;
    }

    try {
        $stmt = $pdo->prepare('SELECT id, ldap_username, display_name, role, is_active, last_login_at, created_at, updated_at
            FROM portal_users
            WHERE ldap_username = :ldap_username
            LIMIT 1');
        $stmt->execute([':ldap_username' => $username]);
        $row = $stmt->fetch();
        return is_array($row) ? $row : null;
    } catch (Throwable $exception) {
        return null;
    }
}

function countPortalUsers(): int
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return 0;
    }

    try {
        $stmt = $pdo->query('SELECT COUNT(*) AS count_value FROM portal_users');
        $row = $stmt->fetch();
        return (int)($row['count_value'] ?? 0);
    } catch (Throwable $exception) {
        return 0;
    }
}

function savePortalUser(string $username, string $displayName, string $role, bool $isActive, ?string $lastLoginAt = null): bool
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return false;
    }

    $username = normalizePortalUsername($username);
    if ($username === '') {
        return false;
    }

    $allowedRoles = ['master', 'butler', 'imaging', 'lab', 'doctor'];
    $role = strtolower(trim($role));
    if (!in_array($role, $allowedRoles, true)) {
        $role = 'doctor';
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO portal_users (ldap_username, display_name, role, is_active, last_login_at)
            VALUES (:ldap_username, :display_name, :role, :is_active, :last_login_at)
            ON DUPLICATE KEY UPDATE
                display_name = VALUES(display_name),
                role = VALUES(role),
                is_active = VALUES(is_active),
                last_login_at = COALESCE(VALUES(last_login_at), last_login_at),
                updated_at = CURRENT_TIMESTAMP");
        return $stmt->execute([
            ':ldap_username' => $username,
            ':display_name' => trim($displayName),
            ':role' => $role,
            ':is_active' => $isActive ? 1 : 0,
            ':last_login_at' => $lastLoginAt,
        ]);
    } catch (Throwable $exception) {
        return false;
    }
}

function deletePortalUser(string $username): bool
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return false;
    }

    $username = normalizePortalUsername($username);
    if ($username === '') {
        return false;
    }

    try {
        $stmt = $pdo->prepare('DELETE FROM portal_users WHERE ldap_username = :ldap_username');
        return $stmt->execute([':ldap_username' => $username]);
    } catch (Throwable $exception) {
        return false;
    }
}

function updatePortalUserLogin(string $username, ?string $displayName = null): bool
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return false;
    }

    $username = normalizePortalUsername($username);
    if ($username === '') {
        return false;
    }

    try {
        $stmt = $pdo->prepare('UPDATE portal_users
            SET display_name = COALESCE(NULLIF(:display_name, \'\'), display_name),
                last_login_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE ldap_username = :ldap_username');
        return $stmt->execute([
            ':ldap_username' => $username,
            ':display_name' => trim((string)$displayName),
        ]);
    } catch (Throwable $exception) {
        return false;
    }
}

/**
 * Validates that result_id exists before attempting to save
 * Returns the result_id if valid, or null if invalid
 * This prevents FK constraint violations in saveSentRecord
 */
function validateResultIdExists(int $resultId): ?int {
    if ($resultId <= 0) {
        return null;
    }
    
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }
    
    try {
        $stmt = $pdo->prepare('SELECT id FROM patient_results WHERE id = ?');
        $stmt->execute([$resultId]);
        $row = $stmt->fetch();
        return is_array($row) ? $resultId : null;
    } catch (Throwable $e) {
        error_log(sprintf(
            "[%s] validateResultIdExists FAILED for result_id=%d: [%s] %s",
            date('Y-m-d H:i:s'),
            $resultId,
            $e->getCode(),
            $e->getMessage()
        ));
        return null;
    }
}

/**
 * Wrapper around saveSentRecord with validation and better error handling
 * Returns: array with 'success' => bool, 'error' => string (if failed)
 */
function saveSentRecordValidated(
    int $resultId,
    string $templateType,
    string $contentType,
    string $contentValue,
    string $sentBy,
    array $providerMeta = []
): array {
    // Validate result_id exists in database
    $validatedId = validateResultIdExists($resultId);
    if ($validatedId === null) {
        $error = sprintf(
            "Invalid result_id=%d: Patient result not found in database. Check that patient_results record exists.",
            $resultId
        );
        error_log("[" . date('Y-m-d H:i:s') . "] saveSentRecordValidated FAILED: " . $error);
        return [
            'success' => false,
            'error' => $error,
            'result_id' => $resultId,
        ];
    }
    
    // Attempt to save
    $saved = saveSentRecord($resultId, $templateType, $contentType, $contentValue, $sentBy, $providerMeta);
    
    if ($saved) {
        return [
            'success' => true,
            'result_id' => $resultId,
        ];
    } else {
        // saveSentRecord logs the error already
        return [
            'success' => false,
            'error' => 'Database save failed (check error_log for details)',
            'result_id' => $resultId,
        ];
    }
}

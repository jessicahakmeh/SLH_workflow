# Send Pending Results - Web Access Guide

## Overview

`send_pending_results.php` can now be called via both **CLI** and **HTTPS/Web requests**. This enables:
- Manual triggering via web interface
- Integration with external monitoring/scheduling systems
- RESTful API calls from dashboards

## Configuration

### 1. Enable Web Access

Edit `.env` file and set an API key:

```env
SEND_PENDING_RESULTS_API_KEY=your-secure-api-key-here
```

**Important**: Leave this blank (`""`) to disable web access entirely.

### 2. Generate a Secure API Key

Generate a strong random key (example):

```bash
# On Windows PowerShell:
[System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes([guid]::NewGuid().ToString())) | ForEach-Object { $_ -replace '[+/=]', '' }

# Or use any secure random string generator
```

## Usage Methods

### Method 1: Query Parameter (Simplest)

```
https://slouishospital.com/send_pending_results.php?api_key=your-secure-api-key-here
```

### Method 2: Authorization Header (Recommended)

```bash
curl -H "Authorization: Bearer your-secure-api-key-here" \
     https://slouishospital.com/send_pending_results.php
```

### Method 3: POST Parameter

```bash
curl -X POST \
     -d "api_key=your-secure-api-key-here" \
     https://slouishospital.com/send_pending_results.php
```

## Response Format

### Success Response (HTTP 200)

```json
{
  "success": true,
  "message": "Daily send summary since 2026-10-03 12:00:01: candidates=5, sent=4, failed=1, email_sent=0, email_failed=0, email_skipped=0",
  "timestamp": "2026-10-05 16:16:30",
  "data": {
    "candidates": 5,
    "sent": 4,
    "failed": 1,
    "email_sent": 0,
    "email_failed": 0,
    "email_skipped": 0
  }
}
```

### Error Response (HTTP 500)

```json
{
  "success": false,
  "message": "Daily send summary since 2026-10-03 12:00:01: candidates=0, sent=0, failed=0, email_sent=0, email_failed=0, email_skipped=0 (ERROR: Table 'slhcycle.patient_results' doesn't exist)",
  "timestamp": "2026-10-05 16:16:30",
  "data": {
    "candidates": 0,
    "sent": 0,
    "failed": 0,
    "email_sent": 0,
    "email_failed": 0,
    "email_skipped": 0
  }
}
```

### Unauthorized Response (HTTP 401)

```json
{
  "success": false,
  "message": "Unauthorized. Provide valid API key via Authorization header, ?api_key query parameter, or POST api_key parameter.",
  "timestamp": "2026-10-05 16:16:30"
}
```

### Lock Conflict Response (HTTP 429)

```json
{
  "success": false,
  "message": "Another send_pending_index.php process is already running.",
  "timestamp": "2026-10-05 16:16:30"
}
```

## HTTP Status Codes

| Code | Meaning | Reason |
|------|---------|--------|
| 200 | OK | Job ran successfully, no errors |
| 401 | Unauthorized | Invalid or missing API key |
| 429 | Too Many Requests | Another process already running (lock held) |
| 500 | Server Error | Job ran but had errors or failures |

## CLI Behavior (Unchanged)

Running from command line requires **no authentication**:

```bash
php send_pending_results.php
```

Output:
```
send_pending_index.php: LOCK ACQUIRED - Starting send run at 2026-10-05 16:16:29
Delivery status sync: success=1 received=0 updated=0 ignored=0 http=200
Daily send summary since 2026-10-03 12:00:01: candidates=5, sent=4, failed=1, email_sent=0, email_failed=0, email_skipped=0
```

Exit codes:
- `0` = Success
- `1` = Failure or error occurred

## Logging

All executions (CLI and Web) are logged to:
- **Log file**: `logs/send_pending_results.log`
- **Apache error log**: `php_error_log` (for errors)
- **Lock file**: `logs/send_pending_results.lock`
- **Last run marker**: `logs/send_pending_last_run.txt`

## Monitoring Dashboard Integration

### Example: JavaScript/Fetch

```javascript
async function runSendPendingResults() {
  try {
    const response = await fetch('https://slouishospital.com/send_pending_results.php', {
      method: 'GET',
      headers: {
        'Authorization': 'Bearer your-secure-api-key-here',
        'Accept': 'application/json'
      }
    });

    const data = await response.json();
    
    if (response.ok) {
      console.log('Send successful:', data.data);
      updateDashboard(data.data);
    } else {
      console.error('Send failed:', data.message);
      showErrorNotification(data.message);
    }
  } catch (error) {
    console.error('Request failed:', error);
  }
}
```

### Example: cURL

```bash
#!/bin/bash
curl -s -H "Authorization: Bearer your-secure-api-key-here" \
     "https://slouishospital.com/send_pending_results.php" | \
     jq '.data'
```

### Example: PowerShell

```powershell
$apiKey = "your-secure-api-key-here"
$url = "https://slouishospital.com/send_pending_results.php"

$response = Invoke-WebRequest -Uri $url `
  -Headers @{ Authorization = "Bearer $apiKey" } `
  -ContentType "application/json"

$data = $response.Content | ConvertFrom-Json
Write-Host "Send Summary:" $data.data
```

## Security Best Practices

1. **Use HTTPS only** - Never transmit API keys over HTTP
2. **Rotate API keys regularly** - Update `.env` periodically
3. **Use Authorization header** - More secure than query parameters
4. **Restrict access** - Consider Apache/Nginx auth rules:

   ```apache
   <Files "send_pending_results.php">
     Order allow,deny
     Allow from 192.168.20.0/24
     Deny from all
   </Files>
   ```

5. **Monitor logs** - Check for failed authentication attempts
6. **Use strong keys** - At least 32 random characters

## Troubleshooting

### "Unauthorized" Response

- Verify API key is set in `.env`
- Check Authorization header format: `Bearer YOUR_KEY`
- Ensure query parameter is URL-encoded

### "Another process already running"

- Job is already executing (stale lock timeout = 10 minutes)
- Wait 10 minutes or manually delete `logs/send_pending_results.lock`

### Silent Failures (No Output)

- Check Apache error log for PHP errors
- Verify PHP can write to `logs/` directory
- Ensure database is accessible (see `DIAGNOSIS_AND_FIX_REPORT.txt`)

### JSON Response Not Returned (Plain Text Instead)

- Ensure API key is valid
- Check `Content-Type` header expectations
- Verify no PHP errors are occurring

## Migration from CLI-Only

If you're currently using CLI-only scheduling:

1. Generate and set API key in `.env`
2. Test web access: `curl -H "Authorization: Bearer KEY" https://host/send_pending_results.php`
3. Update scheduled tasks to use either method (or keep CLI)
4. Monitor logs to ensure everything works

## Backward Compatibility

✅ **CLI access is unchanged** - All existing scripts/cron jobs continue to work
✅ **No API key required for CLI** - Only web requests need authentication
✅ **Same logging** - Both methods write to identical log files
✅ **Same locking mechanism** - Prevents concurrent execution

---

**Last Updated**: 2026-10-05  
**Version**: 1.0

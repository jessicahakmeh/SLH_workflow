<?php

declare(strict_types=1);

// Security: Only allow local access for web requests; CLI is allowed.
$isCli = PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';
$isLocalhost = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', 'localhost'], true);
if (!$isCli && !$isLocalhost) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=UTF-8');
    echo "Forbidden. Database setup is only available from localhost.\n";
    exit;
}

require_once __DIR__ . '/env.php';
loadEnvFile();

$host = (string)(envValue('DB_HOST', null) ?? '');
$port = (string)(envValue('DB_PORT', null) ?? '');
$user = (string)(envValue('DB_USER', null) ?? '');
$pass = (string)(envValue('DB_PASS', null) ?? '');
$dbName = (string)(envValue('DB_NAME', null) ?? '');

$missing = [];
if ($host === '') {
  $missing[] = 'DB_HOST';
}
if ($port === '') {
  $missing[] = 'DB_PORT';
}
if ($user === '') {
  $missing[] = 'DB_USER';
}
if ($dbName === '') {
  $missing[] = 'DB_NAME';
}

if (!empty($missing)) {
  http_response_code(500);
  header('Content-Type: text/plain; charset=UTF-8');
  echo 'Database setup failed: missing required environment variables: ' . implode(', ', $missing) . "\n";
  exit;
}

try {
    $pdo = new PDO(
        "mysql:host={$host};port={$port};charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    // Step 1: Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbName`");
    $pdo->exec("USE `$dbName`");

    // Step 2: Create patients table
    $pdo->exec(<<<SQL
        CREATE TABLE IF NOT EXISTS patients (
            id CHAR(5) PRIMARY KEY,
            mrn VARCHAR(50) NOT NULL,
            patient_name VARCHAR(255) NOT NULL,
            care_mobile VARCHAR(50) DEFAULT NULL,
            email VARCHAR(255) DEFAULT NULL,
            date_of_birth DATE DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_patients_mrn (mrn),
            INDEX idx_patients_care_mobile (care_mobile),
            INDEX idx_patients_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    SQL);

    // Step 3: Create patient_results table
    $pdo->exec(<<<SQL
        CREATE TABLE IF NOT EXISTS patient_results (
            id INT AUTO_INCREMENT PRIMARY KEY,
            mrn VARCHAR(50) NOT NULL,
            department VARCHAR(100) NOT NULL COMMENT 'Laboratory or Radiology',
            test_or_image VARCHAR(255) NOT NULL,
            request_code VARCHAR(100) DEFAULT NULL,
            pdf_result_link TEXT NOT NULL,
            result_link_added_at DATETIME DEFAULT NULL,
            visit_date DATE DEFAULT NULL,
            end_visit_date DATE DEFAULT NULL,
            case_number VARCHAR(100) DEFAULT NULL,
            doctor_name VARCHAR(255) DEFAULT NULL,
            doctor_specialty VARCHAR(255) DEFAULT NULL,
            source ENUM('json_import', 'manual_upload', 'collection_notice') DEFAULT 'json_import',
            json_file_hash VARCHAR(64) DEFAULT NULL,
            manual_filename VARCHAR(255) DEFAULT NULL,
            first_seen_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            unique_check VARCHAR(500) GENERATED ALWAYS AS (
                CASE 
                    WHEN source = 'json_import' AND department = 'Laboratory' THEN CONCAT(mrn, '|', request_code, '|', department)
                    ELSE NULL
                END
            ) STORED,
            UNIQUE KEY uq_result (unique_check),
            INDEX idx_mrn (mrn),
            INDEX idx_first_seen (first_seen_at),
            CONSTRAINT fk_patient_results_mrn FOREIGN KEY (mrn) REFERENCES patients(mrn) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    SQL);

    // Step 4: Create sent_results table with SMS columns built-in
    $pdo->exec(<<<SQL
        CREATE TABLE IF NOT EXISTS sent_results (
            id INT AUTO_INCREMENT PRIMARY KEY,
            result_id INT NOT NULL,
            template_type ENUM('result', 'collection_notice', 'manual_pdf') DEFAULT 'result',
            content_type ENUM('link', 'pdf_upload') DEFAULT 'link',
            content_value TEXT NOT NULL,
            sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            sent_by VARCHAR(100) DEFAULT NULL,
            provider_ack VARCHAR(100) DEFAULT NULL,
            provider_status VARCHAR(60) DEFAULT NULL,
            provider_recipient VARCHAR(30) DEFAULT NULL,
            provider_response TEXT DEFAULT NULL,
            delivered_at DATETIME DEFAULT NULL,
            status_checked_at DATETIME DEFAULT NULL,
            status_source VARCHAR(30) DEFAULT NULL,
            email_sent TINYINT(1) DEFAULT 0,
            email_delivered_at DATETIME DEFAULT NULL,
            email_last_attempt_at DATETIME DEFAULT NULL,
            sms_sent TINYINT(1) DEFAULT 0,
            sms_delivered_at DATETIME DEFAULT NULL,
            sms_last_attempt_at DATETIME DEFAULT NULL,
            wp_sent TINYINT(1) DEFAULT 0,
            wp_last_attempt_at DATETIME DEFAULT NULL,
            UNIQUE KEY uq_sent (result_id, template_type),
            INDEX idx_result_id (result_id),
            INDEX idx_provider_ack (provider_ack),
            INDEX idx_provider_status (provider_status),
            INDEX idx_email_sent (email_sent),
            INDEX idx_sms_sent (sms_sent),
            INDEX idx_wp_sent (wp_sent),
            CONSTRAINT fk_sent_results_result FOREIGN KEY (result_id) REFERENCES patient_results(id) ON DELETE CASCADE ON UPDATE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    SQL);

    // Step 5: Create portal_users table
    $pdo->exec(<<<SQL
        CREATE TABLE IF NOT EXISTS portal_users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ldap_username VARCHAR(255) NOT NULL,
            display_name VARCHAR(255) DEFAULT NULL,
            role ENUM('master', 'butler', 'imaging', 'lab', 'doctor') NOT NULL DEFAULT 'doctor',
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            last_login_at DATETIME DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_portal_users_username (ldap_username),
            INDEX idx_portal_users_role (role),
            INDEX idx_portal_users_active (is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    SQL);

    // Step 6: Create json_import_log table
    $pdo->exec(<<<SQL
        CREATE TABLE IF NOT EXISTS json_import_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            mrn VARCHAR(50) DEFAULT NULL,
            file_name VARCHAR(255) DEFAULT NULL,
            file_hash VARCHAR(64) DEFAULT NULL,
            status VARCHAR(30) NOT NULL,
            imported_count INT NOT NULL DEFAULT 0,
            skipped_count INT NOT NULL DEFAULT 0,
            error_message TEXT DEFAULT NULL,
            run_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_run_at (run_at),
            INDEX idx_mrn (mrn)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    SQL);

    header('Content-Type: text/plain; charset=UTF-8');
    echo "Database setup completed successfully.\n";
    echo "Database: $dbName\n";
    echo "Tables created: patients, patient_results, sent_results, portal_users, json_import_log\n";
} catch (Throwable $exception) {
    http_response_code(500);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Database setup failed: ' . $exception->getMessage() . "\n";
}

<?php

declare(strict_types=1);

require_once __DIR__ . '/result_sending.php';

enforceSendingAccess();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        'status' => 'error',
        'sent' => false,
        'message' => 'Method not allowed. Use POST.',
    ]);
    exit;
}

$result = sendResultApi($_POST);
http_response_code((int)$result['http_code']);
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($result['payload']);

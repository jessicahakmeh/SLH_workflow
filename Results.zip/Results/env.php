<?php

declare(strict_types=1);

if (!function_exists('loadEnvFile')) {
    function loadEnvFile(?string $filePath = null): void
    {
        static $loadedFiles = [];

        $target = $filePath ?? (__DIR__ . DIRECTORY_SEPARATOR . '.env');
        $realTarget = realpath($target) ?: $target;

        if (isset($loadedFiles[$realTarget])) {
            return;
        }
        $loadedFiles[$realTarget] = true;

        if (!is_file($target) || !is_readable($target)) {
            return;
        }

        $lines = @file($target, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) {
            return;
        }

        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '' || strpos($line, '#') === 0) {
                continue;
            }

            $parts = explode('=', $line, 2);
            if (count($parts) !== 2) {
                continue;
            }

            $name = trim((string)$parts[0]);
            $value = trim((string)$parts[1]);

            if ($name === '') {
                continue;
            }

            if ((str_starts_with($value, '"') && str_ends_with($value, '"')) || (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
                $value = substr($value, 1, -1);
            }

            // .env should be the authoritative source for this app runtime.
            putenv($name . '=' . $value);
            $_ENV[$name] = $value;
            $_SERVER[$name] = $value;
        }
    }
}

if (!function_exists('envValue')) {
    function envValue(string $name, ?string $default = null): ?string
    {
        $value = getenv($name);
        if ($value === false) {
            return $default;
        }

        $trimmed = trim((string)$value);
        if ($trimmed === '') {
            return $default;
        }

        return $trimmed;
    }
}

if (!function_exists('externalHostnameValue')) {
    function externalHostnameValue(?string $default = null): ?string
    {
        $raw = envValue('EXTERNAL_HOSTNAME', $default);

        if ($raw === null) {
            return $default;
        }

        $raw = trim($raw);
        if ($raw === '') {
            return $default;
        }

        if (preg_match('/^[A-Za-z][A-Za-z0-9+\-.]*:\/\//', $raw) === 1) {
            $parsed = parse_url($raw);
            if (is_array($parsed) && !empty($parsed['host'])) {
                $host = (string)$parsed['host'];
                if (isset($parsed['port'])) {
                    return $host . ':' . (int)$parsed['port'];
                }
                return $host;
            }
        }

        if (strpos($raw, '/') !== false) {
            $parsed = parse_url('http://' . ltrim($raw, '/'));
            if (is_array($parsed) && !empty($parsed['host'])) {
                $host = (string)$parsed['host'];
                if (isset($parsed['port'])) {
                    return $host . ':' . (int)$parsed['port'];
                }
                return $host;
            }
        }

        return $raw;
    }
}

if (!function_exists('rewriteUrlWithExternalHostname')) {
    function rewriteUrlWithExternalHostname(string $url, ?string $defaultHostname = null): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        $externalHostname = (string)(externalHostnameValue($defaultHostname) ?? '');
        if ($externalHostname === '') {
            return $url;
        }

        $externalParts = parse_url('http://' . $externalHostname);
        $externalHost = '';
        $externalPort = null;

        if (is_array($externalParts) && !empty($externalParts['host'])) {
            $externalHost = (string)$externalParts['host'];
            $externalPort = isset($externalParts['port']) ? (int)$externalParts['port'] : null;
        } else {
            $externalHost = $externalHostname;
        }

        if ($externalHost === '') {
            return $url;
        }

        $parts = parse_url($url);

        // Handle scheme-less URLs like "192.168.20.3/path" or "localhost/path".
        if ((!is_array($parts) || !isset($parts['host'])) && preg_match('/^(localhost|127\.0\.0\.1|\d+\.\d+\.\d+\.\d+)(:\d+)?([\/\\\\].*)?$/i', $url) === 1) {
            $guess = parse_url('http://' . ltrim($url, '/\\'));
            if (is_array($guess) && isset($guess['host'])) {
                $parts = $guess;
            }
        }

        if (!is_array($parts) || !isset($parts['host'])) {
            return $url;
        }

        $currentHost = strtolower((string)$parts['host']);
        $isLocalHost = $currentHost === 'localhost' || $currentHost === '127.0.0.1';
        $isPrivateHost = str_starts_with($currentHost, '192.168.');
        $isExternalHost = $currentHost === strtolower($externalHost);

        if (!$isLocalHost && !$isPrivateHost && !$isExternalHost) {
            return $url;
        }

        $parts['host'] = $externalHost;
        $parts['scheme'] = 'https';
        if ($externalPort !== null) {
            $parts['port'] = $externalPort;
        } else {
            unset($parts['port']);
        }

        $scheme = isset($parts['scheme']) ? $parts['scheme'] . '://' : '';
        $user = $parts['user'] ?? '';
        $pass = isset($parts['pass']) ? ':' . $parts['pass'] : '';
        $auth = $user !== '' ? $user . $pass . '@' : '';
        $host = $parts['host'] ?? '';
        $port = isset($parts['port']) ? ':' . $parts['port'] : '';
        $path = $parts['path'] ?? '';
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';
        $fragment = isset($parts['fragment']) ? '#' . $parts['fragment'] : '';

        return $scheme . $auth . $host . $port . $path . $query . $fragment;
    }
}

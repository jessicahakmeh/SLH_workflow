<?php
declare(strict_types=1);
require_once __DIR__ . '/env.php';
require_once __DIR__ . '/sent_results_db.php';

echo "\n=== Verifying Database Connection ===\n";
$pdo = openResultsDb();

// Verify which database we're connected to
$stmt = $pdo->query("SELECT DATABASE() as db, @@hostname as host");
$info = $stmt->fetch(PDO::FETCH_ASSOC);
echo sprintf("Connected to: %s on host %s\n", $info['db'], $info['host']);
echo "\n";

// Check MRNs from activity.log
$mrns = ['165370', '165350', '165367', '165368'];

echo "=== Checking Patient Records ===\n";
echo str_repeat("─", 100) . "\n";

foreach ($mrns as $mrn) {
    echo "\nMRN: $mrn\n";
    
    // Check patients table
    $stmt = $pdo->prepare("SELECT id, mrn, patient_name, care_mobile, email FROM patients WHERE mrn = ?");
    $stmt->execute([$mrn]);
    $patient = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($patient) {
        echo "  ✓ FOUND in patients table\n";
        echo "    Patient: " . $patient['patient_name'] . "\n";
        echo "    Phone: " . $patient['care_mobile'] . "\n";
        echo "    Email: " . $patient['email'] . "\n";
    } else {
        echo "  ✗ NOT FOUND in patients table\n";
    }
    
    // Check results
    $stmt = $pdo->prepare("SELECT id, first_seen_at FROM patient_results WHERE mrn = ? LIMIT 3");
    $stmt->execute([$mrn]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($results) > 0) {
        echo "  ✓ HAS " . count($results) . " result record(s):\n";
        foreach ($results as $result) {
            echo "    - ID: " . $result['id'] . " | Date: " . $result['first_seen_at'] . "\n";
        }
    } else {
        echo "  ✗ No results found\n";
    }
    
    // Check if sends were attempted
    $stmt = $pdo->prepare("
        SELECT sr.id, sr.result_id, sr.template_type, sr.provider_status, sr.wp_sent, sr.created_at
        FROM sent_results sr
        WHERE sr.result_id IN (
            SELECT id FROM patient_results WHERE mrn = ?
        )
        LIMIT 3
    ");
    $stmt->execute([$mrn]);
    $sends = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($sends) > 0) {
        echo "  ✓ HAS " . count($sends) . " send record(s):\n";
        foreach ($sends as $send) {
            echo "    - ID: " . $send['id'] . " | Result: " . $send['result_id'] . " | Status: " . $send['provider_status'] . " | wp_sent: " . $send['wp_sent'] . "\n";
        }
    } else {
        echo "  ✗ No send records found\n";
    }
}

echo "\n" . str_repeat("─", 100) . "\n";
echo "Summary: Rechecking which MRNs are actually missing from patients table\n";

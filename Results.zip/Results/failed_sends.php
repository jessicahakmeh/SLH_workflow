<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/sent_results_db.php';

// Require butler role or higher
$currentUser = portalRequireLogin('butler');
$currentUsername = portalNormalizeLdapUsername((string)($currentUser['ldap_username'] ?? ''));

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function normalizeDateInput(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }

    $dt = DateTime::createFromFormat('Y-m-d', $value);
    if (!$dt || $dt->format('Y-m-d') !== $value) {
        return '';
    }

    return $value;
}

// Get filter parameters
$startDate = normalizeDateInput((string)($_GET['start_date'] ?? ''));
$endDate = normalizeDateInput((string)($_GET['end_date'] ?? ''));
$channel = strtolower(trim((string)($_GET['channel'] ?? '')));

if (!in_array($channel, ['all', 'whatsapp', 'sms', 'email'], true)) {
    $channel = 'all';
}

// Fetch failed sends from database
$failures = [];
$pdo = openResultsDb();

if ($pdo !== null) {
    try {
        $sql = "SELECT 
                    sr.id,
                    sr.sent_at,
                    sr.sent_by,
                    sr.email_sent,
                    sr.email_last_attempt_at,
                    sr.sms_sent,
                    sr.sms_last_attempt_at,
                    sr.wp_sent,
                    sr.wp_last_attempt_at,
                    sr.provider_recipient,
                    sr.provider_response,
                    p.mrn,
                    p.patient_name,
                    p.care_mobile,
                    p.email,
                    pr.id AS result_id,
                    pr.department,
                    pr.test_or_image,
                    pr.request_code,
                    pr.pdf_result_link,
                    pr.result_link_added_at
                FROM sent_results sr
                INNER JOIN patient_results pr ON sr.result_id = pr.id
                INNER JOIN patients p ON p.mrn = pr.mrn
                WHERE sr.template_type = 'result'
                  AND (
                    (sr.email_sent = 0 AND sr.email_last_attempt_at IS NOT NULL)
                    OR (sr.sms_sent = 0 AND sr.sms_last_attempt_at IS NOT NULL)
                    OR (sr.wp_sent = 0 AND sr.wp_last_attempt_at IS NOT NULL)
                  )
                  AND (sr.sent_by = 'auto_send' OR sr.sent_by = :username)";
        
        $params = [':username' => $currentUsername];

        // Apply date filter based on the channel being filtered
        if ($startDate !== '' || $endDate !== '') {
            $dateConditions = [];
            
            if ($channel === 'all' || $channel === 'email') {
                $dateConditions[] = 'sr.email_last_attempt_at';
            }
            if ($channel === 'all' || $channel === 'sms') {
                $dateConditions[] = 'sr.sms_last_attempt_at';
            }
            if ($channel === 'all' || $channel === 'whatsapp') {
                $dateConditions[] = 'sr.wp_last_attempt_at';
            }

            if (!empty($dateConditions)) {
                $dateChecks = [];
                
                if ($startDate !== '') {
                    $fromTs = $startDate . ' 00:00:00';
                    $params[':start_date'] = $fromTs;
                    foreach ($dateConditions as $col) {
                        $dateChecks[] = "($col >= :start_date)";
                    }
                }

                if ($endDate !== '') {
                    $toTs = $endDate . ' 23:59:59';
                    $params[':end_date'] = $toTs;
                    foreach ($dateConditions as $col) {
                        $dateChecks[] = "($col <= :end_date)";
                    }
                }

                if (!empty($dateChecks)) {
                    $sql .= " AND (" . implode(' OR ', $dateChecks) . ")";
                }
            }
        }

        // Apply channel filter
        if ($channel !== 'all') {
            if ($channel === 'email') {
                $sql .= " AND sr.email_sent = 0 AND sr.email_last_attempt_at IS NOT NULL";
            } elseif ($channel === 'sms') {
                $sql .= " AND sr.sms_sent = 0 AND sr.sms_last_attempt_at IS NOT NULL";
            } elseif ($channel === 'whatsapp') {
                $sql .= " AND sr.wp_sent = 0 AND sr.wp_last_attempt_at IS NOT NULL";
            }
        }

        $sql .= " ORDER BY COALESCE(sr.email_last_attempt_at, sr.sms_last_attempt_at, sr.wp_last_attempt_at) DESC";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        if (is_array($rows)) {
            foreach ($rows as $row) {
                $failures[] = $row;
            }
        }
    } catch (Exception $e) {
        error_log('Failed sends query error: ' . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Failed Sends</title>
    <style>
        :root {
            --bg: #f4f8fc;
            --card: #ffffff;
            --text: #1f2d3d;
            --muted: #6b7c93;
            --border: #d9e2ec;
            --accent: #0e73b8;
            --danger: #c0392b;
            --warning: #f39c12;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        .wrap {
            max-width: 1400px;
            margin: 18px auto;
            padding: 0 16px;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
        }

        .back-link {
            display: inline-block;
            padding: 8px 12px;
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 6px;
            color: var(--accent);
            text-decoration: none;
            font-size: 14px;
            transition: background-color 0.2s;
        }

        .back-link:hover {
            background: #f0f4f8;
        }

        .filters {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 24px;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            align-items: flex-end;
        }

        .filter-group {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .filter-group label {
            font-size: 12px;
            font-weight: 600;
            color: var(--muted);
            text-transform: uppercase;
        }

        .filter-group input,
        .filter-group select {
            padding: 8px 12px;
            border: 1px solid var(--border);
            border-radius: 4px;
            font-size: 14px;
            font-family: inherit;
            background: white;
            color: var(--text);
        }

        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(14, 115, 184, 0.1);
        }

        .btn-filter {
            padding: 8px 16px;
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: background-color 0.2s;
        }

        .btn-filter:hover {
            background: #0a5a91;
        }

        .btn-clear {
            padding: 8px 16px;
            background: var(--card);
            color: var(--text);
            border: 1px solid var(--border);
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            transition: background-color 0.2s;
        }

        .btn-clear:hover {
            background: #f0f4f8;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 16px;
            text-align: center;
        }

        .stat-number {
            font-size: 28px;
            font-weight: 700;
            color: var(--accent);
        }

        .stat-label {
            font-size: 12px;
            color: var(--muted);
            margin-top: 4px;
            text-transform: uppercase;
        }

        .message {
            background: var(--card);
            border-left: 4px solid var(--warning);
            border-radius: 4px;
            padding: 16px;
            margin-bottom: 24px;
            color: var(--text);
        }

        .results-table {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 8px;
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        thead {
            background: #fafbfc;
            border-bottom: 2px solid var(--border);
        }

        th {
            padding: 12px 16px;
            text-align: left;
            font-weight: 600;
            color: var(--text);
        }

        td {
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
        }

        tbody tr:hover {
            background: #fafbfc;
        }

        .channel-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            margin: 2px;
        }

        .channel-badge.email {
            background: #e3f2fd;
            color: #1976d2;
        }

        .channel-badge.sms {
            background: #f3e5f5;
            color: #7b1fa2;
        }

        .channel-badge.whatsapp {
            background: #e8f5e9;
            color: #388e3c;
        }

        .failed {
            color: var(--danger);
            font-weight: 600;
        }

        .timestamp {
            color: var(--muted);
            font-size: 13px;
        }

        .mrn {
            font-weight: 600;
            color: var(--accent);
        }

        .patient-cell {
            max-width: 300px;
        }

        .channel-cell {
            white-space: nowrap;
        }

        .contact-cell {
            max-width: 250px;
            word-break: break-all;
            font-size: 13px;
            color: var(--muted);
        }

        .no-results {
            text-align: center;
            padding: 48px 16px;
            color: var(--muted);
        }

        footer {
            text-align: center;
            margin-top: 32px;
            padding: 16px;
            color: var(--muted);
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="wrap">
        <header>
            <h1>Failed Sends</h1>
            <a href="index.php" class="back-link">← Back to Dashboard</a>
        </header>

        <div class="filters">
            <form method="get" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; width: 100%;">
                <div class="filter-group">
                    <label for="start-date">Start Date</label>
                    <input type="date" id="start-date" name="start_date" value="<?php echo h($startDate); ?>">
                </div>

                <div class="filter-group">
                    <label for="end-date">End Date</label>
                    <input type="date" id="end-date" name="end_date" value="<?php echo h($endDate); ?>">
                </div>

                <div class="filter-group">
                    <label for="channel">Channel</label>
                    <select id="channel" name="channel">
                        <option value="all" <?php echo $channel === 'all' ? 'selected' : ''; ?>>All Channels</option>
                        <option value="whatsapp" <?php echo $channel === 'whatsapp' ? 'selected' : ''; ?>>WhatsApp</option>
                        <option value="sms" <?php echo $channel === 'sms' ? 'selected' : ''; ?>>SMS</option>
                        <option value="email" <?php echo $channel === 'email' ? 'selected' : ''; ?>>Email</option>
                    </select>
                </div>

                <button type="submit" class="btn-filter">Filter</button>
                <a href="failed_sends.php" class="btn-clear">Clear Filters</a>
            </form>
        </div>

        <?php if (!empty($failures)): ?>
            <div class="stats">
                <?php
                    $emailFails = count(array_filter($failures, fn($f) => !$f['email_sent'] && $f['email_last_attempt_at']));
                    $smsFails = count(array_filter($failures, fn($f) => !$f['sms_sent'] && $f['sms_last_attempt_at']));
                    $wpFails = count(array_filter($failures, fn($f) => !$f['wp_sent'] && $f['wp_last_attempt_at']));
                ?>
                <div class="stat-card">
                    <div class="stat-number"><?php echo count($failures); ?></div>
                    <div class="stat-label">Total Failed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $wpFails; ?></div>
                    <div class="stat-label">WhatsApp Failures</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $smsFails; ?></div>
                    <div class="stat-label">SMS Failures</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $emailFails; ?></div>
                    <div class="stat-label">Email Failures</div>
                </div>
            </div>

            <div class="results-table">
                <table>
                    <thead>
                        <tr>
                            <th>MRN</th>
                            <th>Patient Name</th>
                            <th>Failed Channel(s)</th>
                            <th>Attempt Time</th>
                            <th>Contact</th>
                            <th>Sent By</th>
                            <th>Test/Image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($failures as $failure): ?>
                            <tr>
                                <td class="mrn"><?php echo h($failure['mrn']); ?></td>
                                <td class="patient-cell"><?php echo h($failure['patient_name']); ?></td>
                                <td class="channel-cell">
                                    <?php if (!$failure['email_sent'] && $failure['email_last_attempt_at']): ?>
                                        <span class="channel-badge email">Email</span>
                                    <?php endif; ?>
                                    <?php if (!$failure['sms_sent'] && $failure['sms_last_attempt_at']): ?>
                                        <span class="channel-badge sms">SMS</span>
                                    <?php endif; ?>
                                    <?php if (!$failure['wp_sent'] && $failure['wp_last_attempt_at']): ?>
                                        <span class="channel-badge whatsapp">WhatsApp</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="timestamp">
                                        <?php
                                            $times = [];
                                            if ($failure['email_last_attempt_at']) $times[] = $failure['email_last_attempt_at'];
                                            if ($failure['sms_last_attempt_at']) $times[] = $failure['sms_last_attempt_at'];
                                            if ($failure['wp_last_attempt_at']) $times[] = $failure['wp_last_attempt_at'];
                                            $latestTime = max($times);
                                            echo h(substr($latestTime, 0, 16));
                                        ?>
                                    </div>
                                </td>
                                <td class="contact-cell">
                                    <?php
                                        $contacts = [];
                                        if ($failure['email_last_attempt_at'] && $failure['email']) {
                                            $contacts[] = '📧 ' . h($failure['email']);
                                        }
                                        if ($failure['sms_last_attempt_at'] && $failure['care_mobile']) {
                                            $contacts[] = '📱 ' . h($failure['care_mobile']);
                                        }
                                        if ($failure['wp_last_attempt_at'] && $failure['care_mobile']) {
                                            $contacts[] = '💬 ' . h($failure['care_mobile']);
                                        }
                                        echo implode('<br>', $contacts);
                                    ?>
                                </td>
                                <td>
                                    <span style="font-size: 12px; color: var(--muted);">
                                        <?php echo h($failure['sent_by'] === 'auto_send' ? 'System' : $failure['sent_by']); ?>
                                    </span>
                                </td>
                                <td style="font-size: 13px; color: var(--muted);">
                                    <?php echo h($failure['test_or_image']); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="no-results">
                <p><strong>No failed sends found</strong></p>
                <p style="font-size: 13px;">Try adjusting your filters or check back later.</p>
            </div>
        <?php endif; ?>

        <footer>
            <p>Showing results for: You and System Auto-Send</p>
            <p style="margin-top: 8px; font-size: 11px;">Last updated: <?php echo date('Y-m-d H:i:s'); ?></p>
        </footer>
    </div>
</body>
</html>

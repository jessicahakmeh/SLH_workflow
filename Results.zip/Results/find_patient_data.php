<?php
require 'sent_results_db.php';

try {
    // Try connecting to different databases to find patient_results
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    
    $databases = ['slhcycle', 'slh', 'slh_cmp', 'slh_new', 'slh_fresh_e2e'];
    
    foreach ($databases as $dbname) {
        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
            
            // Check if patient_results exists
            $stmt = $pdo->query("SELECT COUNT(*) FROM patient_results WHERE mrn = 165255 AND department = 'Radiology' LIMIT 1");
            $count = $stmt->fetch(PDO::FETCH_COLUMN);
            
            if ($count > 0) {
                echo "=== Found in database: $dbname ===\n";
                $stmt = $pdo->prepare('
                    SELECT 
                        id,
                        mrn,
                        department,
                        request_code,
                        result_link_added_at,
                        visit_date,
                        source,
                        pdf_result_link
                    FROM patient_results 
                    WHERE mrn = 165255 
                    AND department = "Radiology" 
                    ORDER BY result_link_added_at DESC
                ');
                $stmt->execute();
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                echo "Patient 165255 Radiology Results:\n";
                foreach ($results as $row) {
                    echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
                }
                echo "\n";
                
                // Check sent status for these results
                echo "=== Sent Status ===\n";
                foreach ($results as $result) {
                    $resultId = $result['id'];
                    $checkStmt = $pdo->prepare('
                        SELECT 
                            id,
                            sent_at,
                            wp_sent,
                            sms_sent,
                            email_sent,
                            wp_last_attempt_at,
                            sms_last_attempt_at,
                            email_last_attempt_at
                        FROM sent_results
                        WHERE result_id = ?
                        ORDER BY sent_at DESC
                    ');
                    $checkStmt->execute([$resultId]);
                    $sent = $checkStmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    echo "Result ID $resultId (code=" . $result['request_code'] . "):\n";
                    if (count($sent) > 0) {
                        foreach ($sent as $s) {
                            echo "  Sent at: " . $s['sent_at'] . " | WP: " . ($s['wp_sent'] ? 'Y' : 'N') . 
                                 " | SMS: " . ($s['sms_sent'] ? 'Y' : 'N') . 
                                 " | Email: " . ($s['email_sent'] ? 'Y' : 'N') . "\n";
                            echo "  Last attempts: WP=" . $s['wp_last_attempt_at'] . " SMS=" . $s['sms_last_attempt_at'] . "\n";
                        }
                    } else {
                        echo "  NO SENT RECORDS FOUND\n";
                    }
                }
            }
        } catch (Exception $e) {
            // Silently skip if database doesn't exist
        }
    }
    
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage() . "\n";
}
?>

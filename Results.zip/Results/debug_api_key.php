<?php
declare(strict_types=1);

/**
 * Debug: Check if API key is being loaded from .env
 */

require_once __DIR__ . '/env.php';

// First, call loadEnvFile to ensure .env is loaded
loadEnvFile();

echo "═══════════════════════════════════════════════════════════════\n";
echo "API KEY LOADING DEBUG\n";
echo "═══════════════════════════════════════════════════════════════\n\n";

echo "Step 1: Check if .env file exists\n";
echo "────────────────────────────────────────────────────────────\n";
$envFile = __DIR__ . '/.env';
if (file_exists($envFile)) {
    echo "✓ .env file found at: $envFile\n";
    echo "  File size: " . filesize($envFile) . " bytes\n";
    echo "  Is readable: " . (is_readable($envFile) ? "Yes" : "No") . "\n";
} else {
    echo "✗ .env file NOT found at: $envFile\n";
}

echo "\nStep 2: Check getenv() function\n";
echo "────────────────────────────────────────────────────────────\n";
$value = getenv('SEND_PENDING_RESULTS_API_KEY');
echo "getenv('SEND_PENDING_RESULTS_API_KEY'): " . 
    ($value === false ? "(false - not found)" : "'" . $value . "'") . "\n";

echo "\nStep 3: Check envValue() function\n";
echo "────────────────────────────────────────────────────────────\n";
if (function_exists('envValue')) {
    echo "✓ envValue() function exists\n";
    $value = envValue('SEND_PENDING_RESULTS_API_KEY', 'DEFAULT_VALUE');
    echo "envValue('SEND_PENDING_RESULTS_API_KEY', 'DEFAULT_VALUE'): '$value'\n";
} else {
    echo "✗ envValue() function NOT found\n";
}

echo "\nStep 4: Check $_SERVER['HTTP_AUTHORIZATION']\n";
echo "────────────────────────────────────────────────────────────\n";
echo "Value: " . (isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : "(not set)") . "\n";

echo "\nStep 5: Check \$_GET['api_key']\n";
echo "────────────────────────────────────────────────────────────\n";
echo "Value: " . (isset($_GET['api_key']) ? $_GET['api_key'] : "(not set)") . "\n";

echo "\nStep 6: Manual test of isValidWebAuthorization() logic\n";
echo "────────────────────────────────────────────────────────────\n";

// Simulate the logic
$apiKey = envValue('SEND_PENDING_RESULTS_API_KEY', '');
echo "API Key loaded: " . (empty($apiKey) ? "(empty)" : "'" . $apiKey . "'") . "\n";
echo "API Key length: " . strlen($apiKey) . " chars\n";

if (empty($apiKey)) {
    echo "Result: ✗ Web access DISABLED (API key is empty)\n";
} else {
    echo "Result: ✓ Web access ENABLED\n";
    echo "\nChecking each authorization method:\n";
    
    // Check Bearer token
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        if (preg_match('/^Bearer\s+(.+)$/i', $_SERVER['HTTP_AUTHORIZATION'], $matches)) {
            $tokenMatch = hash_equals($apiKey, $matches[1]);
            echo "  • Authorization Bearer header: " . ($tokenMatch ? "✓ MATCHES" : "✗ does not match") . "\n";
        } else {
            echo "  • Authorization header found but wrong format\n";
        }
    } else {
        echo "  • Authorization Bearer header: ✗ not provided\n";
    }
    
    // Check query parameter
    if (!empty($_GET['api_key'])) {
        $paramMatch = hash_equals($apiKey, (string)$_GET['api_key']);
        echo "  • Query parameter ?api_key: " . ($paramMatch ? "✓ MATCHES" : "✗ does not match") . "\n";
    } else {
        echo "  • Query parameter ?api_key: ✗ not provided\n";
    }
    
    // Check POST parameter
    if (!empty($_POST['api_key'])) {
        $postMatch = hash_equals($apiKey, (string)$_POST['api_key']);
        echo "  • POST parameter api_key: " . ($postMatch ? "✓ MATCHES" : "✗ does not match") . "\n";
    } else {
        echo "  • POST parameter api_key: ✗ not provided\n";
    }
}

echo "\n═══════════════════════════════════════════════════════════════\n";
echo "NEXT STEPS\n";
echo "═══════════════════════════════════════════════════════════════\n\n";

echo "Make sure you're sending the API key in ONE of these ways:\n\n";

$apiKey = envValue('SEND_PENDING_RESULTS_API_KEY', '');
$testKey = empty($apiKey) ? 'test-send-pending-key-12345' : $apiKey;

echo "✓ Method 1 - Authorization Header (RECOMMENDED):\n";
echo "  curl -H \"Authorization: Bearer $testKey\" \\\n";
echo "       http://192.168.20.17/send_pending_results.php\n\n";

echo "✓ Method 2 - Query Parameter:\n";
echo "  curl \"http://192.168.20.17/send_pending_results.php?api_key=$testKey\"\n\n";

echo "✓ Method 3 - POST Parameter:\n";
echo "  curl -X POST -d \"api_key=$testKey\" \\\n";
echo "       http://192.168.20.17/send_pending_results.php\n\n";

echo "═══════════════════════════════════════════════════════════════\n";

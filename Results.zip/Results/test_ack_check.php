<?php
require_once __DIR__ . '/auth.php';

$pdo = openResultsDb();

// Check total records
$stmt = $pdo->query('SELECT COUNT(*) as cnt FROM sent_results');
$totalCount = $stmt->fetchColumn();
echo "=== Database Status ===" . PHP_EOL;
echo "Total records in sent_results: " . $totalCount . PHP_EOL;
echo PHP_EOL;

// Check for the phone number from the log
$stmt = $pdo->prepare('SELECT id, provider_recipient, provider_ack, provider_status, sent_at, provider_response FROM sent_results WHERE provider_recipient = ? ORDER BY sent_at DESC LIMIT 10');
$stmt->execute(['9613107133']);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "=== Records for phone 9613107133 ===" . PHP_EOL;
if (!empty($records)) {
    echo json_encode($records, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . PHP_EOL;
} else {
    echo "No records found" . PHP_EOL;
}

// Also try to find the specific ACK
echo PHP_EOL . "=== Checking for ACK 1692372341 ===" . PHP_EOL;
$stmt = $pdo->prepare('SELECT id, provider_recipient, provider_ack, provider_status, sent_at, provider_response FROM sent_results WHERE provider_ack = ?');
$stmt->execute(['1692372341']);
$record = $stmt->fetch(PDO::FETCH_ASSOC);

if ($record) {
    echo json_encode($record, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . PHP_EOL;
} else {
    echo "ACK 1692372341 not found" . PHP_EOL;
}

// Check for latest records
echo PHP_EOL . "=== Latest 5 records in sent_results ===" . PHP_EOL;
$stmt = $pdo->prepare('SELECT id, result_id, provider_recipient, provider_ack, provider_status, sent_at FROM sent_results ORDER BY sent_at DESC LIMIT 5');
$stmt->execute();
$latest = $stmt->fetchAll(PDO::FETCH_ASSOC);
if (!empty($latest)) {
    echo json_encode($latest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . PHP_EOL;
} else {
    echo "No records found" . PHP_EOL;
}

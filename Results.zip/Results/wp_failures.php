<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

portalRequireMaster();

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function normalizeDateInput(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }

    $dt = DateTime::createFromFormat('Y-m-d', $value);
    if (!$dt || $dt->format('Y-m-d') !== $value) {
        return '';
    }

    return $value;
}

function parseFailureLine(string $line): ?array
{
    $line = trim($line);
    if ($line === '' || strpos($line, ' success=0 ') === false) {
        return null;
    }

    if (preg_match('/^\[(.*?)\]\s+(.*)$/', $line, $m) !== 1) {
        return null;
    }

    $timestamp = trim((string)$m[1]);
    $payload = (string)$m[2];

    $extract = static function (string $key, string $text): string {
        if (preg_match('/\b' . preg_quote($key, '/') . '=([^\s]+)/', $text, $mm) === 1) {
            return (string)$mm[1];
        }
        return '';
    };

    $requestUrl = '';
    if (preg_match('/\brequest_url=(.*?)\s+response=/', $payload, $urlMatch) === 1) {
        $requestUrl = trim((string)$urlMatch[1]);
    }

    $response = '';
    if (preg_match('/\bresponse=(.*)$/', $payload, $respMatch) === 1) {
        $response = trim((string)$respMatch[1]);
    }

    return [
        'timestamp' => $timestamp,
        'template' => $extract('template', $payload),
        'http_code' => $extract('http', $payload),
        'error_type' => $extract('error_type', $payload),
        'provider_code' => $extract('provider_code', $payload),
        'duration_ms' => $extract('duration_ms', $payload),
        'request_url' => $requestUrl,
        'response' => $response,
        'raw' => $line,
    ];
}

$startDate = normalizeDateInput((string)($_GET['start_date'] ?? ''));
$endDate = normalizeDateInput((string)($_GET['end_date'] ?? ''));

$logFile = __DIR__ . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'wp.log';
$failures = [];
$errorMessage = '';

if (!is_file($logFile)) {
    $errorMessage = 'Log file not found: logs/wp.log';
} else {
    $lines = @file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($lines === false) {
        $errorMessage = 'Unable to read logs/wp.log';
    } else {
        foreach ($lines as $line) {
            $parsed = parseFailureLine((string)$line);
            if ($parsed === null) {
                continue;
            }

            $rowTs = strtotime((string)$parsed['timestamp']);
            if ($rowTs === false) {
                continue;
            }

            if ($startDate !== '') {
                $fromTs = strtotime($startDate . ' 00:00:00');
                if ($fromTs !== false && $rowTs < $fromTs) {
                    continue;
                }
            }

            if ($endDate !== '') {
                $toTs = strtotime($endDate . ' 23:59:59');
                if ($toTs !== false && $rowTs > $toTs) {
                    continue;
                }
            }

            $failures[] = $parsed;
        }

        usort(
            $failures,
            static fn(array $a, array $b): int => strcmp((string)$b['timestamp'], (string)$a['timestamp'])
        );
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WhatsApp Failures</title>
    <style>
        :root {
            --bg: #f4f8fc;
            --card: #ffffff;
            --text: #1f2d3d;
            --muted: #6b7c93;
            --border: #d9e2ec;
            --accent: #0e73b8;
            --danger: #c0392b;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: "Segoe UI", Tahoma, sans-serif;
            background: var(--bg);
            color: var(--text);
        }

        .wrap {
            max-width: 1280px;
            margin: 18px auto;
            padding: 0 16px;
        }

        .card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 14px;
            box-shadow: 0 6px 16px rgba(15, 41, 68, 0.08);
            margin-bottom: 14px;
        }

        h1 {
            margin: 0 0 10px 0;
            font-size: 22px;
        }

        .muted { color: var(--muted); }

        .toolbar {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: end;
        }

        .field {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .field label {
            font-size: 12px;
            color: var(--muted);
        }

        input[type="date"] {
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 8px 10px;
            min-width: 180px;
        }

        .btn {
            border: none;
            border-radius: 8px;
            height: 38px;
            padding: 0 12px;
            min-width: 84px;
            cursor: pointer;
            color: #fff;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            background: var(--accent);
        }

        .btn.secondary {
            background: #6b7c93;
        }

        .notice {
            color: var(--danger);
            font-weight: 600;
        }

        .count {
            font-size: 15px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
        }

        th, td {
            border: 1px solid var(--border);
            padding: 8px;
            text-align: left;
            vertical-align: top;
            font-size: 13px;
        }

        th {
            background: #eef5fb;
            font-weight: 700;
        }

        .mono {
            font-family: Consolas, "Courier New", monospace;
            word-break: break-all;
        }

        .empty {
            padding: 12px;
            border: 1px dashed var(--border);
            border-radius: 8px;
            color: var(--muted);
        }
    </style>
</head>
<body>
<div class="wrap">
    <div class="card">
        <h1>WhatsApp Failures</h1>
        <p class="muted">Source: logs/wp.log (entries with success=0)</p>
        <form method="get" class="toolbar">
            <div class="field">
                <label for="start_date">Start date</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo h($startDate); ?>">
            </div>
            <div class="field">
                <label for="end_date">End date</label>
                <input type="date" id="end_date" name="end_date" value="<?php echo h($endDate); ?>">
            </div>
            <button class="btn" type="submit">Apply</button>
            <a class="btn secondary" href="wp_failures.php">Reset</a>
        </form>
    </div>

    <div class="card">
        <?php if ($errorMessage !== ''): ?>
            <p class="notice"><?php echo h($errorMessage); ?></p>
        <?php else: ?>
            <div class="count">Total failures: <?php echo h((string)count($failures)); ?></div>
            <?php if (empty($failures)): ?>
                <div class="empty">No failures found for the selected date range.</div>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Template</th>
                        <th>HTTP</th>
                        <th>Error Type</th>
                        <th>Provider</th>
                        <th>Duration (ms)</th>
                        <th>Request URL</th>
                        <th>Response</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($failures as $failure): ?>
                        <tr>
                            <td><?php echo h((string)$failure['timestamp']); ?></td>
                            <td><?php echo h((string)$failure['template']); ?></td>
                            <td><?php echo h((string)$failure['http_code']); ?></td>
                            <td><?php echo h((string)$failure['error_type']); ?></td>
                            <td><?php echo h((string)$failure['provider_code']); ?></td>
                            <td><?php echo h((string)$failure['duration_ms']); ?></td>
                            <td class="mono"><?php echo h((string)$failure['request_url']); ?></td>
                            <td class="mono"><?php echo h((string)$failure['response']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
</body>
</html>

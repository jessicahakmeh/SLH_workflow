<?php

declare(strict_types=1);

require_once __DIR__ . '/env.php';
loadEnvFile();

require_once __DIR__ . '/sent_results_db.php';
require_once __DIR__ . '/result_sending.php';

// Debug: Log every invocation to Apache error log
error_log("send_pending_index.php invoked at " . date('Y-m-d H:i:s') . " (SAPI: " . PHP_SAPI . ")");

if (!defined('SEND_PENDING_RESULTS_LOG_FILE')) {
    define('SEND_PENDING_RESULTS_LOG_FILE', __DIR__ . '/logs/send_pending_results.log');
}

if (!defined('SEND_PENDING_RESULTS_LOCK_FILE')) {
    define('SEND_PENDING_RESULTS_LOCK_FILE', __DIR__ . '/logs/send_pending_results.lock');
}

if (!defined('SEND_PENDING_RESULTS_LAST_RUN_FILE')) {
    define('SEND_PENDING_RESULTS_LAST_RUN_FILE', __DIR__ . '/logs/send_pending_last_run.txt');
}

if (!defined('SEND_PENDING_RESULTS_API_KEY')) {
    // Allow web access only with valid API key from .env or config
    // Leave empty in .env to disable web access (CLI only)
    $apiKey = envValue('SEND_PENDING_RESULTS_API_KEY', '');
    define('SEND_PENDING_RESULTS_API_KEY', (string)$apiKey);
}

// Log rotation constant
const SEND_PENDING_LOG_MAX_SIZE = 52428800; // 50MB in bytes

/**
 * Rotate log file if it exceeds 50MB
 * Renames existing log to filename.YYYY-MM-DD_HH-MM-SS.log
 * @param string $logFile Full path to the log file
 */
function rotateSendPendingLogIfNeeded(string $logFile): void
{
    if (!file_exists($logFile)) {
        return;
    }

    $fileSize = @filesize($logFile);
    if ($fileSize === false || $fileSize < SEND_PENDING_LOG_MAX_SIZE) {
        return;
    }

    // File exceeds 50MB, rotate it
    $timestamp = date('Y-m-d_H-i-s');
    $pathInfo = pathinfo($logFile);
    $rotatedFile = $pathInfo['dirname'] . '/' . $pathInfo['filename'] . '.' . $timestamp . '.log';

    // Attempt to rename the old log file
    if (@rename($logFile, $rotatedFile)) {
        // Successfully rotated, new log file will be created on next write
        error_log("Send pending log rotated: $logFile -> $rotatedFile");
    }
}

function isCliSendPendingRequest(): bool
{
    return PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';
}

/**
 * Check if web request has valid API key authorization
 * Accepts API key via:
 *  1. Authorization header: "Authorization: Bearer YOUR_API_KEY"
 *  2. Query parameter: ?api_key=YOUR_API_KEY
 *  3. POST parameter: form data api_key=YOUR_API_KEY
 */
function isValidWebAuthorization(): bool
{
    if (isCliSendPendingRequest()) {
        return true; // CLI always authorized
    }

    $apiKey = SEND_PENDING_RESULTS_API_KEY;
    if (empty($apiKey)) {
        return false; // No API key configured, deny web access
    }

    // Check Authorization header (Bearer token)
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        if (preg_match('/^Bearer\s+(.+)$/i', $_SERVER['HTTP_AUTHORIZATION'], $matches)) {
            return hash_equals($apiKey, $matches[1]);
        }
    }

    // Check query parameter (accept both api_key and API_KEY for convenience)
    if (!empty($_GET['api_key'])) {
        return hash_equals($apiKey, (string)$_GET['api_key']);
    }
    if (!empty($_GET['API_KEY'])) {
        return hash_equals($apiKey, (string)$_GET['API_KEY']);
    }

    // Check POST parameter (accept both api_key and API_KEY for convenience)
    if (!empty($_POST['api_key'])) {
        return hash_equals($apiKey, (string)$_POST['api_key']);
    }
    if (!empty($_POST['API_KEY'])) {
        return hash_equals($apiKey, (string)$_POST['API_KEY']);
    }

    return false;
}

/**
 * Output response (text for CLI, JSON for web)
 */
function sendSendPendingResponse(int $httpCode, string $message, ?array $data = null, bool $isError = false): void
{
    if (isCliSendPendingRequest()) {
        // CLI output: plain text to stdout only (no JSON)
        echo $message . PHP_EOL;
    } else {
        // Web output: JSON with HTTP headers
        if (!headers_sent()) {
            http_response_code($httpCode);
            header('Content-Type: application/json; charset=UTF-8');
        }

        $response = [
            'success' => !$isError && ($httpCode < 400),
            'message' => $message,
            'timestamp' => date('Y-m-d H:i:s'),
        ];

        if ($data !== null) {
            $response['data'] = $data;
        }

        echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    }
}

function writeSendPendingLog(string $level, string $message): void
{
    $dir = dirname(SEND_PENDING_RESULTS_LOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }

    rotateSendPendingLogIfNeeded(SEND_PENDING_RESULTS_LOG_FILE);
    $line = sprintf("[%s] [%s] %s\n", date('Y-m-d H:i:s'), strtoupper($level), $message);
    @file_put_contents(SEND_PENDING_RESULTS_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

/**
 * @return resource|null
 */
function acquireSendPendingLock()
{
    $dir = dirname(SEND_PENDING_RESULTS_LOCK_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }

    // Check for stale lock (held longer than 10 minutes)
    $lockTimeout = 600; // 10 minutes in seconds
    if (file_exists(SEND_PENDING_RESULTS_LOCK_FILE)) {
        $lockAge = time() - @filemtime(SEND_PENDING_RESULTS_LOCK_FILE);
        if ($lockAge > $lockTimeout) {
            error_log("send_pending_index.php: Removing stale lock (age: {$lockAge}s, timeout: {$lockTimeout}s)");
            @unlink(SEND_PENDING_RESULTS_LOCK_FILE);
        }
    }

    $handle = @fopen(SEND_PENDING_RESULTS_LOCK_FILE, 'c+');
    if ($handle === false) {
        return null;
    }

    if (!@flock($handle, LOCK_EX | LOCK_NB)) {
        @fclose($handle);
        error_log("send_pending_index.php: Could not acquire lock (currently held by another process)");
        return null;
    }

    // Write timestamp to lock file for staleness detection
    @ftruncate($handle, 0);
    @fwrite($handle, date('Y-m-d H:i:s'));
    @fflush($handle);

    return $handle;
}

function releaseSendPendingLock($handle): void
{
    if ($handle !== null && is_resource($handle)) {
        @flock($handle, LOCK_UN);
        @fclose($handle);
    }
}

function readLastSendRun(): ?string
{
    $raw = @file_get_contents(SEND_PENDING_RESULTS_LAST_RUN_FILE);
    if ($raw === false) {
        return null;
    }

    $raw = trim((string)$raw);
    if ($raw === '') {
        return null;
    }

    if (preg_match('/^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})$/', $raw) !== 1) {
        return null;
    }

    return $raw;
}

function writeLastSendRun(string $timestamp): void
{
    $dir = dirname(SEND_PENDING_RESULTS_LAST_RUN_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }

    @file_put_contents(SEND_PENDING_RESULTS_LAST_RUN_FILE, trim($timestamp), LOCK_EX);
}

function runSendPendingResults(): int
{
    // Check authorization for web requests
    if (!isCliSendPendingRequest()) {
        if (!isValidWebAuthorization()) {
            sendSendPendingResponse(
                401,
                'Unauthorized. Provide valid API key via Authorization header, ?api_key query parameter, or POST api_key parameter.',
                null,
                true
            );
            return 1;
        }
    }

    $lockHandle = acquireSendPendingLock();
    if ($lockHandle === null) {
        error_log("send_pending_index.php: LOCK FAILED - Another process running");
        $message = 'Another send_pending_index.php process is already running.';
        writeSendPendingLog('warning', $message);
        sendSendPendingResponse(429, $message, null, true);
        return 1;
    }

    error_log("send_pending_index.php: LOCK ACQUIRED - Starting send run at " . date('Y-m-d H:i:s'));

    try {
        $runStartedAt = date('Y-m-d H:i:s');
        $notBefore = readLastSendRun();
        if ($notBefore === null) {
            writeLastSendRun($runStartedAt);
            $bootstrapMessage = 'No previous send run marker found. Baseline initialized; no results sent in this run.';
            writeSendPendingLog('info', $bootstrapMessage);
            sendSendPendingResponse(200, $bootstrapMessage);
            return 0;
        }

        if (!isAnyChannelAutoSendEnabled()) {
            $message = 'Auto-send is disabled for all channels (WHATSAPP_AUTO_SEND=SMS_AUTO_SEND=EMAIL_AUTO_SEND=0).';
            writeSendPendingLog('info', $message);
            sendSendPendingResponse(200, $message);
            return 0;
        }

        $sync = syncWhatsAppDeliveryStatuses(1000);
        $syncMessage = sprintf(
            'Delivery status sync: success=%s received=%d updated=%d ignored=%d http=%d',
            !empty($sync['success']) ? '1' : '0',
            (int)($sync['received'] ?? 0),
            (int)($sync['updated'] ?? 0),
            (int)($sync['ignored'] ?? 0),
            (int)($sync['http_code'] ?? 0)
        );
        writeSendPendingLog(!empty($sync['success']) ? 'info' : 'warning', $syncMessage);
        sendSendPendingResponse(200, $syncMessage);

        // If sync failed, log a warning but continue with sending.
        // This makes the scheduled job resilient to temporary status-sync outages.
        if (empty($sync['success'])) {
            writeSendPendingLog('warning', 'WhatsApp status sync failed; continuing send run');
            error_log('WhatsApp status sync failed; continuing send run.');
        }

        // Call sendPendingJsonResults with error handling
        // Ensure summary is always written, even on errors
        $summary = null;
        $sendError = null;
        try {
            $summary = sendPendingJsonResults($notBefore);
        } catch (Throwable $exception) {
            $sendError = $exception;
            error_log("send_pending_index.php: EXCEPTION in sendPendingJsonResults: " . $exception->getMessage());
            writeSendPendingLog('error', 'sendPendingJsonResults FAILED: ' . $exception->getMessage());
            
            // Return empty stats on error so summary line still gets written
            $summary = [
                'candidates' => 0,
                'sent' => 0,
                'failed' => 0,
                'email_sent' => 0,
                'email_failed' => 0,
                'email_skipped' => 0,
            ];
        }

        // Always write the summary line, even if an error occurred
        $message = sprintf(
            'Daily send summary since %s: candidates=%d, sent=%d, failed=%d, email_sent=%d, email_failed=%d, email_skipped=%d%s',
            $notBefore,
            (int)($summary['candidates'] ?? 0),
            (int)($summary['sent'] ?? 0),
            (int)($summary['failed'] ?? 0),
            (int)($summary['email_sent'] ?? 0),
            (int)($summary['email_failed'] ?? 0),
            (int)($summary['email_skipped'] ?? 0),
            $sendError !== null ? ' (ERROR: ' . $sendError->getMessage() . ')' : ''
        );

        writeSendPendingLog($sendError !== null ? 'error' : 'info', $message);
        
        // Send response with summary data
        $httpCode = ($sendError !== null || (int)($summary['failed'] ?? 0) > 0) ? 500 : 200;
        sendSendPendingResponse($httpCode, $message, $summary, $sendError !== null);

        // Advance marker on every run so scheduling windows stay strict.
        writeLastSendRun($runStartedAt);

        return ($sendError !== null || (int)($summary['failed'] ?? 0) > 0) ? 1 : 0;
    } finally {
        releaseSendPendingLock($lockHandle);
    }
}

$exitCode = runSendPendingResults();

// Only call exit() for CLI requests; web requests should return naturally
if (isCliSendPendingRequest()) {
    exit($exitCode);
}

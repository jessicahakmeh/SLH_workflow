<?php

declare(strict_types=1);

require_once __DIR__ . '/result_sending.php';

enforceSendingAccess();

$status = getResultStatusApi($_REQUEST);

if ((int)$status['http_code'] >= 400) {
    http_response_code((int)$status['http_code']);
    header('Content-Type: text/plain; charset=UTF-8');
    echo '0';
    exit;
}

$alreadySent = !empty($status['payload']['already_sent']);
header('Content-Type: text/plain; charset=UTF-8');
echo $alreadySent ? '1' : '0';

<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

if (portalIsLoggedIn()) {
    header('Location: ' . portalDefaultLandingUrl(portalCurrentUser() ?? ['role' => 'patient']));
    exit;
}

$notice = '';
$returnUrl = portalSanitizeReturnUrl((string)($_GET['return_url'] ?? 'index.php'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $returnUrl = portalSanitizeReturnUrl((string)($_POST['return_url'] ?? $returnUrl));

    $localAdminUser = portalAuthenticateLocalAdmin($username, $password);
    if (is_array($localAdminUser)) {
        portalLoginSession($localAdminUser);
        header('Location: user_management.php');
        exit;
    }

    $ldapUser = portalAuthenticateWithLdap($username, $password);
    if (!is_array($ldapUser)) {
        $notice = 'LDAP authentication failed.';
    } else {
        $portalUser = portalResolveAuthorizedUser($ldapUser);
        if (!is_array($portalUser)) {
            $notice = 'This LDAP account is not enabled for the results portal.';
        } else {
            portalLoginSession($portalUser);
            $destination = $returnUrl !== '' ? $returnUrl : portalDefaultLandingUrl($portalUser);
            if (preg_match('/^(?:results\.php|index\.php)(?:\?.*)?$/', $destination) === 1) {
                $parsed = parse_url($destination);
                $requestedView = '';
                if (is_array($parsed) && !empty($parsed['query'])) {
                    parse_str((string)$parsed['query'], $queryParams);
                    $requestedView = strtolower(trim((string)($queryParams['view'] ?? '')));
                }

                if ($requestedView !== '' && $requestedView !== 'patient' && !portalAuthorizedView($requestedView, $portalUser)) {
                    $destination = portalDefaultLandingUrl($portalUser);
                }
            }
            header('Location: ' . $destination);
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results Portal Login</title>
    <link rel="icon" href="favicon.php" sizes="any">
    <style>
        :root {
            --bg1: #08111f;
            --bg2: #10273f;
            --surface: rgba(255,255,255,0.94);
            --line: rgba(160,181,201,0.35);
            --text: #102338;
            --muted: #5d7087;
            --accent: #0e73b8;
            --accent-strong: #0a5a91;
            --danger: #a13131;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            display: grid;
            place-items: center;
            font-family: "Segoe UI", Tahoma, sans-serif;
            color: var(--text);
            background:
                radial-gradient(circle at top left, rgba(14,115,184,0.35), transparent 35%),
                radial-gradient(circle at bottom right, rgba(34,96,148,0.22), transparent 32%),
                linear-gradient(160deg, var(--bg1), var(--bg2));
        }

        .panel {
            width: min(440px, calc(100vw - 32px));
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 20px;
            box-shadow: 0 30px 80px rgba(0,0,0,0.25);
            padding: 28px;
        }

        h1 {
            margin: 0 0 8px;
            font-size: 28px;
        }

        p {
            margin: 0 0 16px;
            color: var(--muted);
            line-height: 1.5;
        }

        label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            margin: 12px 0 6px;
        }

        input {
            width: 100%;
            border: 1px solid #c9d5e1;
            border-radius: 12px;
            padding: 12px 14px;
            font-size: 15px;
            min-height: 46px;
        }

        .btn {
            width: 100%;
            margin-top: 18px;
            border: 0;
            border-radius: 12px;
            padding: 12px 14px;
            min-height: 46px;
            font-size: 15px;
            font-weight: 700;
            color: #fff;
            background: linear-gradient(135deg, var(--accent), var(--accent-strong));
            cursor: pointer;
        }

        .btn:hover { filter: brightness(1.02); }

        .notice {
            margin-top: 14px;
            border-radius: 12px;
            padding: 10px 12px;
            border: 1px solid rgba(161,49,49,0.25);
            background: rgba(255,245,245,0.95);
            color: var(--danger);
        }

        .links {
            margin-top: 16px;
            display: flex;
            justify-content: space-between;
            gap: 10px;
            flex-wrap: wrap;
            font-size: 14px;
        }

        a {
            color: var(--accent-strong);
            text-decoration: none;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <main class="panel">
        <h1>Results Portal</h1>
        <p>Sign in with your LDAP account to access the operational views.</p>

        <form method="post" action="login.php">
            <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($returnUrl, ENT_QUOTES, 'UTF-8'); ?>">
            <label for="username">LDAP Username</label>
            <input id="username" name="username" type="text" autocomplete="username" required>

            <label for="password">Password</label>
            <input id="password" name="password" type="password" autocomplete="current-password" required>

            <button class="btn" type="submit">Sign in</button>
        </form>

        <?php if ($notice !== ''): ?>
            <div class="notice"><?php echo htmlspecialchars($notice, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
    </main>
</body>
</html>

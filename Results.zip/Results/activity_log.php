<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/sent_results_db.php';

// ============================================================
// Activity Log Viewer - Master Role Only
// ============================================================

function enforceActivityLogAccess(): void
{
    $isCli = PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';
    if ($isCli) {
        return;
    }

    if (!portalIsLoggedIn()) {
        header('Location: login.php');
        exit;
    }

    $currentUser = portalCurrentUser();
    $currentRole = portalNormalizeRole((string)($currentUser['role'] ?? 'doctor'));

    // Allow master and butler roles to access the activity log.
    if (!in_array($currentRole, ['master', 'butler'], true)) {
        http_response_code(403);
        header('Content-Type: text/html; charset=UTF-8');
        echo '<h1>Forbidden</h1><p>Activity log access is restricted to master and butler roles only.</p>';
        exit;
    }
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function parseActivityLogLine(string $line): ?array
{
    $line = trim($line);
    if ($line === '') {
        return null;
    }

    $parts = explode('|', $line, 8);
    if (count($parts) < 8) {
        return null;
    }

    return [
        'timestamp' => trim($parts[0]),
        'username' => trim($parts[1]),
        'action' => trim($parts[2]),
        'mrn' => trim($parts[3]),
        'channel' => trim($parts[4]),
        'target_phone' => trim($parts[5]),
        'target_email' => trim($parts[6]),
        'details' => trim($parts[7]),
    ];
}

function buildFilterQueryString(?string $filterMrn = null, ?array $filterUsername = null, ?string $filterDateRange = null, ?string $filterStartDate = null, ?string $filterEndDate = null, ?string $filterStatus = null, ?array $filterChannels = null): string
{
    $params = [];
    if ($filterMrn !== '' && $filterMrn !== null) $params[] = 'mrn=' . urlencode($filterMrn);
    if (!empty($filterUsername) && is_array($filterUsername)) {
        foreach ($filterUsername as $username) {
            $params[] = 'username[]=' . urlencode($username);
        }
    }
    if ($filterDateRange !== '' && $filterDateRange !== null) $params[] = 'date_range=' . urlencode($filterDateRange);
    if ($filterStartDate !== '' && $filterStartDate !== null) $params[] = 'start_date=' . urlencode($filterStartDate);
    if ($filterEndDate !== '' && $filterEndDate !== null) $params[] = 'end_date=' . urlencode($filterEndDate);
    if ($filterStatus !== '' && $filterStatus !== null) $params[] = 'status=' . urlencode($filterStatus);
    if (!empty($filterChannels) && is_array($filterChannels)) {
        foreach ($filterChannels as $channel) {
            $params[] = 'channels[]=' . urlencode($channel);
        }
    }
    return empty($params) ? '' : '?' . implode('&', $params);
}

function readActivityLog(): array
{
    $logFile = __DIR__ . '/logs/activity.log';
    if (!file_exists($logFile)) {
        return [];
    }

    $lines = @file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!is_array($lines)) {
        return [];
    }

    $entries = [];
    foreach ($lines as $line) {
        $entry = parseActivityLogLine($line);
        if ($entry !== null) {
            $entries[] = $entry;
        }
    }

    return array_reverse($entries); // Newest first
}

function filterActivityLog(array $entries, ?string $filterMrn = null, ?array $filterUsername = null, ?string $filterDateRange = null, ?string $filterStartDate = null, ?string $filterEndDate = null, ?string $filterStatus = null, ?array $filterChannels = null): array
{
    return array_filter($entries, function ($entry) use ($filterMrn, $filterUsername, $filterDateRange, $filterStartDate, $filterEndDate, $filterStatus, $filterChannels) {
        if ($filterMrn !== null && $filterMrn !== '' && strpos($entry['mrn'], $filterMrn) === false) {
            return false;
        }
        // Username filter - match if username is in the selected usernames array
        if ($filterUsername !== null && !empty($filterUsername) && !in_array($entry['username'], $filterUsername)) {
            return false;
        }
        
        // Channel filter - match if channel is in the selected channels array
        if ($filterChannels !== null && !empty($filterChannels) && !in_array(strtolower($entry['channel']), array_map('strtolower', $filterChannels))) {
            return false;
        }
        
        // Status filter - extract from details field
        if ($filterStatus !== null && $filterStatus !== '') {
            $detailsLower = strtolower($entry['details']);
            if ($filterStatus === 'success' && strpos($detailsLower, 'success') === false) {
                return false;
            }
            if ($filterStatus === 'failed' && strpos($detailsLower, 'failed') === false && strpos($detailsLower, 'error') === false) {
                return false;
            }
        }

        // Date range filtering
        if ($filterDateRange !== null && $filterDateRange !== '') {
            $today = date('Y-m-d');
            $yesterday = date('Y-m-d', strtotime('-1 day'));
            $entryDate = substr(trim($entry['timestamp']), 0, 10);

            if ($filterDateRange === 'today' && $entryDate !== $today) {
                return false;
            } elseif ($filterDateRange === 'yesterday' && $entryDate !== $yesterday) {
                return false;
            }
        }

        // Custom date range filtering
        if ($filterStartDate !== null && $filterStartDate !== '') {
            $entryDate = substr(trim($entry['timestamp']), 0, 10);
            if ($entryDate < $filterStartDate) {
                return false;
            }
        }

        if ($filterEndDate !== null && $filterEndDate !== '') {
            $entryDate = substr(trim($entry['timestamp']), 0, 10);
            if ($entryDate > $filterEndDate) {
                return false;
            }
        }

        return true;
    });
}

function getUniqueUsernames(): array
{
    $user = portalCurrentUser();
    $role = portalNormalizeRole((string)($user['role'] ?? ''));

    // Butlers only see themselves and the auto_send system user
    if ($role === 'butler') {
        $currentUsername = (string)($user['username'] ?? '');
        $result = ['auto_send'];
        if ($currentUsername !== '') {
            $result[] = $currentUsername;
        }
        return array_values(array_unique($result));
    }

    $usernames = [];

    // Add local admin user
    if (defined('AUTH_LOCAL_ADMIN_USER')) {
        $adminUser = (string)AUTH_LOCAL_ADMIN_USER;
        if ($adminUser !== '') {
            $usernames[$adminUser] = true;
        }
    }

    // Add auto_send system user
    $usernames['auto_send'] = true;

    // Get usernames from activity log
    $logFile = __DIR__ . '/logs/activity.log';
    if (file_exists($logFile)) {
        $lines = @file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (is_array($lines)) {
            foreach ($lines as $line) {
                $entry = parseActivityLogLine($line);
                if ($entry !== null && $entry['username'] !== '') {
                    $usernames[$entry['username']] = true;
                }
            }
        }
    }

    // Also get usernames from sent_results database table
    $pdo = openResultsDb();
    if ($pdo !== null) {
        try {
            $sql = "SELECT DISTINCT sent_by FROM sent_results WHERE sent_by IS NOT NULL AND sent_by != '' ORDER BY sent_by";
            $stmt = $pdo->query($sql);
            if ($stmt) {
                $rows = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
                if (is_array($rows)) {
                    foreach ($rows as $username) {
                        if ($username !== '' && $username !== null) {
                            $usernames[$username] = true;
                        }
                    }
                }
            }
        } catch (Exception $e) {
            // Silently fail if database query fails
        }
    }

    return array_keys($usernames);
}

enforceActivityLogAccess();

$currentUser = portalCurrentUser();
$filterMrn = trim((string)($_GET['mrn'] ?? ''));

// Handle multiple usernames - convert to array if provided
$filterUsername = [];
if (isset($_GET['username']) && is_array($_GET['username'])) {
    $filterUsername = array_filter(array_map('trim', $_GET['username']), function ($u) {
        return $u !== '';
    });
}

$filterDateRange = trim((string)($_GET['date_range'] ?? ''));
$filterStartDate = trim((string)($_GET['start_date'] ?? ''));
$filterEndDate = trim((string)($_GET['end_date'] ?? ''));
$filterStatus = trim((string)($_GET['status'] ?? ''));

// Handle multiple channel checkboxes - default to all channels if none selected
$filterChannels = [];
if (isset($_GET['channels']) && is_array($_GET['channels'])) {
    $filterChannels = array_filter(array_map('trim', $_GET['channels']), function ($ch) {
        return in_array($ch, ['whatsapp', 'sms', 'email']);
    });
}
// If no channels specified, default to all channels
if (empty($filterChannels)) {
    $filterChannels = ['whatsapp', 'sms', 'email'];
}

$entries = readActivityLog();
// If current user is a butler, restrict visible entries to auto_send and their own username
$currentRole = portalNormalizeRole((string)($currentUser['role'] ?? ''));
$currentUsername = (string)($currentUser['username'] ?? '');
if ($currentRole === 'butler') {
    $entries = array_filter($entries, function ($e) use ($currentUsername) {
        $uname = (string)($e['username'] ?? '');
        return $uname === 'auto_send' || $uname === $currentUsername;
    });
    // Re-index entries (since array_filter preserves keys)
    $entries = array_values($entries);
}
$filtered = filterActivityLog($entries, $filterMrn !== '' ? $filterMrn : null, !empty($filterUsername) ? $filterUsername : null, $filterDateRange !== '' ? $filterDateRange : null, $filterStartDate !== '' ? $filterStartDate : null, $filterEndDate !== '' ? $filterEndDate : null, $filterStatus !== '' ? $filterStatus : null, !empty($filterChannels) ? $filterChannels : null);

// Get unique usernames from activity log and database
$uniqueUsernames = getUniqueUsernames();
sort($uniqueUsernames);

// Pagination setup
$entriesPerPage = 100;
$totalEntries = count($filtered);
$totalPages = ceil($totalEntries / $entriesPerPage);
$currentPage = max(1, (int)($_GET['page'] ?? 1));
$currentPage = min($currentPage, $totalPages);
$offset = (int)(($currentPage - 1) * $entriesPerPage);
$paginatedEntries = array_slice($filtered, $offset, $entriesPerPage);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Log - Results System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }

        .container {
            max-width: 90%;
            margin: 0 auto;
            padding: 20px;
        }

        header {
            background: #f8f9fa;
            border-bottom: 1px solid #e8eaed;
            padding: 24px 0;
            margin-bottom: 24px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
        }

        header h1 {
            font-size: 28px;
            margin-bottom: 8px;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        header h1 i {
            font-size: 30px;
            color: #5f6368;
        }

        .header-meta {
            font-size: 13px;
            color: #5f6368;
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            align-items: center;
        }

        .header-meta strong {
            color: #202124;
        }

        .header-meta a {
            color: #1a73e8;
            text-decoration: none;
            font-weight: 500;
            padding: 6px 12px;
            border-radius: 4px;
            background: transparent;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .header-meta a:hover {
            background: #f0f4f8;
            text-decoration: none;
        }

        .filters {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
            border: 1px solid #e8eaed;
        }

        .filters form {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .filter-group {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
            align-items: flex-start;
        }

        .filter-group > div:has(.checkbox-group) {
            grid-column: 1 / -1;
        }

        .filter-group > div {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .filter-row {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            flex-wrap: wrap;
        }

        .filter-field {
            display: flex;
            flex-direction: column;
            gap: 6px;
            flex: 1;
            min-width: 140px;
        }

        .filter-channels-wrapper {
            display: flex;
            align-items: center;
            gap: 12px;
            flex: 1;
            min-width: 300px;
        }

        .filter-channels-wrapper label {
            margin-bottom: 0;
            white-space: nowrap;
            font-weight: 500;
            color: #333;
            font-size: 13px;
        }

        .filter-row-channels {
            align-items: center;
        }

        label {
            display: block;
            font-weight: 500;
            margin-bottom: 0;
            font-size: 13px;
            color: #333;
        }

        input[type="text"],
        select {
            width: 100%;
            padding: 9px 11px;
            border: 1px solid #dadce0;
            border-radius: 4px;
            font-size: 13px;
            font-family: inherit;
            background: white;
            color: #333;
            transition: all 0.2s ease;
        }

        input[type="text"]::placeholder,
        select > option {
            color: #999;
        }

        input[type="text"]:focus,
        select:focus {
            outline: none;
            border-color: #1a73e8;
            box-shadow: 0 1px 3px rgba(26, 115, 232, 0.3);
            background: white;
        }

        .checkbox-group {
            display: flex;
            flex-direction: row;
            gap: 20px;
            align-items: center;
        }

        .checkbox-wrapper {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #1a73e8;
        }

        .checkbox-wrapper label {
            margin-bottom: 0;
            cursor: pointer;
            font-weight: 400;
            color: #333;
        }

        .filter-buttons {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .btn-apply {
            padding: 9px 16px;
            background: #1a73e8;
            color: white;
            border: 1px solid #1a73e8;
            border-radius: 4px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
        }

        .btn-apply:hover {
            background: #1565c0;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
        }

        .btn-apply:active {
            background: #1350a8;
        }

        button {
            padding: 12px 28px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }

        button:not(.btn-clear) {
            padding: 12px 28px;
        }

        .btn-primary {
            background: #1a73e8;
            color: white;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
        }

        .btn-primary:hover {
            background: #1765cc;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
        }

        .btn-primary:active {
            background: #1565c0;
        }

        .btn-secondary {
            background: #f8f9fa;
            color: #3c4043;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
            border: 1px solid #dadce0;
        }

        .btn-secondary:hover {
            background: #f1f3f4;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.12);
        }

        .btn-secondary:active {
            background: #eaecf0;
        }

        .btn-clear {
            padding: 9px 16px;
            background: rgba(244, 67, 54, 0.15);
            color: #d32f2f;
            font-size: 13px;
            font-weight: 500;
            border-radius: 4px;
            border: 1px solid rgba(244, 67, 54, 0.3);
            transition: all 0.2s ease;
            gap: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            cursor: pointer;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
        }

        .btn-clear:hover {
            background: rgba(244, 67, 54, 0.25);
            border-color: rgba(244, 67, 54, 0.5);
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
        }

        .btn-clear:active {
            background: rgba(244, 67, 54, 0.35);
        }

        .log-stats {
            background: white;
            padding: 18px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            font-size: 14px;
            color: #555;
            border-left: 4px solid #1a73e8;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: center;
        }

        .log-stats strong {
            color: #333;
            font-weight: 600;
        }

        .log-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8f9fa;
            border-bottom: 1px solid #dadce0;
        }

        th {
            padding: 14px 15px;
            text-align: left;
            font-weight: 600;
            font-size: 12px;
            color: #333;
        }

        td {
            padding: 13px 15px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
        }

        tbody tr {
            transition: all 0.2s ease;
        }

        tbody tr:hover {
            background: #f8f9fa;
        }

        .timestamp {
            color: #666;
            white-space: nowrap;
            font-family: monospace;
        }

        .username {
            font-weight: 600;
            color: #0066cc;
        }

        .username-filter {
            cursor: pointer;
            text-decoration: underline;
        }

        .username-filter:hover {
            color: #0052a3;
        }

        .action {
            background: #f0f0f0;
            padding: 4px 8px;
            border-radius: 3px;
            font-family: monospace;
            font-size: 12px;
        }

        .action.send_result_single {
            background: #e3f2fd;
        }

        .action.send_manual_pdf {
            background: #f3e5f5;
        }

        .action.send_manual_link {
            background: #e8f5e9;
        }

        .action.send_collection_notice {
            background: #fff3e0;
        }

        .mrn {
            font-weight: 600;
            font-family: monospace;
        }

        .mrn-filter {
            cursor: pointer;
            text-decoration: underline;
        }

        .mrn-filter:hover {
            color: #0066cc;
        }

        .channel {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: 600;
        }

        .channel.whatsapp {
            background: #25d366;
            color: white;
        }

        .channel.sms {
            background: #ff9800;
            color: white;
        }

        .channel.email {
            background: #2196f3;
            color: white;
        }

        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-badge.status-success {
            background: #4caf50;
            color: white;
        }

        .status-badge.status-failed {
            background: #f44336;
            color: white;
        }

        .details {
            color: #666;
            font-size: 12px;
            font-family: monospace;
            max-width: 300px;
            word-break: break-all;
        }

        .empty-state {
            text-align: center;
            padding: 60px 40px;
            color: #999;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 16px;
            color: #dadce0;
        }

        .empty-state p {
            font-size: 16px;
            margin: 0;
            color: #666;
        }

        footer {
            text-align: center;
            padding: 30px 24px;
            color: #888;
            font-size: 13px;
            margin-top: 30px;
            border-top: 1px solid #f0f0f0;
        }

        .pagination {
            background: white;
            padding: 24px;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-pagination {
            padding: 8px 16px;
            background: #1a73e8;
            color: white;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
        }

        .btn-pagination:hover {
            background: #1765cc;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
        }

        .btn-pagination:active {
            background: #1565c0;
        }

        .pagination-info {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .page-number {
            padding: 6px 10px;
            font-size: 12px;
            border-radius: 4px;
            text-decoration: none;
            color: #1a73e8;
            cursor: pointer;
            display: inline-block;
            min-width: 32px;
            text-align: center;
            border: 1px solid #dadce0;
            transition: all 0.2s ease;
            font-weight: 500;
            background: white;
        }

        .page-number:hover {
            background: #f8f9fa;
            border-color: #1a73e8;
        }

        .page-number.active {
            background: #1a73e8;
            color: white;
            border-color: #0066cc;
        }

        @media (max-width: 768px) {
            .filter-group {
                grid-template-columns: 1fr;
            }

            table {
                font-size: 12px;
            }

            th,
            td {
                padding: 8px 10px;
            }

            .details {
                max-width: 150px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1><i class="fas fa-history"></i> Activity Log</h1>
            <div class="header-meta">
                Logged in as: <strong><?php echo h($currentUser['display_name'] ?? $currentUser['username'] ?? 'Unknown'); ?></strong>
                <a href="index.php"><i class="fas fa-arrow-left"></i> Dashboard</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="filters">
            <form method="get" action="activity_log.php">
                <!-- Row 1: MRN, User, Status -->
                <div class="filter-row">
                    <div class="filter-field">
                        <label for="filter_mrn">Filter by Patient MRN:</label>
                        <input type="text" id="filter_mrn" name="mrn" value="<?php echo h($filterMrn); ?>" placeholder="e.g., 12345">
                    </div>
                    <div class="filter-field">
                        <label for="filter_username">Filter by User:</label>
                        <select id="filter_username" name="username[]" multiple>
                            <?php foreach ($uniqueUsernames as $username): ?>
                                <option value="<?php echo h($username); ?>" <?php echo (is_array($filterUsername) && in_array($username, $filterUsername)) || (is_string($filterUsername) && $filterUsername === $username) ? 'selected' : ''; ?>>
                                    <?php echo h($username); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-field">
                        <label for="filter_status">Filter by Status:</label>
                        <select id="filter_status" name="status">
                            <option value="">-- All Status --</option>
                            <option value="success" <?php echo $filterStatus === 'success' ? 'selected' : ''; ?>>Success</option>
                            <option value="failed" <?php echo $filterStatus === 'failed' ? 'selected' : ''; ?>>Failed/Error</option>
                        </select>
                    </div>
                </div>

                <!-- Row 2: Date Range -->
                <div class="filter-row">
                    <div class="filter-field">
                        <label for="filter_date_range">Date Range:</label>
                        <select id="filter_date_range" name="date_range">
                            <option value="">-- Any Date --</option>
                            <option value="today" <?php echo $filterDateRange === 'today' ? 'selected' : ''; ?>>Today</option>
                            <option value="yesterday" <?php echo $filterDateRange === 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                            <option value="custom" <?php echo ($filterStartDate !== '' || $filterEndDate !== '') ? 'selected' : ''; ?>>Custom Range</option>
                        </select>
                    </div>
                    <div id="date_inputs_container" style="display: <?php echo ($filterStartDate !== '' || $filterEndDate !== '') ? 'contents' : 'none'; ?>;">
                        <div class="filter-field">
                            <label for="custom_date_range">Select Date Range:</label>
                            <input type="text" id="custom_date_range" name="custom_date_range" placeholder="Pick date range" 
                                   value="<?php echo $filterStartDate !== '' && $filterEndDate !== '' ? h($filterStartDate) . ' to ' . h($filterEndDate) : ''; ?>">
                            <input type="hidden" id="filter_start_date" name="start_date" value="<?php echo h($filterStartDate); ?>">
                            <input type="hidden" id="filter_end_date" name="end_date" value="<?php echo h($filterEndDate); ?>">
                        </div>
                    </div>
                </div>

                <!-- Row 3: Channels + Clear Button -->
                <div class="filter-row filter-row-channels">
                    <div class="filter-channels-wrapper">
                        <label>Filter by Channel:</label>
                        <div class="checkbox-group">
                            <div class="checkbox-wrapper">
                                <input type="checkbox" id="ch_whatsapp" name="channels[]" value="whatsapp" <?php echo (is_array($filterChannels) && in_array('whatsapp', $filterChannels)) ? 'checked' : ''; ?>>
                                <label for="ch_whatsapp">WhatsApp</label>
                            </div>
                            <div class="checkbox-wrapper">
                                <input type="checkbox" id="ch_sms" name="channels[]" value="sms" <?php echo (is_array($filterChannels) && in_array('sms', $filterChannels)) ? 'checked' : ''; ?>>
                                <label for="ch_sms">SMS</label>
                            </div>
                            <div class="checkbox-wrapper">
                                <input type="checkbox" id="ch_email" name="channels[]" value="email" <?php echo (is_array($filterChannels) && in_array('email', $filterChannels)) ? 'checked' : ''; ?>>
                                <label for="ch_email">Email</label>
                            </div>
                        </div>
                    </div>
                    <div class="filter-buttons">
                        <button type="submit" class="btn-apply">
                            <i class="fas fa-filter"></i> Apply Filters
                        </button>
                        <a href="activity_log.php" class="btn-clear">
                            <i class="fas fa-times-circle"></i> Clear
                        </a>
                    </div>
                </div>
            </form>
        </div>

        <div class="log-stats">
            <strong>Showing:</strong> <?php echo $totalEntries > 0 ? ($offset + 1) . '-' . min($offset + $entriesPerPage, $totalEntries) : 0; ?> of <?php echo $totalEntries; ?>
            <?php if ($totalPages > 1): ?>
                | <strong>Page <?php echo $currentPage; ?> of <?php echo $totalPages; ?></strong>
            <?php endif; ?>
            <?php if ($filterMrn !== '' || !empty($filterUsername) || $filterDateRange !== '' || $filterStartDate !== '' || $filterEndDate !== ''): ?>
                | <strong>Active filters:</strong>
                <?php if ($filterMrn !== ''): ?>
                    MRN: <code><?php echo h($filterMrn); ?></code>
                <?php endif; ?>
                <?php if (!empty($filterUsername)): ?>
                    User: <code><?php echo h(implode(', ', $filterUsername)); ?></code>
                <?php endif; ?>
                <?php if ($filterDateRange === 'today'): ?>
                    Date: <code>Today</code>
                <?php elseif ($filterDateRange === 'yesterday'): ?>
                    Date: <code>Yesterday</code>
                <?php elseif ($filterStartDate !== '' || $filterEndDate !== ''): ?>
                    Date Range: <code><?php echo h($filterStartDate); ?> to <?php echo h($filterEndDate); ?></code>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if (count($filtered) === 0): ?>
            <div class="log-table">
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>No activity log entries found.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="log-table">
                <table>
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>User</th>
                            <th>Action</th>
                            <th>Patient MRN</th>
                            <th>Channel</th>
                            <th>Status</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($paginatedEntries as $entry): 
                            // Extract status from details (treat 'sent' and 'delivered' as success)
                            $statusText = '';
                            $statusClass = '';
                            $details = (string)($entry['details'] ?? '');
                            // Consider common success keywords
                            if (preg_match('/\b(success|sent|delivered|ok|accepted)\b/i', $details)) {
                                $statusText = 'Success';
                                $statusClass = 'status-success';
                            } elseif (preg_match('/\b(failed|error|undeliver|rejected|not sent|not_sent)\b/i', $details)) {
                                $statusText = 'Failed';
                                $statusClass = 'status-failed';
                            }
                        ?>
                            <tr>
                                <td class="timestamp"><?php echo h($entry['timestamp']); ?></td>
                                <td>
                                    <span class="username username-filter" onclick="window.location.href='activity_log.php?username=<?php echo urlencode($entry['username']); ?>';">
                                        <?php echo h($entry['username']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="action action<?php echo strpos($entry['action'], '_') !== false ? '.' . str_replace('_', '_', $entry['action']) : ''; ?>">
                                        <?php echo h($entry['action']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="mrn mrn-filter" onclick="window.location.href='activity_log.php?mrn=<?php echo urlencode($entry['mrn']); ?>';">
                                        <?php echo h($entry['mrn']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($entry['channel'] !== ''): ?>
                                        <span class="channel <?php echo strtolower(h($entry['channel'])); ?>">
                                            <?php echo strtoupper(h($entry['channel'])); ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #ccc;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($statusText !== ''): ?>
                                        <span class="status-badge <?php echo h($statusClass); ?>">
                                            <?php echo h($statusText); ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #ccc;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $entry['target_phone'] !== '' ? h($entry['target_phone']) : '<span style="color: #ccc;">-</span>'; ?></td>
                                <td><?php echo $entry['target_email'] !== '' ? h($entry['target_email']) : '<span style="color: #ccc;">-</span>'; ?></td>
                                <td class="details"><?php echo h($entry['details']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($totalPages > 1): 
                $filterQueryString = buildFilterQueryString($filterMrn, !empty($filterUsername) ? $filterUsername : null, $filterDateRange, $filterStartDate, $filterEndDate, $filterStatus, !empty($filterChannels) ? $filterChannels : null);
                $filterQueryString = substr($filterQueryString, 1); // Remove leading '?'
                $filterSep = $filterQueryString !== '' ? '&' : '?';
            ?>
                <div class="pagination">
                    <?php if ($currentPage > 1): ?>
                        <a href="activity_log.php?page=1<?php echo $filterQueryString !== '' ? '&' . $filterQueryString : ''; ?>" class="btn-pagination">
                            <i class="fas fa-chevron-double-left"></i> First
                        </a>
                        <a href="activity_log.php?page=<?php echo $currentPage - 1; ?><?php echo $filterQueryString !== '' ? '&' . $filterQueryString : ''; ?>" class="btn-pagination">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    <?php endif; ?>

                    <span class="pagination-info">
                        <?php 
                        $startPage = max(1, $currentPage - 2);
                        $endPage = min($totalPages, $currentPage + 2);
                        
                        if ($startPage > 1): ?>
                            <a href="activity_log.php?page=1<?php echo $filterQueryString !== '' ? '&' . $filterQueryString : ''; ?>" class="page-number">1</a>
                            <?php if ($startPage > 2): ?><span class="page-number">...</span><?php endif; ?>
                        <?php endif; ?>

                        <?php for ($p = $startPage; $p <= $endPage; $p++): ?>
                            <?php if ($p === $currentPage): ?>
                                <span class="page-number active"><?php echo $p; ?></span>
                            <?php else: ?>
                                <a href="activity_log.php?page=<?php echo $p; ?><?php echo $filterQueryString !== '' ? '&' . $filterQueryString : ''; ?>" class="page-number"><?php echo $p; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($endPage < $totalPages): ?>
                            <?php if ($endPage < $totalPages - 1): ?><span class="page-number">...</span><?php endif; ?>
                            <a href="activity_log.php?page=<?php echo $totalPages; ?><?php echo $filterQueryString !== '' ? '&' . $filterQueryString : ''; ?>" class="page-number"><?php echo $totalPages; ?></a>
                        <?php endif; ?>
                    </span>

                    <?php if ($currentPage < $totalPages): ?>
                        <a href="activity_log.php?page=<?php echo $currentPage + 1; ?><?php echo $filterQueryString !== '' ? '&' . $filterQueryString : ''; ?>" class="btn-pagination">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                        <a href="activity_log.php?page=<?php echo $totalPages; ?><?php echo $filterQueryString !== '' ? '&' . $filterQueryString : ''; ?>" class="btn-pagination">
                            Last <i class="fas fa-chevron-double-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <footer>
        <p>Activity Log - Manual sending actions are tracked for audit purposes. Last updated: <?php echo date('Y-m-d H:i:s'); ?></p>
    </footer>

    <script>
        // Handle custom date range visibility and Flatpickr initialization
        function initializeDatePicker() {
            const dateRangeSelect = document.getElementById('filter_date_range');
            const dateInputsContainer = document.getElementById('date_inputs_container');
            const customDateRangeInput = document.getElementById('custom_date_range');
            const startDateHidden = document.getElementById('filter_start_date');
            const endDateHidden = document.getElementById('filter_end_date');

            // Initialize Flatpickr on the custom date range input
            if (customDateRangeInput && typeof flatpickr !== 'undefined') {
                flatpickr(customDateRangeInput, {
                    mode: 'range',
                    dateFormat: 'Y-m-d',
                    allowInput: true,
                    onClose: function(selectedDates, dateStr, instance) {
                        if (selectedDates.length === 2) {
                            const startDate = selectedDates[0];
                            const endDate = selectedDates[1];
                            startDateHidden.value = flatpickr.formatDate(startDate, 'Y-m-d');
                            endDateHidden.value = flatpickr.formatDate(endDate, 'Y-m-d');

                            // Ensure the visible input also reflects the selection
                            customDateRangeInput.value = instance.formatDate(startDate, 'Y-m-d') + ' to ' + instance.formatDate(endDate, 'Y-m-d');
                        }
                    }

                });
            }

            function toggleDateInputs() {
                    const selectedValue = dateRangeSelect.value;
                if (selectedValue === 'custom') {
                    dateInputsContainer.style.display = 'contents';
                    // Focus and open picker when custom is selected
                    if (customDateRangeInput && customDateRangeInput._flatpickr) {
                        setTimeout(() => {
                            customDateRangeInput.focus();
                            customDateRangeInput._flatpickr.open();
                        }, 50);
                    }
                } else {

                    dateInputsContainer.style.display = 'none';
                    // Clear the date inputs when switching away from custom
                    if (customDateRangeInput && customDateRangeInput._flatpickr) {
                        customDateRangeInput._flatpickr.clear();
                    }
                    if (customDateRangeInput) customDateRangeInput.value = '';
                    if (startDateHidden) startDateHidden.value = '';
                    if (endDateHidden) endDateHidden.value = '';
                }
            }

            // Listen for changes
            if (dateRangeSelect) {
                dateRangeSelect.addEventListener('change', toggleDateInputs);
            }
        }

        // Wait for both DOM and flatpickr to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
                // Wait a bit for flatpickr to load
                setTimeout(initializeDatePicker, 100);
            });
        } else {
            // DOM already loaded
            setTimeout(initializeDatePicker, 100);
        }

        // Initialize auto-apply for Status and Channels only
        document.addEventListener('DOMContentLoaded', function() {
            const filterForm = document.querySelector('.filters form');
            if (filterForm) {
                // Auto-submit only for Status and Channel checkboxes
                const statusSelect = document.getElementById('filter_status');
                const channelCheckboxes = filterForm.querySelectorAll('input[name="channels[]"]');
                
                if (statusSelect) {
                    statusSelect.addEventListener('change', function() {
                        filterForm.submit();
                    });
                }
                
                channelCheckboxes.forEach(checkbox => {
                    checkbox.addEventListener('change', function() {
                        filterForm.submit();
                    });
                });
            }
        });
    </script>
</body>
</html>

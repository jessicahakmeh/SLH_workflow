<?php
echo "=== MySQL Diagnostic Information ===\n\n";

// Check if port 3306 is listening
echo "Checking if MySQL port 3306 is listening...\n";
echo "Running: netstat -an | findstr 3306\n";
echo "---\n";
shell_exec('netstat -an | findstr 3306');
echo "\n";

// List running processes with mysql in name
echo "Looking for MySQL processes...\n";
echo "Running: tasklist | findstr mysql\n";
echo "---\n";
$output = shell_exec('tasklist | findstr /i mysql');
if ($output) {
    echo $output . "\n";
} else {
    echo "(No MySQL processes found in task list)\n\n";
}

// Try to detect MySQL installation
echo "Checking common MySQL installation paths...\n";
$mysqlPaths = [
    'C:\\Program Files\\MySQL',
    'C:\\Program Files (x86)\\MySQL',
    'C:\\ProgramData\\MySQL',
    'C:\\MySQL',
];

foreach ($mysqlPaths as $path) {
    if (is_dir($path)) {
        echo "  Found: $path\n";
    }
}

// Check services
echo "\nChecking for MySQL services...\n";
echo "Running: tasklist /svc | findstr mysql\n";
echo "---\n";
$svc = shell_exec('tasklist /svc | findstr /i mysql');
if ($svc) {
    echo $svc . "\n";
} else {
    echo "(No MySQL services found)\n";
}

echo "\n=== Recommendations ===\n";
echo "1. Verify MySQL service is running:\n";
echo "   - Open Services (services.msc)\n";
echo "   - Look for 'MySQL80' or similar service\n";
echo "   - Ensure it's status is 'Running'\n\n";

echo "2. If MySQL is running, check its configuration:\n";
echo "   - Find my.ini or my.cnf file\n";
echo "   - Check 'bind_address' setting (should be 0.0.0.0, 127.0.0.1, or localhost)\n";
echo "   - Check 'port' setting (should be 3306)\n\n";

echo "3. Test connection with host ip.address instead of localhost:\n";
echo "   - Update DB_HOST to 127.0.0.1 or the actual MySQL server IP\n";
echo "   - Ensure the IP is routable from your CLI context\n\n";

echo "4. Check Windows Firewall:\n";
echo "   - Firewall & network protection settings\n";
echo "   - Inbound rules for MySQL (port 3306)\n";
?>

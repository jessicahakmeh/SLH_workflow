<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/result_sending.php';

function webhookJsonResponse(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function webhookExtractSecretFromRequest(): string
{
    $headerSecret = trim((string)($_SERVER['HTTP_X_WEBHOOK_SECRET'] ?? ''));
    if ($headerSecret !== '') {
        return $headerSecret;
    }

    $bearer = trim((string)($_SERVER['HTTP_AUTHORIZATION'] ?? ''));
    if (stripos($bearer, 'Bearer ') === 0) {
        return trim(substr($bearer, 7));
    }

    return trim((string)($_GET['secret'] ?? $_POST['secret'] ?? ''));
}

function webhookCollectStatusRows($node, array &$rows): void
{
    if (!is_array($node)) {
        return;
    }

    $hasAck = isset($node['ack']) || isset($node['message_id']) || isset($node['messageId']) || isset($node['id']);
    $hasStatus = isset($node['opstatus']) || isset($node['status']) || isset($node['message_status']);

    if ($hasAck && $hasStatus) {
        $rows[] = [
            'ack' => (string)($node['ack'] ?? $node['message_id'] ?? $node['messageId'] ?? $node['id'] ?? ''),
            'opstatus' => (string)($node['opstatus'] ?? $node['status'] ?? $node['message_status'] ?? ''),
            'recipient' => (string)($node['recipient'] ?? $node['recipient_id'] ?? $node['to'] ?? $node['destination'] ?? ''),
        ];
    }

    if (isset($node['statuses']) && is_array($node['statuses'])) {
        foreach ($node['statuses'] as $statusRow) {
            webhookCollectStatusRows($statusRow, $rows);
        }
    }

    foreach ($node as $value) {
        if (is_array($value)) {
            webhookCollectStatusRows($value, $rows);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $mode = trim((string)($_GET['hub_mode'] ?? $_GET['hub.mode'] ?? ''));
    $challenge = trim((string)($_GET['hub_challenge'] ?? $_GET['hub.challenge'] ?? ''));
    if ($mode !== '' && $challenge !== '') {
        header('Content-Type: text/plain; charset=UTF-8');
        echo $challenge;
        exit;
    }

    webhookJsonResponse(200, ['ok' => true, 'message' => 'Webhook endpoint is online.']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    webhookJsonResponse(405, ['ok' => false, 'message' => 'Method not allowed.']);
}

$expectedSecret = trim((string)WHATSAPP_META_WEBHOOK_SECRET);
if ($expectedSecret !== '') {
    $incomingSecret = webhookExtractSecretFromRequest();
    if ($incomingSecret === '' || !hash_equals($expectedSecret, $incomingSecret)) {
        webhookJsonResponse(401, ['ok' => false, 'message' => 'Unauthorized webhook secret.']);
    }
}

$rawBody = file_get_contents('php://input');
if (!is_string($rawBody) || trim($rawBody) === '') {
    webhookJsonResponse(400, ['ok' => false, 'message' => 'Empty webhook payload.']);
}

$payload = json_decode($rawBody, true);
if (!is_array($payload)) {
    webhookJsonResponse(400, ['ok' => false, 'message' => 'Invalid JSON payload.']);
}

$rows = [];
webhookCollectStatusRows($payload, $rows);

if (empty($rows)) {
    writeWhatsappLogLine('[' . date('Y-m-d H:i:s') . '] meta_webhook no_status_rows payload=' . substr($rawBody, 0, 1000));
    webhookJsonResponse(200, ['ok' => true, 'received' => 0, 'updated' => 0, 'ignored' => 0]);
}

$summary = applyDeliveryStatusesFromRows($rows, 'meta_webhook');

writeWhatsappLogLine(sprintf(
    '[%s] meta_webhook received=%d updated=%d ignored=%d',
    date('Y-m-d H:i:s'),
    (int)($summary['received'] ?? 0),
    (int)($summary['updated'] ?? 0),
    (int)($summary['ignored'] ?? 0)
));

webhookJsonResponse(200, [
    'ok' => true,
    'received' => (int)($summary['received'] ?? 0),
    'updated' => (int)($summary['updated'] ?? 0),
    'ignored' => (int)($summary['ignored'] ?? 0),
]);

<?php
require 'sent_results_db.php';

try {
    $pdo = openResultsDb();
    if (!$pdo) {
        echo "Error: Could not open database\n";
        exit(1);
    }
    
    // Get all databases
    $stmt = $pdo->query("SHOW DATABASES");
    $databases = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "=== Available Databases ===\n";
    foreach ($databases as $db) {
        echo $db . "\n";
    }
    echo "\n";
    
    // Try checking in different databases for patient_results
    foreach ($databases as $db) {
        $stmt = $pdo->prepare("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME LIKE ?");
        $stmt->execute([$db, '%patient%']);
        $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if (count($tables) > 0) {
            echo "=== Tables in $db with 'patient' ===\n";
            foreach ($tables as $table) {
                echo $table . "\n";
            }
            echo "\n";
        }
    }
    
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage() . "\n";
}
?>

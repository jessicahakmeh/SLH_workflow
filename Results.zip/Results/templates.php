<?php

declare(strict_types=1);

/**
 * Centralized Template Definitions
 * All templates use {{1}}, {{2}} placeholders
 * {{1}} = patient name
 * {{2}} = result link
 */

return [
    // ============================================================
    // WhatsApp Templates
    // ============================================================
    'whatsapp' => [
        'lab_results' => "Dear Mr./Mrs. {{1}},\nYour laboratory results are now available on your portal. You may access your report using the following link:\n\nعزيزي السيد/عزيزتي السيدة\nنتائج الفحوصات المخبرية الخاصة بكم أصبحت جاهزة ويمكنكم الاطلاع على التقرير من خلال حسابكم الإلكتروني على موقع المستشفى عبر الرابط التالي:\n\n{{2}}\n\nOur team remains available to support you!",
        
        'mi_results' => "Dear {{1}},\nYour imaging results are now available on your portal. You may access your report using the following link:\n\nعزيزي السيد/عزيزتي السيدة\nنتائج التصوير الطبي الخاصة بكم أصبحت جاهزة ويمكنكم الاطلاع على التقرير من خلال حسابكم الإلكتروني على موقع المستشفى عبر الرابط التالي:\n\n{{2}}\n\nShould you require any assistance, our team remains available to support you!",
        
        'result_collection' => "Dear {{1}} {{2}},\n\nYour results are now ready for collection.\nCollection Hours:\n• Monday – Friday: 08:00 – 16:30\n• Saturday: 08:00 – 13:00\n\nImportant Notes:\n• Please bring your ID.\n• If someone else will collect the results on your behalf, kindly provide us with their full name and ensure they bring their ID.\n\nOur team remains available to support you!\n\n{{4}} {{3}} حضرة\n\nنتائجكم أصبحت جاهزة للاستلام\nأوقات الاستلام:\n• من الإثنين إلى الجمعة: من الساعة الثامنة صباحًا حتى الساعة الرابعة والنصف بعد الظهر\n• السبت: من الساعة الثامنة صباحًا حتى الساعة الواحدة ظهرًا\n\nملاحظات مهمة:\n• يرجى إحضار بطاقة الهوية.\n• في حال قيام شخص آخر باستلام النتائج نيابةً عنكم، يرجى تزويدنا باسمه الكامل والتأكد من إحضاره لبطاقة الهوية الخاصة به.\n\nيبقى فريقنا على استعداد دائم لتقديم الدعم والمساعدة لكم",
        
        'result' => "Dear {{1}},\nThank you for choosing SLH. Your results are now available. Should you require any assistance, our team remains available to support you!",
    ],
    
    // ============================================================
    // SMS Templates
    // ============================================================
    'sms' => [
       'lab_results' => "Dear Mr./Mrs. {{1}},\nYour laboratory results are now available on your portal. You may access your report using the following link:\n\nعزيزي السيد/عزيزتي السيدة\nنتائج الفحوصات المخبرية الخاصة بكم أصبحت جاهزة ويمكنكم الاطلاع على التقرير من خلال حسابكم الإلكتروني على موقع المستشفى عبر الرابط التالي:\n\n{{2}}\n\nOur team remains available to support you!",
        
        'mi_results' => "Dear {{1}},\nYour imaging results are now available on your portal. You may access your report using the following link:\n\nعزيزي السيد/عزيزتي السيدة\nنتائج التصوير الطبي الخاصة بكم أصبحت جاهزة ويمكنكم الاطلاع على التقرير من خلال حسابكم الإلكتروني على موقع المستشفى عبر الرابط التالي:\n\n{{2}}\n\nShould you require any assistance, our team remains available to support you!",
        
        'result_collection' => "Dear {{1}} {{2}},\n\nYour results are now ready for collection.\nCollection Hours:\n• Monday – Friday: 08:00 – 16:30\n• Saturday: 08:00 – 13:00\n\nImportant Notes:\n• Please bring your ID.\n• If someone else will collect the results on your behalf, kindly provide us with their full name and ensure they bring their ID.\n\nOur team remains available to support you!\n\n{{4}} {{3}} حضرة\n\nنتائجكم أصبحت جاهزة للاستلام\nأوقات الاستلام:\n• من الإثنين إلى الجمعة: من الساعة الثامنة صباحًا حتى الساعة الرابعة والنصف بعد الظهر\n• السبت: من الساعة الثامنة صباحًا حتى الساعة الواحدة ظهرًا\n\nملاحظات مهمة:\n• يرجى إحضار بطاقة الهوية.\n• في حال قيام شخص آخر باستلام النتائج نيابةً عنكم، يرجى تزويدنا باسمه الكامل والتأكد من إحضاره لبطاقة الهوية الخاصة به.\n\nيبقى فريقنا على استعداد دائم لتقديم الدعم والمساعدة لكم",
        
        
    ],
    
    // ============================================================
    // Email Templates
    // ============================================================
    'email' => [
        'subject' => "You have a New Result Available",
        
        'lab_results' => "Dear Mr./Mrs. {{1}},\nYour laboratory results are now available on your portal. You may access your report using the following link:\n\nعزيزي السيد/عزيزتي السيدة\nنتائج الفحوصات المخبرية الخاصة بكم أصبحت جاهزة ويمكنكم الاطلاع على التقرير من خلال حسابكم الإلكتروني على موقع المستشفى عبر الرابط التالي:\n\n{{2}}\n\nOur team remains available to support you!",
        
        'mi_results' => "Dear {{1}},\nYour imaging results are now available on your portal. You may access your report using the following link:\n\nعزيزي السيد/عزيزتي السيدة\nنتائج التصوير الطبي الخاصة بكم أصبحت جاهزة ويمكنكم الاطلاع على التقرير من خلال حسابكم الإلكتروني على موقع المستشفى عبر الرابط التالي:\n\n{{2}}\n\nShould you require any assistance, our team remains available to support you!",
        
        'result_collection' => "Dear {{1}} {{2}},\n\nYour results are now ready for collection.\nCollection Hours:\n• Monday – Friday: 08:00 – 16:30\n• Saturday: 08:00 – 13:00\n\nImportant Notes:\n• Please bring your ID.\n• If someone else will collect the results on your behalf, kindly provide us with their full name and ensure they bring their ID.\n\nOur team remains available to support you!\n\n{{4}} {{3}} حضرة\n\nنتائجكم أصبحت جاهزة للاستلام\nأوقات الاستلام:\n• من الإثنين إلى الجمعة: من الساعة الثامنة صباحًا حتى الساعة الرابعة والنصف بعد الظهر\n• السبت: من الساعة الثامنة صباحًا حتى الساعة الواحدة ظهرًا\n\nملاحظات مهمة:\n• يرجى إحضار بطاقة الهوية.\n• في حال قيام شخص آخر باستلام النتائج نيابةً عنكم، يرجى تزويدنا باسمه الكامل والتأكد من إحضاره لبطاقة الهوية الخاصة به.\n\nيبقى فريقنا على استعداد دائم لتقديم الدعم والمساعدة لكم",
        
        'result' => "Dear {{1}},\nThank you for choosing SLH. Your results are now available. \nShould you require any assistance, our team remains available to support you!",
    ],

    // ============================================================
    // Collection Notice Templates
    // {{1}} = Mr./Mrs. (gender-based)
    // {{2}} = Patient name
    // {{3}} = Patient name (Arabic context)
    // {{4}} = السيد/السيدة (gender-based Arabic title)
    // ============================================================
    'collection_notice' => [
        'whatsapp' => "Dear {{1}} {{2}},\n\nYour results are now ready for collection.\nCollection Hours:\n• Monday – Friday: 08:00 – 16:30\n• Saturday: 08:00 – 13:00\n\nImportant Notes:\n• Please bring your ID.\n• If someone else will collect the results on your behalf, kindly provide us with their full name and ensure they bring their ID.\n\nOur team remains available to support you!\n\n{{4}} {{3}} حضرة\n\nنتائجكم أصبحت جاهزة للاستلام\nأوقات الاستلام:\n• من الإثنين إلى الجمعة: من الساعة الثامنة صباحًا حتى الساعة الرابعة والنصف بعد الظهر\n• السبت: من الساعة الثامنة صباحًا حتى الساعة الواحدة ظهرًا\n\nملاحظات مهمة:\n• يرجى إحضار بطاقة الهوية.\n• في حال قيام شخص آخر باستلام النتائج نيابةً عنكم، يرجى تزويدنا باسمه الكامل والتأكد من إحضاره لبطاقة الهوية الخاصة به.\n\nيبقى فريقنا على استعداد دائم لتقديم الدعم والمساعدة لكم",
        'sms' => "Dear {{1}} {{2}},\n\nYour results are now ready for collection.\nCollection Hours:\n• Monday – Friday: 08:00 – 16:30\n• Saturday: 08:00 – 13:00\n\nImportant Notes:\n• Please bring your ID.\n• If someone else will collect the results on your behalf, kindly provide us with their full name and ensure they bring their ID.\n\nOur team remains available to support you!\n\n{{4}} {{3}} حضرة\n\nنتائجكم أصبحت جاهزة للاستلام\nأوقات الاستلام:\n• من الإثنين إلى الجمعة: من الساعة الثامنة صباحًا حتى الساعة الرابعة والنصف بعد الظهر\n• السبت: من الساعة الثامنة صباحًا حتى الساعة الواحدة ظهرًا\n\nملاحظات مهمة:\n• يرجى إحضار بطاقة الهوية.\n• في حال قيام شخص آخر باستلام النتائج نيابةً عنكم، يرجى تزويدنا باسمه الكامل والتأكد من إحضاره لبطاقة الهوية الخاصة به.\n\nيبقى فريقنا على استعداد دائم لتقديم الدعم والمساعدة لكم",
        'email_subject' => "Your Results Are Ready for Collection",
        'email' => "Dear {{1}} {{2}},\n\nYour results are now ready for collection.\nCollection Hours:\n• Monday – Friday: 08:00 – 16:30\n• Saturday: 08:00 – 13:00\n\nImportant Notes:\n• Please bring your ID.\n• If someone else will collect the results on your behalf, kindly provide us with their full name and ensure they bring their ID.\n\nOur team remains available to support you!\n\n{{4}} {{3}} حضرة\n\nنتائجكم أصبحت جاهزة للاستلام\nأوقات الاستلام:\n• من الإثنين إلى الجمعة: من الساعة الثامنة صباحًا حتى الساعة الرابعة والنصف بعد الظهر\n• السبت: من الساعة الثامنة صباحًا حتى الساعة الواحدة ظهرًا\n\nملاحظات مهمة:\n• يرجى إحضار بطاقة الهوية.\n• في حال قيام شخص آخر باستلام النتائج نيابةً عنكم، يرجى تزويدنا باسمه الكامل والتأكد من إحضاره لبطاقة الهوية الخاصة به.\n\nيبقى فريقنا على استعداد دائم لتقديم الدعم والمساعدة لكم",
    ],

    // ============================================================
    // User Information
    // ============================================================
    'user_info' => [
        'master' => "System Administrator - Full access to all features, user management, and activity logs.",
        'lab' => "Lab Department - Access to laboratory results only.",
        'imaging' => "Imaging Department - Access to imaging results only.",
        'doctor' => "Doctor - View patient results and send reports.",
        'butler' => "Butler - Administrative support with full result viewing and sending capabilities.",
        'patient' => "Patient - View your own results and access information.",
    ],
];

?>

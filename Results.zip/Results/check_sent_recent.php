<?php
require 'sent_results_db.php';

try {
    $pdo = openResultsDb();
    if (!$pdo) {
        echo "Error: Could not open database\n";
        exit(1);
    }
    
    $currentDb = $pdo->query("SELECT DATABASE()")->fetch(PDO::FETCH_COLUMN);
    echo "=== Connected to Database: $currentDb ===\n\n";
    
    // Get recent sent results
    $stmt = $pdo->query('
        SELECT 
            id,
            result_id,
            template_type,
            content_value,
            sent_at,
            wp_sent,
            sms_sent,
            email_sent,
            wp_last_attempt_at,
            sms_last_attempt_at,
            email_last_attempt_at
        FROM sent_results
        WHERE sent_at >= DATE_SUB(NOW(), INTERVAL 2 DAY)
        ORDER BY sent_at DESC
        LIMIT 50
    ');
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Recent Sent Results (last 2 days):\n";
    echo "Total records: " . count($records) . "\n\n";
    
    // Group by result_id to see patterns
    $byResultId = [];
    foreach ($records as $record) {
        $rid = $record['result_id'];
        if (!isset($byResultId[$rid])) {
            $byResultId[$rid] = [];
        }
        $byResultId[$rid][] = $record;
    }
    
    // Show summary
    echo "=== Summary by Result ID ===\n";
    foreach ($byResultId as $resultId => $items) {
        $latest = $items[0];
        echo "Result ID $resultId: Sent at " . $latest['sent_at'] . "\n";
        foreach ($items as $item) {
            echo "  - wp_sent=" . ($item['wp_sent'] ? 'Y' : 'N') . 
                 " sms_sent=" . ($item['sms_sent'] ? 'Y' : 'N') . 
                 " email_sent=" . ($item['email_sent'] ? 'Y' : 'N') . 
                 " sent_at=" . $item['sent_at'] . "\n";
        }
    }
    
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage() . "\n";
}
?>

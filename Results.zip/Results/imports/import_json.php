<?php

declare(strict_types=1);

require_once __DIR__ . '/../sent_results_db.php';

if (!defined('JSON_PATH')) {
    define('JSON_PATH', rtrim((string)getenv('JSON_PATH'), '/\\\\') . DIRECTORY_SEPARATOR);
}

if (!defined('IMPORT_LOG_FILE')) {
    define('IMPORT_LOG_FILE', __DIR__ . '/../logs/import.log');
}

if (!defined('IMPORT_LAST_RUN_FILE')) {
    define('IMPORT_LAST_RUN_FILE', __DIR__ . '/../logs/last_run.txt');
}

if (!defined('IMPORT_LOCK_FILE')) {
    define('IMPORT_LOCK_FILE', __DIR__ . '/../logs/import.lock');
}

if (!defined('NETWORK_SHARE_USERNAME')) {
    define('NETWORK_SHARE_USERNAME', 'stlouis\\appuser');
}

if (!defined('NETWORK_SHARE_PASSWORD')) {
    define('NETWORK_SHARE_PASSWORD', '$ecure@pp');
}

function mountNetworkShareWithCredentials(string $sharePath): bool
{
    if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
        // Not on Windows, skip mounting
        return true;
    }

    // Extract the UNC path 
    $uncPath = rtrim($sharePath, '\\/' . DIRECTORY_SEPARATOR);
    
    // Use cmd.exe with net use command
    $command = sprintf(
        'net use * "%s" /user:%s %s /persistent:no',
        $uncPath,
        escapeshellarg(NETWORK_SHARE_USERNAME),
        escapeshellarg(NETWORK_SHARE_PASSWORD)
    );

    $output = [];
    $returnCode = 0;
    exec($command . ' 2>&1', $output, $returnCode);

    // net use returns 0 on success or if share is already mounted
    return $returnCode === 0;
}

function isCliImportRequest(): bool
{
    return PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';
}

function wantsJsonImportResponse(): bool
{
    if (isCliImportRequest()) {
        return false;
    }

    $format = strtolower(trim((string)($_GET['format'] ?? '')));
    if ($format === 'json') {
        return true;
    }
    if ($format === 'text' || $format === 'txt') {
        return false;
    }

    $accept = strtolower((string)($_SERVER['HTTP_ACCEPT'] ?? ''));
    return strpos($accept, 'application/json') !== false;
}

function formatImportResponseLine(string $level, string $message): string
{
    $normalizedLevel = strtoupper(trim($level));
    return sprintf('[%s] %s', $normalizedLevel, $message);
}

function recordImportResponse(string $level, string $message, bool $useStderr = false): void
{
    if (!isset($GLOBALS['import_response_messages']) || !is_array($GLOBALS['import_response_messages'])) {
        $GLOBALS['import_response_messages'] = [];
    }

    $formatted = formatImportResponseLine($level, $message);
    $GLOBALS['import_response_messages'][] = [
        'level' => strtoupper(trim($level)),
        'message' => $message,
        'formatted' => $formatted,
    ];

    if (!isCliImportRequest()) {
        return;
    }

    if ($useStderr && defined('STDERR')) {
        fwrite(STDERR, $formatted . PHP_EOL);
        return;
    }

    echo $formatted . PHP_EOL;
}

function writeImportResponse(string $level, string $message): void
{
    recordImportResponse($level, $message, false);
}

function writeStderr(string $message): void
{
    $trimmed = trim($message);
    if ($trimmed === '') {
        return;
    }

    if (preg_match('/^\[(?<level>[A-Z]+)\]\s*(?<text>.*)$/', $trimmed, $matches) === 1) {
        recordImportResponse((string)$matches['level'], trim((string)$matches['text']), true);
        return;
    }

    recordImportResponse('ERROR', $trimmed, true);
}

function emitImportHttpResponse(int $exitCode): void
{
    if (isCliImportRequest()) {
        return;
    }

    $messages = $GLOBALS['import_response_messages'] ?? [];
    $payload = [
        'status' => $exitCode === 0 ? 'ok' : 'error',
        'exitCode' => $exitCode,
        'messages' => array_values(array_map(
            static function ($entry): array {
                return [
                    'level' => (string)($entry['level'] ?? 'INFO'),
                    'message' => (string)($entry['message'] ?? ''),
                ];
            },
            is_array($messages) ? $messages : []
        )),
    ];

    if (!headers_sent()) {
        header(wantsJsonImportResponse() ? 'Content-Type: application/json; charset=UTF-8' : 'Content-Type: text/plain; charset=UTF-8');
    }

    if (wantsJsonImportResponse()) {
        echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        return;
    }

    $lines = array_map(
        static fn(array $entry): string => (string)($entry['formatted'] ?? ''),
        is_array($messages) ? $messages : []
    );

    echo implode(PHP_EOL, array_filter($lines, static fn(string $line): bool => $line !== ''));
}

function readLastRunTimestamp(): int
{
    // If both local marker and DB baseline are unavailable, start from epoch to import all available JSON files.
    $fallbackTs = 0;

    $raw = @file_get_contents(IMPORT_LAST_RUN_FILE);
    if ($raw === false || trim((string)$raw) === '') {
        // If the local marker is missing, resume from the latest JSON-imported DB update.
        $dbTs = getLatestJsonImportUpdateTimestamp();
        return $dbTs ?? $fallbackTs;
    }

    $ts = (int)trim((string)$raw);
    if ($ts > 0) {
        return $ts;
    }

    $dbTs = getLatestJsonImportUpdateTimestamp();
    return $dbTs ?? $fallbackTs;
}

function getLatestJsonImportUpdateTimestamp(): ?int
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        return null;
    }

    $sql = "SELECT MAX(last_updated_at) AS latest_json_update
            FROM patient_results
            WHERE source = 'json_import'";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch();
        if (!is_array($row)) {
            return null;
        }

        $raw = trim((string)($row['latest_json_update'] ?? ''));
        if ($raw === '') {
            return null;
        }

        $ts = strtotime($raw);
        return $ts === false ? null : $ts;
    } catch (Throwable $exception) {
        return null;
    }
}

function writeLastRunTimestamp(int $ts): void
{
    $dir = dirname(IMPORT_LAST_RUN_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    @file_put_contents(IMPORT_LAST_RUN_FILE, (string)$ts, LOCK_EX);
}

/**
 * @return resource|null
 */
function acquireImportLock()
{


    $lockDir = dirname(IMPORT_LOCK_FILE);
    if (!is_dir($lockDir)) {
        @mkdir($lockDir, 0777, true);
    }

    $handle = @fopen(IMPORT_LOCK_FILE, 'c+');
    if ($handle === false) {
        return null;
    }

    if (!@flock($handle, LOCK_EX | LOCK_NB)) {
        // Another instance is running; do not block
        @fclose($handle);
        return null;
    }

    return $handle;
}

function releaseImportLock($handle): void
{

    if ($handle !== null && is_resource($handle)) {
        @flock($handle, LOCK_UN);
        @fclose($handle);
    }
}

function isModifiedSince(string $filePath, int $since): bool
{
    $modifiedAt = @filemtime($filePath);
    return $modifiedAt !== false && $modifiedAt >= $since;
}

function writeImportRuntimeLog(string $level, string $message): void
{
    $dir = dirname(IMPORT_LOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }

    $line = sprintf("[%s] [%s] %s\n", date('Y-m-d H:i:s'), strtoupper($level), $message);
    @file_put_contents(IMPORT_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

function extractPatientField(array $json, string $key): string
{
    $value = trim((string)($json[$key] ?? ''));
    if ($value !== '') {
        return $value;
    }

    $patient = $json['Patient'] ?? null;
    if (is_array($patient)) {
        return trim((string)($patient[$key] ?? ''));
    }

    return '';
}

function extractRequestCode(array $request): string
{
    $requestCode = trim((string)($request['RequestCode'] ?? ''));
    if ($requestCode !== '') {
        return $requestCode;
    }

    $requestCode = trim((string)($request['LabNo'] ?? ''));
    if ($requestCode !== '') {
        return $requestCode;
    }

    $link = trim((string)($request['PDFResultLink'] ?? ''));
    if ($link === '') {
        return '';
    }

    $parts = @parse_url($link);
    if (!is_array($parts) || empty($parts['query'])) {
        return '';
    }

    $query = [];
    parse_str((string)$parts['query'], $query);

    $candidate = trim((string)($query['labNo'] ?? ($query['LabNo'] ?? ($query['acc'] ?? ''))));
    return $candidate;
}

function normalizeImportDepartment(string $department): string
{
    $dep = strtolower(trim($department));
    if ($dep === 'laboratory' || $dep === 'lab') {
        return 'Laboratory';
    }
    if ($dep === 'radiology' || strpos($dep, 'imaging') !== false) {
        return 'Radiology';
    }

    return '';
}

function importJsonFile(string $filePath): void
{
    $fileName = basename($filePath);
    $filenameMrn = sanitizeMrn(pathinfo($fileName, PATHINFO_FILENAME));

    if ($filenameMrn === '') {
        writeImportRuntimeLog('warn', "Skipping file {$fileName}: invalid filename MRN");
        insertImportLog([
            'mrn' => '',
            'file_name' => $fileName,
            'file_hash' => '',
            'status' => 'error',
            'imported_count' => 0,
            'skipped_count' => 1,
            'error_message' => 'Invalid filename MRN',
        ]);
        return;
    }

    $content = @file_get_contents($filePath);
    if ($content === false || trim($content) === '') {
        writeImportRuntimeLog('error', "Failed reading file {$fileName}");
        insertImportLog([
            'mrn' => $filenameMrn,
            'file_name' => $fileName,
            'file_hash' => '',
            'status' => 'error',
            'imported_count' => 0,
            'skipped_count' => 1,
            'error_message' => 'Empty or unreadable file',
        ]);
        return;
    }

    $fileHash = hash('sha256', $content);
    $lastHash = getLastJsonHashForMrn($filenameMrn);

    if ($lastHash !== null && hash_equals($lastHash, $fileHash)) {
        writeImportRuntimeLog('info', "Skipped {$fileName}: hash unchanged");
        insertImportLog([
            'mrn' => $filenameMrn,
            'file_name' => $fileName,
            'file_hash' => $fileHash,
            'status' => 'skipped',
            'imported_count' => 0,
            'skipped_count' => 1,
            'error_message' => '',
        ]);
        return;
    }

    $json = json_decode($content, true);
    if (!is_array($json)) {
        writeImportRuntimeLog('error', "Invalid JSON in {$fileName}");
        insertImportLog([
            'mrn' => $filenameMrn,
            'file_name' => $fileName,
            'file_hash' => $fileHash,
            'status' => 'error',
            'imported_count' => 0,
            'skipped_count' => 1,
            'error_message' => 'Malformed JSON',
        ]);
        return;
    }

    $jsonMrn = sanitizeMrn((string)($json['MRN'] ?? ''));
    if ($jsonMrn !== '' && strcasecmp($jsonMrn, $filenameMrn) !== 0) {
        writeImportRuntimeLog('error', "MRN mismatch in {$fileName}: filename={$filenameMrn} json={$jsonMrn}");
        insertImportLog([
            'mrn' => $filenameMrn,
            'file_name' => $fileName,
            'file_hash' => $fileHash,
            'status' => 'error',
            'imported_count' => 0,
            'skipped_count' => 1,
            'error_message' => 'MRN mismatch between filename and JSON',
        ]);
        return;
    }

    $patientName = extractPatientField($json, 'PatientName');
    if ($patientName === '') {
        $patientName = extractPatientField($json, 'FullName');
    }
    if ($patientName === '') {
        $patientName = $filenameMrn;
    }

    $phone = extractPatientField($json, 'PhoneNumber');
    if ($phone === '') {
        $phone = extractPatientField($json, 'Mobile');
    }

    $email = extractPatientField($json, 'Email');
    if ($email === '') {
        $email = extractPatientField($json, 'EmailAddress');
    }

    $dateOfBirth = normalizeDateOnly(extractPatientField($json, 'DOB'));
    if ($dateOfBirth === null) {
        $dateOfBirth = normalizeDateOnly(extractPatientField($json, 'DateOfBirth'));
    }

    $patientId = getOrCreatePatientId($filenameMrn, $patientName, $phone, $email, $dateOfBirth);
    if ($patientId === null) {
        writeImportRuntimeLog('error', "Failed creating/updating patient for {$fileName}");
        insertImportLog([
            'mrn' => $filenameMrn,
            'file_name' => $fileName,
            'file_hash' => $fileHash,
            'status' => 'error',
            'imported_count' => 0,
            'skipped_count' => 1,
            'error_message' => 'Failed to create/update patient',
        ]);
        return;
    }

    $visits = $json['Visits'] ?? null;
    if (!is_array($visits)) {
        $visits = [];
    }

    $importedCount = 0;
    $skippedCount = 0;

    foreach ($visits as $visit) {
        if (!is_array($visit)) {
            $skippedCount++;
            continue;
        }

        $visitDate = normalizeDateOnly((string)($visit['VisitDate'] ?? ''));
        $endVisitDate = normalizeDateOnly((string)($visit['EndVisitDate'] ?? ''));
        $caseNumber = trim((string)($visit['CaseNumber'] ?? ''));
        $doctorName = trim((string)($visit['DoctorName'] ?? ''));
        $doctorSpecialty = trim((string)($visit['DoctorSpecialty'] ?? ''));

        $requests = $visit['Requests'] ?? null;
        if (!is_array($requests)) {
            $skippedCount++;
            continue;
        }

        foreach ($requests as $request) {
            if (!is_array($request)) {
                $skippedCount++;
                continue;
            }

            $department = normalizeImportDepartment((string)($request['Department'] ?? ''));
            if ($department === '') {
                $skippedCount++;
                continue;
            }

            $requestCode = extractRequestCode($request);
            if ($requestCode === '') {
                $skippedCount++;
                continue;
            }

            $testOrImage = trim((string)($request['TestOrImage'] ?? ''));
            if ($testOrImage === '') {
                $testOrImage = $department === 'Laboratory' ? 'Laboratory Result' : 'Imaging Result';
            }

            $link = trim((string)($request['PDFResultLink'] ?? ''));
            if ($link === '') {
                $skippedCount++;
                continue;
            }

            $ok = upsertPatientResult([
                'mrn' => $filenameMrn,
                'patient_name' => $patientName,
                'care_mobile' => $phone,
                'email' => $email,
                'date_of_birth' => $dateOfBirth,
                'department' => $department,
                'test_or_image' => $testOrImage,
                'request_code' => $requestCode,
                'pdf_result_link' => $link,
                'visit_date' => $visitDate,
                'end_visit_date' => $endVisitDate,
                'case_number' => $caseNumber,
                'doctor_name' => $doctorName,
                'doctor_specialty' => $doctorSpecialty,
                'source' => 'json_import',
                'json_file_hash' => $fileHash,
                'manual_filename' => null,
            ]);

            if ($ok) {
                $importedCount++;
            } else {
                $skippedCount++;
            }
        }
    }

    $status = $importedCount > 0 ? 'imported' : 'skipped';
    $errorMessage = $importedCount > 0 ? '' : 'No valid requests found in file (patient record updated).';

    writeImportRuntimeLog(
        $importedCount > 0 ? 'info' : 'warn',
        "Processed {$fileName}: imported={$importedCount}, skipped={$skippedCount}, status={$status}"
    );

    insertImportLog([
        'mrn' => $filenameMrn,
        'file_name' => $fileName,
        'file_hash' => $fileHash,
        'status' => $status,
        'imported_count' => $importedCount,
        'skipped_count' => $skippedCount,
        'error_message' => $errorMessage,
    ]);
}

function runImport(): int
{
    $lockHandle = acquireImportLock();
    if ($lockHandle === null) {
        writeStderr("[WARN]  Another import is already running. Exiting.\n");
        writeImportRuntimeLog('warn', 'Skipped: another import already running');
        return 0;
    }

    try {
        return runImportInternal();
    } finally {
        releaseImportLock($lockHandle);
    }
}

function runImportInternal(): int
{
    $pdo = openResultsDb();
    if ($pdo === null) {
        $msg = 'Database connection failed.';
        writeImportRuntimeLog('error', $msg);
        writeStderr("[ERROR] {$msg}\n");
        return 1;
    }

    // Mount network share with credentials
    if (!mountNetworkShareWithCredentials(JSON_PATH)) {
        writeImportRuntimeLog('warn', 'Could not mount network share, will attempt to access directly');
    }

    $jsonPath = JSON_PATH;
    $pathExists = is_dir($jsonPath);
    $pathReadable = $pathExists && is_readable($jsonPath);

    if (!$pathExists) {
        $msg = "JSON folder not found:     {$jsonPath}";
        writeImportRuntimeLog('error', "JSON_PATH is not a directory: {$jsonPath}");
        writeStderr("[ERROR] {$msg}\n");
        return 1;
    }

    if (!$pathReadable) {
        $msg = "JSON folder exists but is not accessible: {$jsonPath}";
        writeImportRuntimeLog('error', $msg);
        writeStderr("[ERROR] {$msg}\n");
        return 1;
    }

    writeImportResponse('OK', "JSON folder accessible: {$jsonPath}");

    $files = glob($jsonPath . '*.json');
    if (!is_array($files)) {
        $msg = "Failed scanning JSON directory: {$jsonPath}";
        writeImportRuntimeLog('error', $msg);
        writeStderr("[ERROR] {$msg}\n");
        return 1;
    }

    if (empty($files)) {
        $msg = "No JSON files found in {$jsonPath}";
        writeImportRuntimeLog('info', $msg);
        writeImportResponse('INFO', $msg);
        return 0;
    }

    $lastRun = readLastRunTimestamp();
    $lastRunFormatted = date('Y-m-d H:i:s', $lastRun);

    $eligibleFiles = [];
    foreach ($files as $filePath) {
        if (!is_file($filePath)) {
            continue;
        }

        if (!isModifiedSince($filePath, $lastRun)) {
            continue;
        }

        $eligibleFiles[] = $filePath;
    }

    // Record the run time before processing so any file written during
    // this run is picked up on the next execution.
    writeLastRunTimestamp(time());

    if (empty($eligibleFiles)) {
        $msg = "No JSON files modified since {$lastRunFormatted} in {$jsonPath}";
        writeImportRuntimeLog('info', $msg);
        writeImportResponse('INFO', $msg);
        return 0;
    }

    writeImportResponse('INFO', 'Found ' . count($eligibleFiles) . " JSON file(s) modified since {$lastRunFormatted}.");

    foreach ($eligibleFiles as $filePath) {
        importJsonFile($filePath);
    }

    writeImportRuntimeLog('info', 'Import cycle completed. No auto-send executed in this task.');
    writeImportResponse('INFO', 'Import cycle completed. No auto-send executed in this task.');

    return 0;
}

$exitCode = runImport();
emitImportHttpResponse($exitCode);
exit($exitCode);

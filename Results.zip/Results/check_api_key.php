<?php
declare(strict_types=1);

require_once __DIR__ . '/env.php';
loadEnvFile();

echo "API KEY LOADING DEBUG\n";
echo str_repeat("=", 70) . "\n\n";

// Check .env file
$envFile = __DIR__ . '/.env';
echo "1. .env file check:\n";
echo "   File exists: " . (file_exists($envFile) ? "YES" : "NO") . "\n";
echo "   File readable: " . (is_readable($envFile) ? "YES" : "NO") . "\n";

// Check envValue
echo "\n2. API Key from envValue():\n";
$apiKey = envValue('SEND_PENDING_RESULTS_API_KEY', '');
echo "   Value: " . (empty($apiKey) ? "(empty - WEB ACCESS DISABLED)" : "'$apiKey'") . "\n";
echo "   Length: " . strlen($apiKey) . " chars\n";

// Check getenv
echo "\n3. API Key from getenv():\n";
$envValue = getenv('SEND_PENDING_RESULTS_API_KEY');
echo "   Value: " . ($envValue === false ? "(not found)" : "'$envValue'") . "\n";

// Check authorization headers
echo "\n4. Current Request Info:\n";
echo "   PHP SAPI: " . PHP_SAPI . "\n";
echo "   Authorization header: " . (isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : "(not set)") . "\n";
echo "   Query api_key: " . (isset($_GET['api_key']) ? $_GET['api_key'] : "(not set)") . "\n";
echo "   POST api_key: " . (isset($_POST['api_key']) ? $_POST['api_key'] : "(not set)") . "\n";

echo "\n" . str_repeat("=", 70) . "\n";
echo "SOLUTION\n";
echo str_repeat("=", 70) . "\n\n";

echo "You must pass the API key in ONE of these ways:\n\n";

$key = empty($apiKey) ? "test-send-pending-key-12345" : $apiKey;

echo "Method 1 (RECOMMENDED - Authorization Header):\n";
echo "  curl -H \"Authorization: Bearer $key\" http://host/send_pending_results.php\n\n";

echo "Method 2 (Query Parameter):\n";
echo "  curl \"http://host/send_pending_results.php?api_key=$key\"\n\n";

echo "Method 3 (POST Parameter):\n";
echo "  curl -X POST -d \"api_key=$key\" http://host/send_pending_results.php\n\n";

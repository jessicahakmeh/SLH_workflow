<?php
require 'sent_results_db.php';

try {
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    
    $databases = ['slhcycle', 'slh', 'slh_cmp', 'slh_new', 'slh_fresh_e2e'];
    
    foreach ($databases as $dbname) {
        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
            
            // Check if patient_results exists
            $stmt = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = '$dbname' AND table_name = 'patient_results'");
            $tableExists = $stmt->fetch(PDO::FETCH_COLUMN);
            
            if ($tableExists) {
                echo "=== Database: $dbname (has patient_results) ===\n";
                
                // Check patient 165255
                $stmt = $pdo->prepare('SELECT COUNT(*) FROM patient_results WHERE mrn = 165255');
                $stmt->execute();
                $count = $stmt->fetch(PDO::FETCH_COLUMN);
                echo "Patient 165255: $count records\n";
                
                // Check patient 165497 (the one that was sent)
                $stmt = $pdo->prepare('SELECT COUNT(*) FROM patient_results WHERE mrn = 165497');
                $stmt->execute();
                $count497 = $stmt->fetch(PDO::FETCH_COLUMN);
                echo "Patient 165497: $count497 records\n";
                
                // Show all patients to understand range
                $stmt = $pdo->query('SELECT MIN(mrn), MAX(mrn), COUNT(DISTINCT mrn) FROM patient_results');
                $row = $stmt->fetch(PDO::FETCH_NUM);
                echo "MRN Range: MIN=" . $row[0] . ", MAX=" . $row[1] . ", Total patients=" . $row[2] . "\n";
                echo "\n";
            }
        } catch (Exception $e) {
            // Silently skip
        }
    }
    
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage() . "\n";
}
?>

<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';

// Load PHPMailer for better SMTP support
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

// Load centralized templates
$TEMPLATES = require_once __DIR__ . '/templates.php';

// ============================================================
// All configuration is in .env file - use envValue() directly
// ============================================================

/**
 * Get a template by channel and type
 * @param string $channel 'whatsapp', 'sms', or 'email'
 * @param string $templateType 'lab_results', 'mi_results', 'result_collection', 'result'
 * @return string The template string with {{1}}, {{2}} placeholders
 */
function getTemplate(string $channel, string $templateType): string
{
    global $TEMPLATES;
    if (!isset($TEMPLATES[$channel][$templateType])) {
        return '';
    }
    return (string)$TEMPLATES[$channel][$templateType];
}

function enforceSendingAccess(): void
{
    $isCli = PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';
    if ($isCli) {
        return;
    }

    $currentPortalUser = portalCurrentUser();
    if (!is_array($currentPortalUser)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Forbidden. Sign in required.';
        exit;
    }

    $currentPortalRole = portalNormalizeRole((string)($currentPortalUser['role'] ?? 'doctor'));
    if (!in_array($currentPortalRole, ['master', 'butler', 'imaging', 'lab'], true)) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Forbidden. This role cannot send results.';
        exit;
    }
}

/**
 * Check if any channel auto-send is enabled (WhatsApp OR SMS OR Email).
 */
function isAnyChannelAutoSendEnabled(): bool
{
    $wpEnabled = strtolower((string)(envValue('WHATSAPP_AUTO_SEND', '0') ?? '0')) === '1';
    $smsEnabled = strtolower((string)(envValue('SMS_AUTO_SEND', '0') ?? '0')) === '1';
    $emailEnabled = strtolower((string)(envValue('EMAIL_AUTO_SEND', '0') ?? '0')) === '1';
    
    return $wpEnabled || $smsEnabled || $emailEnabled;
}

function parseFailureEmailAddresses(string $emailsRaw): array
{
    $emails = [];
    foreach (explode(',', $emailsRaw) as $email) {
        $email = trim($email);
        if ($email === '') {
            continue;
        }
        $filtered = filter_var($email, FILTER_VALIDATE_EMAIL);
        if (is_string($filtered)) {
            $emails[] = $filtered;
        }
    }
    return $emails;
}

function isWhatsAppFailureEmailEnabled(): bool
{
    $emails = parseFailureEmailAddresses((string)(envValue('WHATSAPP_FAILURE_EMAIL_TO', '') ?? ''));    
    return (strtolower((string)(envValue('WHATSAPP_FAILURE_EMAIL_ENABLED', '1') ?? '1')) === '1')
        && !empty($emails)
        && trim((string)(envValue('SMTP_FROM', 'results@slouishospital.com') ?? '')) !== '';
}

function sendWhatsAppFailureEmail(array $context): void
{
    if (!isWhatsAppFailureEmailEnabled()) {
        return;
    }

    $host = trim((string)(envValue('SMTP_HOST', 'localhost') ?? ''));
    $port = ((int)(envValue('SMTP_PORT', '25') ?? '25')) > 0 ? ((int)(envValue('SMTP_PORT', '25') ?? '25')) : 25;
    if ($host === '') {
        writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=host_empty', date('Y-m-d H:i:s')));
        return;
    }

    // Transport selection is unchanged from original logic.
    // STARTTLS (RFC 3207) is handled separately (flag-controlled).
    $useImplicitTls = strtolower((string)(envValue('SMTP_USE_TLS', '0') ?? '0')) === '1';
    $transport = $useImplicitTls ? 'tls://' . $host : $host;

    $socket = @stream_socket_client(
        $transport . ':' . $port,
        $errno,
        $errstr,
        20,
        STREAM_CLIENT_CONNECT
    );

    if (!is_resource($socket)) {
        writeWhatsappLogLine(sprintf(
            '[%s] failure_email=0 reason=socket_failed errno=%d errstr=%s',
            date('Y-m-d H:i:s'),
            $errno,
            $errstr
        ));
        return;
    }

    stream_set_timeout($socket, 20);

    $greeting = smtpReadResponse($socket);
    if (strpos($greeting, '220') !== 0) {
        @fclose($socket);
        writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=greeting_failed response=%s', date('Y-m-d H:i:s'), trim($greeting)));
        return;
    }

    // EHLO (or HELO fallback) for capabilities
    [$ok, $resp] = smtpSendCommand($socket, 'EHLO localhost', [250]);
    if (!$ok) {
        // Keep original behavior: treat EHLO failure as hard error
        @fclose($socket);
        writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=ehlo_failed response=%s', date('Y-m-d H:i:s'), trim($resp)));
        return;
    }

    // STARTTLS only makes sense when not already using implicit TLS.
    // If SMTP_USE_TLS=1, we skip STARTTLS.
    if (!$useImplicitTls) {
        $startTlsResult = smtpTryStartTls($socket);
        if (!empty($startTlsResult['success']) && !empty($startTlsResult['enabled'])) {
            // RFC requires EHLO again after successful STARTTLS.
            [$ok, $resp] = smtpSendCommand($socket, 'EHLO localhost', [250]);
            if (!$ok) {
                @fclose($socket);
                writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=ehlo_after_starttls_failed response=%s', date('Y-m-d H:i:s'), trim($resp)));
                return;
            }
        } elseif (empty($startTlsResult['success'])) {
            @fclose($socket);
            writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=starttls_failed response=%s', date('Y-m-d H:i:s'), trim((string)($startTlsResult['response'] ?? ''))));
            return;
        }
    }

    $username = trim((string)(envValue('SMTP_USERNAME', '') ?? ''));
    $password = (string)((string)(envValue('SMTP_PASSWORD', '') ?? ''));
    if ($username !== '' || $password !== '') {
        [$ok, $resp] = smtpSendCommand($socket, 'AUTH LOGIN', [334]);
        if (!$ok) {
            @fclose($socket);
            writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=auth_failed response=%s', date('Y-m-d H:i:s'), trim($resp)));
            return;
        }

        [$ok, $resp] = smtpSendCommand($socket, base64_encode($username), [334]);
        if (!$ok) {
            @fclose($socket);
            writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=username_failed response=%s', date('Y-m-d H:i:s'), trim($resp)));
            return;
        }

        [$ok, $resp] = smtpSendCommand($socket, base64_encode($password), [235]);
        if (!$ok) {
            @fclose($socket);
            writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=password_failed response=%s', date('Y-m-d H:i:s'), trim($resp)));
            return;
        }
    }

    [$ok, $resp] = smtpSendCommand($socket, 'MAIL FROM:<' . ((string)(envValue('SMTP_FROM', 'results@slouishospital.com') ?? '')) . '>', [250]);
    if (!$ok) {
        @fclose($socket);
        writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=mail_from_failed response=%s', date('Y-m-d H:i:s'), trim($resp)));
        return;
    }

    $emails = parseFailureEmailAddresses((string)(envValue('WHATSAPP_FAILURE_EMAIL_TO', '') ?? ''));
    if (empty($emails)) {
        @fclose($socket);
        writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=no_valid_recipients', date('Y-m-d H:i:s')));
        return;
    }

    foreach ($emails as $toEmail) {
        [$ok, $resp] = smtpSendCommand($socket, 'RCPT TO:<' . $toEmail . '>', [250, 251]);
        if (!$ok) {
            @fclose($socket);
            writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=rcpt_to_failed email=%s response=%s', date('Y-m-d H:i:s'), $toEmail, trim($resp)));
            return;
        }
    }

    [$ok, $resp] = smtpSendCommand($socket, 'DATA', [354]);
    if (!$ok) {
        @fclose($socket);
        writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=data_failed response=%s', date('Y-m-d H:i:s'), trim($resp)));
        return;
    }

    $subject = '[Results] Failed automatic WhatsApp send';
    $body = "Automatic WhatsApp sending failed.\n\n"
        . 'Timestamp: ' . date('Y-m-d H:i:s') . "\n"
        . 'MRN: ' . trim((string)($context['mrn'] ?? '')) . "\n"
        . 'Patient Name: ' . trim((string)($context['patient_name'] ?? '')) . "\n"
        . 'Phone: ' . trim((string)($context['phone'] ?? '')) . "\n"
        . 'Result ID: ' . trim((string)($context['result_id'] ?? '')) . "\n"
        . 'Request Code: ' . trim((string)($context['request_code'] ?? '')) . "\n"
        . 'Department: ' . trim((string)($context['department'] ?? '')) . "\n"
        . 'Reason: ' . trim((string)($context['reason'] ?? 'unknown')) . "\n"
        . 'Error Type: ' . trim((string)($context['error_type'] ?? '')) . "\n"
        . 'HTTP Code: ' . trim((string)($context['http_code'] ?? '')) . "\n"
        . 'Provider Code: ' . trim((string)($context['provider_code'] ?? '')) . "\n"
        . 'Request URL: ' . trim((string)($context['request_url'] ?? '')) . "\n"
        . 'Response: ' . trim((string)($context['response'] ?? '')) . "\n";

    $headers = [];
    $headers[] = 'From: ' . ((string)(envValue('SMTP_FROM', 'results@slouishospital.com') ?? ''));
    $headers[] = 'To: ' . implode(', ', $emails);
    $headers[] = 'Subject: =?UTF-8?B?' . base64_encode($subject) . '?=';
    $headers[] = 'Content-Type: text/plain; charset=UTF-8';

    $message = implode("\r\n", $headers) . "\r\n\r\n" . str_replace("\n", "\r\n", $body) . "\r\n";

    [$ok, $resp] = smtpSendCommand($socket, $message . "\r\n.", [250]);
    @fclose($socket);

    if (!$ok) {
        writeWhatsappLogLine(sprintf('[%s] failure_email=0 reason=send_failed response=%s', date('Y-m-d H:i:s'), trim($resp)));
        return;
    }

    writeWhatsappLogLine(sprintf('[%s] failure_email=1 to=%s from=%s', date('Y-m-d H:i:s'), implode(',', $emails), (string)(envValue('SMTP_FROM', 'results@slouishospital.com') ?? '')));
}

function isResultEmailEnabled(): bool
{
    return (strtolower((string)(envValue('RESULTS_EMAIL_ENABLED', '1') ?? '1')) === '1')
        && trim((string)(envValue('SMTP_HOST', 'localhost') ?? '')) !== ''
        && ((int)(envValue('SMTP_PORT', '25') ?? '25')) > 0
        && trim((string)(envValue('SMTP_FROM', 'results@slouishospital.com') ?? '')) !== '';
}

function normalizePatientEmail(string $email): string
{
    $email = trim($email);
    if ($email === '') {
        return '';
    }

    $filtered = filter_var($email, FILTER_VALIDATE_EMAIL);
    return is_string($filtered) ? $filtered : '';
}

function smtpReadResponse($socket): string
{
    $response = '';
    while (!feof($socket)) {
        $line = fgets($socket, 515);
        if ($line === false) {
            break;
        }

        $response .= $line;
        if (preg_match('/^\d{3}\s/', $line) === 1) {
            break;
        }
    }

    return trim($response);
}

function smtpSendCommand($socket, string $command, array $allowedCodes): array
{
    if (@fwrite($socket, $command . "\r\n") === false) {
        return [false, 'write_failed'];
    }

    $response = smtpReadResponse($socket);
    $code = (int)substr($response, 0, 3);
    return [in_array($code, $allowedCodes, true), $response];
}

function smtpGetCapabilities($socket): string
{
    // NOTE: This sends EHLO/HELO and reads the response.
    // Use it only when you intend to re-EHLO afterwards.
    [$okEhlo, $respEhlo] = smtpSendCommand($socket, 'EHLO localhost', [250]);
    if ($okEhlo) {
        return $respEhlo;
    }

    [, $respHelo] = smtpSendCommand($socket, 'HELO localhost', [250, 200]);
    return $respHelo;
}

function smtpTryStartTls($socket): array
{
    $useStartTls = strtolower((string)(envValue('SMTP_USE_STARTTLS', '0') ?? '0')) === '1';
    if (!$useStartTls) {
        return ['success' => true, 'enabled' => false, 'response' => ''];
    }

    $force = strtolower((string)(envValue('SMTP_STARTTLS_FORCE', '0') ?? '0')) === '1';

    $cap = smtpGetCapabilities($socket);
    $startTlsOffered = stripos($cap, 'STARTTLS') !== false;

    if (!$startTlsOffered && !$force) {
        return ['success' => true, 'enabled' => false, 'response' => 'STARTTLS not offered by server, continuing (force=0).'];
    }

    if (!$startTlsOffered && $force) {
        return ['success' => false, 'enabled' => true, 'response' => 'STARTTLS not offered by server.'];
    }

    [$ok, $resp] = smtpSendCommand($socket, 'STARTTLS', [220]);
    if (!$ok) {
        return ['success' => false, 'enabled' => true, 'response' => 'STARTTLS command failed: ' . $resp];
    }

    $cryptoOk = @stream_socket_enable_crypto(
        $socket,
        true,
        STREAM_CRYPTO_METHOD_TLS_CLIENT
    );

    if ($cryptoOk !== true && $cryptoOk !== 1) {
        return ['success' => false, 'enabled' => true, 'response' => 'stream_socket_enable_crypto failed.'];
    }

    return ['success' => true, 'enabled' => true, 'response' => 'STARTTLS enabled.'];
}

function emailAddressDomain(string $email): string
{
    $parts = explode('@', trim($email), 2);
    if (count($parts) !== 2) {
        return '';
    }
    return strtolower(trim($parts[1]));
}

function isInternalEmailRecipient(string $email): bool
{
    $domain = emailAddressDomain($email);
    if ($domain === '') {
        return false;
    }

    $configured = trim((string)(envValue('INTERNAL_EMAIL_DOMAINS', 'slouishospital.com') ?? 'slouishospital.com'));
    if ($configured === '') {
        $configured = 'slouishospital.com';
    }

    $allowedDomains = array_filter(array_map(
        static fn(string $item): string => strtolower(trim($item)),
        explode(',', $configured)
    ));

    return in_array($domain, $allowedDomains, true);
}

function shouldUseSmtpAuthForRecipient(string $email): bool
{
    $allowInternalNoAuth = strtolower((string)(envValue('SMTP_ALLOW_INTERNAL_NO_AUTH', '0') ?? '0')) === '1';
    if ($allowInternalNoAuth && isInternalEmailRecipient($email)) {
        return false;
    }

    return true;
}

function smtpAuthTypeCandidates(): array
{
    $configured = trim((string)(envValue('SMTP_AUTH_TYPES', 'LOGIN,NTLM') ?? 'LOGIN,NTLM'));
    $items = array_filter(array_map(
        static fn(string $item): string => strtoupper(trim($item)),
        explode(',', $configured)
    ));

    if ($items === []) {
        $items = ['LOGIN', 'NTLM'];
    }

    $allowed = ['LOGIN', 'NTLM', 'PLAIN', 'CRAM-MD5'];
    $result = [];
    foreach ($items as $item) {
        if (in_array($item, $allowed, true) && !in_array($item, $result, true)) {
            $result[] = $item;
        }
    }

    return $result === [] ? ['LOGIN', 'NTLM'] : $result;
}

function isVerboseEmailLogEnabled(): bool
{
    return strtolower((string)(envValue('EMAIL_LOG_VERBOSE', '0') ?? '0')) === '1';
}

function smtpAuthUsernameCandidates(): array
{
    $configured = trim((string)(envValue('SMTP_USERNAME', '') ?? ''));
    $candidates = [];

    if ($configured !== '') {
        $candidates[] = $configured;

        if (strpos($configured, '\\') !== false) {
            $parts = explode('\\', $configured, 2);
            if (isset($parts[1]) && trim($parts[1]) !== '') {
                $candidates[] = trim($parts[1]);
            }
        }

        if (strpos($configured, '/') !== false) {
            $parts = explode('/', $configured, 2);
            if (isset($parts[1]) && trim($parts[1]) !== '') {
                $candidates[] = trim($parts[1]);
            }
        }

        if (strpos($configured, '@') !== false) {
            $parts = explode('@', $configured, 2);
            if (isset($parts[0]) && trim($parts[0]) !== '') {
                $candidates[] = trim($parts[0]);
            }
        }
    }

    $smtpFrom = trim((string)(envValue('SMTP_FROM', '') ?? ''));
    $fromDomain = emailAddressDomain($smtpFrom);
    foreach ($candidates as $candidate) {
        if (
            $fromDomain !== ''
            && strpos($candidate, '@') === false
            && strpos($candidate, '\\') === false
            && strpos($candidate, '/') === false
        ) {
            $candidates[] = $candidate . '@' . $fromDomain;
        }
    }

    $alt = trim((string)(envValue('SMTP_USERNAME_ALT', '') ?? ''));
    if ($alt !== '') {
        foreach (explode(',', $alt) as $candidate) {
            $candidate = trim($candidate);
            if ($candidate !== '') {
                $candidates[] = $candidate;
            }
        }
    }

    $unique = [];
    foreach ($candidates as $candidate) {
        if ($candidate !== '' && !in_array($candidate, $unique, true)) {
            $unique[] = $candidate;
        }
    }

    return $unique;
}

function sendResultEmailSmtp(
    string $toEmail,
    string $subject,
    string $textBody,
    array $attachments = [],
    ?bool $forceAuth = null
): array {
    if (!isResultEmailEnabled()) {
        return ['success' => false, 'error' => 'Result email is not configured.'];
    }

    $toEmail = normalizePatientEmail($toEmail);
    if ($toEmail === '') {
        return ['success' => false, 'error' => 'Invalid patient email address.'];
    }

    $host = trim((string)(envValue('SMTP_HOST', 'localhost') ?? ''));
    $port = ((int)(envValue('SMTP_PORT', '25') ?? '25'));

    $useImplicitTls = strtolower((string)(envValue('SMTP_USE_TLS', '0') ?? '0')) === '1';
    $transport = $useImplicitTls ? 'tls://' . $host : $host;

    $socket = @stream_socket_client(
        $transport . ':' . $port,
        $errno,
        $errstr,
        20,
        STREAM_CLIENT_CONNECT
    );

    if (!is_resource($socket)) {
        writeEmailLogLine(sprintf(
            '[%s] ERROR: SMTP connect failed: host=%s port=%d errno=%d errstr=%s',
            date('Y-m-d H:i:s'),
            $host,
            $port,
            $errno,
            $errstr
        ));
        return ['success' => false, 'error' => 'SMTP connect failed: ' . trim($errstr) . ' (' . (int)$errno . ')'];
    }

    stream_set_timeout($socket, 20);

    $greeting = smtpReadResponse($socket);
    if (strpos($greeting, '220') !== 0) {
        @fclose($socket);
        writeEmailLogLine(sprintf(
            '[%s] ERROR: SMTP greeting failed: response=%s',
            date('Y-m-d H:i:s'),
            trim($greeting)
        ));
        return ['success' => false, 'error' => 'SMTP greeting failed: ' . $greeting];
    }

    [$ok, $resp] = smtpSendCommand($socket, 'EHLO localhost', [250]);
    if (!$ok) {
        @fclose($socket);
        return ['success' => false, 'error' => 'SMTP EHLO failed: ' . $resp];
    }

    // If using implicit TLS already, do not attempt STARTTLS.
    if (!$useImplicitTls) {
        $startTlsResult = smtpTryStartTls($socket);
        if (!empty($startTlsResult['success']) && !empty($startTlsResult['enabled'])) {
            // EHLO again after STARTTLS
            [$ok, $resp] = smtpSendCommand($socket, 'EHLO localhost', [250]);
            if (!$ok) {
                @fclose($socket);
                return ['success' => false, 'error' => 'SMTP EHLO after STARTTLS failed: ' . $resp];
            }
        } elseif (empty($startTlsResult['success'])) {
            @fclose($socket);
            return ['success' => false, 'error' => 'STARTTLS failed: ' . (string)($startTlsResult['response'] ?? '')];
        }
    }

    $useAuth = $forceAuth ?? shouldUseSmtpAuthForRecipient($toEmail);
    $username = trim((string)(envValue('SMTP_USERNAME', '') ?? ''));
    $password = (string)((string)(envValue('SMTP_PASSWORD', '') ?? ''));

    if ($useAuth && ($username === '' || $password === '')) {
        @fclose($socket);
        return ['success' => false, 'error' => 'SMTP credentials are required for authenticated send.'];
    }

    if ($useAuth) {
        [$ok, $resp] = smtpSendCommand($socket, 'AUTH LOGIN', [334]);
        if (!$ok) {
            @fclose($socket);
            return ['success' => false, 'error' => 'SMTP AUTH failed: ' . $resp];
        }

        [$ok, $resp] = smtpSendCommand($socket, base64_encode($username), [334]);
        if (!$ok) {
            @fclose($socket);
            return ['success' => false, 'error' => 'SMTP username failed: ' . $resp];
        }

        [$ok, $resp] = smtpSendCommand($socket, base64_encode($password), [235]);
        if (!$ok) {
            @fclose($socket);
            return ['success' => false, 'error' => 'SMTP password failed: ' . $resp];
        }
    }

    [$ok, $resp] = smtpSendCommand($socket, 'MAIL FROM:<' . ((string)(envValue('SMTP_FROM', 'results@slouishospital.com') ?? '')) . '>', [250]);
    if (!$ok) {
        @fclose($socket);
        return ['success' => false, 'error' => 'SMTP MAIL FROM failed: ' . $resp];
    }

    [$ok, $resp] = smtpSendCommand($socket, 'RCPT TO:<' . $toEmail . '>', [250, 251]);
    if (!$ok) {
        @fclose($socket);
        return ['success' => false, 'error' => 'SMTP RCPT TO failed: ' . $resp];
    }

    [$ok, $resp] = smtpSendCommand($socket, 'DATA', [354]);
    if (!$ok) {
        @fclose($socket);
        return ['success' => false, 'error' => 'SMTP DATA failed: ' . $resp];
    }

    $boundaryMixed = 'mix_' . md5(uniqid('results', true));
    $boundaryAlt = 'alt_' . md5(uniqid('results_alt', true));

    $headers = [];
    $headers[] = 'From: ' . ((string)(envValue('SMTP_FROM', 'results@slouishospital.com') ?? ''));
    $headers[] = 'To: ' . $toEmail;
    $headers[] = 'Subject: =?UTF-8?B?' . base64_encode($subject) . '?=';
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-Type: multipart/mixed; boundary="' . $boundaryMixed . '"';

    $message = implode("\r\n", $headers) . "\r\n\r\n";
    $message .= '--' . $boundaryMixed . "\r\n";
    $message .= 'Content-Type: multipart/alternative; boundary="' . $boundaryAlt . '"' . "\r\n\r\n";

    $plain = trim($textBody) !== '' ? trim($textBody) : 'Please see your result details.';
    $plain = str_replace("\n", "\r\n", $plain);

    $message .= '--' . $boundaryAlt . "\r\n";
    $message .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
    $message .= $plain . "\r\n\r\n";
    $message .= '--' . $boundaryAlt . "--\r\n";

    foreach ($attachments as $attachment) {
        if (!is_array($attachment)) {
            continue;
        }

        $fileName = trim((string)($attachment['filename'] ?? 'attachment.bin'));
        if ($fileName === '') {
            $fileName = 'attachment.bin';
        }

        $content = (string)($attachment['content'] ?? '');
        if ($content === '') {
            continue;
        }

        $mimeType = trim((string)($attachment['mime_type'] ?? 'application/octet-stream'));
        if ($mimeType === '') {
            $mimeType = 'application/octet-stream';
        }

        $message .= '--' . $boundaryMixed . "\r\n";
        $message .= 'Content-Type: ' . $mimeType . '; name="' . addslashes($fileName) . '"' . "\r\n";
        $message .= 'Content-Transfer-Encoding: base64' . "\r\n";
        $message .= 'Content-Disposition: attachment; filename="' . addslashes($fileName) . '"' . "\r\n\r\n";
        $message .= chunk_split(base64_encode($content), 76, "\r\n");
        $message .= "\r\n";
    }

    $message .= '--' . $boundaryMixed . "--\r\n";
    $message = str_replace("\n.", "\n..", $message);
    $message .= "\r\n.\r\n";

    if (@fwrite($socket, $message) === false) {
        @fclose($socket);
        writeEmailLogLine(sprintf(
            '[%s] ERROR: SMTP message write failed: recipient=%s',
            date('Y-m-d H:i:s'),
            $toEmail
        ));
        return ['success' => false, 'error' => 'SMTP message write failed.'];
    }

    $response = smtpReadResponse($socket);
    $code = (int)substr($response, 0, 3);
    if ($code !== 250) {
        @fclose($socket);
        writeEmailLogLine(sprintf(
            '[%s] ERROR: SMTP send failed: recipient=%s response=%s',
            date('Y-m-d H:i:s'),
            $toEmail,
            trim($response)
        ));
        return ['success' => false, 'error' => 'SMTP send failed: ' . $response];
    }

    smtpSendCommand($socket, 'QUIT', [221, 250]);
    @fclose($socket);

    writeEmailLogLine(sprintf(
        '[%s] SUCCESS: Email delivered: recipient=%s subject=%s',
        date('Y-m-d H:i:s'),
        $toEmail,
        $subject
    ));

    return ['success' => true, 'error' => ''];
}

/**
 * Send email using PHPMailer (better STARTTLS and auth handling)
 * Handles NTLM, LOGIN, and PLAIN authentication methods
 * This is an alternative to sendResultEmailSmtp() when raw socket fails
 */
function sendResultEmailViaPhpMailer(
    string $toEmail,
    string $subject,
    string $textBody,
    array $attachments = [],
    ?bool $forceAuth = null
): array {
    // Check if PHPMailer is available
    if (!class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
        return ['success' => false, 'error' => 'PHPMailer not installed'];
    }

    $useAuth = $forceAuth ?? shouldUseSmtpAuthForRecipient($toEmail);
    $host = trim((string)(envValue('SMTP_HOST', 'localhost') ?? ''));
    $port = (int)(envValue('SMTP_PORT', '25') ?? '25');
    $password = (string)(envValue('SMTP_PASSWORD', '') ?? '');
    $from = trim((string)(envValue('SMTP_FROM', 'results@slouishospital.com') ?? ''));
    $useImplicitTls = strtolower((string)(envValue('SMTP_USE_TLS', '0') ?? '0')) === '1';
    $useStartTls = strtolower((string)(envValue('SMTP_USE_STARTTLS', '1') ?? '1')) === '1';
    $verifyCerts = strtolower((string)(envValue('VERIFY_SSL_CERTS', '0') ?? '0')) === '1';

    $attempts = [];
    if ($useAuth) {
        $usernames = smtpAuthUsernameCandidates();
        $authTypes = smtpAuthTypeCandidates();
        foreach ($authTypes as $authType) {
            foreach ($usernames as $username) {
                $attempts[] = [
                    'auth' => true,
                    'authType' => $authType,
                    'username' => $username,
                ];
            }
        }

        if ($attempts === []) {
            return ['success' => false, 'error' => 'No SMTP username candidates available for authenticated send.'];
        }
    } else {
        $attempts[] = [
            'auth' => false,
            'authType' => '',
            'username' => '',
        ];
    }

    $lastError = 'Unknown SMTP error.';
    foreach ($attempts as $idx => $attempt) {
        try {
            if (isVerboseEmailLogEnabled()) {
                writeEmailLogLine(sprintf(
                    '[%s] PHPMailer attempt %d: recipient=%s auth=%s auth_type=%s username=%s',
                    date('Y-m-d H:i:s'),
                    $idx + 1,
                    $toEmail,
                    $attempt['auth'] ? '1' : '0',
                    $attempt['authType'] !== '' ? $attempt['authType'] : 'none',
                    $attempt['username'] !== '' ? $attempt['username'] : 'none'
                ));
            }

            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = $host;
            $mail->Port = $port;
            $mail->SMTPAuth = (bool)$attempt['auth'];
            $mail->Username = (string)$attempt['username'];
            $mail->Password = $password;
            if ($attempt['authType'] !== '') {
                $mail->AuthType = $attempt['authType'];
            }

            $mail->From = $from;
            $mail->FromName = 'Saint Louis Hospital Results';

            if ($useImplicitTls) {
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($useStartTls && (bool)$attempt['auth']) {
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            } else {
                $mail->SMTPSecure = '';
            }

            if (!$verifyCerts) {
                $mail->SMTPOptions = [
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true,
                    ],
                ];
            }

            $mail->addAddress($toEmail);
            $mail->Subject = $subject;
            $mail->Body = $textBody;
            $mail->isHTML(false);
            $mail->CharSet = 'UTF-8';

            foreach ($attachments as $attachment) {
                if (is_array($attachment) && !empty($attachment['content']) && !empty($attachment['filename'])) {
                    $mail->addStringAttachment(
                        $attachment['content'],
                        $attachment['filename'],
                        'base64',
                        $attachment['mime_type'] ?? 'application/octet-stream'
                    );
                }
            }

            $mail->send();

            writeEmailLogLine(sprintf(
                '[%s] SUCCESS: PHPMailer email delivered: recipient=%s subject=%s',
                date('Y-m-d H:i:s'),
                $toEmail,
                $subject
            ));

            return ['success' => true, 'error' => ''];
        } catch (\Throwable $e) {
            $lastError = $e->getMessage();
            if (isVerboseEmailLogEnabled()) {
                writeEmailLogLine(sprintf(
                    '[%s] ERROR: PHPMailer attempt %d failed: recipient=%s auth_type=%s username=%s error=%s',
                    date('Y-m-d H:i:s'),
                    $idx + 1,
                    $toEmail,
                    $attempt['authType'] !== '' ? $attempt['authType'] : 'none',
                    $attempt['username'] !== '' ? $attempt['username'] : 'none',
                    $lastError
                ));
            }
        }
    }

    writeEmailLogLine(sprintf(
        '[%s] ERROR: PHPMailer failed: recipient=%s error=%s',
        date('Y-m-d H:i:s'),
        $toEmail,
        $lastError
    ));

    return ['success' => false, 'error' => $lastError];
}

function buildResultEmailSubject(
    string $patientName,
    string $mrn,
    string $department
): string {
    $name = trim($patientName) !== '' ? trim($patientName) : 'Patient';
    $subjectTemplate = getTemplate('email', 'subject');
    if ($subjectTemplate === '') {
        return 'Your Results Are Available - ' . $name;
    }
    return str_replace('{{1}}', $name, $subjectTemplate);
}

function buildResultEmailBody(
    string $patientName,
    string $mrn,
    string $department,
    string $requestCode,
    string $link
): string {
    $name = trim($patientName) !== '' ? trim($patientName) : 'Patient';
    $externalLink = rewriteUrlWithExternalHostname($link);
    $deptLower = strtolower($department);

    if ($deptLower === 'laboratory') {
        $templateType = 'lab_results';
    } elseif ($deptLower === 'radiology' || $deptLower === 'imaging') {
        $templateType = 'mi_results';
    } else {
        $templateType = 'result';
    }

    $template = getTemplate('email', $templateType);
    if ($template === '') {
        $template = "Dear {{1}},\n\nYour results are now available. Click here to view: {{2}}\n\nRegards,\nSaint Louis Hospital";
    }

    return str_replace(
        ['{{1}}', '{{2}}'],
        [$name, $externalLink],
        $template
    );
}

function sendResultEmailWithLink(
    string $toEmail,
    string $patientName,
    string $mrn,
    string $department,
    string $requestCode,
    string $link
): array {
    $subject = buildResultEmailSubject($patientName, $mrn, $department);
    $body = buildResultEmailBody($patientName, $mrn, $department, $requestCode, $link);

    return sendResultEmailSmtp($toEmail, $subject, $body);
}

function sendResultEmailWithPdf(
    string $toEmail,
    string $patientName,
    string $mrn,
    string $pdfBinary,
    string $fileName,
    string $department = ''
): array {
    $subject = buildResultEmailSubject($patientName, $mrn, $department);
    $body = str_replace('{{1}}', $patientName !== '' ? $patientName : 'Patient', getTemplate('email', 'result'));

    return sendResultEmailSmtp($toEmail, $subject, $body, [[
        'filename' => $fileName,
        'mime_type' => 'application/pdf',
        'content' => $pdfBinary,
    ]]);
}

function sanitizeLocalReturnUrl(string $url, string $fallback = 'index.php'): string
{
    $url = trim($url);
    if ($url === '') {
        return $fallback;
    }

    $parts = @parse_url($url);
    if (!is_array($parts)) {
        return $fallback;
    }

    if (!empty($parts['scheme']) || !empty($parts['host'])) {
        return $fallback;
    }

    $path = (string)($parts['path'] ?? '');
    if ($path === '' || strpos($path, '..') !== false || preg_match('/^[A-Za-z]:/', $path) === 1) {
        return $fallback;
    }

    return ltrim($url, '/');
}

// --- Logging and helper functions ---

if (!defined('ACTIVITY_LOG_FILE')) {
    define('ACTIVITY_LOG_FILE', __DIR__ . '/logs/activity.log');
}
if (!defined('SMS_LOG_FILE')) {
    define('SMS_LOG_FILE', __DIR__ . '/logs/sms.log');
}

if (!defined('WP_LOG_FILE')) {
    define('WP_LOG_FILE', __DIR__ . '/logs/wp.log');
}

if (!defined('EMAIL_LOG_FILE')) {
    define('EMAIL_LOG_FILE', __DIR__ . '/logs/email.log');
}

if (!defined('API_CALLS_LOG_FILE')) {
    define('API_CALLS_LOG_FILE', __DIR__ . '/logs/api_calls.log');
}

// --- Log rotation function ---

const LOG_MAX_SIZE = 52428800; // 50MB in bytes

/**
 * Rotate log file if it exceeds 50MB
 * Renames existing log to filename.YYYY-MM-DD_HH-MM-SS.log
 * @param string $logFile Full path to the log file
 */
function rotateLogIfNeeded(string $logFile): void
{
    if (!file_exists($logFile)) {
        return;
    }

    $fileSize = @filesize($logFile);
    if ($fileSize === false || $fileSize < LOG_MAX_SIZE) {
        return;
    }

    // File exceeds 50MB, rotate it
    $timestamp = date('Y-m-d_H-i-s');
    $pathInfo = pathinfo($logFile);
    $rotatedFile = $pathInfo['dirname'] . '/' . $pathInfo['filename'] . '.' . $timestamp . '.log';

    // Attempt to rename the old log file
    if (@rename($logFile, $rotatedFile)) {
        // Successfully rotated, new log file will be created on next write
        error_log("Log rotated: $logFile -> $rotatedFile");
    }
}

// --- Logging functions ---

function writeActivityLogLine(string $message): void
{
    $dir = dirname(ACTIVITY_LOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    rotateLogIfNeeded(ACTIVITY_LOG_FILE);
    @file_put_contents(ACTIVITY_LOG_FILE, $message . "\n", FILE_APPEND | LOCK_EX);
}

function writeSmsLogLine(string $message): void
{
    $dir = dirname(SMS_LOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    rotateLogIfNeeded(SMS_LOG_FILE);
    @file_put_contents(SMS_LOG_FILE, $message . "\n", FILE_APPEND | LOCK_EX);
}

function writeWhatsappLogLine(string $message): void
{
    $dir = dirname(WP_LOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    rotateLogIfNeeded(WP_LOG_FILE);
    @file_put_contents(WP_LOG_FILE, $message . "\n", FILE_APPEND | LOCK_EX);
}

function writeEmailLogLine(string $message): void
{
    $dir = dirname(EMAIL_LOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    rotateLogIfNeeded(EMAIL_LOG_FILE);
    @file_put_contents(EMAIL_LOG_FILE, $message . "\n", FILE_APPEND | LOCK_EX);
}

function writeApiCallLog(string $message): void
{
    $dir = dirname(API_CALLS_LOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }
    rotateLogIfNeeded(API_CALLS_LOG_FILE);
    @file_put_contents(API_CALLS_LOG_FILE, $message . "\n", FILE_APPEND | LOCK_EX);
}

/**
 * Log a send action with structured data.
 * Format: timestamp|username|action|mrn|channel|target_phone|target_email|details
 */
function logSendActivity(
    string $username,
    string $action,
    string $mrn,
    string $channel,
    ?string $targetPhone = null,
    ?string $targetEmail = null,
    ?string $details = null
): void {
    $logEntry = implode('|', [
        date('Y-m-d H:i:s'),
        $username,
        $action,
        $mrn,
        $channel,
        $targetPhone ?? '',
        $targetEmail ?? '',
        $details ?? '',
    ]);
    writeActivityLogLine($logEntry);
}

// --- Auto-send functions ---

/**
 * Build WhatsApp message from template
 */
function buildWhatsAppMessage(string $name, string $mrn, string $department, string $requestCode, string $link): string
{
    $deptLower = strtolower($department);

    if ($deptLower === 'laboratory') {
        $templateType = 'lab_results';
    } elseif ($deptLower === 'radiology' || $deptLower === 'imaging') {
        $templateType = 'mi_results';
    } else {
        $templateType = 'result';
    }

    $template = getTemplate('whatsapp', $templateType);
    if ($template === '') {
        $template = "Hello {{1}}, your results are ready. Access via: {{2}}";
    }

    return str_replace(
        ['{{1}}', '{{2}}'],
        [$name, $link],
        $template
    );
}

/**
 * Build WhatsApp template variables for API (comma-separated for {{1}}, {{2}}, etc.)
 * Returns array with 'template' type and 'variables' string
 */
function buildWhatsAppTemplateVars(string $name, string $link = '', string $department = ''): array
{
    $deptLower = strtolower($department);
    
    if ($deptLower === 'laboratory') {
        // lab_results: {{1}}=name, {{2}}=link
        return [
            'template' => 'lab_results',
            'variables' => $name . ',' . $link,
        ];
    } elseif ($deptLower === 'radiology' || $deptLower === 'imaging') {
        // mi_results: {{1}}=name, {{2}}=link
        return [
            'template' => 'mi_results',
            'variables' => $name . ',' . $link,
        ];
    } elseif ($deptLower === 'collection') {
        // result_collection: {{1}}=name
        return [
            'template' => 'result_collection',
            'variables' => $name,
        ];
    } else {
        // result: {{1}}=name
        return [
            'template' => 'result',
            'variables' => $name,
        ];
    }
}

/**
 * Build SMS message from template using {{1}}, {{2}} format
 * {{1}} = patient name, {{2}} = result link
 */
function buildSmsMessage(string $name, string $department, string $link): string
{
    $deptLower = strtolower($department);
    
    if ($deptLower === 'laboratory') {
        $templateType = 'lab_results';
    } elseif ($deptLower === 'radiology' || $deptLower === 'imaging') {
        $templateType = 'mi_results';
    } else {
        $templateType = 'result';
    }

    $template = getTemplate('sms', $templateType);
    if ($template === '') {
        $template = "Dear {{1}},\nThank you for choosing SLH.\nYou have a new result available. You may access your report via the following link: \n\n{{2}}\n\nYour results are also posted on your website profile.";
    }

    return str_replace(
        ['{{1}}', '{{2}}'],
        [$name, $link],
        $template
    );
}

/**
 * Build email subject from template
 */
function buildEmailSubject(string $name, string $department): string
{
    $subjectTemplate = getTemplate('email', 'subject');
    if ($subjectTemplate === '') {
        return 'Your Results Are Available - ' . $name;
    }
    return str_replace('{{1}}', $name, $subjectTemplate);
}

/**
 * Build email body from template using {{1}}, {{2}} format
 * {{1}} = patient name, {{2}} = result link
 */
function buildEmailBody(string $name, string $department, string $link): string
{
    $deptLower = strtolower($department);
    
    if ($deptLower === 'laboratory') {
        $templateType = 'lab_results';
    } elseif ($deptLower === 'radiology' || $deptLower === 'imaging') {
        $templateType = 'mi_results';
    } else {
        $templateType = 'result';
    }

    $template = getTemplate('email', $templateType);
    if ($template === '') {
        $template = "Dear {{1}},\n\nThank you for choosing SLH.\nYou have a new result available. You may access your report via the following link: \n\n{{2}}\n\nYour results are also posted on your website profile.";
    }

    return str_replace(
        ['{{1}}', '{{2}}'],
        [$name, $link],
        $template
    );
}

/**
 * Get gender-based titles
 * @param string $gender Gender value: 'M', 'F', or 'U' (unknown)
 * @return array [$englishTitle, $arabicTitle]
 */
function getGenderBasedTitles(string $gender): array
{
    $gender = strtoupper(trim($gender));
    if ($gender === 'F') {
        return ['Mrs.', 'السيدة'];
    } elseif ($gender === 'M') {
        return ['Mr.', 'السيد'];
    } else {
        return ['Mr./Mrs.', 'السيد/السيدة'];
    }
}

/**
 * Build collection notice WhatsApp message from template
 */
function buildCollectionNoticeWhatsAppMessage(string $name, string $gender = 'U'): string
{
    $template = getTemplate('collection_notice', 'whatsapp');
    if ($template === '') {
        $template = "Dear {{1}},\n\nYour results are now ready for collection at our office.\nCollection Hours:\n• Monday – Friday: 08:00 – 16:30\n• Saturday: 08:00 – 13:00\n\nPlease bring your ID. Thank you!";
    }
    
    [$enTitle, $arTitle] = getGenderBasedTitles($gender);
    
    return str_replace(
        ['{{1}}', '{{2}}', '{{3}}', '{{4}}'],
        [$enTitle, $name, $name, $arTitle],
        $template
    );
}

/**
 * Build collection notice SMS message from template
 */
function buildCollectionNoticeSmsMessage(string $name, string $gender = 'U'): string
{
    $template = getTemplate('collection_notice', 'sms');
    if ($template === '') {
        $template = "Dear {{1}}, your results are ready for collection. Hours: Mon-Fri 08:00-16:30, Sat 08:00-13:00. Please bring your ID.";
    }
    
    [$enTitle, $arTitle] = getGenderBasedTitles($gender);
    
    return str_replace(
        ['{{1}}', '{{2}}', '{{3}}', '{{4}}'],
        [$enTitle, $name, $name, $arTitle],
        $template
    );
}

/**
 * Build collection notice email subject from template
 */
function buildCollectionNoticeEmailSubject(string $name, string $gender = 'U'): string
{
    $template = getTemplate('collection_notice', 'email_subject');
    if ($template === '') {
        $template = "Your Results Are Ready for Collection";
    }
    
    [$enTitle, $arTitle] = getGenderBasedTitles($gender);
    
    return str_replace(
        ['{{1}}', '{{2}}', '{{3}}', '{{4}}'],
        [$enTitle, $name, $name, $arTitle],
        $template
    );
}

/**
 * Build collection notice email body from template
 */
function buildCollectionNoticeEmailBody(string $name, string $gender = 'U'): string
{
    $template = getTemplate('collection_notice', 'email');
    if ($template === '') {
        $template = "Dear {{1}},\n\nYour results are now ready for collection.\n\nCollection Hours:\n• Monday – Friday: 08:00 – 16:30\n• Saturday: 08:00 – 13:00\n\nImportant Notes:\n• Please bring your ID.\n• If someone else will collect the results on your behalf, kindly provide us with their full name and ensure they bring their ID.\n\nOur team remains available to support you!";
    }
    
    [$enTitle, $arTitle] = getGenderBasedTitles($gender);
    
    return str_replace(
        ['{{1}}', '{{2}}', '{{3}}', '{{4}}'],
        [$enTitle, $name, $name, $arTitle],
        $template
    );
}

/**
 * Get the current username from portal session.
 */
function getCurrentUsername(): ?string
{
    $user = portalCurrentUser();
    if (!is_array($user) || empty($user['username'])) {
        return null;
    }
    return trim((string)$user['username']);
}

/**
 * Check if a channel send should be retried based on contact info and retry window.
 * Contact must exist and either never attempted or last attempt > 24 hours ago.
 */
function shouldRetryChannelSend(?string $contact, ?string $lastAttemptAt, ?string $resultAvailableSince = null): bool
{
    // Skip if no contact info
    if ($contact === null || trim($contact) === '') {
        return false;
    }

    // Check if result has exceeded retry window (RETRY_FAILED_SENDS days)
    if ($resultAvailableSince !== null) {
        try {
            $retryDays = (int)(envValue('RETRY_FAILED_SENDS', '14') ?? '14');
            if ($retryDays > 0) {
                $resultDate = new DateTime($resultAvailableSince, new DateTimeZone('UTC'));
                $now = new DateTime('now', new DateTimeZone('UTC'));
                $interval = $resultDate->diff($now);
                
                // Convert days to total days
                $totalDays = $interval->days + ($interval->h >= 12 ? 1 : 0); // Round up if 12+ hours
                
                if ($totalDays > $retryDays) {
                    // Result has exceeded retry window, stop retrying
                    return false;
                }
            }
        } catch (Exception $e) {
            // If date parsing fails, continue with retry window check
        }
    }

    // If never attempted, should retry
    if ($lastAttemptAt === null) {
        return true;
    }

    // Check if last attempt was > 24 hours ago
    try {
        $lastAttempt = new DateTime($lastAttemptAt, new DateTimeZone('UTC'));
        $now = new DateTime('now', new DateTimeZone('UTC'));
        $interval = $lastAttempt->diff($now);
        
        // Convert days and hours to total hours
        $totalHours = ($interval->days * 24) + $interval->h;
        return $totalHours >= 24;
    } catch (Exception $e) {
        // If date parsing fails, don't retry
        return false;
    }
}

/**
 * Process all pending results for auto-send with retry logic.
 * Only retries on channels with valid contact info and respects 24-hour windows.
 * Stops retrying after RETRY_FAILED_SENDS days from when result link was added.
 */
function sendPendingJsonResults(string $notBefore): array
{
    // Fetch pending results that haven't been sent or have been updated since last send
    $pendingResults = [];
    $getPendingError = null;
    
    try {
        $pendingResults = getPendingAutoSendResults();
    } catch (Throwable $exception) {
        $getPendingError = $exception;
        error_log("sendPendingJsonResults: EXCEPTION in getPendingAutoSendResults: " . $exception->getMessage());
        error_log("Trace: " . $exception->getTraceAsString());
    }
    
    $stats = [
        'candidates' => count($pendingResults),
        'sent' => 0,
        'failed' => 0,
        'skipped' => 0,
        'email_sent' => 0,
        'email_failed' => 0,
        'email_skipped' => 0,
    ];

    // If getPendingAutoSendResults failed, log it and re-throw
    if ($getPendingError !== null) {
        throw $getPendingError;
    }

    if (empty($pendingResults)) {
        return $stats;
    }

    try {
        foreach ($pendingResults as $result) {
            $resultId = (int)$result['result_id'];
            $mrn = trim((string)$result['mrn']);
            $department = trim((string)$result['department']);
            $patientName = trim((string)$result['patient_name']);
            $phone = trim((string)$result['care_mobile']);
            $email = trim((string)$result['email']);
            $resultLink = trim((string)$result['pdf_result_link']);
            $requestCode = trim((string)$result['request_code']);

            if ($resultId <= 0 || $mrn === '') {
                $stats['skipped']++;
                continue;
            }

            // Extract attempt timestamps from query result
            $resultLinkAddedAt = $result['result_link_added_at'] ?? null;
            $wpLastAttempt = $result['wp_last_attempt_at'] ?? null;
            $smsLastAttempt = $result['sms_last_attempt_at'] ?? null;
            $emailLastAttempt = $result['email_last_attempt_at'] ?? null;

            // Try WhatsApp if enabled and contact exists
            if ($phone !== '' && strtolower((string)(envValue('WHATSAPP_AUTO_SEND', '0') ?? '0')) === '1') {
                if (shouldRetryChannelSend($phone, $wpLastAttempt, $resultLinkAddedAt)) {
                    $externalLink = rewriteUrlWithExternalHostname($resultLink);
                    $templateVars = buildWhatsAppTemplateVars($patientName, $externalLink, $department);
                    $sendResult = sendViaWhatsApp($phone, '', $templateVars['template'], null, $templateVars['variables']);
                    
                    // Update attempt timestamp regardless of success/failure
                    $nowTime = date('Y-m-d H:i:s');
                    saveSentRecord($resultId, 'result', 'link', $resultLink, 'auto_send', [
                        'provider_ack' => $sendResult['provider_ack'],
                        'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                        'wp_sent' => !empty($sendResult['success']) ? 1 : 0,
                        'wp_last_attempt_at' => $nowTime,
                        'provider_recipient' => $phone,
                        'provider_response' => $sendResult['provider_response'] ?? '',
                    ]);
                    
                    if (!empty($sendResult['success'])) {
                        $stats['sent']++;
                        logSendActivity(
                            'auto_send',
                            'auto_send_whatsapp',
                            $mrn,
                            'whatsapp',
                            $phone,
                            null,
                            'request_code=' . $requestCode . ' status=success'
                        );
                    } else {
                        $stats['failed']++;
                        $errorMsg = $sendResult['error_message'] ?? 'Unknown error';
                        logSendActivity(
                            'auto_send',
                            'auto_send_whatsapp',
                            $mrn,
                            'whatsapp',
                            $phone,
                            null,
                            'request_code=' . $requestCode . ' status=failed error=' . h($errorMsg)
                        );
                    }
                }
            }

            // Try SMS if enabled and contact exists
            if ($phone !== '' && strtolower((string)(envValue('SMS_AUTO_SEND', '0') ?? '0')) === '1') {
                if (shouldRetryChannelSend($phone, $smsLastAttempt, $resultLinkAddedAt)) {
                    $externalLink = rewriteUrlWithExternalHostname($resultLink);
                    $message = buildSmsMessage($patientName, $department, $externalLink);
                    $sendResult = sendViaSMS($phone, $message);
                    
                    // Update attempt timestamp regardless of success/failure
                    $nowTime = date('Y-m-d H:i:s');
                    saveSentRecord($resultId, 'result', 'link', $resultLink, 'auto_send', [
                        'provider_ack' => $sendResult['provider_ack'],
                        'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                        'sms_sent' => !empty($sendResult['success']) ? 1 : 0,
                        'sms_last_attempt_at' => $nowTime,
                        'provider_recipient' => $phone,
                    ]);
                    
                    if (!empty($sendResult['success'])) {
                        $stats['sent']++;
                        logSendActivity(
                            'auto_send',
                            'auto_send_sms',
                            $mrn,
                            'sms',
                            $phone,
                            null,
                            'request_code=' . $requestCode . ' status=success'
                        );
                    } else {
                        $stats['failed']++;
                        $errorMsg = $sendResult['error_message'] ?? 'Unknown error';
                        logSendActivity(
                            'auto_send',
                            'auto_send_sms',
                            $mrn,
                            'sms',
                            $phone,
                            null,
                            'request_code=' . $requestCode . ' status=failed error=' . h($errorMsg)
                        );
                    }
                }
            }

            // Try Email if enabled and contact exists
            if ($email !== '' && strtolower((string)(envValue('EMAIL_AUTO_SEND', '0') ?? '0')) === '1') {
                if (shouldRetryChannelSend($email, $emailLastAttempt, $resultLinkAddedAt)) {
                    $externalLink = rewriteUrlWithExternalHostname($resultLink);
                    $subject = buildEmailSubject($patientName, $department);
                    $body = buildEmailBody($patientName, $department, $externalLink);
                    $sendResult = sendViaEmail($email, $subject, $body);
                    
                    // Update attempt timestamp regardless of success/failure
                    $nowTime = date('Y-m-d H:i:s');
                    saveSentRecord($resultId, 'result', 'link', $resultLink, 'auto_send', [
                        'provider_ack' => $sendResult['provider_ack'],
                        'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                        'email_sent' => !empty($sendResult['success']) ? 1 : 0,
                        'email_last_attempt_at' => $nowTime,
                        'provider_recipient' => $email,
                    ]);
                    
                    if (!empty($sendResult['success'])) {
                        $stats['email_sent']++;
                        logSendActivity(
                            'auto_send',
                            'auto_send_email',
                            $mrn,
                            'email',
                            null,
                            $email,
                            'request_code=' . $requestCode . ' status=success'
                        );
                    } else {
                        $stats['email_failed']++;
                        $errorMsg = $sendResult['error_message'] ?? 'Unknown error';
                        logSendActivity(
                            'auto_send',
                            'auto_send_email',
                            $mrn,
                            'email',
                            null,
                            $email,
                            'request_code=' . $requestCode . ' status=failed error=' . h($errorMsg)
                        );
                    }
                } else if ($email !== '' && $emailLastAttempt === null) {
                    // Email contact exists but never attempted (shouldn't happen if email_sent exists)
                    $stats['email_skipped']++;
                }
            }
        }
    } catch (Throwable $loopException) {
        // Log individual result processing errors but don't fail the whole job
        error_log("sendPendingJsonResults: ERROR processing results: " . $loopException->getMessage());
        error_log("Trace: " . $loopException->getTraceAsString());
        // Continue and return whatever stats we've collected so far
    }
    
    return $stats;
}

/**
 * Sync delivery statuses from provider API
 */
function syncWhatsAppDeliveryStatuses(int $limit = 100): array
{
    $debugFile = __DIR__ . '/logs/sync_debug.log';
    
    $statusApiUrl = trim((string)(envValue('WHATSAPP_STATUS_API_URL', '') ?? ''));
    $apiKey = trim((string)(envValue('WHATSAPP_API_KEY', '') ?? ''));
    $apiSecret = trim((string)(envValue('WHATSAPP_API_SECRET', '') ?? ''));

    @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Starting sync. URL empty=" . (empty($statusApiUrl) ? '1' : '0') . ", Key empty=" . (empty($apiKey) ? '1' : '0') . ", Secret empty=" . (empty($apiSecret) ? '1' : '0') . "\n", FILE_APPEND);

    if ($statusApiUrl === '' || $apiKey === '' || $apiSecret === '') {
        if (function_exists('writeSendPendingLog')) {
            writeSendPendingLog('warning', 'WhatsApp status sync skipped: missing API configuration (url=' . (!empty($statusApiUrl) ? 'ok' : 'missing') . ', key=' . (!empty($apiKey) ? 'ok' : 'missing') . ', secret=' . (!empty($apiSecret) ? 'ok' : 'missing') . ')');
        }
        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] API config missing, returning early\n", FILE_APPEND);
        return [
            'success' => false,
            'received' => 0,
            'updated' => 0,
            'ignored' => 0,
            'http_code' => 0,
        ];
    }

    $pdo = openResultsDb();
    if ($pdo === null) {
        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Database connection failed\n", FILE_APPEND);
        if (function_exists('writeSendPendingLog')) {
            writeSendPendingLog('error', 'WhatsApp status sync failed: database connection error');
        }
        return [
            'success' => false,
            'received' => 0,
            'updated' => 0,
            'ignored' => 0,
            'http_code' => 0,
        ];
    }

    try {
        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Querying pending records\n", FILE_APPEND);
        
        $sql = "SELECT provider_ack FROM sent_results 
                WHERE provider_ack IS NOT NULL 
                AND provider_ack <> ''
                AND (
                    (provider_status NOT IN ('DELIVERED', 'READ', 'FAILED') OR provider_status IS NULL)
                    OR (provider_status = 'FAILED' AND wp_sent = 1)
                )
                LIMIT :limit";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll();

        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Query returned " . count($rows) . " records\n", FILE_APPEND);

        if (!is_array($rows) || empty($rows)) {
            @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] No pending records, returning success\n", FILE_APPEND);
            return [
                'success' => true,
                'received' => 0,
                'updated' => 0,
                'ignored' => 0,
                'http_code' => 200,
            ];
        }

        $acks = array_column($rows, 'provider_ack');
        $payload = [
            'api_key' => $apiKey,
            'api_secret' => $apiSecret,
            'route' => 'wp',
            'acks' => $acks,
        ];

        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Calling cURL to URL: " . $statusApiUrl . "\n", FILE_APPEND);

        $ch = curl_init();
        if ($ch === false) {
            @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] curl_init() failed\n", FILE_APPEND);
            if (function_exists('writeSendPendingLog')) {
                writeSendPendingLog('error', 'WhatsApp status sync failed: curl_init() failed');
            }
            return [
                'success' => false,
                'received' => count($acks),
                'updated' => 0,
                'ignored' => 0,
                'http_code' => 0,
            ];
        }

        curl_setopt_array($ch, [
            CURLOPT_URL => $statusApiUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => strtolower((string)(envValue('VERIFY_SSL_CERTS', '1') ?? '1')) === '1',
        ]);

        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Executing cURL\n", FILE_APPEND);

        $response = curl_exec($ch);
        $curlError = curl_error($ch);
        $curlErrno = curl_errno($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] cURL completed. errno=" . $curlErrno . ", error=" . $curlError . ", httpCode=" . $httpCode . ", responseLen=" . strlen($response ?? '') . "\n", FILE_APPEND);

        if ($response === false || !empty($curlError)) {
            @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] cURL error occurred\n", FILE_APPEND);
            if (function_exists('writeSendPendingLog')) {
                writeSendPendingLog('error', 'WhatsApp status sync cURL error: errno=' . $curlErrno . ', error=' . $curlError . ', url=' . $statusApiUrl);
            }
            return [
                'success' => false,
                'received' => count($acks),
                'updated' => 0,
                'ignored' => 0,
                'http_code' => $httpCode,
            ];
        }

        if ($httpCode >= 400) {
            @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] HTTP error: " . $httpCode . "\n", FILE_APPEND);
            if (function_exists('writeSendPendingLog')) {
                writeSendPendingLog('error', 'WhatsApp status sync HTTP error: code=' . $httpCode . ', response=' . substr($response, 0, 200));
            }
            return [
                'success' => false,
                'received' => count($acks),
                'updated' => 0,
                'ignored' => 0,
                'http_code' => $httpCode,
            ];
        }

        $statusData = json_decode($response, true);
        if (!is_array($statusData)) {
            @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Non-array JSON response\n", FILE_APPEND);
            if (function_exists('writeSendPendingLog')) {
                writeSendPendingLog('warning', 'WhatsApp status sync received non-array JSON response, treating as empty: ' . substr($response, 0, 200));
            }
            return [
                'success' => true,
                'received' => count($acks),
                'updated' => 0,
                'ignored' => 0,
                'http_code' => $httpCode,
            ];
        }

        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Applying delivery statuses\n", FILE_APPEND);

        $summary = applyDeliveryStatusesFromRows($statusData, 'sync_wp_delivery_status');

        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Sync completed successfully\n", FILE_APPEND);

        return [
            'success' => true,
            'received' => count($acks),
            'updated' => (int)($summary['updated'] ?? 0),
            'ignored' => (int)($summary['ignored'] ?? 0),
            'http_code' => $httpCode,
        ];
    } catch (Throwable $e) {
        @file_put_contents($debugFile, date('Y-m-d H:i:s') . " [DEBUG] Exception: " . $e->getMessage() . " at " . $e->getFile() . ":" . $e->getLine() . "\n", FILE_APPEND);
        if (function_exists('writeSendPendingLog')) {
            writeSendPendingLog('error', 'WhatsApp status sync exception: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine());
        }
        return [
            'success' => false,
            'received' => 0,
            'updated' => 0,
            'ignored' => 0,
            'http_code' => 0,
        ];
    }
}

/**
 * Sync SMS delivery statuses from provider API
 */
function syncSmsDeliveryStatuses(int $limit = 100): array
{
    $statusApiUrl = trim((string)(envValue('SMS_STATUS_API_URL', '') ?? ''));
    $apiKey = trim((string)(envValue('SMS_API_KEY', '') ?? ''));
    $apiSecret = trim((string)(envValue('SMS_API_SECRET', '') ?? ''));

    if ($statusApiUrl === '' || $apiKey === '' || $apiSecret === '') {
        return [
            'success' => false,
            'received' => 0,
            'updated' => 0,
            'ignored' => 0,
            'http_code' => 0,
            'message' => 'SMS status API not configured',
        ];
    }

    $pdo = openResultsDb();
    if ($pdo === null) {
        return [
            'success' => false,
            'received' => 0,
            'updated' => 0,
            'ignored' => 0,
            'http_code' => 0,
            'message' => 'Database connection failed',
        ];
    }

    try {
        $sql = "SELECT provider_ack FROM sent_results 
                WHERE provider_ack IS NOT NULL 
                AND provider_ack <> ''
                AND (
                    (sms_sent = 1 AND (provider_status NOT IN ('DELIVERED', 'FAILED') OR provider_status IS NULL))
                    OR (provider_status = 'FAILED' AND sms_sent = 1)
                    OR provider_status IN ('IN_TRANSIT', 'SENT', 'PENDING')
                    OR (provider_status IS NULL AND provider_ack IS NOT NULL)
                )
                LIMIT :limit";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        $rows = $stmt->fetchAll();

        if (!is_array($rows) || empty($rows)) {
            return [
                'success' => true,
                'received' => 0,
                'updated' => 0,
                'ignored' => 0,
                'http_code' => 200,
            ];
        }

        $acks = array_column($rows, 'provider_ack');
        $payload = [
            'api_key' => $apiKey,
            'api_secret' => $apiSecret,
            'route' => 'sms',
            'acks' => $acks,
        ];

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $statusApiUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => strtolower((string)(envValue('VERIFY_SSL_CERTS', '1') ?? '1')) === '1',
        ]);

        $response = @curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false || $httpCode >= 400) {
            return [
                'success' => false,
                'received' => count($acks),
                'updated' => 0,
                'ignored' => 0,
                'http_code' => $httpCode,
                'message' => 'API request failed',
            ];
        }

        $statusData = json_decode($response, true);
        if (!is_array($statusData)) {
            return [
                'success' => true,
                'received' => count($acks),
                'updated' => 0,
                'ignored' => 0,
                'http_code' => $httpCode,
                'message' => 'No status data in response',
            ];
        }

        $summary = applyDeliveryStatusesFromRows($statusData, 'sync_sms_delivery_status');

        return [
            'success' => true,
            'received' => count($acks),
            'updated' => (int)($summary['updated'] ?? 0),
            'ignored' => (int)($summary['ignored'] ?? 0),
            'http_code' => $httpCode,
        ];
    } catch (Throwable $e) {
        return [
            'success' => false,
            'received' => 0,
            'updated' => 0,
            'ignored' => 0,
            'http_code' => 0,
            'message' => $e->getMessage(),
        ];
    }
}

/**
 * Detect SMS-specific error messages and rejection reasons
 * Maps error messages to appropriate FAILED or IN_TRANSIT status codes
 * 
 * @param string $responseText Raw API response or error message
 * @return array ['detected' => bool, 'errorMessage' => string, 'statusCode' => string]
 */
function detectSmsErrorMessage(string $responseText): array
{
    $response = strtolower(trim($responseText));
    
    $errorPatterns = [
        // Credit/Account issues
        'no credits' => 'INSUFFICIENT_CREDITS',
        'insufficient credits' => 'INSUFFICIENT_CREDITS',
        'low credits' => 'INSUFFICIENT_CREDITS',
        'out of credits' => 'INSUFFICIENT_CREDITS',
        
        // Rate limiting / throttling
        'throttled' => 'THROTTLED',
        'rate limit' => 'RATE_LIMITED',
        'rate_limited' => 'RATE_LIMITED',
        'too many requests' => 'THROTTLED',
        'request throttled' => 'THROTTLED',
        
        // Invalid recipient
        'invalid phone' => 'INVALID_RECIPIENT',
        'invalid number' => 'INVALID_RECIPIENT',
        'invalid destination' => 'INVALID_RECIPIENT',
        'does not exist' => 'INVALID_RECIPIENT',
        'cannot route' => 'INVALID_RECIPIENT',
        
        // Account/Service issues
        'account suspended' => 'ACCOUNT_ERROR',
        'account disabled' => 'ACCOUNT_ERROR',
        'account has been suspended' => 'ACCOUNT_ERROR',
        'unauthorized' => 'ACCOUNT_ERROR',
        'authentication failed' => 'ACCOUNT_ERROR',
        'invalid credentials' => 'ACCOUNT_ERROR',
        
        // Network/API issues
        'connection timeout' => 'TIMEOUT',
        'network error' => 'NETWORK_ERROR',
        'service unavailable' => 'SERVICE_ERROR',
        'temporarily unavailable' => 'SERVICE_ERROR',
        
        // In transit / pending
        'in transit' => 'IN_TRANSIT',
        'pending' => 'IN_TRANSIT',
        'queued' => 'IN_TRANSIT',
        
        // Generic failures
        'failed' => 'FAILED',
        'error' => 'ERROR',
    ];
    
    foreach ($errorPatterns as $pattern => $statusCode) {
        if (strpos($response, $pattern) !== false) {
            return [
                'detected' => true,
                'errorMessage' => $pattern,
                'statusCode' => $statusCode,
            ];
        }
    }
    
    return [
        'detected' => false,
        'errorMessage' => '',
        'statusCode' => '',
    ];
}

/**
 * Normalize SMS provider status with enhanced error detection
 * Converts numeric and text statuses to standard values: SENT, DELIVERED, FAILED, IN_TRANSIT, UNKNOWN
 * Also detects specific error messages
 * 
 * @param string $status Numeric (1, 2) or text status from provider
 * @param string $fullResponse Full API response for error message detection
 * @return array ['status' => string, 'errorType' => string, 'errorMessage' => string]
 */
function normalizeSmsProviderStatus(string $status, string $fullResponse = ''): array
{
    $status = strtoupper(trim($status));
    $errorType = '';
    $errorMessage = '';
    
    // Check for SMS error messages in the response
    if ($fullResponse !== '') {
        $errorDetection = detectSmsErrorMessage($fullResponse);
        if ($errorDetection['detected']) {
            $errorType = $errorDetection['statusCode'];
            $errorMessage = $errorDetection['errorMessage'];
            // Map specific error types to appropriate status
            if (in_array($errorType, ['INSUFFICIENT_CREDITS', 'ACCOUNT_ERROR', 'INVALID_RECIPIENT'], true)) {
                return [
                    'status' => 'FAILED',
                    'errorType' => $errorType,
                    'errorMessage' => $errorMessage,
                ];
            } elseif (in_array($errorType, ['THROTTLED', 'RATE_LIMITED', 'SERVICE_ERROR', 'TIMEOUT'], true)) {
                // Temporary errors could allow retry
                return [
                    'status' => 'IN_TRANSIT',
                    'errorType' => $errorType,
                    'errorMessage' => $errorMessage,
                ];
            } elseif ($errorType === 'IN_TRANSIT') {
                return [
                    'status' => 'IN_TRANSIT',
                    'errorType' => $errorType,
                    'errorMessage' => $errorMessage,
                ];
            } else {
                return [
                    'status' => 'FAILED',
                    'errorType' => $errorType,
                    'errorMessage' => $errorMessage,
                ];
            }
        }
    }
    
    // Normalize numeric statuses (if provider uses them)
    if ($status === '1' || $status === 'SENT') {
        $normalizedStatus = 'SENT';
    } elseif ($status === '2' || $status === 'DELIVERED') {
        $normalizedStatus = 'DELIVERED';
    } elseif ($status === '0' || $status === 'FAILED') {
        $normalizedStatus = 'FAILED';
    } elseif (in_array($status, ['IN_TRANSIT', 'PENDING', 'QUEUED', 'UNKNOWN'], true)) {
        $normalizedStatus = $status;
    } else {
        $normalizedStatus = 'UNKNOWN';
    }
    
    return [
        'status' => $normalizedStatus,
        'errorType' => $errorType,
        'errorMessage' => $errorMessage,
    ];
}

/**
 * Detect WhatsApp-specific error messages and rejection reasons
 * Maps error messages to appropriate FAILED status codes
 * 
 * @param string $responseText Raw API response or error message
 * @return array ['detected' => bool, 'errorMessage' => string, 'statusCode' => string]
 */
function detectWhatsAppErrorMessage(string $responseText): array
{
    $response = strtolower(trim($responseText));
    
    $errorPatterns = [
        // WhatsApp rate limiting / ecosystem health
        'not delivered to maintain healthy ecosystem engagement' => 'REJECTED_ECOSYSTEM',
        'maintain healthy ecosystem' => 'REJECTED_ECOSYSTEM',
        'throttled' => 'THROTTLED',
        'rate limit' => 'RATE_LIMITED',
        'rate_limited' => 'RATE_LIMITED',
        
        // Invalid recipient
        'invalid phone' => 'INVALID_RECIPIENT',
        'invalid recipient' => 'INVALID_RECIPIENT',
        'invalid number' => 'INVALID_RECIPIENT',
        'number is invalid' => 'INVALID_RECIPIENT',
        'does not exist' => 'INVALID_RECIPIENT',
        'not a valid whatsapp number' => 'INVALID_RECIPIENT',
        
        // Account/template issues
        'invalid template' => 'INVALID_TEMPLATE',
        'template not found' => 'INVALID_TEMPLATE',
        'template_error' => 'INVALID_TEMPLATE',
        'account suspended' => 'ACCOUNT_ERROR',
        'account disabled' => 'ACCOUNT_ERROR',
        'account has been suspended' => 'ACCOUNT_ERROR',
        'account has been disabled' => 'ACCOUNT_ERROR',
        'unauthorized' => 'ACCOUNT_ERROR',
        'authentication failed' => 'ACCOUNT_ERROR',
        
        // Network/API issues
        'connection timeout' => 'TIMEOUT',
        'network error' => 'NETWORK_ERROR',
        'service unavailable' => 'SERVICE_ERROR',
        
        // Generic failures
        'failed' => 'FAILED',
        'error' => 'ERROR',
    ];
    
    foreach ($errorPatterns as $pattern => $statusCode) {
        if (strpos($response, $pattern) !== false) {
            return [
                'detected' => true,
                'errorMessage' => $pattern,
                'statusCode' => $statusCode,
            ];
        }
    }
    
    return [
        'detected' => false,
        'errorMessage' => '',
        'statusCode' => '',
    ];
}

/**
 * Normalize WhatsApp provider status with enhanced error detection
 * Converts numeric and text statuses to standard values: SENT, DELIVERED, READ, FAILED, UNKNOWN
 * Also detects specific error messages
 * 
 * @param string $status Numeric (1,2) or text status from provider
 * @param string $fullResponse Full API response for error message detection
 * @return array ['status' => string, 'errorType' => string, 'errorMessage' => string]
 */
function normalizeWhatsAppProviderStatus(string $status, string $fullResponse = ''): array
{
    $status = strtoupper(trim($status));
    $errorType = '';
    $errorMessage = '';
    
    // Check for WhatsApp error messages in the response
    if ($fullResponse !== '') {
        $errorDetection = detectWhatsAppErrorMessage($fullResponse);
        if ($errorDetection['detected']) {
            $errorType = $errorDetection['statusCode'];
            $errorMessage = $errorDetection['errorMessage'];
            // If we detected a specific error, treat as FAILED
            return [
                'status' => 'FAILED',
                'errorType' => $errorType,
                'errorMessage' => $errorMessage,
            ];
        }
    }
    
    // Normalize numeric statuses
    if ($status === '1') {
        $normalizedStatus = 'SENT';
    } elseif ($status === '2') {
        $normalizedStatus = 'DELIVERED';
    } elseif ($status === '3' || $status === '0') {
        $normalizedStatus = 'FAILED';
    } elseif (in_array($status, ['SENT', 'DELIVERED', 'READ', 'FAILED', 'UNKNOWN', 'PENDING'], true)) {
        $normalizedStatus = $status;
    } else {
        $normalizedStatus = 'UNKNOWN';
    }
    
    return [
        'status' => $normalizedStatus,
        'errorType' => $errorType,
        'errorMessage' => $errorMessage,
    ];
}

/**
 * Validate and update delivery status from API ACK status check
 * This ensures we properly capture late delivery failures (e.g., "not delivered to maintain healthy ecosystem engagement")
 * 
 * @param string $ack Message ACK/ID from provider
 * @param string $apiResponse Full response from provider status API
 * @return bool True if update was successful
 */
function validateAndUpdateAckDeliveryStatus(string $ack, string $apiResponse): bool
{
    if (trim($ack) === '') {
        return false;
    }
    
    // Check for WhatsApp-specific error messages first
    $errorDetection = detectWhatsAppErrorMessage($apiResponse);
    
    // Extract status and normalize it
    $normalizedResult = normalizeWhatsAppProviderStatus('', $apiResponse);
    
    if ($normalizedResult['status'] === 'FAILED' && $errorDetection['detected']) {
        writeWhatsappLogLine(sprintf(
            '[%s] ACK Delivery Validation: ack=%s detected_error=%s error_type=%s',
            date('Y-m-d H:i:s'),
            $ack,
            $errorDetection['errorMessage'],
            $normalizedResult['errorType']
        ));
        
        // Update the delivery status with failure reason
        return (updateSentRecordDeliveryByAck(
            $ack,
            'FAILED',
            null,
            date('Y-m-d H:i:s'),
            'ack_validation',
            $apiResponse
        ) > 0);
    }
    
    return false;
}

/**
 * Apply delivery status updates from API rows
 */
function applyDeliveryStatusesFromRows(array $rows, string $source): array
{
    $updated = 0;
    $ignored = 0;

    foreach ($rows as $row) {
        if (!is_array($row)) {
            continue;
        }

        $ack = trim((string)($row['ack'] ?? $row['id'] ?? $row['message_id'] ?? ''));
        // Accept multiple possible status fields returned by providers (opstatus, status, op_status)
        $rawStatus = trim((string)($row['status'] ?? $row['opstatus'] ?? $row['op_status'] ?? $row['message_status'] ?? 'UNKNOWN'));
        $fullResponse = trim((string)($row['response'] ?? ''));
        $recipient = trim((string)($row['recipient'] ?? $row['to'] ?? ''));

        if ($ack === '') {
            $ignored++;
            continue;
        }

        // Normalize status with enhanced error detection based on channel
        $isSmsSync = strpos($source, 'sms') !== false;
        if ($isSmsSync) {
            $statusNormalization = normalizeSmsProviderStatus($rawStatus, $fullResponse);
        } else {
            $statusNormalization = normalizeWhatsAppProviderStatus($rawStatus, $fullResponse);
        }
        $normalizedStatus = $statusNormalization['status'];
        $errorType = $statusNormalization['errorType'];
        
        // Build enhanced response that includes error type if detected
        $enhancedResponse = $fullResponse;
        if ($errorType !== '') {
            $enhancedResponse = "ERROR_TYPE={$errorType}; " . $fullResponse;
        }

        $logLine = sprintf(
            '[%s] Applying delivery status: ack=%s raw_status=%s normalized=%s error_type=%s source=%s',
            date('Y-m-d H:i:s'),
            $ack,
            $rawStatus,
            $normalizedStatus,
            $errorType ?: 'none',
            $source
        );
        
        if ($isSmsSync) {
            writeSmsLogLine($logLine);
        } else {
            writeWhatsappLogLine($logLine);
        }

        $rowsUpdated = updateSentRecordDeliveryByAck(
            $ack,
            $normalizedStatus,
            $recipient !== '' ? $recipient : null,
            date('Y-m-d H:i:s'),
            $source,
            $enhancedResponse
        );

        $updated += $rowsUpdated;
        if ($rowsUpdated === 0) {
            $ignored++;
        }
    }

    return [
        'updated' => $updated,
        'ignored' => $ignored,
    ];
}

/**
 * Send via WhatsApp API (BestSMSBulk or similar)
 * Now accepts template type and variables string for {{1}}, {{2}} placeholders
 */
function sendViaWhatsApp(
    string $phone,
    string $messageBody,
    string $templateType,
    ?string $providerId = null,
    string $templateVariables = '',
    string $media = '',
    string $mediaFilename = ''
): array {
    $apiUrl = trim((string)(envValue('WHATSAPP_API_URL', '') ?? ''));
    $apiKey = trim((string)(envValue('WHATSAPP_API_KEY', '') ?? ''));
    $apiSecret = trim((string)(envValue('WHATSAPP_API_SECRET', '') ?? ''));
    $senderId = trim((string)(envValue('SMS_SENDER_ID', '') ?? ''));

    writeWhatsappLogLine(sprintf(
        '[%s] WhatsApp send attempt: url=%s phone=%s template=%s',
        date('Y-m-d H:i:s'),
        $apiUrl,
        $phone,
        $templateType
    ));

    if ($apiUrl === '' || $apiKey === '' || $apiSecret === '') {
        writeWhatsappLogLine(sprintf(
            '[%s] ERROR: WhatsApp API credentials missing: url=%s key_present=%s secret_present=%s',
            date('Y-m-d H:i:s'),
            $apiUrl === '' ? 'MISSING' : 'OK',
            $apiKey === '' ? 'MISSING' : 'OK',
            $apiSecret === '' ? 'MISSING' : 'OK'
        ));
        return [
            'success' => false,
            'error' => 'WhatsApp API credentials not configured',
            'provider_ack' => null,
            'provider_status' => 'FAILED',
        ];
    }

    // Normalize phone number (remove +, spaces, dashes)
    $originalPhone = $phone;
    $phone = preg_replace('/[^0-9]/', '', $phone) ?? '';
    if ($phone === '' || strlen($phone) < 10) {
        writeWhatsappLogLine(sprintf(
            '[%s] ERROR: Invalid phone number: original=%s normalized=%s length=%d',
            date('Y-m-d H:i:s'),
            $originalPhone,
            $phone,
            strlen($phone)
        ));
        return [
            'success' => false,
            'error' => 'Invalid phone number',
            'provider_ack' => null,
            'provider_status' => 'INVALID_PHONE',
        ];
    }

    // Use provided variables or fall back to messageBody for legacy compatibility
    $variables = $templateVariables !== '' ? $templateVariables : $messageBody;
    
    // Prepare URL with query parameters (BestSMSBulk WhatsApp API format)
    $queryParams = [
        'api_key' => $apiKey,
        'api_secret' => $apiSecret,
        'senderid' => $senderId,
        'destination' => $phone,
        'route' => 'wp',
        'template' => $templateType,
        'variables' => $variables,
    ];

    // Attach media (PDF) when provided (BestSMSBulk accepts a URL OR encoded content in 'media')
    if ($media !== '') {
        $queryParams['media'] = $media;
        if ($mediaFilename !== '') {
            $queryParams['filename'] = $mediaFilename;
        }
    }
    
    $fullUrl = $apiUrl . '?' . http_build_query($queryParams);

    // Decide whether to send as GET or POST. If media is present (likely large encoded content), use POST.
    $usePost = ($media !== '');

    writeWhatsappLogLine(sprintf(
        '[%s] API Request: %s to %s with phone=%s template=%s media_len=%d msglen=%d',
        date('Y-m-d H:i:s'),
        $usePost ? 'POST' : 'GET',
        $apiUrl,
        $phone,
        $templateType,
        $media !== '' ? strlen($media) : 0,
        strlen($messageBody)
    ));

    writeApiCallLog(sprintf(
        '[%s] WhatsApp API Request: url=%s destination=%s route=wp senderid=%s template=%s msglen=%d media_len=%d',
        date('Y-m-d H:i:s'),
        $apiUrl,
        $phone,
        $senderId,
        $templateType,
        strlen($messageBody),
        $media !== '' ? strlen($media) : 0
    ));

    $ch = curl_init();
    if ($usePost) {
        curl_setopt_array($ch, [
            CURLOPT_URL => $apiUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($queryParams),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_SSL_VERIFYPEER => strtolower((string)(envValue('VERIFY_SSL_CERTS', '1') ?? '1')) === '1',
        ]);
    } else {
        curl_setopt_array($ch, [
            CURLOPT_URL => $fullUrl,
            CURLOPT_POST => false,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => strtolower((string)(envValue('VERIFY_SSL_CERTS', '1') ?? '1')) === '1',
        ]);
    }

    $response = @curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    writeWhatsappLogLine(sprintf(
        '[%s] API Response: http_code=%d curl_error=%s response_len=%d response=%s',
        date('Y-m-d H:i:s'),
        $httpCode,
        $curlError ?: 'none',
        strlen((string)$response),
        substr((string)$response, 0, 200)
    ));

    writeApiCallLog(sprintf(
        '[%s] WhatsApp API Response: http_code=%d curl_error=%s response=%s',
        date('Y-m-d H:i:s'),
        $httpCode,
        $curlError ?: 'none',
        substr((string)$response, 0, 200)
    ));

    if ($response === false || $httpCode >= 400) {
        writeWhatsappLogLine(sprintf(
            '[%s] ERROR: API call failed: http_code=%d response=%s',
            date('Y-m-d H:i:s'),
            $httpCode,
            substr((string)$response, 0, 500)
        ));

        writeApiCallLog(sprintf(
            '[%s] WhatsApp API Response: FAILED http_code=%d response=%s',
            date('Y-m-d H:i:s'),
            $httpCode,
            substr((string)$response, 0, 200)
        ));

        return [
            'success' => false,
            'error' => 'API request failed (HTTP ' . $httpCode . ')',
            'provider_ack' => null,
            'provider_status' => 'FAILED',
            'http_code' => $httpCode,
            'provider_response' => (string)$response,
        ];
    }

    // Parse response - BestSMSBulk WhatsApp returns: message_id;destination;status (similar to SMS)
    $ack = '';
    $status = '1';
    
    if (is_string($response) && strpos($response, ';') !== false) {
        // Semicolon-separated response: message_id;destination;status
        $parts = explode(';', trim($response));
        if (count($parts) >= 1 && $parts[0] !== '' && 
            strpos(strtolower($parts[0]), 'error') === false && 
            strpos(strtolower($parts[0]), 'invalid') === false) {
            $ack = trim($parts[0]);
            if (count($parts) >= 3) {
                $status = trim($parts[2]);
            }
            writeWhatsappLogLine(sprintf(
                '[%s] Extracted ACK from semicolon response: ack=%s status=%s parts=%d',
                date('Y-m-d H:i:s'),
                $ack,
                $status,
                count($parts)
            ));
        } else {
            // Check if response is an error message
            if (strpos(strtolower($response), 'error') !== false || 
                strpos(strtolower($response), 'invalid') !== false || 
                strpos(strtolower($response), 'field is empty') !== false) {
                writeWhatsappLogLine(sprintf(
                    '[%s] ERROR: API error response: %s',
                    date('Y-m-d H:i:s'),
                    substr((string)$response, 0, 500)
                ));

                writeApiCallLog(sprintf(
                    '[%s] WhatsApp API Response: ERROR %s',
                    date('Y-m-d H:i:s'),
                    substr((string)$response, 0, 200)
                ));

                return [
                    'success' => false,
                    'error' => 'API error: ' . substr((string)$response, 0, 100),
                    'provider_ack' => null,
                    'provider_status' => 'FAILED',
                    'provider_response' => (string)$response,
                ];
            }
        }
    } elseif (is_string($response)) {
        // Try JSON parsing as fallback
        $decoded = json_decode($response, true);
        if (is_array($decoded)) {
            $ack = (string)($decoded['id'] ?? $decoded['ack'] ?? $decoded['message_id'] ?? '');
            $status = (string)($decoded['status'] ?? '1');
            writeWhatsappLogLine(sprintf(
                '[%s] Extracted ACK from JSON response: ack=%s status=%s',
                date('Y-m-d H:i:s'),
                $ack,
                $status
            ));
        } else {
            writeWhatsappLogLine(sprintf(
                '[%s] ERROR: Unparseable response: %s',
                date('Y-m-d H:i:s'),
                substr((string)$response, 0, 500)
            ));

            writeApiCallLog(sprintf(
                '[%s] WhatsApp API Response: UNPARSEABLE %s',
                date('Y-m-d H:i:s'),
                substr((string)$response, 0, 200)
            ));

            return [
                'success' => false,
                'error' => 'Invalid API response format',
                'provider_ack' => null,
                'provider_status' => 'FAILED',
            ];
        }
    }

    if ($ack === '') {
        writeWhatsappLogLine(sprintf(
            '[%s] ERROR: No message ID in response: %s',
            date('Y-m-d H:i:s'),
            substr((string)$response, 0, 500)
        ));

        writeApiCallLog(sprintf(
            '[%s] WhatsApp API Response: NO_ACK %s',
            date('Y-m-d H:i:s'),
            substr((string)$response, 0, 200)
        ));

        return [
            'success' => false,
            'error' => 'No message ID in response',
            'provider_ack' => null,
            'provider_status' => 'FAILED',
        ];
    }

    writeWhatsappLogLine(sprintf(
        '[%s] SUCCESS: WhatsApp sent: phone=%s ack=%s status=%s',
        date('Y-m-d H:i:s'),
        $phone,
        $ack,
        $status
    ));

    writeApiCallLog(sprintf(
        '[%s] WhatsApp API Response: SUCCESS ack=%s status=%s',
        date('Y-m-d H:i:s'),
        $ack,
        $status
    ));

    // Normalize status with enhanced error detection (passing full response for error message parsing)
    // IMPORTANT: If we got an ACK, the API accepted the message. Error messages in response are warnings,
    // not failures. We only treat it as FAILED if the API rejected it (no ACK).
    $statusNormalization = normalizeWhatsAppProviderStatus($status, $response);
    $errorType = $statusNormalization['errorType'];
    $errorMessage = $statusNormalization['errorMessage'];
    
    // If ACK exists, API accepted it - mark as SENT regardless of warnings in response
    // Warnings will be logged but don't mark the initial send as failed
    $normalizedStatus = 'SENT';
    
    if ($errorType !== '') {
        writeWhatsappLogLine(sprintf(
            '[%s] WhatsApp API Response contains warning/error (but accepted): ack=%s error_type=%s error_msg=%s',
            date('Y-m-d H:i:s'),
            $ack,
            $errorType,
            $errorMessage
        ));
    }

    return [
        'success' => true,  // API accepted it (we got an ACK), so mark as success
        'provider_ack' => $ack,
        'provider_status' => $normalizedStatus,
        'provider_response' => $response,
        'http_code' => $httpCode,
    ];
}

/**
 * Send via SMS API
 */
function sendViaSMS(
    string $phone,
    string $messageBody,
    ?string $providerId = null
): array {
    $apiUrl = trim((string)(envValue('SMS_API_URL', '') ?? ''));
    $apiKey = trim((string)(envValue('SMS_API_KEY', '') ?? ''));
    $apiSecret = trim((string)(envValue('SMS_API_SECRET', '') ?? ''));
    $senderId = trim((string)(envValue('SMS_SENDER_ID', '') ?? ''));

    // Log the request details
    writeSmsLogLine(sprintf(
        '[%s] SMS send attempt: url=%s phone=%s sender=%s',
        date('Y-m-d H:i:s'),
        $apiUrl,
        $phone,
        $senderId
    ));

    if ($apiUrl === '' || $apiKey === '' || $apiSecret === '') {
        writeSmsLogLine(sprintf(
            '[%s] ERROR: SMS API credentials missing: url=%s key_present=%s secret_present=%s',
            date('Y-m-d H:i:s'),
            $apiUrl === '' ? 'MISSING' : 'OK',
            $apiKey === '' ? 'MISSING' : 'OK',
            $apiSecret === '' ? 'MISSING' : 'OK'
        ));
        return [
            'success' => false,
            'error' => 'SMS API credentials not configured',
            'provider_ack' => null,
            'provider_status' => 'FAILED',
        ];
    }

    // Normalize phone
    $originalPhone = $phone;
    $phone = preg_replace('/[^0-9]/', '', $phone) ?? '';
    if ($phone === '' || strlen($phone) < 10) {
        writeSmsLogLine(sprintf(
            '[%s] ERROR: Invalid phone number: original=%s normalized=%s length=%d',
            date('Y-m-d H:i:s'),
            $originalPhone,
            $phone,
            strlen($phone)
        ));
        return [
            'success' => false,
            'error' => 'Invalid phone number',
            'provider_ack' => null,
            'provider_status' => 'INVALID_PHONE',
        ];
    }

    $postData = http_build_query([
        'api_key' => $apiKey,
        'api_secret' => $apiSecret,
        'destination' => $phone,
        'route' => 'sms',
        'message' => $messageBody,
        'senderid' => $senderId,
    ]);

    writeSmsLogLine(sprintf(
        '[%s] API Request: POST to %s with phone=%s msglen=%d',
        date('Y-m-d H:i:s'),
        $apiUrl,
        $phone,
        strlen($messageBody)
    ));

    writeApiCallLog(sprintf(
        '[%s] SMS API Request: url=%s destination=%s route=sms senderid=%s msglen=%d',
        date('Y-m-d H:i:s'),
        $apiUrl,
        $phone,
        $senderId,
        strlen($messageBody)
    ));

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $apiUrl,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => strtolower((string)(envValue('VERIFY_SSL_CERTS', '1') ?? '1')) === '1',
    ]);

    $response = @curl_exec($ch);
    $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($response === false || $httpCode >= 400) {
        writeSmsLogLine(sprintf(
            '[%s] ERROR: API call failed: http_code=%d curl_error=%s response=%s',
            date('Y-m-d H:i:s'),
            $httpCode,
            $curlError,
            substr((string)$response, 0, 500)
        ));

        writeApiCallLog(sprintf(
            '[%s] SMS API Response: FAILED http_code=%d curl_error=%s response=%s',
            date('Y-m-d H:i:s'),
            $httpCode,
            $curlError,
            substr((string)$response, 0, 500)
        ));

        return [
            'success' => false,
            'error' => 'SMS API request failed (HTTP ' . $httpCode . ')',
            'provider_ack' => null,
            'provider_status' => 'FAILED',
            'http_code' => $httpCode,
            'provider_response' => (string)$response,
        ];
    }

    writeSmsLogLine(sprintf(
        '[%s] API Response: http_code=%d response=%s',
        date('Y-m-d H:i:s'),
        $httpCode,
        substr((string)$response, 0, 500)
    ));

    writeApiCallLog(sprintf(
        '[%s] SMS API Response: http_code=%d response=%s',
        date('Y-m-d H:i:s'),
        $httpCode,
        substr((string)$response, 0, 500)
    ));

    // CHECK FOR ERROR MESSAGES FIRST (before ACK extraction)
    $responseStr = (string)$response;
    $errorDetection = detectSmsErrorMessage($responseStr);
    $normalization = normalizeSmsProviderStatus('', $responseStr);
    
    if ($errorDetection['detected']) {
        writeSmsLogLine(sprintf(
            '[%s] ERROR: API returned error: error_type=%s message=%s',
            date('Y-m-d H:i:s'),
            $errorDetection['statusCode'],
            substr($errorDetection['errorMessage'], 0, 100)
        ));

        writeApiCallLog(sprintf(
            '[%s] SMS API Response: ERROR error_type=%s message=%s full=%s',
            date('Y-m-d H:i:s'),
            $errorDetection['statusCode'],
            $errorDetection['errorMessage'],
            substr($responseStr, 0, 200)
        ));

        // Generate ACK even for error cases (for tracking failed sends)
        $ack = md5($phone . ':' . time());
        
        return [
            'success' => false,
            'error' => $errorDetection['errorMessage'],
            'provider_ack' => $ack,
            'provider_status' => $normalization['status'],
            'provider_response' => $responseStr,
            'error_type' => $errorDetection['statusCode'],
            'http_code' => $httpCode,
        ];
    }

    // Try to extract ACK from response - BestSMSBulk returns: message_id;destination;status
    $ack = '';
    $decoded = json_decode($response, true);
    if (is_array($decoded)) {
        // JSON response (if any)
        $ack = (string)($decoded['id'] ?? $decoded['ack'] ?? $decoded['message_id'] ?? $decoded['sms_id'] ?? '');
    } elseif (is_string($response) && strpos($response, ';') !== false) {
        // Semicolon-separated response from BestSMSBulk: message_id;destination;status
        $parts = explode(';', trim($response));
        if (count($parts) >= 1 && $parts[0] !== '') {
            $ack = trim($parts[0]);
            writeSmsLogLine(sprintf(
                '[%s] Extracted ACK from semicolon response: ack=%s parts=%d',
                date('Y-m-d H:i:s'),
                $ack,
                count($parts)
            ));
        }
    }

    // If no ACK extracted, generate one
    if ($ack === '') {
        $ack = md5($phone . ':' . time());
        writeSmsLogLine(sprintf(
            '[%s] Generated ACK (not in response): ack=%s response_snippet=%s',
            date('Y-m-d H:i:s'),
            $ack,
            substr((string)$response, 0, 100)
        ));
    } else {
        writeSmsLogLine(sprintf(
            '[%s] Extracted ACK from response: ack=%s',
            date('Y-m-d H:i:s'),
            $ack
        ));
    }

    writeSmsLogLine(sprintf(
        '[%s] SUCCESS: SMS queued: phone=%s ack=%s',
        date('Y-m-d H:i:s'),
        $phone,
        $ack
    ));

    writeApiCallLog(sprintf(
        '[%s] SMS API Response: SUCCESS ack=%s',
        date('Y-m-d H:i:s'),
        $ack
    ));

    return [
        'success' => true,
        'provider_ack' => $ack,
        'provider_status' => 'SENT',
        'provider_response' => (string)$response,
        'http_code' => $httpCode,
    ];
}

/**
 * Send via Email
 */
function sendViaEmail(
    string $email,
    string $subject,
    string $body,
    array $attachments = []
): array {
    $email = trim($email);
    
    writeEmailLogLine(sprintf(
        '[%s] Email send attempt: recipient=%s subject_len=%d body_len=%d attachments=%d',
        date('Y-m-d H:i:s'),
        $email,
        strlen($subject),
        strlen($body),
        count($attachments)
    ));

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        writeEmailLogLine(sprintf(
            '[%s] ERROR: Invalid email address: email=%s',
            date('Y-m-d H:i:s'),
            $email
        ));
        return [
            'success' => false,
            'error' => 'Invalid email address',
            'provider_ack' => null,
            'provider_status' => 'INVALID_EMAIL',
        ];
    }

    $preferredAuth = shouldUseSmtpAuthForRecipient($email);

    // Try PHPMailer first (better STARTTLS support)
    if (class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
        writeEmailLogLine(sprintf(
            '[%s] Attempting send via PHPMailer: recipient=%s mode=%s',
            date('Y-m-d H:i:s'),
            $email,
            $preferredAuth ? 'auth' : 'relay'
        ));
        $result = sendResultEmailViaPhpMailer($email, $subject, $body, $attachments, $preferredAuth);
        if (!empty($result['success'])) {
            writeEmailLogLine(sprintf(
                '[%s] SUCCESS: Email sent via PHPMailer: recipient=%s subject=%s',
                date('Y-m-d H:i:s'),
                $email,
                $subject
            ));
            return [
                'success' => true,
                'error' => null,
                'provider_ack' => md5($email . ':' . time()),
                'provider_status' => 'SENT',
            ];
        }

        if ($preferredAuth) {
            // For authenticated external sends, keep behavior simple: PHPMailer is the primary path.
            writeEmailLogLine(sprintf(
                '[%s] ERROR: Email send failed: recipient=%s method=phpmailer error=%s',
                date('Y-m-d H:i:s'),
                $email,
                $result['error'] ?? 'Unknown error'
            ));

            return [
                'success' => false,
                'error' => $result['error'] ?? 'Unknown error',
                'provider_ack' => md5($email . ':' . time()),
                'provider_status' => 'FAILED',
            ];
        }

        writeEmailLogLine(sprintf(
            '[%s] PHPMailer failed for relay mode, trying raw SMTP: error=%s',
            date('Y-m-d H:i:s'),
            $result['error'] ?? 'Unknown error'
        ));
    }

    // Fallback to raw SMTP socket (mainly for internal relay mode)
    $fallbackAuth = $preferredAuth;
    $result = sendResultEmailSmtp($email, $subject, $body, $attachments, $fallbackAuth);
    
    if (!empty($result['success'])) {
        writeEmailLogLine(sprintf(
            '[%s] SUCCESS: Email sent via raw SMTP: recipient=%s subject=%s',
            date('Y-m-d H:i:s'),
            $email,
            $subject
        ));
    } else {
        writeEmailLogLine(sprintf(
            '[%s] ERROR: Email send failed (all methods): recipient=%s error=%s',
            date('Y-m-d H:i:s'),
            $email,
            $result['error'] ?? 'Unknown error'
        ));
    }

    return [
        'success' => !empty($result['success']),
        'error' => $result['error'] ?? null,
        'provider_ack' => md5($email . ':' . time()),
        'provider_status' => !empty($result['success']) ? 'SENT' : 'FAILED',
    ];
}

// --- Main Request Handler ---

function handleResultSendingRequest(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Method not allowed. Use POST.';
        exit;
    }

    enforceSendingAccess();

    $currentUsername = getCurrentUsername();
    if ($currentUsername === null) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'User not identified.';
        exit;
    }

    $returnUrl = sanitizeLocalReturnUrl((string)($_POST['return_url'] ?? ''), 'index.php');

    // Handle: send_result_single
    if (!empty($_POST['send_result_single'])) {
        $mrn = trim((string)($_POST['mrn'] ?? ''));
        $department = trim((string)($_POST['department'] ?? ''));
        $requestCode = trim((string)($_POST['request_code'] ?? ''));
        $sendChannel = trim((string)($_POST['send_channel'] ?? ''));
        $forceResend = !empty($_POST['force_resend']) ? '1' : '0';

        if ($mrn === '' || $requestCode === '' || $sendChannel === '') {
            $_SESSION['error_message'] = 'Missing required fields for single result send.';
            header('Location: ' . $returnUrl);
            exit;
        }

        // Fetch patient and result data
        $patient = getPatientByMrn($mrn);
        if ($patient === null) {
            $_SESSION['error_message'] = 'Patient not found for MRN ' . $mrn;
            header('Location: ' . $returnUrl);
            exit;
        }

        $patientName = trim((string)($patient['patient_name'] ?? ''));
        $phone = trim((string)($patient['care_mobile'] ?? ''));
        $email = trim((string)($patient['email'] ?? ''));

        // Fetch the result to get its ID and link
        $pdo = openResultsDb();
        if ($pdo === null) {
            $_SESSION['error_message'] = 'Database connection failed.';
            header('Location: ' . $returnUrl);
            exit;
        }

        try {
            $sql = "SELECT id, pdf_result_link FROM patient_results 
                    WHERE mrn = :mrn AND request_code = :request_code 
                    ORDER BY last_updated_at DESC LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':mrn' => $mrn, ':request_code' => $requestCode]);
            $result = $stmt->fetch();
            
            if (!is_array($result)) {
                $_SESSION['error_message'] = 'Result not found for this request code.';
                header('Location: ' . $returnUrl);
                exit;
            }

            $resultId = (int)$result['id'];
            $resultLink = trim((string)($result['pdf_result_link'] ?? ''));

            if ($resultLink === '') {
                $_SESSION['error_message'] = 'Result link not available.';
                header('Location: ' . $returnUrl);
                exit;
            }

            $sendSuccess = false;
            $sendResult = [
                'success' => false,
                'error' => 'Unknown error',
                'provider_ack' => null,
                'provider_status' => 'FAILED',
            ];

            // Send via chosen channel
            if ($sendChannel === 'whatsapp' && $phone !== '') {
                $externalLink = rewriteUrlWithExternalHostname($resultLink);
                $templateVars = buildWhatsAppTemplateVars($patientName, $externalLink, $department);
                $sendResult = sendViaWhatsApp($phone, '', $templateVars['template'], null, $templateVars['variables']);
                
                saveSentRecord($resultId, 'result', 'link', $resultLink, $currentUsername, [
                    'provider_ack' => $sendResult['provider_ack'],
                    'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                    'wp_sent' => !empty($sendResult['success']) ? 1 : 0,
                    'wp_last_attempt_at' => date('Y-m-d H:i:s'),
                    'provider_recipient' => $phone,
                    'provider_response' => $sendResult['provider_response'] ?? '',
                ]);
                if (!empty($sendResult['success'])) {
                    $sendSuccess = true;
                }
            } elseif ($sendChannel === 'sms' && $phone !== '') {
                $externalLink = rewriteUrlWithExternalHostname($resultLink);
                $message = buildSmsMessage($patientName, $department, $externalLink);
                $sendResult = sendViaSMS($phone, $message);
                
                saveSentRecord($resultId, 'result', 'link', $resultLink, $currentUsername, [
                    'provider_ack' => $sendResult['provider_ack'],
                    'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                    'sms_sent' => !empty($sendResult['success']) ? 1 : 0,
                    'sms_last_attempt_at' => date('Y-m-d H:i:s'),
                    'provider_recipient' => $phone,
                ]);
                if (!empty($sendResult['success'])) {
                    $sendSuccess = true;
                }
            } elseif ($sendChannel === 'email' && $email !== '') {
                $externalLink = rewriteUrlWithExternalHostname($resultLink);
                $subject = buildEmailSubject($patientName, $department);
                $body = buildEmailBody($patientName, $department, $externalLink);
                $sendResult = sendViaEmail($email, $subject, $body);
                
                saveSentRecord($resultId, 'result', 'link', $resultLink, $currentUsername, [
                    'provider_ack' => $sendResult['provider_ack'],
                    'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                    'email_sent' => !empty($sendResult['success']) ? 1 : 0,
                    'email_last_attempt_at' => date('Y-m-d H:i:s'),
                    'provider_recipient' => $email,
                ]);
                if (!empty($sendResult['success'])) {
                    $sendSuccess = true;
                }
            } else {
                // Contact info missing for the chosen channel
                $sendResult['error'] = 'No ' . strtoupper($sendChannel) . ' contact info available';
                $saveMeta = [
                    'provider_ack' => null,
                    'provider_status' => 'NO_CONTACT_INFO',
                    'provider_recipient' => '',
                ];
                if ($sendChannel === 'sms') {
                    $saveMeta['sms_sent'] = 0;
                    $saveMeta['sms_last_attempt_at'] = date('Y-m-d H:i:s');
                } elseif ($sendChannel === 'email') {
                    $saveMeta['email_sent'] = 0;
                    $saveMeta['email_last_attempt_at'] = date('Y-m-d H:i:s');
                } elseif ($sendChannel === 'whatsapp') {
                    $saveMeta['wp_sent'] = 0;
                    $saveMeta['wp_last_attempt_at'] = date('Y-m-d H:i:s');
                }
                saveSentRecord($resultId, 'result', 'link', $resultLink, $currentUsername, [
                    ...$saveMeta,
                ]);
            }

            if ($sendSuccess) {
                $target = $sendChannel === 'email' ? $email : $phone;
                logSendActivity(
                    $currentUsername,
                    'send_result_single',
                    $mrn,
                    $sendChannel,
                    $sendChannel === 'email' ? null : $phone,
                    $sendChannel === 'email' ? $email : null,
                    'request_code=' . $requestCode . ' force_resend=' . $forceResend
                );
                $_SESSION['success_message'] = sprintf(
                    'Sent result via %s for MRN %s',
                    strtoupper($sendChannel),
                    $mrn
                );
            } else {
                $_SESSION['error_message'] = 'Failed to send via ' . strtoupper($sendChannel) . '. Invalid contact info or API error.';
                logSendActivity(
                    $currentUsername,
                    'send_result_single_failed',
                    $mrn,
                    $sendChannel,
                    $sendChannel === 'email' ? null : $phone,
                    $sendChannel === 'email' ? $email : null,
                    'request_code=' . $requestCode . ' error=' . ($sendResult['error'] ?? 'unknown')
                );
            }
        } catch (Throwable $e) {
            $_SESSION['error_message'] = 'Error: ' . $e->getMessage();
        }

        header('Location: ' . $returnUrl);
        exit;
    }

    // Handle: send_collection_notice
    if (!empty($_POST['send_collection_notice'])) {
        $mrn = trim((string)($_POST['mrn'] ?? ''));
        $sendChannel = trim((string)($_POST['send_channel'] ?? 'whatsapp'));

        if ($mrn === '') {
            $_SESSION['error_message'] = 'Missing MRN for collection notice.';
            header('Location: ' . $returnUrl);
            exit;
        }

        // Fetch patient data
        $patient = getPatientByMrn($mrn);
        if ($patient === null) {
            $_SESSION['error_message'] = 'Patient not found for MRN ' . $mrn;
            header('Location: ' . $returnUrl);
            exit;
        }

        $patientName = trim((string)($patient['patient_name'] ?? ''));
        $phone = trim((string)($patient['care_mobile'] ?? ''));
        $email = trim((string)($patient['email'] ?? ''));

        // Create a new result record for the collection notice
        $pdo = openResultsDb();
        if ($pdo === null) {
            $_SESSION['error_message'] = 'Database connection failed.';
            header('Location: ' . $returnUrl);
            exit;
        }

        try {
            $sql = "INSERT INTO patient_results (
                mrn, department, test_or_image, source, pdf_result_link, manual_filename,
                first_seen_at, last_updated_at
            ) VALUES (
                :mrn, 'Collection Notice', '', 'collection_notice', '[collection_notice]', 'Collection Notice',
                NOW(), NOW()
            )";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':mrn' => $mrn
            ]);
            $resultId = (int)$pdo->lastInsertId();
        } catch (Throwable $e) {
            $_SESSION['error_message'] = 'Failed to create collection notice record.';
            header('Location: ' . $returnUrl);
            exit;
        }

        $sendSuccess = false;

        // Send collection notice via chosen channel
        if ($sendChannel === 'whatsapp' && $phone !== '') {
            $gender = trim((string)($patient['gender'] ?? 'U'));
            [$enTitle, $arTitle] = getGenderBasedTitles($gender);
            // For WhatsApp, use the registered template with variables
            $templateVariables = $enTitle . ',' . $patientName . ',' . $patientName . ',' . $arTitle;
            $sendResult = sendViaWhatsApp($phone, '', 'result_collection', null, $templateVariables);
            
            saveSentRecord($resultId, 'collection_notice', 'link', '', $currentUsername, [
                'provider_ack' => $sendResult['provider_ack'],
                'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                'wp_sent' => !empty($sendResult['success']) ? 1 : 0,
                'wp_last_attempt_at' => date('Y-m-d H:i:s'),
                'provider_recipient' => $phone,
                'provider_response' => $sendResult['provider_response'] ?? '',
            ]);
            if (!empty($sendResult['success'])) {
                $sendSuccess = true;
            }
        } elseif ($sendChannel === 'sms' && $phone !== '') {
            $gender = trim((string)($patient['gender'] ?? 'U'));
            $message = buildCollectionNoticeSmsMessage($patientName, $gender);
            $sendResult = sendViaSMS($phone, $message);
            
            saveSentRecord($resultId, 'collection_notice', 'link', '', $currentUsername, [
                'provider_ack' => $sendResult['provider_ack'],
                'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                'sms_sent' => !empty($sendResult['success']) ? 1 : 0,
                'sms_last_attempt_at' => date('Y-m-d H:i:s'),
                'provider_recipient' => $phone,
            ]);
            if (!empty($sendResult['success'])) {
                $sendSuccess = true;
            }
        } elseif ($sendChannel === 'email' && $email !== '') {
            $gender = trim((string)($patient['gender'] ?? 'U'));
            $subject = buildCollectionNoticeEmailSubject($patientName, $gender);
            $body = buildCollectionNoticeEmailBody($patientName, $gender);
            $sendResult = sendViaEmail($email, $subject, $body);
            
            saveSentRecord($resultId, 'collection_notice', 'link', '', $currentUsername, [
                'provider_ack' => $sendResult['provider_ack'],
                'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                'email_sent' => !empty($sendResult['success']) ? 1 : 0,
                'email_last_attempt_at' => date('Y-m-d H:i:s'),
                'provider_recipient' => $email,
            ]);
            if (!empty($sendResult['success'])) {
                $sendSuccess = true;
            }
        }

        if ($sendSuccess) {
            logSendActivity(
                $currentUsername,
                'send_collection_notice',
                $mrn,
                $sendChannel,
                $sendChannel === 'email' ? null : $phone,
                $sendChannel === 'email' ? $email : null,
                'Collection notice'
            );

            $_SESSION['success_message'] = 'Collection notice sent via ' . strtoupper($sendChannel) . ' for MRN ' . $mrn;
        } else {
            $_SESSION['error_message'] = 'Failed to send collection notice via ' . strtoupper($sendChannel) . '. Invalid contact info or API error.';
            logSendActivity(
                $currentUsername,
                'send_collection_notice_failed',
                $mrn,
                $sendChannel,
                $sendChannel === 'email' ? null : $phone,
                $sendChannel === 'email' ? $email : null,
                'error=' . ($sendResult['error'] ?? 'unknown')
            );
        }

        header('Location: ' . $returnUrl);
        exit;
    }

    // Handle: send_manual_pdf
    if (!empty($_POST['send_manual_pdf'])) {
        $mrn = trim((string)($_POST['mrn'] ?? ''));
        $sendChannel = trim((string)($_POST['send_channel'] ?? ''));

        if ($mrn === '' || $sendChannel === '') {
            $_SESSION['error_message'] = 'Missing required fields for manual PDF send.';
            header('Location: ' . $returnUrl);
            exit;
        }

        if (empty($_FILES['manual_pdf_file']) || $_FILES['manual_pdf_file']['error'] !== UPLOAD_ERR_OK) {
            $_SESSION['error_message'] = 'No valid PDF file uploaded.';
            header('Location: ' . $returnUrl);
            exit;
        }

        // Fetch patient data
        $patient = getPatientByMrn($mrn);
        if ($patient === null) {
            $_SESSION['error_message'] = 'Patient not found for MRN ' . $mrn;
            header('Location: ' . $returnUrl);
            exit;
        }

        $patientName = trim((string)($patient['patient_name'] ?? ''));
        $phone = trim((string)($patient['care_mobile'] ?? ''));
        $email = trim((string)($patient['email'] ?? ''));

        // Get PDF file content
        $pdfContent = @file_get_contents($_FILES['manual_pdf_file']['tmp_name']);
        if ($pdfContent === false) {
            $_SESSION['error_message'] = 'Failed to read PDF file.';
            header('Location: ' . $returnUrl);
            exit;
        }

        $fileName = basename($_FILES['manual_pdf_file']['name']);

        // Always create a NEW record for manual PDF upload (don't update existing results)
        // This keeps the manual upload as a separate card with its own metadata
        $pdo = openResultsDb();
        if ($pdo === null) {
            $_SESSION['error_message'] = 'Database connection failed.';
            header('Location: ' . $returnUrl);
            exit;
        }

        try {
            $sql = "INSERT INTO patient_results (
                mrn, department, test_or_image, request_code, source, pdf_result_link, manual_filename,
                first_seen_at, last_updated_at
            ) VALUES (
                :mrn, 'Manual Upload', '', 'MANUAL_PDF', 'manual_upload', '[manual_upload]', :manual_filename,
                NOW(), NOW()
            )";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':mrn' => $mrn,
                ':manual_filename' => $fileName
            ]);
            $resultId = (int)$pdo->lastInsertId();
        } catch (Throwable $e) {
            error_log('Manual PDF insert failed: ' . $e->getMessage());
            $_SESSION['error_message'] = 'Failed to create result record for manual PDF. Error: ' . $e->getMessage();
            header('Location: ' . $returnUrl);
            exit;
        }

        $sendSuccess = false;

        // Send via chosen channel
        if ($sendChannel === 'whatsapp' && $phone !== '') {
            // Encode PDF as base64 and send as media (no public URL)
            $encoded = base64_encode($pdfContent);

            $templateVars = buildWhatsAppTemplateVars($patientName, '', 'manual_upload');
            $sendResult = sendViaWhatsApp($phone, '', $templateVars['template'], null, $templateVars['variables'], $encoded, $fileName);
            
            saveSentRecord($resultId, 'manual_pdf', 'pdf_upload', $fileName, $currentUsername, [
                'provider_ack' => $sendResult['provider_ack'],
                'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                'wp_sent' => !empty($sendResult['success']) ? 1 : 0,
                'wp_last_attempt_at' => date('Y-m-d H:i:s'),
                'provider_recipient' => $phone,
                'provider_response' => $sendResult['provider_response'] ?? '',
            ]);
            if (!empty($sendResult['success'])) {
                $sendSuccess = true;
            }
        } elseif ($sendChannel === 'email' && $email !== '') {
            $sendResult = sendViaEmail(
                $email,
                buildResultEmailSubject($patientName, $mrn, 'Manual Upload'),
                str_replace('{{1}}', $patientName, getTemplate('email', 'result')),
                [['filename' => $fileName, 'mime_type' => 'application/pdf', 'content' => $pdfContent]]
            );
            
            saveSentRecord($resultId, 'manual_pdf', 'pdf_upload', $fileName, $currentUsername, [
                'provider_ack' => $sendResult['provider_ack'],
                'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                'email_sent' => !empty($sendResult['success']) ? 1 : 0,
                'email_last_attempt_at' => date('Y-m-d H:i:s'),
                'provider_recipient' => $email,
            ]);
            if (!empty($sendResult['success'])) {
                $sendSuccess = true;
            }
        }

        if ($sendSuccess) {
            logSendActivity(
                $currentUsername,
                'send_manual_pdf',
                $mrn,
                $sendChannel,
                $sendChannel === 'email' ? null : $phone,
                $sendChannel === 'email' ? $email : null,
                'filename=' . $fileName . ' status=SENT'
            );
            $_SESSION['success_message'] = sprintf(
                'Manual PDF sent via %s for MRN %s',
                strtoupper($sendChannel),
                $mrn
            );
        } else {
            $_SESSION['error_message'] = 'Failed to send PDF via ' . strtoupper($sendChannel) . '. Invalid contact info or API error.';
            logSendActivity(
                $currentUsername,
                'send_manual_pdf_failed',
                $mrn,
                $sendChannel,
                $sendChannel === 'email' ? null : $phone,
                $sendChannel === 'email' ? $email : null,
                'filename=' . $fileName . ' error=' . ($sendResult['error'] ?? 'unknown')
            );
        }

        header('Location: ' . $returnUrl);
        exit;
    }

    // Handle: send_manual_link
    if (!empty($_POST['send_manual_link'])) {
        $mrn = trim((string)($_POST['mrn'] ?? ''));
        $link = trim((string)($_POST['manual_result_link'] ?? ''));
        $sendChannel = trim((string)($_POST['send_channel'] ?? ''));

        if ($mrn === '' || $link === '' || $sendChannel === '') {
            $_SESSION['error_message'] = 'Missing required fields for manual link send.';
            header('Location: ' . $returnUrl);
            exit;
        }

        // Fetch patient data
        $patient = getPatientByMrn($mrn);
        if ($patient === null) {
            $_SESSION['error_message'] = 'Patient not found for MRN ' . $mrn;
            header('Location: ' . $returnUrl);
            exit;
        }

        $patientName = trim((string)($patient['patient_name'] ?? ''));
        $phone = trim((string)($patient['care_mobile'] ?? ''));
        $email = trim((string)($patient['email'] ?? ''));

        // Always create a NEW record for manual link send (don't update existing results)
        // This keeps the manual send as a separate card with its own metadata
        $pdo = openResultsDb();
        if ($pdo === null) {
            $_SESSION['error_message'] = 'Database connection failed.';
            header('Location: ' . $returnUrl);
            exit;
        }

        try {
            $sql = "INSERT INTO patient_results (
                mrn, department, test_or_image, source, pdf_result_link, manual_filename,
                first_seen_at, last_updated_at
            ) VALUES (
                :mrn, 'Manual Send', '', 'manual_upload', :link, :link,
                NOW(), NOW()
            )";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':mrn' => $mrn,
                ':link' => $link
            ]);
            $resultId = (int)$pdo->lastInsertId();
        } catch (Throwable $e) {
            error_log('Manual link insert failed: ' . $e->getMessage());
            $_SESSION['error_message'] = 'Failed to create result record for manual link. Error: ' . $e->getMessage();
            header('Location: ' . $returnUrl);
            exit;
        }

        $sendSuccess = false;

        // Send via chosen channel
        if ($sendChannel === 'whatsapp' && $phone !== '') {
            $externalLink = rewriteUrlWithExternalHostname($link);
            $templateVars = buildWhatsAppTemplateVars($patientName, $externalLink);
            $sendResult = sendViaWhatsApp($phone, '', $templateVars['template'], null, $templateVars['variables']);
            
            saveSentRecord($resultId, 'result', 'link', $link, $currentUsername, [
                'provider_ack' => $sendResult['provider_ack'],
                'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                'wp_sent' => !empty($sendResult['success']) ? 1 : 0,
                'wp_last_attempt_at' => date('Y-m-d H:i:s'),
                'provider_recipient' => $phone,
                'provider_response' => $sendResult['provider_response'] ?? '',
            ]);
            if (!empty($sendResult['success'])) {
                $sendSuccess = true;
            }
        } elseif ($sendChannel === 'sms' && $phone !== '') {
            $externalLink = rewriteUrlWithExternalHostname($link);
            $message = buildSmsMessage($patientName, '', $externalLink);
            $sendResult = sendViaSMS($phone, $message);
            
            saveSentRecord($resultId, 'result', 'link', $link, $currentUsername, [
                'provider_ack' => $sendResult['provider_ack'],
                'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                'sms_sent' => !empty($sendResult['success']) ? 1 : 0,
                'sms_last_attempt_at' => date('Y-m-d H:i:s'),
                'provider_recipient' => $phone,
            ]);
            if (!empty($sendResult['success'])) {
                $sendSuccess = true;
            }
        } elseif ($sendChannel === 'email' && $email !== '') {
            $externalLink = rewriteUrlWithExternalHostname($link);
            $sendResult = sendViaEmail(
                $email,
                'Your Results Link',
                "Click here to view your results: " . $externalLink
            );
            
            saveSentRecord($resultId, 'result', 'link', $link, $currentUsername, [
                'provider_ack' => $sendResult['provider_ack'],
                'provider_status' => $sendResult['provider_status'] ?? 'FAILED',
                'email_sent' => !empty($sendResult['success']) ? 1 : 0,
                'email_last_attempt_at' => date('Y-m-d H:i:s'),
                'provider_recipient' => $email,
            ]);
            if (!empty($sendResult['success'])) {
                $sendSuccess = true;
            }
        }

        if ($sendSuccess) {
            logSendActivity(
                $currentUsername,
                'send_manual_link',
                $mrn,
                $sendChannel,
                $sendChannel === 'email' ? null : $phone,
                $sendChannel === 'email' ? $email : null,
                'link=' . substr($link, 0, 50) . ' status=SENT'
            );
            $_SESSION['success_message'] = sprintf(
                'Manual link sent via %s for MRN %s',
                strtoupper($sendChannel),
                $mrn
            );
        } else {
            $_SESSION['error_message'] = 'Failed to send via ' . strtoupper($sendChannel) . '. Invalid contact info or API error.';
            logSendActivity(
                $currentUsername,
                'send_manual_link_failed',
                $mrn,
                $sendChannel,
                $sendChannel === 'email' ? null : $phone,
                $sendChannel === 'email' ? $email : null,
                'link=' . substr($link, 0, 50) . ' error=' . ($sendResult['error'] ?? 'unknown')
            );
        }

        header('Location: ' . $returnUrl);
        exit;
    }

    // No recognized action
    $_SESSION['error_message'] = 'No valid action recognized.';
    header('Location: ' . $returnUrl);
    exit;
}

// Process the request only if this file is directly accessed (not included)
if (PHP_SAPI !== 'cli' && PHP_SAPI !== 'phpdbg' && basename(__FILE__) === basename($_SERVER['PHP_SELF'] ?? '')) {
    handleResultSendingRequest();
}

?>


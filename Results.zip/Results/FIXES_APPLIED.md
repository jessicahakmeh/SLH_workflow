# Auto-Send Fixes Applied - 2026-09-09

## Problem
MRN 165254 (request code 2777) with an old visit date (2026-06-23) was being flagged for sending when the JSON file was re-imported on 2026-09-09, even though the result link had not been added today.

## Root Causes

### 1. result_link_added_at Updated on Re-import
The `upsertPatientResult()` function was updating `result_link_added_at` to the current timestamp even when re-importing existing results with the same link. This caused old results to appear "fresh" and pass the auto-send time window filters.

**Old Logic** (line 541-542):
```php
} elseif ($prevLink !== '' && $resultLink !== '' && $prevLink !== $resultLink) {
    $resultLinkAddedAt = $now;  // ← Updates timestamp on any link change, even minor ones
```

### 2. No Visit Date Filter
The `getPendingAutoSendResults()` query had no check for visit date, allowing results from old visits (2026-06-23) to be sent if they passed the `result_link_added_at` window.

## Solutions Applied

### Fix #1: Preserve result_link_added_at on Re-import
**File:** `sent_results_db.php` (lines 535-548)

Changed the logic to **NEVER** update `result_link_added_at` unless the link goes from empty to non-empty (truly new link):

```php
} else {
    // Existing record: NEVER update result_link_added_at on re-import
    // The timestamp should only reflect when the link was FIRST made available, not when JSON was re-imported
    $prevLink = trim((string)($existing['pdf_result_link'] ?? ''));
    $prevAddedAt = $existing['result_link_added_at'] ?? null;
    if ($prevLink === '' && $resultLink !== '') {
        // Link was previously empty, now has content - this is new link availability
        $resultLinkAddedAt = $now;
    } else {
        // Link existed before (same or different) - preserve original timestamp
        // This prevents old results from being re-sent just because JSON was re-imported
        $resultLinkAddedAt = $prevAddedAt;
    }
}
```

**Effect:** `result_link_added_at` now represents when a link was FIRST made available to the system, not when the JSON file was re-imported.

### Fix #2: Add Visit Date Filter to Auto-Send Query
**File:** `sent_results_db.php` (lines 1012-1015)

Added a critical filter to only send results for recent visits (within 90 days):

```php
// CRITICAL: Only send results for recent visits (within 90 days)
// This prevents sending results from old visits that are just being re-imported
$ninetyDaysAgo = date('Y-m-d', strtotime('-90 days'));
$sql .= " AND pr.visit_date >= '{$ninetyDaysAgo}'";
```

**Effect:** Results are now filtered by visit date, preventing old visits (like 2026-06-23) from being sent regardless of when the link was added.

## Result for MRN 165254

**Before Fixes:**
- visit_date: 2026-06-23 ❌ Old visit
- result_link_added_at: 2026-09-09 13:35:05 (Updated on re-import) ❌ Appears fresh
- Status: Would be sent ✉️

**After Fixes:**
- visit_date: 2026-06-23 ❌ Fails `visit_date >= 2026-06-10` filter
- result_link_added_at: 2026-06-23 (Preserved from original) ❌ Old link
- Status: Will NOT be sent ✅

## Configuration

The 90-day window can be adjusted by modifying the `strtotime('-90 days')` value in the query filter to a different number of days as needed.

## Future Re-imports

When MRN 165254's JSON file is re-imported:
- Patient data will be updated (name, contact info, etc.)
- Test/image descriptions will be merged
- **result_link_added_at will NOT be updated** (still shows original date)
- **result will NOT be sent** (fails visit date filter)

This prevents old results from being accidentally re-sent whenever their JSON file is re-processed.

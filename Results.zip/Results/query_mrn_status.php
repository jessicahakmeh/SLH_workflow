<?php

declare(strict_types=1);

require_once __DIR__ . '/env.php';
require_once __DIR__ . '/sent_results_db.php';

loadEnvFile();

echo "=== MRN 165254 Status Check ===\n\n";

// Get last run marker
$lastRunFile = __DIR__ . '/logs/send_pending_last_run.txt';
$lastRunTime = file_exists($lastRunFile) ? trim(file_get_contents($lastRunFile)) : 'N/A';
echo "Last send_pending_results run: $lastRunTime\n";

// Check current time
echo "Current time: " . date('Y-m-d H:i:s') . "\n\n";

// Force connection to 192.168.20.17
try {
    $pdo = new PDO(
        'mysql:host=192.168.20.17;port=3306;dbname=SLHCycle;charset=utf8mb4',
        'root',
        '',
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (Throwable $e) {
    echo "ERROR: Could not connect to 192.168.20.17:3306\n";
    echo "Error details: " . $e->getMessage() . "\n";
    exit(1);
}

// Open database - but we already have it, so just reuse
if ($pdo === null) {
    echo "ERROR: Could not connect to database\n";
    exit(1);
}

// Query for MRN 165254 results
$sql = "SELECT pr.id AS result_id,
               pr.mrn,
               pr.request_code,
               pr.department,
               pr.test_or_image,
               pr.pdf_result_link,
               pr.result_link_added_at,
               pr.source,
               p.patient_name,
               p.care_mobile,
               p.email,
               sr.id AS sent_id,
               sr.wp_sent,
               sr.sms_sent,
               sr.email_sent,
               sr.wp_last_attempt_at,
               sr.sms_last_attempt_at,
               sr.email_last_attempt_at
        FROM patient_results AS pr
        LEFT JOIN patients AS p ON p.mrn = pr.mrn
        LEFT JOIN sent_results AS sr ON sr.result_id = pr.id AND sr.template_type = 'result'
        WHERE pr.mrn = '165254'
        ORDER BY pr.request_code ASC";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $rows = $stmt->fetchAll();
    
    if (empty($rows)) {
        echo "No results found for MRN 165254\n";
        exit(0);
    }
    
    echo "Found " . count($rows) . " result(s) for MRN 165254:\n\n";
    
    foreach ($rows as $row) {
        echo "---\n";
        echo "Result ID: " . $row['result_id'] . "\n";
        echo "Request Code: " . $row['request_code'] . "\n";
        echo "Test/Image: " . $row['test_or_image'] . "\n";
        echo "Department: " . $row['department'] . "\n";
        echo "Source: " . $row['source'] . "\n";
        echo "Result Link Added At: " . $row['result_link_added_at'] . "\n";
        echo "PDF Link: " . substr($row['pdf_result_link'], 0, 80) . (strlen($row['pdf_result_link']) > 80 ? "..." : "") . "\n";
        echo "Patient Name: " . $row['patient_name'] . "\n";
        echo "Mobile: " . $row['care_mobile'] . "\n";
        echo "Email: " . $row['email'] . "\n";
        echo "\nSent Status:\n";
        echo "  - Sent Record ID: " . ($row['sent_id'] ? $row['sent_id'] : "None") . "\n";
        echo "  - WhatsApp Sent: " . ($row['wp_sent'] ? "Yes (Last: " . $row['wp_last_attempt_at'] . ")" : "No/Not Attempted") . "\n";
        echo "  - SMS Sent: " . ($row['sms_sent'] ? "Yes (Last: " . $row['sms_last_attempt_at'] . ")" : "No/Not Attempted") . "\n";
        echo "  - Email Sent: " . ($row['email_sent'] ? "Yes (Last: " . $row['email_last_attempt_at'] . ")" : "No/Not Attempted") . "\n";
        
        // Determine if it will be sent in next run
        echo "\nWill be sent in NEXT run?\n";
        
        $willBeSent = true;
        $reasons = [];
        
        // Check source
        if ($row['source'] !== 'json_import') {
            $willBeSent = false;
            $reasons[] = "Source is '{$row['source']}', not 'json_import'";
        }
        
        // Check department
        if (!in_array($row['department'], ['Laboratory', 'Radiology'])) {
            $willBeSent = false;
            $reasons[] = "Department '{$row['department']}' not in [Laboratory, Radiology]";
        }
        
        // Check PDF link exists
        if (empty($row['pdf_result_link'])) {
            $willBeSent = false;
            $reasons[] = "PDF result link is empty";
        }
        
        // Check result_link_added_at
        if (empty($row['result_link_added_at'])) {
            $willBeSent = false;
            $reasons[] = "result_link_added_at is null";
        } else {
            // Check if it's within the window (1 month ago or AUTO_SEND_START_DATE)
            $oneMonthAgo = date('Y-m-d 00:00:00', strtotime('-1 month'));
            if ($row['result_link_added_at'] < $oneMonthAgo) {
                $willBeSent = false;
                $reasons[] = "result_link_added_at ({$row['result_link_added_at']}) is older than 1 month ({$oneMonthAgo})";
            }
        }
        
        if ($willBeSent) {
            echo "✓ YES - This result WILL be sent on next run\n";
            echo "  Reason: Result is pending (no sent record or link has changed)\n";
        } else {
            echo "✗ NO - This result will NOT be sent\n";
            foreach ($reasons as $reason) {
                echo "  - $reason\n";
            }
        }
        echo "\n";
    }
    
} catch (Throwable $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    exit(1);
}

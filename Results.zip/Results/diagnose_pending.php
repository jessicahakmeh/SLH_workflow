<?php
declare(strict_types=1);

require 'env.php';
loadEnvFile();

echo "=== DATABASE DIAGNOSTIC ===\n";
echo "Connected Database: " . envValue('DB_NAME') . "\n";
echo "Host: " . envValue('DB_HOST') . ":" . envValue('DB_PORT') . "\n";
echo "User: " . envValue('DB_USER') . "\n\n";

try {
    $pdo = new PDO(
        'mysql:host=' . envValue('DB_HOST') . ';port=' . envValue('DB_PORT') . ';dbname=' . envValue('DB_NAME'),
        envValue('DB_USER'),
        envValue('DB_PASS'),
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    echo "✓ Database connection successful\n\n";
    
    // Check if patient_results table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'patient_results'");
    $tableExists = $stmt->rowCount() > 0;
    echo "patient_results table exists: " . ($tableExists ? "YES" : "NO") . "\n";
    
    if ($tableExists) {
        // Get count and sample
        $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM patient_results");
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['cnt'];
        echo "Total records: $count\n\n";
        
        // Check date range
        $stmt = $pdo->query("SELECT MIN(result_link_added_at) as min_date, MAX(result_link_added_at) as max_date FROM patient_results WHERE result_link_added_at IS NOT NULL");
        $dates = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "Date range: " . $dates['min_date'] . " to " . $dates['max_date'] . "\n\n";
        
        // Check for results released today
        $today = date('Y-m-d');
        $stmt = $pdo->prepare('
            SELECT COUNT(*) as cnt 
            FROM patient_results 
            WHERE DATE(result_link_added_at) = ?
            AND department IN ("Laboratory", "Radiology")
            AND pdf_result_link IS NOT NULL
            AND pdf_result_link <> ""
        ');
        $stmt->execute([$today]);
        $todayCount = $stmt->fetch(PDO::FETCH_ASSOC)['cnt'];
        echo "Results released TODAY ($today): $todayCount\n\n";
        
        // Check AUTO_SEND window
        $envStart = trim((string)getenv('AUTO_SEND_START_DATE'));
        $oneMonthAgoTs = strtotime('-1 month');
        $startTs = $oneMonthAgoTs;
        if ($envStart !== '' && strtotime($envStart) !== false) {
            $envTs = strtotime($envStart);
            if ($envTs > $oneMonthAgoTs) {
                $startTs = $envTs;
            }
        }
        $startDateFormatted = date('Y-m-d', $startTs);
        $thirtyDaysAgo = date('Y-m-d', strtotime('-30 days'));
        
        echo "AUTO_SEND_START_DATE: " . ($envStart ?: 'not set, using 1 month ago') . "\n";
        echo "Effective send window start: $startDateFormatted\n";
        echo "Visit date filter (30 days back): $thirtyDaysAgo\n\n";
        
        // Query using the same logic as getPendingAutoSendResults
        $sql = "
            SELECT pr.id, pr.mrn, pr.request_code, pr.department,
                   pr.pdf_result_link, pr.result_link_added_at, pr.visit_date,
                   pr.source, p.patient_name, p.care_mobile, p.email,
                   sr.id as sent_id, sr.content_value
            FROM patient_results AS pr
            INNER JOIN patients AS p ON p.mrn = pr.mrn
            LEFT JOIN sent_results AS sr ON sr.result_id = pr.id AND sr.template_type = 'result'
            WHERE pr.source = 'json_import'
            AND pr.department IN ('Laboratory', 'Radiology')
            AND pr.pdf_result_link IS NOT NULL
            AND pr.pdf_result_link <> ''
            AND pr.result_link_added_at >= '$startDateFormatted'
            AND pr.visit_date >= '$thirtyDaysAgo'
            ORDER BY pr.result_link_added_at DESC
            LIMIT 50
        ";
        
        echo "=== RESULTS MATCHING AUTO_SEND CRITERIA ===\n";
        $stmt = $pdo->query($sql);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo "Total matching: " . count($results) . "\n\n";
        
        if (count($results) > 0) {
            foreach ($results as $row) {
                $status = empty($row['sent_id']) ? 'PENDING' : 'SENT';
                echo "MRN: {$row['mrn']} | Code: {$row['request_code']} | Dept: {$row['department']} | Added: {$row['result_link_added_at']} | Status: $status\n";
                if (!empty($row['care_mobile'])) {
                    echo "  Phone: {$row['care_mobile']}\n";
                }
                if (!empty($row['email'])) {
                    echo "  Email: {$row['email']}\n";
                }
            }
        } else {
            echo "NO RESULTS FOUND MATCHING AUTO_SEND CRITERIA!\n";
            echo "This explains why nothing was sent.\n\n";
            
            // Check what's in the table without filters
            echo "=== ALL RECENT RESULTS (no filters) ===\n";
            $stmt = $pdo->query("
                SELECT pr.id, pr.mrn, pr.request_code, pr.department,
                       pr.result_link_added_at, pr.visit_date, pr.source
                FROM patient_results AS pr
                ORDER BY pr.result_link_added_at DESC
                LIMIT 10
            ");
            $recent = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($recent as $row) {
                echo "MRN: {$row['mrn']} | Code: {$row['request_code']} | Dept: {$row['department']} | Source: {$row['source']} | Added: {$row['result_link_added_at']}\n";
            }
        }
    }
    
} catch (Exception $e) {
    echo "✗ Database connection failed: " . $e->getMessage() . "\n";
}
?>

<?php
require_once __DIR__ . '/env.php';
loadEnvFile();

echo "=== PHP CLI Database Connection Diagnostics ===\n";
echo "PHP Version: " . PHP_VERSION . "\n";
echo "SAPI: " . PHP_SAPI . "\n\n";

echo "Database Configuration:\n";
echo "  DB_HOST: " . (string)(envValue('DB_HOST', '') ?? '') . "\n";
echo "  DB_PORT: " . (string)(envValue('DB_PORT', '') ?? '') . "\n";
echo "  DB_NAME: " . (string)(envValue('DB_NAME', '') ?? '') . "\n";
echo "  DB_USER: " . (string)(envValue('DB_USER', '') ?? '') . "\n";
echo "  DB_PASS: " . (strlen((string)(envValue('DB_PASS', '') ?? '')) > 0 ? "(set)" : "(empty)") . "\n\n";

echo "PDO Drivers Available: " . implode(', ', PDO::getAvailableDrivers()) . "\n\n";

$host = (string)(envValue('DB_HOST', '') ?? '');
$port = (string)(envValue('DB_PORT', '') ?? '');
$name = (string)(envValue('DB_NAME', '') ?? '');
$user = (string)(envValue('DB_USER', '') ?? '');
$pass = (string)(envValue('DB_PASS', '') ?? '');

echo "Attempting connection...\n";
$start = microtime(true);

try {
    $dsn = "mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4";
    echo "DSN: $dsn\n";
    echo "Connecting... ";
    
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_TIMEOUT => 5,
    ]);
    
    $elapsed = round((microtime(true) - $start) * 1000);
    echo "SUCCESS in {$elapsed}ms\n\n";
    
    $result = $pdo->query('SELECT 1')->fetch();
    echo "Test Query Result: " . json_encode($result) . "\n";
    
} catch (PDOException $e) {
    $elapsed = round((microtime(true) - $start) * 1000);
    echo "FAILED after {$elapsed}ms\n";
    echo "Error Code: " . $e->getCode() . "\n";
    echo "Error Message: " . $e->getMessage() . "\n";
    
    // Try to get more detailed error info
    if (strpos($e->getMessage(), '[2002]') !== false) {
        echo "\nNote: Error 2002 typically means:\n";
        echo "  - MySQL server is not running\n";
        echo "  - Server is listening on a different host/port\n";
        echo "  - Firewall is blocking the connection\n";
    }
}
?>

<?php

declare(strict_types=1);

require_once __DIR__ . '/sent_results_db.php';

if (!defined('JSON_PATH')) {
    define('JSON_PATH', rtrim((string)getenv('JSON_PATH'), '/\\\\') . DIRECTORY_SEPARATOR);
}

if (!defined('SETUP_JSON_LOG_FILE')) {
    define('SETUP_JSON_LOG_FILE', __DIR__ . '/logs/setup_json.log');
}

if (!defined('IMPORT_AUTOSEND_READY_FILE')) {
    define('IMPORT_AUTOSEND_READY_FILE', __DIR__ . '/logs/import_autosend_ready.flag');
}

// Log rotation constant
const SETUP_JSON_LOG_MAX_SIZE = 52428800; // 50MB in bytes

/**
 * Rotate log file if it exceeds 50MB
 * Renames existing log to filename.YYYY-MM-DD_HH-MM-SS.log
 * @param string $logFile Full path to the log file
 */
function rotateSetupJsonLogIfNeeded(string $logFile): void
{
    if (!file_exists($logFile)) {
        return;
    }

    $fileSize = @filesize($logFile);
    if ($fileSize === false || $fileSize < SETUP_JSON_LOG_MAX_SIZE) {
        return;
    }

    // File exceeds 50MB, rotate it
    $timestamp = date('Y-m-d_H-i-s');
    $pathInfo = pathinfo($logFile);
    $rotatedFile = $pathInfo['dirname'] . '/' . $pathInfo['filename'] . '.' . $timestamp . '.log';

    // Attempt to rename the old log file
    if (@rename($logFile, $rotatedFile)) {
        // Successfully rotated, new log file will be created on next write
        error_log("Setup JSON log rotated: $logFile -> $rotatedFile");
    }
}

if (!defined('NETWORK_SHARE_USERNAME')) {
    define('NETWORK_SHARE_USERNAME', 'stlouis\\appuser');
}

if (!defined('NETWORK_SHARE_PASSWORD')) {
    define('NETWORK_SHARE_PASSWORD', '$ecure@pp');
}

function mountNetworkShareWithCredentials(string $sharePath): bool
{
    if (strtoupper(substr(PHP_OS, 0, 3)) !== 'WIN') {
        // Not on Windows, skip mounting
        return true;
    }

    // Extract the UNC path 
    $uncPath = rtrim($sharePath, '\\/' . DIRECTORY_SEPARATOR);
    
    // Use cmd.exe with net use command
    $command = sprintf(
        'net use * "%s" /user:%s %s /persistent:no',
        $uncPath,
        escapeshellarg(NETWORK_SHARE_USERNAME),
        escapeshellarg(NETWORK_SHARE_PASSWORD)
    );

    $output = [];
    $returnCode = 0;
    exec($command . ' 2>&1', $output, $returnCode);

    // net use returns 0 on success or if share is already mounted
    return $returnCode === 0;
}

function setupJsonIsCli(): bool
{
    return PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';
}

function setupJsonWrite(string $line): void
{
    echo $line . PHP_EOL;
}

function setupJsonLog(string $level, string $message): void
{
    $dir = dirname(SETUP_JSON_LOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }

    rotateSetupJsonLogIfNeeded(SETUP_JSON_LOG_FILE);
    $line = sprintf("[%s] [%s] %s\n", date('Y-m-d H:i:s'), strtoupper($level), $message);
    @file_put_contents(SETUP_JSON_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

function markImportAutosendReadyFromSetup(): void
{
    $dir = dirname(IMPORT_AUTOSEND_READY_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
    }

    @file_put_contents(IMPORT_AUTOSEND_READY_FILE, date('Y-m-d H:i:s') . ' baseline-from-setup_json', LOCK_EX);
}

function setupJsonExtractPatientField(array $json, string $key): string
{
    $value = trim((string)($json[$key] ?? ''));
    if ($value !== '') {
        return $value;
    }

    $patient = $json['Patient'] ?? null;
    if (is_array($patient)) {
        return trim((string)($patient[$key] ?? ''));
    }

    return '';
}

function setupJsonExtractRequestCode(array $request): string
{
    $requestCode = trim((string)($request['RequestCode'] ?? ''));
    if ($requestCode !== '') {
        return $requestCode;
    }

    $requestCode = trim((string)($request['LabNo'] ?? ''));
    if ($requestCode !== '') {
        return $requestCode;
    }

    $link = trim((string)($request['PDFResultLink'] ?? ''));
    if ($link === '') {
        return '';
    }

    $parts = @parse_url($link);
    if (!is_array($parts) || empty($parts['query'])) {
        return '';
    }

    $query = [];
    parse_str((string)$parts['query'], $query);
    return trim((string)($query['labNo'] ?? ($query['LabNo'] ?? ($query['acc'] ?? ''))));
}

function setupJsonNormalizeImportDepartment(string $department): string
{
    $dep = strtolower(trim($department));
    if ($dep === 'laboratory' || $dep === 'lab') {
        return 'Laboratory';
    }
    if ($dep === 'radiology' || strpos($dep, 'imaging') !== false) {
        return 'Radiology';
    }

    return '';
}

function setupJsonImportFile(string $filePath): array
{
    $fileName = basename($filePath);
    $filenameMrn = sanitizeMrn(pathinfo($fileName, PATHINFO_FILENAME));
    if ($filenameMrn === '') {
        return ['imported' => 0, 'skipped' => 1, 'status' => 'error', 'error' => 'Invalid filename MRN'];
    }

    $content = @file_get_contents($filePath);
    if ($content === false || trim($content) === '') {
        return ['imported' => 0, 'skipped' => 1, 'status' => 'error', 'error' => 'Empty or unreadable file'];
    }

    $fileHash = hash('sha256', $content);
    $json = json_decode($content, true);
    if (!is_array($json)) {
        return ['imported' => 0, 'skipped' => 1, 'status' => 'error', 'error' => 'Malformed JSON'];
    }

    $jsonMrn = sanitizeMrn((string)($json['MRN'] ?? ''));
    if ($jsonMrn !== '' && strcasecmp($jsonMrn, $filenameMrn) !== 0) {
        return ['imported' => 0, 'skipped' => 1, 'status' => 'error', 'error' => 'MRN mismatch between filename and JSON'];
    }

    $patientName = setupJsonExtractPatientField($json, 'PatientName');
    if ($patientName === '') {
        $patientName = setupJsonExtractPatientField($json, 'FullName');
    }
    if ($patientName === '') {
        $patientName = $filenameMrn;
    }

    $phone = setupJsonExtractPatientField($json, 'PhoneNumber');
    if ($phone === '') {
        $phone = setupJsonExtractPatientField($json, 'Mobile');
    }

    $email = setupJsonExtractPatientField($json, 'Email');
    if ($email === '') {
        $email = setupJsonExtractPatientField($json, 'EmailAddress');
    }

    $dateOfBirth = normalizeDateOnly(setupJsonExtractPatientField($json, 'DOB'));
    if ($dateOfBirth === null) {
        $dateOfBirth = normalizeDateOnly(setupJsonExtractPatientField($json, 'DateOfBirth'));
    }

    $patientId = getOrCreatePatientId($filenameMrn, $patientName, $phone, $email, $dateOfBirth);
    if ($patientId === null) {
        return ['imported' => 0, 'skipped' => 1, 'status' => 'error', 'error' => 'Failed to create/update patient'];
    }

    $visits = $json['Visits'] ?? null;
    if (!is_array($visits)) {
        $visits = [];
    }

    $importedCount = 0;
    $skippedCount = 0;

    foreach ($visits as $visit) {
        if (!is_array($visit)) {
            $skippedCount++;
            continue;
        }

        $visitDate = normalizeDateOnly((string)($visit['VisitDate'] ?? ''));
        $endVisitDate = normalizeDateOnly((string)($visit['EndVisitDate'] ?? ''));
        $caseNumber = trim((string)($visit['CaseNumber'] ?? ''));
        $doctorName = trim((string)($visit['DoctorName'] ?? ''));
        $doctorSpecialty = trim((string)($visit['DoctorSpecialty'] ?? ''));

        $requests = $visit['Requests'] ?? null;
        if (!is_array($requests)) {
            $skippedCount++;
            continue;
        }

        foreach ($requests as $request) {
            if (!is_array($request)) {
                $skippedCount++;
                continue;
            }

            $department = setupJsonNormalizeImportDepartment((string)($request['Department'] ?? ''));
            if ($department === '') {
                $skippedCount++;
                continue;
            }

            $requestCode = setupJsonExtractRequestCode($request);
            if ($requestCode === '') {
                $skippedCount++;
                continue;
            }

            $testOrImage = trim((string)($request['TestOrImage'] ?? ''));
            if ($testOrImage === '') {
                $testOrImage = $department === 'Laboratory' ? 'Laboratory Result' : 'Imaging Result';
            }

            $link = trim((string)($request['PDFResultLink'] ?? ''));
            if ($link === '') {
                $skippedCount++;
                continue;
            }

            $ok = upsertPatientResult([
                'mrn' => $filenameMrn,
                'patient_name' => $patientName,
                'care_mobile' => $phone,
                'email' => $email,
                'date_of_birth' => $dateOfBirth,
                'department' => $department,
                'test_or_image' => $testOrImage,
                'request_code' => $requestCode,
                'pdf_result_link' => $link,
                'visit_date' => $visitDate,
                'end_visit_date' => $endVisitDate,
                'case_number' => $caseNumber,
                'doctor_name' => $doctorName,
                'doctor_specialty' => $doctorSpecialty,
                'source' => 'json_import',
                'json_file_hash' => $fileHash,
                'manual_filename' => null,
            ]);

            if ($ok) {
                $importedCount++;
            } else {
                $skippedCount++;
            }
        }
    }

    $status = $importedCount > 0 ? 'imported' : 'skipped';
    $error = $importedCount > 0 ? '' : 'No valid requests found in file (patient record updated).';

    insertImportLog([
        'mrn' => $filenameMrn,
        'file_name' => $fileName,
        'file_hash' => $fileHash,
        'status' => $status,
        'imported_count' => $importedCount,
        'skipped_count' => $skippedCount,
        'error_message' => $error,
    ]);

    return ['imported' => $importedCount, 'skipped' => $skippedCount, 'status' => $status, 'error' => $error];
}

function setupJsonRun(): int
{
    if (!setupJsonIsCli()) {
        $isLocalhost = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', 'localhost'], true);
        if (!$isLocalhost) {
            http_response_code(403);
            header('Content-Type: text/plain; charset=UTF-8');
            echo "Forbidden. setup_json.php is only available from localhost.\n";
            return 1;
        }
    }

    $pdo = openResultsDb();
    if ($pdo === null) {
        setupJsonWrite('Database connection failed.');
        setupJsonLog('error', 'Database connection failed');
        return 1;
    }

    // Mount network share with credentials
    if (!mountNetworkShareWithCredentials(JSON_PATH)) {
        setupJsonLog('warn', 'Could not mount network share, will attempt to access directly');
    }

    if (!is_dir(JSON_PATH) || !is_readable(JSON_PATH)) {
        setupJsonWrite('JSON folder is missing or unreadable: ' . JSON_PATH);
        setupJsonLog('error', 'JSON folder is missing or unreadable: ' . JSON_PATH);
        return 1;
    }

    $files = glob(JSON_PATH . '*.json');
    if (!is_array($files)) {
        setupJsonWrite('Failed to scan JSON folder: ' . JSON_PATH);
        setupJsonLog('error', 'Failed to scan JSON folder: ' . JSON_PATH);
        return 1;
    }

    sort($files);

    if (empty($files)) {
        setupJsonWrite('No JSON files found in: ' . JSON_PATH);
        setupJsonLog('info', 'No JSON files found in: ' . JSON_PATH);
        return 0;
    }

    $totalImported = 0;
    $totalSkipped = 0;
    $processedFiles = 0;

    setupJsonWrite('Starting full JSON setup import. Files found: ' . count($files));
    setupJsonLog('info', 'Starting full JSON setup import. Files found: ' . count($files));

    foreach ($files as $filePath) {
        if (!is_file($filePath)) {
            continue;
        }

        $processedFiles++;
        $result = setupJsonImportFile($filePath);
        $totalImported += (int)($result['imported'] ?? 0);
        $totalSkipped += (int)($result['skipped'] ?? 0);

        setupJsonLog(
            (string)($result['status'] ?? 'info'),
            basename($filePath) . ' imported=' . (int)($result['imported'] ?? 0) . ' skipped=' . (int)($result['skipped'] ?? 0) .
            ((string)($result['error'] ?? '') !== '' ? ' error=' . (string)$result['error'] : '')
        );
    }

    $summary = sprintf(
        'Completed setup import: files=%d, imported=%d, skipped=%d',
        $processedFiles,
        $totalImported,
        $totalSkipped
    );

    setupJsonWrite($summary);
    setupJsonLog('info', $summary);

    // Auto-send baseline decision: if AUTO_SEND_ON_IMPORT is disabled (0), mark baseline
    // so newly imported results won't be sent until next incremental import cycle.
    // If AUTO_SEND_ON_IMPORT is enabled (1), don't mark baseline so results are eligible for send_pending.
    $autoSendOnImport = strtolower((string)getenv('AUTO_SEND_ON_IMPORT')) === '1';
    if (!$autoSendOnImport) {
        markImportAutosendReadyFromSetup();
        setupJsonLog('info', 'AUTO_SEND_ON_IMPORT=0: Baseline marked, imported results deferred from auto-send.');
    } else {
        setupJsonLog('info', 'AUTO_SEND_ON_IMPORT=1: Baseline NOT marked, imported results eligible for auto-send.');
    }

    return 0;
}

$exitCode = setupJsonRun();
exit($exitCode);

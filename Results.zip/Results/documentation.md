# Results Management System - Complete Documentation

## Table of Contents
1. [System Overview](#system-overview)
2. [Core Features](#core-features)
3. [System Architecture](#system-architecture)
4. [User Roles & Permissions](#user-roles--permissions)
5. [System Rules & Workflow](#system-rules--workflow)
6. [Database Structure](#database-structure)
7. [Configuration & Environment Variables](#configuration--environment-variables)
8. [File Structure](#file-structure)
9. [Non-Developer Modification Guide](#non-developer-modification-guide)
10. [Logs & Monitoring](#logs--monitoring)
11. [Troubleshooting](#troubleshooting)

---

## System Overview

**Results Management System** is a multi-role patient result distribution platform designed for healthcare organizations to automate and manage result delivery across multiple communication channels (WhatsApp, SMS, Email).

**Key Characteristics:**
- Automated daily result distribution based on result availability timestamps
- Manual sending capabilities with department-based restrictions
- Role-based access control with 5 distinct permission levels
- Active Directory (LDAP) authentication with local admin fallback
- Per-channel delivery tracking and retry mechanisms
- Comprehensive audit logging for compliance

**System Location:** `z:\htdocs\Results\`

---

## Core Features

### 1. **Automated Result Distribution**
- **Trigger**: Daily execution at 16:00 (configurable timezone)
- **Scope**: Targets results where `result_link_added_at` timestamp is within processing window
- **Channels**: WhatsApp, SMS, Email (can be independently enabled/disabled)
- **Retry Logic**: Automatic retry up to 14 days (configurable)
- **Execution**: CLI-only access via scheduled task (`send_pending_results.php`)

### 2. **Manual Result Sending**
- **PDF Delivery**: Direct file attachment via WhatsApp/SMS/Email
- **Link Sharing**: Full or truncated URLs depending on user role
- **Collection Notice**: Automated notice requesting sample collection
- **Resend**: Retry failed sends from dashboard

### 3. **Patient Result Viewing**
- **Public Access**: No login required via patient MRN lookup
- **Secure**: Patient views only their own results
- **Multi-Department**: Aggregates results from Lab and Imaging

### 4. **Delivery Status Tracking**
- **Per-Channel Timestamps**: `wp_last_attempt_at`, `sms_last_attempt_at`, `email_last_attempt_at`
- **Success Indicators**: `wp_sent=1`, `sms_sent=0`, etc. (binary flags)
- **Failure Recording**: Failed sends displayed with timestamps and reasons

### 5. **Audit Trail & Compliance**
- **Activity Logging**: All send operations (success AND failure) recorded
- **User Attribution**: Logged username for all actions
- **Searchable Log**: Filter by date range, channel, result MRN
- **Permanent Records**: Database + text file backup

### 6. **User Management**
- **Role Assignment**: Assign roles (master, butler, lab, imaging, doctor)
- **Access Control**: Enforce department-level filtering
- **Session Management**: 24-hour inactivity timeout

---

## System Architecture

### Data Flow Overview

```
JSON Files (\\network\share\path\)
    ↓
Import Engine (every 5 minutes)
    ↓
MySQL Database (SLHCycle)
    ↓
Dashboard Display & Auto-Send Processing
    ↓
Communication Channels (WhatsApp, SMS, Email)
    ↓
Delivery Status Tracking
    ↓
Activity Log & Reports
```

### Core Processing Pipelines

#### **A. Import Pipeline** (`imports/import_json.php`)
| Step | Process | Details |
|------|---------|---------|
| 1 | Mount Network Share | Windows: Mounts `\\network\share\path\` using credentials from `.env` |
| 2 | Read JSON Files | Scans JSON_PATH directory for patient/result files |
| 3 | Parse Patient Data | Extracts: MRN, first_name, last_name, mobile, email |
| 4 | Parse Result Data | Extracts: test_type, result_description, result_link, department (Lab/Imaging) |
| 5 | Upsert to Database | Inserts or updates patients and results tables |
| 6 | Set Timestamp | Records `result_link_added_at` when result link first appears |
| 7 | Update Marker | Writes timestamp to `logs/last_run.txt` to prevent re-processing |
| 8 | Lock File | Uses `logs/import.lock` to prevent concurrent execution |

**Configuration in `.env`:**
```
JSON_PATH=\\network\share\path\
NETWORK_SHARE_USERNAME=stlouis\appuser
NETWORK_SHARE_PASSWORD=$ecure@pp
```

**Log File:** `logs/import.log`

#### **B. Auto-Send Pipeline** (`send_pending_results.php`)
| Step | Process | Details |
|------|---------|---------|
| 1 | CLI-Only Check | Rejects web requests (only `php-cli` allowed) |
| 2 | Acquire Lock | Prevents concurrent execution via `logs/send_pending_results.lock` |
| 3 | Read Last Run Marker | Retrieves timestamp from `logs/send_pending_last_run.txt` |
| 4 | Query Database | Finds results where `result_link_added_at >= last_marker_time` |
| 5 | Channel Check | Verifies if WhatsApp/SMS/Email auto-send is enabled in `.env` |
| 6 | Fetch Recipient Info | Gets mobile number (WhatsApp/SMS) or email from patients table |
| 7 | Send Message | Invokes API for each enabled channel |
| 8 | Record Attempt | Updates `wp_last_attempt_at`, `sms_last_attempt_at`, etc. with current timestamp |
| 9 | Mark Success/Failure | Sets `wp_sent=1`, `sms_sent=0`, etc. |
| 10 | Log Entry | Writes to `logs/send_pending_results.log` |
| 11 | Update Marker | Writes new timestamp to `logs/send_pending_last_run.txt` |

**Configuration in `.env`:**
```
WHATSAPP_AUTO_SEND=1
SMS_AUTO_SEND=1
EMAIL_AUTO_SEND=1
RETRY_FAILED_SENDS=14
WHATSAPP_API_URL=https://...
WHATSAPP_API_KEY=...
SMS_API_URL=https://...
SMTP_HOST=mail.hospital.com
SMTP_FROM=results@hospital.com
```

**Log File:** `logs/send_pending_results.log` (rotates at 50MB)

#### **C. Manual Send Pipeline** (`result_sending.php`)
| Step | Process | Details |
|------|---------|---------|
| 1 | Role Check | Verifies user is Master, Butler, Lab, or Imaging |
| 2 | Department Filter | Lab users see only Lab results; Imaging see only Imaging |
| 3 | Get Templates | Loads message templates from `templates.php` by channel and result type |
| 4 | Fetch Recipient | Gets phone/email from patients table |
| 5 | Send via API | Calls WhatsApp/SMS/Email API with formatted message |
| 6 | Record Send | Creates entry in sent_results table with timestamp and sender username |
| 7 | Log Activity | Appends line to `logs/activity.log` with format: `timestamp|username|action|mrn|channel|phone|email|details` |

---

## User Roles & Permissions

### Role Hierarchy & Capabilities

| Feature | Master | Butler | Lab | Imaging | Doctor | Patient |
|---------|--------|--------|-----|---------|--------|---------|
| **Search/View All Results** | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ |
| **Search/View Dept Results** | — | — | ✅ Lab | ✅ Imaging | — | — |
| **Search/View Own Results** | — | — | — | — | — | ✅ (via MRN) |
| **Manual PDF Send** | ✅ | ✅ | ✅ (Lab) | ✅ (Imaging) | ❌ | ❌ |
| **Manual Link Send (Full URL)** | ✅ | ⚠️ Truncated | ✅ | ✅ | ❌ | ❌ |
| **Collection Notice Send** | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| **Resend Result** | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ |
| **View Activity Log** | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **View Failed Sends** | ✅ | ✅ (Own+System) | ❌ | ❌ | ❌ | ❌ |
| **User Management** | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |

### Role Descriptions

**Master**
- Full system access
- Can view all patient results across all departments
- Can perform all send operations (manual, collection notice, resend)
- Full URL sharing (no truncation)
- Access to complete activity logs
- User management capabilities
- Can view all failed sends with full diagnostic info
- Intended for: Hospital admin, IT, Results coordinator

**Butler**
- Near-full access with limited visibility
- Can view all patient results across all departments
- Can perform all send operations (manual, collection notice, resend)
- URL sharing shows truncated/masked URLs (security)
- Access to activity logs
- Can view failed sends for own operations and system-wide failures
- Intended for: Senior results technician, supervisor

**Lab**
- Department-specific access to Lab results only
- Can search/view only Lab-department results
- Can perform manual sends (PDF, link) for Lab results
- Can send collection notices and resends
- Full URL sharing for Lab results
- Cannot access failed sends or activity logs
- Intended for: Laboratory technician/staff

**Imaging**
- Department-specific access to Imaging results only
- Can search/view only Imaging-department results
- Can perform manual sends (PDF, link) for Imaging results
- Can send collection notices and resends
- Full URL sharing for Imaging results
- Cannot access failed sends or activity logs
- Intended for: Imaging technician/radiologist

**Doctor**
- Read-only access to all results
- Can view all patient results across all departments
- Cannot perform any send operations
- Cannot access logs or reports
- Intended for: Physicians, medical staff

**Patient**
- Public, unauthenticated access
- View only own results by MRN lookup
- No send capabilities
- Accessible from public-facing URL

---

## System Rules & Workflow

### Rule Set 1: Import & Processing

1. **JSON Source Truth**
   - Patient data and results import from JSON files in `JSON_PATH`
   - `result_link_added_at` timestamp determines eligibility for auto-send
   - Each import run marked with timestamp in `logs/last_run.txt`

2. **Import Idempotency**
   - Duplicate imports within same 5-minute window rejected via `logs/import.lock`
   - Database upserts prevent duplicate patient/result records
   - Only new results (new `result_link_added_at`) trigger auto-send

3. **Network Share Mounting**
   - Windows systems: Auto-mount share at runtime with credentials from `.env`
   - Credentials: `NETWORK_SHARE_USERNAME=stlouis\appuser`, `NETWORK_SHARE_PASSWORD=...`
   - Linux/macOS: NFS mount must be pre-configured

4. **Result Uniqueness Handling**
   - **Laboratory**: Duplicate results with same `mrn + request_code` are merged into single record
     - Multiple tests combined into comma-separated list in `test_or_image` field
     - Only one auto-send occurs per patient per request code
   - **Imaging (Radiology)**: Each result is independent, even with same `request_code`
     - Multiple imaging tests with identical request code are treated as separate records
     - Each receives independent auto-send attempt
     - Allows multiple different imaging tests (e.g., CT, MRI) under same request code

### Rule Set 2: Auto-Send Execution

1. **Scheduling & CLI-Only**
   - Auto-send runs daily at **16:00 server timezone** (set via `APP_TIMEZONE` in `.env`)
   - Must be executed via CLI: `php send_pending_results.php`
   - Web requests to `send_pending_results.php` are rejected

2. **Result Eligibility**
   - Only processes results where `result_link_added_at >= logs/send_pending_last_run.txt` timestamp
   - Prevents redundant sends to same patient

3. **Channel Independence**
   - Each channel (WhatsApp, SMS, Email) is independently enabled/disabled
   - If WhatsApp disabled but SMS enabled, only SMS sends
   - Failed channel does not block other channels

4. **Retry Policy**
   - Automatic retries up to **14 days** (configurable via `RETRY_FAILED_SENDS` in `.env`)
   - Each retry updates `wp_last_attempt_at`, `sms_last_attempt_at` timestamp
   - Succeeds on first attempt, stops retrying

### Rule Set 3: Manual Sending

1. **Role-Based Department Access**
   - Lab users can ONLY send to Lab results
   - Imaging users can ONLY send to Imaging results
   - Master/Butler can send to any result
   - Doctor/Patient cannot send

2. **Template-Based Messages**
   - All sends use templates from `templates.php`
   - Templates can vary by channel (WhatsApp vs SMS vs Email)
   - Templates can vary by result type (lab_results, mi_results, result_collection, result)

3. **URL Handling**
   - Master/Lab/Imaging users get **full URLs**
   - Butler users get **truncated/masked URLs** (e.g., `hospital.com/...`)
   - URL rewritten with `EXTERNAL_HOSTNAME` from `.env`

4. **Sender Attribution**
   - All manual sends attributed to logged-in username
   - Recorded in database `sent_results` table
   - Logged to `logs/activity.log`

### Rule Set 4: Delivery Tracking

1. **Per-Channel Timestamps**
   - Each send attempt updates channel-specific timestamp:
     - `wp_last_attempt_at` for WhatsApp
     - `sms_last_attempt_at` for SMS
     - `email_last_attempt_at` for Email
   - Timestamp = when send was attempted (not when delivery was confirmed)

2. **Success Flags**
   - Binary flags indicate success:
     - `wp_sent=1` (WhatsApp successful), `wp_sent=0` (failed or not sent)
     - `sms_sent=1` (SMS successful), `sms_sent=0` (failed or not sent)
     - `email_sent=1` (Email successful), `email_sent=0` (failed or not sent)

3. **Failed Sends Query**
   - `failed_sends.php` queries results where any channel has `sent=0` but `last_attempt_at` is not null
   - Searchable by date range and channel

### Rule Set 5: Session & Authentication

1. **Active Directory (LDAP)**
   - Primary auth: LDAP query to `AUTH_AD_SERVER` (default: `ldap://192.168.20.1`)
   - Fallback server: `AUTH_AD_FALLBACK_SERVER` (default: `ldap://192.168.20.100`)
   - Domain: `AUTH_AD_DOMAIN` (default: `stlouis.com`)
   - Base DN: `AUTH_AD_BASE_DN` (default: `DC=stlouis,DC=com`)

2. **Local Admin Fallback**
   - If LDAP fails, allows local admin login:
     - Username: `admin` (constant `AUTH_LOCAL_ADMIN_USER`)
     - Password: `B@ckdoor4!T` (constant `AUTH_LOCAL_ADMIN_PASS`)
   - Recommended to change password in code or `.env`

3. **Session Inactivity**
   - Session timeout: 24 hours (configurable via `SESSION_INACTIVITY_TIMEOUT` in `.env`)
   - Any page load refreshes inactivity timer
   - Expired sessions redirect to `login.php?timeout=1`

4. **Session Persistence**
   - Session cookie lifetime: 24 hours
   - Multiple tabs/windows allowed
   - Session GC maxlifetime: 24 hours

---

## Database Structure

### Database Name
```
SLHCycle
```
(Configured in `.env` as `DB_NAME`)

### Table 1: `patients`

| Column | Type | Description |
|--------|------|-------------|
| id | INT AUTO_INCREMENT | Primary key |
| mrn | VARCHAR(50) UNIQUE | Medical Record Number (patient identifier) |
| first_name | VARCHAR(100) | Patient first name |
| last_name | VARCHAR(100) | Patient last name |
| mobile | VARCHAR(20) | WhatsApp/SMS phone number (E.164 format: +country code) |
| email | VARCHAR(100) | Email address for Email sends |
| created_at | TIMESTAMP DEFAULT CURRENT_TIMESTAMP | Record creation timestamp |
| updated_at | TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### Table 2: `results`

| Column | Type | Description |
|--------|------|-------------|
| id | INT AUTO_INCREMENT | Primary key |
| patient_id | INT FOREIGN KEY | Reference to patients.id |
| mrn | VARCHAR(50) | Denormalized patient MRN (for quick lookup) |
| test_type | VARCHAR(100) | Type of test (e.g., "Complete Blood Count", "Chest X-Ray") |
| result_description | TEXT | Full description/findings of the result |
| result_link | VARCHAR(500) | URL/link to access the result PDF or portal |
| department | ENUM('Lab','Imaging','Other') | Source department of the result |
| result_link_added_at | DATETIME | When the result link first appeared (KEY for auto-send eligibility) |
| wp_sent | TINYINT DEFAULT 0 | 1 = WhatsApp sent successfully, 0 = not sent or failed |
| wp_last_attempt_at | DATETIME NULL | Timestamp of last WhatsApp send attempt |
| sms_sent | TINYINT DEFAULT 0 | 1 = SMS sent successfully, 0 = not sent or failed |
| sms_last_attempt_at | DATETIME NULL | Timestamp of last SMS send attempt |
| email_sent | TINYINT DEFAULT 0 | 1 = Email sent successfully, 0 = not sent or failed |
| email_last_attempt_at | DATETIME NULL | Timestamp of last Email send attempt |
| created_at | TIMESTAMP DEFAULT CURRENT_TIMESTAMP | Record creation timestamp |
| updated_at | TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | Last update timestamp |

### Table 3: `sent_results`

| Column | Type | Description |
|--------|------|-------------|
| id | INT AUTO_INCREMENT | Primary key |
| patient_id | INT FOREIGN KEY | Reference to patients.id |
| result_id | INT FOREIGN KEY | Reference to results.id |
| mrn | VARCHAR(50) | Denormalized patient MRN |
| channel | ENUM('whatsapp','sms','email','pdf') | Communication channel used |
| recipient | VARCHAR(200) | Phone number or email address recipient |
| sent_by | VARCHAR(100) | Username of person who triggered the send |
| sent_at | TIMESTAMP DEFAULT CURRENT_TIMESTAMP | When the send was performed |
| status | ENUM('success','failed','pending') DEFAULT 'pending' | Send result status |
| error_message | TEXT NULL | Error details if failed |
| created_at | TIMESTAMP DEFAULT CURRENT_TIMESTAMP | Record creation timestamp |

### Database Indexes

```sql
-- results table indexes for performance
KEY idx_mrn (mrn)
KEY idx_patient_id (patient_id)
KEY idx_result_link_added_at (result_link_added_at)
KEY idx_department (department)

-- sent_results table indexes
KEY idx_mrn (mrn)
KEY idx_patient_id (patient_id)
KEY idx_result_id (result_id)
KEY idx_sent_at (sent_at)
KEY idx_channel (channel)
```

---

## Configuration & Environment Variables

### File Location
```
z:\htdocs\Results\.env
```

### Required Database Variables

```env
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=SLHCycle
DB_USER=root
DB_PASS=YourDatabasePassword
```

**Impact:** Connection to MySQL database for all data storage and retrieval.

### JSON Import Variables

```env
JSON_PATH=\\network\share\path\
NETWORK_SHARE_USERNAME=stlouis\appuser
NETWORK_SHARE_PASSWORD=$ecure@pp
```

**Impact:** Determines where import engine reads JSON files. Must be UNC path on Windows or NFS on Linux.

### Auto-Send Control Variables

```env
WHATSAPP_AUTO_SEND=1
SMS_AUTO_SEND=1
EMAIL_AUTO_SEND=1
RETRY_FAILED_SENDS=14
```

**Impact:**
- `WHATSAPP_AUTO_SEND=0`: Disables auto-send via WhatsApp
- `SMS_AUTO_SEND=0`: Disables auto-send via SMS
- `EMAIL_AUTO_SEND=0`: Disables auto-send via Email
- `RETRY_FAILED_SENDS=7`: Stops retrying after 7 days (default 14)

### API Credentials

```env
WHATSAPP_API_URL=https://api.whatsapp.provider.com/send
WHATSAPP_API_KEY=your_whatsapp_api_key
WHATSAPP_API_SECRET=your_whatsapp_api_secret
SMS_API_URL=https://api.sms.provider.com/send
SMS_API_KEY=your_sms_api_key
```

**Impact:** Used by `result_sending.php` and `send_pending_results.php` to invoke third-party APIs.

### Email/SMTP Variables

```env
SMTP_HOST=mail.hospital.com
SMTP_PORT=587
SMTP_USER=results@hospital.com
SMTP_PASS=EmailPassword
SMTP_FROM=results@hospital.com
SMTP_FROM_NAME=Results Department
```

**Impact:** Configuration for sending emails via PHPMailer library.

### System Variables

```env
EXTERNAL_HOSTNAME=hospital.com
APP_TIMEZONE=Asia/Beirut
```

**Impact:**
- `EXTERNAL_HOSTNAME`: Used to rewrite result links for external sharing
- `APP_TIMEZONE`: Sets date_default_timezone_set() for all timestamps

### Authentication (Active Directory)

```env
AUTH_AD_SERVER=ldap://192.168.20.1
AUTH_AD_FALLBACK_SERVER=ldap://192.168.20.100
AUTH_AD_PORT=389
AUTH_AD_DOMAIN=stlouis.com
AUTH_AD_NETBIOS=stlouis
AUTH_AD_BASE_DN=DC=stlouis,DC=com
AUTH_AD_USE_TLS=false
AUTH_AD_SEARCH_BIND_USER=svc-directus
AUTH_AD_SEARCH_BIND_PASS=QxmXIgtaXiOR7EWrSXIb
```

**Impact:** LDAP configuration for user authentication. Also has local fallback (admin/B@ckdoor4!T).

### Session Management

```env
SESSION_INACTIVITY_TIMEOUT=86400
SESSION_COOKIE_LIFETIME=86400
SESSION_GC_MAXLIFETIME=86400
```

**Impact:** All times in seconds. 86400 = 24 hours.

---

## File Structure

### Root Directory Files

| File | Purpose |
|------|---------|
| `index.php` | Main dashboard - displays patient results based on role |
| `login.php` | LDAP/local authentication UI |
| `logout.php` | Session termination |
| `auth.php` | Authentication logic, role validation, LDAP integration |
| `env.php` | Environment variable loader from `.env` file |
| `.env` | Configuration file (not version controlled) |
| `sent_results_db.php` | Database connection and query helpers |
| `result_sending.php` | Manual send logic (WhatsApp, SMS, Email) |
| `send_pending_results.php` | Auto-send engine (CLI-only, runs daily) |
| `activity_log.php` | Activity log viewer (Master/Butler roles) |
| `failed_sends.php` | Failed send reporter and retry UI |
| `templates.php` | Message templates for each channel and result type |
| `user_management.php` | User role assignment (Master only) |
| `setup_database.php` | Database schema creation (localhost/CLI only) |
| `recheck_patients.php` | Utility for re-importing patient data |
| `sync_wp_delivery_status.php` | WhatsApp delivery status sync (webhook) |
| `sync_sms_delivery_status.php` | SMS delivery status sync (webhook) |
| `meta_webhook.php` | Meta/WhatsApp webhook receiver |
| `post_wp_result.php` | Direct WhatsApp send via Facebook Graph API |
| `mysql_diagnostics.php` | Database diagnostics tool |
| `test_db_connection.php` | Database connection tester |
| `test_ack_check.php` | Testing utility for acknowledgment |
| `check_ack_delivery_status.php` | Delivery status acknowledgment checker |
| `wp_failures.php` | WhatsApp-specific failure analysis |
| `get_result_status.php` | API endpoint for result status |
| `composer.json` | PHP dependencies (PHPMailer) |
| `documentation.md` | This documentation file |

### Subdirectories

| Directory | Purpose |
|-----------|---------|
| `imports/import_json.php` | JSON file import engine (runs every 5 minutes) |
| `vendor/` | Composer dependencies (PHPMailer) |
| `logs/` | Runtime logs and markers |

### Logs Directory (`logs/`)

| File | Purpose |
|------|---------|
| `import.log` | Import engine activity log |
| `last_run.txt` | Timestamp of last import run |
| `send_pending_results.log` | Auto-send engine activity log (rotates at 50MB) |
| `send_pending_last_run.txt` | Timestamp of last auto-send run |
| `activity.log` | All send operations (manual and auto) - text file |
| `import.lock` | Lock file for import concurrency control |
| `send_pending_results.lock` | Lock file for auto-send concurrency control |
| `sync_status.flag` | Sync operation status marker |
| `import_autosend_ready.flag` | Flag indicating auto-send readiness |
| `db_debug.log` | Database connection debug information |

---

## CRON Jobs & Scheduled Task Management

### Overview

The Results System relies on two scheduled jobs:

1. **Import Job** (`imports/import_json.php`)
   - Runs every 5 minutes
   - Reads JSON files from network share
   - Imports patient data and results into database
   - Location: `/z/htdocs/Results/imports/import_json.php`

2. **Auto-Send Job** (`send_pending_results.php`)
   - Runs daily at 16:00 (4:00 PM)
   - Processes results eligible for sending
   - Sends via WhatsApp, SMS, Email (as configured)
   - Location: `/z/htdocs/Results/send_pending_results.php`

### Linux/Unix: CRON Setup

#### Step 1: Edit Crontab

```bash
# Open crontab editor
crontab -e

# Or as root (for system-wide cron)
sudo crontab -e
```

#### Step 2: Add Import Job (Every 5 Minutes)

```bash
# Import JSON files every 5 minutes
*/5 * * * * cd /var/www/Results && /usr/bin/php imports/import_json.php >> /var/www/Results/logs/cron_import.log 2>&1
```

**Breakdown:**
- `*/5` = Every 5 minutes
- `*` = Every hour
- `*` = Every day of month
- `*` = Every month
- `*` = Every day of week
- `cd /var/www/Results` = Change to application directory
- `/usr/bin/php` = Full path to PHP CLI binary
- `>> /var/www/Results/logs/cron_import.log 2>&1` = Redirect output to log file

#### Step 3: Add Auto-Send Job (Daily at 16:00)

```bash
# Auto-send results daily at 16:00 (4:00 PM)
0 16 * * * cd /var/www/Results && /usr/bin/php send_pending_results.php >> /var/www/Results/logs/cron_autosend.log 2>&1
```

**Breakdown:**
- `0` = At minute 0 (top of hour)
- `16` = At 16:00 (4:00 PM)
- `*` = Every day
- `*` = Every month
- `*` = Every day of week

#### Step 4: Verify CRON Jobs

```bash
# List all user cron jobs
crontab -l

# List system-wide cron jobs
sudo crontab -l

# Check cron logs (varies by system)
tail -f /var/log/cron                    # Red Hat/CentOS
tail -f /var/log/syslog                  # Ubuntu/Debian
log stream --predicate 'process == "cron"' --level debug  # macOS
```

#### Step 5: Test Manual Execution

```bash
# Test import job manually
cd /var/www/Results
php imports/import_json.php

# Test auto-send job manually
php send_pending_results.php
```

**Expected Output:** Should write to respective log files without errors.

#### Common Linux CRON Times

```bash
# Every minute
* * * * * command

# Every 5 minutes
*/5 * * * * command

# Every 15 minutes
*/15 * * * * command

# Every hour at minute 0
0 * * * * command

# Every day at 08:00
0 8 * * * command

# Every day at 16:00 (4:00 PM)
0 16 * * * command

# Every Monday at 09:00
0 9 * * 1 command

# Every 1st day of month at 00:00
0 0 1 * * command

# Every 6 hours
0 */6 * * * command
```

---

### Windows: Task Scheduler Setup

#### Step 1: Open Task Scheduler

1. Press `Win + R`
2. Type: `taskschd.msc`
3. Press Enter

**Or:**

1. Settings → Control Panel → Administrative Tools → Task Scheduler

#### Step 2: Create Import Task

1. **Right-click** → **Create Basic Task**
2. **Name:** `Results Import Job`
3. **Description:** `Import patient results from JSON every 5 minutes`
4. Click **Next**

**Trigger:**
1. Select: **Custom trigger**
2. **Repetition:** Every 5 minutes (in repeat pattern window)
3. **Duration:** For the lifetime of the task
4. Click **OK**

**Action:**
1. **Program:** `C:\PHP\php.exe` (or wherever PHP is installed)
2. **Arguments:** `z:\htdocs\Results\imports\import_json.php`
3. **Start In:** `z:\htdocs\Results`
4. Click **OK**

**Settings:**
1. Check: ✅ Run whether user is logged in or not
2. Check: ✅ Run with highest privileges
3. Uncheck: ❌ Stop task if it runs longer than (so it can complete)

#### Step 3: Create Auto-Send Task

1. **Right-click** → **Create Basic Task**
2. **Name:** `Results Auto-Send Job`
3. **Description:** `Send pending results daily at 16:00`
4. Click **Next**

**Trigger:**
1. Select: **Daily**
2. **Start Date/Time:** Tomorrow at 16:00
3. Click **OK**

**Action:**
1. **Program:** `C:\PHP\php.exe`
2. **Arguments:** `z:\htdocs\Results\send_pending_results.php`
3. **Start In:** `z:\htdocs\Results`
4. Click **OK**

**Settings:**
1. Check: ✅ Run whether user is logged in or not
2. Check: ✅ Run with highest privileges

#### Step 4: Verify Task Scheduler Jobs

1. **Task Scheduler Library** → Find your tasks
2. **Status column:** Should show **Ready** (not Disabled)
3. **Right-click task** → **Run** to execute manually
4. **Right-click task** → **Properties** → **History** to view logs

#### Step 5: Troubleshooting Windows Tasks

**Task doesn't run:**
1. Verify user account has sufficient permissions
2. Check if PHP path is correct: `C:\PHP\php.exe -v`
3. Verify working directory (z:\htdocs\Results) exists
4. Check Event Viewer: Start → eventvwr.msc → Windows Logs → System

**View Task Run History:**
1. Task Scheduler → Select task
2. **History tab** shows all execution records
3. **Status:** Shows "Task completed with error code..." if failed

**Manually test task:**
1. Open Command Prompt (Admin)
2. Run: `cd z:\htdocs\Results`
3. Run: `C:\PHP\php.exe imports/import_json.php`
4. Check output for errors

---

### CRON Output & Log Monitoring

#### Log File Locations

After setting up CRON jobs, logs will be written to:

```
z:\htdocs\Results\logs\cron_import.log       # Import job output (Linux)
z:\htdocs\Results\logs\cron_autosend.log     # Auto-send job output (Linux)
z:\htdocs\Results\logs\import.log            # Import engine internal log
z:\htdocs\Results\logs\send_pending_results.log  # Auto-send engine internal log
```

#### Monitor CRON Activity (Linux)

```bash
# View last 50 lines of import cron output
tail -50 /var/www/Results/logs/cron_import.log

# View last 50 lines of auto-send cron output
tail -50 /var/www/Results/logs/cron_autosend.log

# Watch import log in real-time
tail -f /var/www/Results/logs/import.log

# Watch auto-send log in real-time
tail -f /var/www/Results/logs/send_pending_results.log

# Search for errors in import
grep -i "error\|failed" /var/www/Results/logs/import.log

# Search for errors in auto-send
grep -i "error\|failed" /var/www/Results/logs/send_pending_results.log
```

#### Check Last Execution Timestamps

```bash
# When was last import run?
cat /var/www/Results/logs/last_run.txt

# When was last auto-send run?
cat /var/www/Results/logs/send_pending_last_run.txt

# When was last marker update?
stat /var/www/Results/logs/last_run.txt | grep Modify
```

---

### CRON Job Health Monitoring

#### Warning Signs

| Sign | Meaning | Action |
|------|---------|--------|
| `last_run.txt` timestamp is >5 minutes old | Import job not running | Check CRON status, verify PHP path |
| `send_pending_last_run.txt` timestamp is >24 hours old | Auto-send job not running | Check CRON status, verify schedule |
| `import.log` has "lock" errors | Import job concurrent execution | Previous import still running (hung) |
| `send_pending_results.log` has "Database connection failed" | Database is down | Verify MySQL is running, check network |
| `cron_import.log` or `cron_autosend.log` is empty | No CRON output captured | CRON job ran successfully (no output) |

#### Health Check Script (Optional)

Create `health_check.php` to monitor job health:

```php
<?php
// Check if import job is running (every 5 minutes)
$lastRunFile = __DIR__ . '/logs/last_run.txt';
$lastRun = file_exists($lastRunFile) ? filemtime($lastRunFile) : 0;
$timeSinceLastRun = time() - $lastRun;

if ($timeSinceLastRun > 600) { // More than 10 minutes
    echo "⚠️ WARNING: Import job has not run in " . ($timeSinceLastRun/60) . " minutes\n";
} else {
    echo "✅ Import job running normally\n";
}

// Check if auto-send job is running (daily at 16:00)
$lastSendFile = __DIR__ . '/logs/send_pending_last_run.txt';
$lastSend = file_exists($lastSendFile) ? filemtime($lastSendFile) : 0;
$timeSinceLastSend = time() - $lastSend;

if ($timeSinceLastSend > 86400) { // More than 24 hours
    echo "⚠️ WARNING: Auto-send job has not run in " . ($timeSinceLastSend/3600) . " hours\n";
} else {
    echo "✅ Auto-send job running normally\n";
}
?>
```

---

### Common CRON Issues & Solutions

| Issue | Cause | Solution |
|-------|-------|----------|
| CRON job not executing | PHP path wrong | Verify with `which php` or `where php.exe` |
| CRON job executes but does nothing | Working directory wrong | Add `cd /path/to/Results` before command |
| File permission denied | PHP process lacks permissions | Change file owner or permissions: `chmod 755 logs/` |
| Database connection fails in CRON | MySQL socket issue | Use `DB_HOST=127.0.0.1` (TCP) instead of `localhost` (socket) |
| Email/API calls fail in CRON | Different environment variables | Ensure `.env` file readable and in correct location |
| Output not captured | Redirect to log file missing | Add `>> /path/to/logfile 2>&1` to CRON command |
| CRON email notification unwanted | Mailer configured | Add `MAILTO=""` at top of crontab to suppress |
| Task runs twice | Overlapping execution | Check lock files: `ls -la logs/*.lock` |

---

## Non-Developer Modification Guide

### Scenario 1: Change Auto-Send Time

**Current Setup:** Auto-send runs at 16:00 daily

**To Change Time:**

**Method A: Via Cron Job (Linux/Unix)**
```bash
# Edit system crontab
crontab -e

# Example: Change to 14:00 (2:00 PM)
0 14 * * * cd /var/www/Results && php send_pending_results.php

# Example: Change to 08:00 (8:00 AM)
0 8 * * * cd /var/www/Results && php send_pending_results.php
```

**Method B: Via Task Scheduler (Windows)**
1. Open Windows Task Scheduler
2. Find task: "Results Auto-Send" or create new task
3. Edit trigger to desired time
4. Action: `php.exe z:\htdocs\Results\send_pending_results.php`

**What Changed:** Only the execution time; all business logic remains the same.

---

### Scenario 2: Disable WhatsApp Sends (Keep SMS/Email)

**Current Setup:** WhatsApp, SMS, Email all enabled

**To Change:**

Edit `.env` file:
```env
# Before
WHATSAPP_AUTO_SEND=1
SMS_AUTO_SEND=1
EMAIL_AUTO_SEND=1

# After
WHATSAPP_AUTO_SEND=0
SMS_AUTO_SEND=1
EMAIL_AUTO_SEND=1
```

**Save** and restart the application. Next auto-send run will skip WhatsApp.

**Effect:** 
- Manual sends still allow WhatsApp option in UI
- Only auto-send skips WhatsApp
- To disable in all contexts, see "Scenario 5"

---

### Scenario 3: Modify Patient Notification Message Templates

**Files to Edit:** `templates.php`

**Structure:**
```php
$TEMPLATES = [
    'whatsapp' => [
        'lab_results' => 'Hi {{1}}, your lab results are ready. Link: {{2}}',
        'mi_results' => 'Hi {{1}}, your imaging results are ready. Link: {{2}}',
        'result_collection' => 'Hi {{1}}, please collect your results at the lab.',
        'result' => 'Hi {{1}}, result available: {{2}}'
    ],
    'sms' => [
        'lab_results' => 'Lab results ready: {{2}}',
        'mi_results' => 'Imaging results ready: {{2}}',
        'result_collection' => 'Please collect results at lab',
        'result' => 'Result: {{2}}'
    ],
    'email' => [
        'lab_results' => 'Your lab results are ready...',
        'mi_results' => 'Your imaging results are ready...',
        'result_collection' => 'Please collect your results...',
        'result' => 'Result notification...'
    ]
];
```

**Placeholders:**
- `{{1}}` = Patient first name
- `{{2}}` = Result link or description

**Example Modification:**
```php
// Before
'lab_results' => 'Hi {{1}}, your lab results are ready. Link: {{2}}'

// After (adds hospital name and custom message)
'lab_results' => 'Hello {{1}}, your lab results from St. Louis Medical Center are ready. Please visit: {{2}}'
```

**Save** and all new sends will use updated templates.

---

### Scenario 4: Extend Retry Period for Failed Sends

**Current Setup:** Stops retrying after 14 days

**To Change:**

Edit `.env`:
```env
# Before
RETRY_FAILED_SENDS=14

# After (extend to 30 days)
RETRY_FAILED_SENDS=30
```

**Effect:** System will continue retrying failed sends for 30 days instead of 14.

---

### Scenario 5: Change External Hostname for Result Links

**Current Setup:** Links use `hospital.com`

**To Change:**

Edit `.env`:
```env
# Before
EXTERNAL_HOSTNAME=hospital.com

# After (e.g., for new domain or subdomain)
EXTERNAL_HOSTNAME=results.hospital.com
```

**In Code:** Used by `toExternalResultLink()` function in `index.php` and `result_sending.php`

**Effect:** All patient-facing result links will use new hostname.

---

### Scenario 6: Change Database Connection

**Current Setup:** Localhost MySQL at `127.0.0.1:3306`, database `SLHCycle`

**To Change:**

Edit `.env`:
```env
# Before
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=SLHCycle
DB_USER=root
DB_PASS=

# After (example: remote server)
DB_HOST=192.168.1.50
DB_PORT=3306
DB_NAME=PatientResults_Prod
DB_USER=results_user
DB_PASS=SecurePassword123
```

**Verification:** Visit `test_db_connection.php` to verify connection.

---

### Scenario 7: Modify LDAP Authentication Server

**Current Setup:** Primary LDAP at `ldap://192.168.20.1`

**To Change:**

Edit `.env`:
```env
# Before
AUTH_AD_SERVER=ldap://192.168.20.1
AUTH_AD_FALLBACK_SERVER=ldap://192.168.20.100
AUTH_AD_DOMAIN=stlouis.com
AUTH_AD_BASE_DN=DC=stlouis,DC=com

# After (example: new domain)
AUTH_AD_SERVER=ldap://192.168.30.1
AUTH_AD_FALLBACK_SERVER=ldap://192.168.30.2
AUTH_AD_DOMAIN=newhospital.local
AUTH_AD_BASE_DN=DC=newhospital,DC=local
```

**Effect:** Users will authenticate against new LDAP server. Local admin (admin/B@ckdoor4!T) always works as fallback.

---

### Scenario 8: Add/Remove User Roles

**Current Roles:** master, butler, lab, imaging, doctor, patient

**To Add New Role (Developer Task):**

Edit `auth.php`:
```php
// Find function:
function portalRoleList(): array
{
    return ['master', 'butler', 'imaging', 'lab', 'doctor'];
}

// Add your role:
function portalRoleList(): array
{
    return ['master', 'butler', 'imaging', 'lab', 'doctor', 'newrole'];
}
```

**Note:** Adding roles requires developer work in `index.php` and `result_sending.php` to define permissions.

---

### Scenario 9: Change JSON Import Path

**Current Setup:** Reads JSON from `\\network\share\path\`

**To Change:**

Edit `.env`:
```env
# Before
JSON_PATH=\\network\share\path\

# After (example: new network location)
JSON_PATH=\\fileserver2\hl7_results\
```

**Windows Network Share Mounting:**
```env
NETWORK_SHARE_USERNAME=newdomain\newuser
NETWORK_SHARE_PASSWORD=NewPassword123
```

**Effect:** Next import run will read from new path.

---

### Scenario 10: Audit Trail - Extract Activity Logs

**File:** `logs/activity.log` (text file)

**Format:** Each line is pipe-separated:
```
timestamp|username|action|mrn|channel|phone|email|details
2024-01-15 14:32:45|john.smith|manual_send|MRN-12345|whatsapp|+961123456789||Result link sent
2024-01-15 14:33:12|auto_send|auto_send|MRN-12346|sms|+961198765432||Auto-send attempt
```

**To Extract Reports:**

**All sends by date range:**
```bash
grep "2024-01" logs/activity.log > report_jan_2024.txt
```

**All WhatsApp sends:**
```bash
grep "whatsapp" logs/activity.log > report_whatsapp.txt
```

**All sends by user "john.smith":**
```bash
grep "john.smith" logs/activity.log > report_john.txt
```

**All failed sends:**
```bash
grep "failed" logs/activity.log > report_failures.txt
```

---

### Scenario 11: Troubleshoot Import Failures

**Check Import Log:**
```bash
cat logs/import.log
```

**Common Issues:**

1. **Network Share Unreachable**
   - Verify `JSON_PATH` is correct
   - Verify network share is online: `ping \\fileserver\share`
   - Verify credentials in `.env` are correct
   - Check Windows Event Logs for mount errors

2. **Invalid JSON Files**
   - Verify JSON file format is valid (use online JSON validator)
   - Check file permissions (import service must have read access)
   - Check file encoding (UTF-8 required)

3. **Database Insert Failures**
   - Verify `DB_HOST`, `DB_USER`, `DB_PASS` in `.env`
   - Check MySQL is running: `mysql -u root -p SLHCycle`
   - Check table structure: `SHOW TABLES;` in database

---

### Scenario 12: Troubleshoot Auto-Send Failures

**Check Auto-Send Log:**
```bash
tail -100 logs/send_pending_results.log
```

**Check Last Run Marker:**
```bash
cat logs/send_pending_last_run.txt
```

**Common Issues:**

1. **API Credentials Invalid**
   - Verify `WHATSAPP_API_KEY`, `SMS_API_KEY` in `.env`
   - Verify API URLs are correct: `WHATSAPP_API_URL`, `SMS_API_URL`
   - Test API manually with curl

2. **SMTP (Email) Issues**
   - Verify `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` in `.env`
   - Test SMTP connection: Use online SMTP checker or telnet
   - Check firewall allows port 587 or 25

3. **Results Not Sending**
   - Check if `WHATSAPP_AUTO_SEND=1` in `.env`
   - Verify `logs/send_pending_last_run.txt` has recent timestamp
   - Verify results exist in database with `result_link_added_at` set

---

## Logs & Monitoring

### Critical Log Files

| Log File | Location | Purpose | Rotation |
|----------|----------|---------|----------|
| Import Log | `logs/import.log` | Import engine activity | Manual |
| Auto-Send Log | `logs/send_pending_results.log` | Auto-send engine activity | 50MB |
| Activity Log | `logs/activity.log` | All send operations (audit trail) | Manual |
| Database Debug | `logs/db_debug.log` | Database connection issues | Manual |
| Lock Files | `logs/import.lock`, `logs/send_pending_results.lock` | Concurrency control | Automatic |

### Monitoring Dashboard

**URLs:**
- Main Dashboard: `http://hospital.com/index.php`
- Activity Log (Master/Butler): `http://hospital.com/activity_log.php`
- Failed Sends (Master/Butler): `http://hospital.com/failed_sends.php`
- Database Diagnostics: `http://hospital.com/mysql_diagnostics.php`

### Key Metrics to Monitor

1. **Import Success Rate**
   - Monitor `logs/import.log` for errors
   - Check `logs/last_run.txt` timestamp (should update every 5 minutes)

2. **Auto-Send Success Rate**
   - Monitor `logs/send_pending_results.log` for failures
   - Check database: `SELECT COUNT(*) FROM results WHERE wp_sent=0 AND wp_last_attempt_at > DATE_SUB(NOW(), INTERVAL 14 DAY);`

3. **Failed Sends**
   - View `failed_sends.php` for recent failures
   - Check `sent_results` table for error_message details

4. **User Activity**
   - View `activity_log.php` for manual send history
   - Monitor who sent what, when, via which channel

---

## Troubleshooting

### Common Problems & Solutions

| Problem | Cause | Solution |
|---------|-------|----------|
| **Login fails** | LDAP server unreachable | Check `AUTH_AD_SERVER` in `.env`, verify network connectivity. Try local admin (admin/B@ckdoor4!T). |
| **Import not running** | Cron/Task Scheduler not configured | Set up cron job or Windows Task Scheduler to run `php send_pending_results.php` daily. |
| **No results appear** | JSON files not found | Verify `JSON_PATH` in `.env` is correct and accessible. |
| **WhatsApp sends fail** | Invalid API key | Verify `WHATSAPP_API_KEY` and `WHATSAPP_API_URL` in `.env`. |
| **Email sends fail** | SMTP configuration wrong | Verify `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER` in `.env`. Test with telnet. |
| **Database connection fails** | Wrong host/user/pass | Verify `DB_HOST`, `DB_USER`, `DB_PASS` in `.env`. Test with `mysql` CLI. |
| **Permission denied on network share** | Wrong credentials | Verify `NETWORK_SHARE_USERNAME` and `NETWORK_SHARE_PASSWORD` in `.env`. |
| **Session expires immediately** | Timezone mismatch | Verify `APP_TIMEZONE` in `.env` is correct. |
| **Patient view shows no results** | MRN not found | Verify patient MRN exactly matches database. |

---

## Summary for Non-Developers

**If you need to modify the system without developer help, focus on these `.env` variables:**

```env
# ===== FREQUENTLY MODIFIED =====
WHATSAPP_AUTO_SEND=1          # Disable WhatsApp: set to 0
SMS_AUTO_SEND=1               # Disable SMS: set to 0
EMAIL_AUTO_SEND=1             # Disable Email: set to 0
RETRY_FAILED_SENDS=14         # Change retry period (days)
EXTERNAL_HOSTNAME=hospital.com # Change patient-facing domain

# ===== OCCASIONALLY MODIFIED =====
JSON_PATH=\\network\share\path\ # Change import source folder
DB_HOST=127.0.0.1             # Change database server
APP_TIMEZONE=Asia/Beirut      # Change timezone

# ===== RARELY MODIFIED =====
AUTH_AD_SERVER=ldap://...     # Change LDAP server
SMTP_HOST=mail.hospital.com   # Change email server
WHATSAPP_API_KEY=...          # Change API credentials
```

**For more complex changes (adding roles, changing templates, modifying database)**, contact a developer.

**For operational tasks:**
- View activity log: Visit `activity_log.php` (Master/Butler only)
- View failed sends: Visit `failed_sends.php` (Master/Butler only)
- Check logs: SSH/RDP into server and `cat logs/*.log`
- Reset password: Use local admin (admin/B@ckdoor4!T) and change via user management

---

**Last Updated:** 2024-01-20  
**System Version:** 1.0  
**Support Contact:** IT Department
- **Filtering**: By MRN, username, date, channel, **status (success/failed)**

### Failed Sends Page (`failed_sends.php`)
- **Access**: Butler+ (filtered by own sends + system auto-send)
- **Storage**: Database query
- **Filters**: Date range, Channel
- **Shows**: Failed attempts with contact info and attempt time

### Database Tables
**sent_results** (What we track):
- `wp_sent`, `sms_sent`, `email_sent` (0/1): Success/failure
- `wp_last_attempt_at`, `sms_last_attempt_at`, `email_last_attempt_at`: When attempted
- `sent_by`: "auto_send" or username

**patient_results** (Result metadata):
- `result_link_added_at`: When link appeared (used for filtering)
- `source`: "json_import" | "manual_upload" | "collection_notice"

---

## Workflows

### Daily Auto-Send
```
JSON updated overnight
  ↓
05:00 → Import task runs (every 5 min)
        Result inserted: result_link_added_at = NOW()
  ↓
16:00 → Send task runs
        Sends to all 3 channels
        Records timestamps per channel
  ↓
Dashboard shows: ✅ Sent (with time) or ❌ Failed
```

### Manual Send by Butler
```
Butler → Dashboard → "Send PDF" button
  ↓
Activity log entry: butler_username | action | ... | status=success/failed
  ↓
failed_sends.php shows failure (if failed) under "Sent By: butler_username"
  ↓
Dashboard shows: ✅ Sent or ❌ Failed
```

### Failed Recovery
```
16:00 → Auto-send fails (wp_sent=0, wp_last_attempt_at=16:00:30)
  ↓ Activity log: status=failed error=...
  ↓ failed_sends.php shows WhatsApp as failed
  ↓
16:30 → Operator manually resends
        wp_last_attempt_at updated to 16:30:45, wp_sent=1
  ↓
Dashboard & activity log updated
```

---

## Setup & Deployment

### One-Time Setup
```bash
# 1. Create database
php setup_database.php

# 2. Baseline import
php setup_json.php

# 3. Configure .env
# Set DB, API credentials, paths

# 4. Test
php imports/import_json.php
```

### Windows Task Scheduler

**Import (Every 5 Minutes)**
```
Program: C:\xampp\php\php.exe
Arguments: C:\xampp\htdocs\Results\imports\import_json.php
Trigger: Repeat every 5 minutes
Run as: System
```

**Send (Daily 16:00)**
```
Program: C:\xampp\php\php.exe
Arguments: C:\xampp\htdocs\Results\send_pending_results.php
Trigger: Daily at 16:00
Run as: System
```

### Verify Setup
1. Check logs exist: `logs/import.log`, `logs/send_pending_results.log`
2. Verify DB: `SELECT COUNT(*) FROM patient_results;`
3. Test dashboard: `http://localhost/index.php?view=master`
4. Test manual send

---

## Logs & Troubleshooting

### Log Files
| File | Purpose |
|------|---------|
| `logs/import.log` | Import details |
| `logs/send_pending_results.log` | Auto-send details |
| `logs/activity.log` | Send history (audit trail) |
| `logs/wp.log` | WhatsApp API calls |

### Common Issues

**Results imported but not sending?**
- Check: `WHATSAPP_AUTO_SEND=1`
- Check: `logs/send_pending_results.log`
- Check: API credentials in .env

**Import not running?**
- Check: Windows Task Scheduler → Run History
- Test: `php imports/import_json.php`

**Failed sends not showing in failed_sends.php?**
- Check: `sent_results` table where `*_sent=0 AND *_last_attempt_at IS NOT NULL`

**Activity log doesn't show failures?**
- Check: Status filter looks for "status=failed" or "error=" in details

---

## What Gets Auto-Sent?

✅ **Yes:**
- Lab + Radiology results with PDF links
- Imported via JSON
- Has phone/email
- Within RETRY_FAILED_SENDS window

❌ **No:**
- Manual uploads
- Collection notices
- Results older than RETRY_FAILED_SENDS days

---

## Status Meaning

| Status | Meaning |
|--------|---------|
| `*_sent=1, *_last_attempt_at=<time>` | Successfully sent |
| `*_sent=0, *_last_attempt_at=<time>` | Attempted but failed |
| `*_last_attempt_at=NULL` | Never attempted |

---

## Retry Logic

- **First attempt**: When result enters send window
- **Retry interval**: Every 24 hours
- **Stop after**: RETRY_FAILED_SENDS days (default 14 days)

**Purpose:** Send a PDF file to a patient via WhatsApp, SMS, or Email.

**Workflow:**
1. Navigate to Dashboard → Patient Details
2. Scroll to "Manual PDF Upload" section
3. Select patient MRN (or search)
4. Upload PDF file
5. Select delivery channel: WhatsApp, SMS, or Email
6. Click "Send PDF"
7. System creates new result record with:
   - `department = 'Manual Upload'`
   - `source = 'manual_upload'`
   - `first_seen_at = NOW()`

**Result Display:**
- New card appears in patient's result history
- Shows: Department (Manual Upload), Filename (PDF name), Test/Image (empty)
- Send State displays: Channel + Status (Sent/Failed) + Timestamp

**Channel Details:**
- **WhatsApp**: Sends PDF as media attachment with template message
- **SMS**: Sends text message with notification (no file attachment via SMS)
- **Email**: Sends PDF as attachment via SMTP

### 3.3 Manual Link Send
**Purpose:** Send a direct result link to patient via WhatsApp, SMS, or Email.

**Workflow:**
1. Navigate to Dashboard → Patient Details
2. Scroll to "Manual Link Send" section
3. Select patient MRN (or search)
4. Paste result URL
5. Select delivery channel: WhatsApp, SMS, or Email
6. Click "Send Link"
7. System creates new result record with:
   - `department = 'Manual Send'`
   - `source = 'manual_upload'`
   - `manual_filename = {actual_url}` (full URL stored in DB)

**URL Display (Role-based):**
- **master**: Sees full URL `http://hospital.com/results/patient/abc123xyz`
- **butler**: Sees truncated `http://....c123xyz` (last 6 characters)
- **doctor, lab, imaging, patient**: No URL displayed (security restriction)

**Result Display:**
- New card appears in patient's result history
- Shows: Department (Manual Send), Filename (depends on role), Test/Image (empty)
- Send State displays: Channel + Status (Sent/Failed) + Timestamp

### 3.4 Manual Collection Notice
**Purpose:** Send a hardcopy collection notice to patient via WhatsApp, SMS, or Email.

**Workflow:**
1. Navigate to Dashboard → Patient Details
2. Scroll to "Send Collection Notice" section
3. Select patient MRN
4. Select delivery channel: WhatsApp, SMS, or Email
5. Click "Send Notice"
6. System creates new result record with:
   - `department = 'Collection Notice'`
   - `source = 'collection_notice'`
   - `first_seen_at = NOW()`

**Result Display:**
- New card appears (butler/master views only)
- Not shown in doctor/patient read-only views
- Shows: Department (Collection Notice), Request Code (empty), Test/Image (empty)
- Send State displays: Channel + Status (Sent/Failed) + Timestamp

### 3.5 Single Result Resend
**Purpose:** Resend a single lab/imaging result via different channel.

**Workflow:**
1. Navigate to Dashboard → Patient Details
2. Locate desired result card
3. Click appropriate channel button (WhatsApp, SMS, or Email)
4. System updates existing sent record or creates new one if changed
5. Timestamp recorded for attempt

**Multiple Channel Support:**
- Can send same result via multiple channels sequentially
- Each channel maintains independent attempt timestamp
- Resending updates `*_last_attempt_at` for that channel

### 3.6 Send All Not-Sent Results
**Purpose:** Batch send all unsent results for a patient across all channels.

**Workflow:**
1. Navigate to Dashboard → Patient Details (master/butler views only)
2. Click "Send All Not-Sent" button
3. System sends each pending result via WhatsApp, SMS, and Email
4. Progress modal shows during sending
5. Results marked as sent with timestamps

---

## 4. Automated Sending (Scheduler)

### 4.1 Architecture
Automated sending uses a **two-phase model** for reliability and control:

**Phase 1: Import** (Every 5 minutes)
- Scans JSON files for new/modified results
- Upserts into database
- Does NOT send automatically
- Flexible trigger: CLI, web, or manual

**Phase 2: Scheduled Send** (Daily at 16:00)
- Processes pending results from Phase 1
- Applies time window filter
- Sends via enabled channels
- Records delivery metadata

**Rationale:** This separation prevents accidental auto-sends during import and allows centralized control.

### 4.2 Configuration
Enable/disable automatic sending:
```
WHATSAPP_AUTO_SEND=1  (or true, yes, on)
```

If disabled:
- Import continues normally
- Scheduled sender exits without sending
- Marker still advances
- Manual sends always work

### 4.3 Import Task (Incremental)
**File:** `imports/import_json.php`

**Trigger:** Every 5 minutes via Windows Task Scheduler

**Process:**
1. Acquires non-blocking lock `logs/import.lock`
2. Reads last import marker from `logs/last_run.txt`
3. Scans `JSON_PATH` for `*.json` files
4. Processes files with modification time >= marker
5. Upserts patient records and results
6. Updates `result_link_added_at` when link changes
7. Writes import log to `logs/import.log`
8. Updates marker timestamp

**CLI Example:**
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\Results\imports\import_json.php
```

**Scheduled Task Configuration (Windows):**
- **Program**: `C:\xampp\php\php.exe`
- **Arguments**: `C:\xampp\htdocs\Results\imports\import_json.php`
- **Frequency**: Every 5 minutes
- **Run as**: System account with DB/file access
- **Start**: Immediately on boot

### 4.4 Scheduled Send Task
**File:** `send_pending_results.php`

**Trigger:** Daily at 16:00 via Windows Task Scheduler (or on-demand)

**Process:**
1. Acquires lock `logs/send_pending_results.lock`
2. Checks if `WHATSAPP_AUTO_SEND` is enabled
3. Reads last send marker from `logs/send_pending_last_run.txt`
4. If marker missing: writes current time, exits (baseline protection)
5. Queries pending candidates:
   - Source = `json_import`
   - Department = Laboratory OR Radiology
   - Has `pdf_result_link`
   - Has patient mobile phone
   - No sent record OR sent record has different link
6. Filters to records with `result_link_added_at >= marker_timestamp`
7. Sends via enabled channels:
   - WhatsApp (always attempted if phone exists)
   - SMS (if enabled and phone exists)
   - Email (if enabled and email exists)
8. Records sent metadata: `provider_ack`, `provider_status`, timestamps
9. Advances marker to current run start time
10. Writes log to `logs/send_pending_results.log`

**Channel-Specific Timestamps:**
- `wp_last_attempt_at`: When WhatsApp send was attempted (success OR failure)
- `sms_last_attempt_at`: When SMS send was attempted (success OR failure)
- `email_last_attempt_at`: When Email send was attempted (success OR failure)

**Status Values:**
- `1` = Sent successfully
- `0` = Attempted but failed
- Absent/NULL = Not attempted

**CLI Example:**
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\Results\send_pending_results.php
```

**Scheduled Task Configuration (Windows):**
- **Program**: `C:\xampp\php\php.exe`
- **Arguments**: `C:\xampp\htdocs\Results\send_pending_results.php`
- **Trigger**: Daily at 16:00 (or your preferred time)
- **Run as**: System account with DB/file access
- **Start**: Immediately on boot
- **Retry**: 3 attempts with 5-minute interval on failure

### 4.5 Automation Scenarios

**Scenario A: New Result Imported**
```
16:00 (Previous day) → Result inserted, link added, result_link_added_at set
16:00 (Today) → Send task processes it
       → Sends via WhatsApp, SMS, Email (if enabled)
       → Records attempt timestamps
       → Marks as sent
```

**Scenario B: Result Link Changed**
```
16:00 (Day 1) → Result imported with link_A, sent
16:00 (Day 2) → Import detects link_B, updates result_link_added_at
16:00 (Same day) → Send task sees "changed" state
            → Sends updated link via all channels
            → Updates attempt timestamps
```

**Scenario C: Old Unsent Data Before Marker**
```
OLD DATA (before baseline) → Not sent
16:00 (Baseline day) → Marker created with current timestamp, exits
16:00 (Day after) → Only NEW data (after marker) is processed
RESULT: Old data intentionally NOT auto-sent (prevents backfill)
```

**Scenario D: Auto-Send Disabled**
```
WHATSAPP_AUTO_SEND=0 (or false, no, off)
16:00 → Send task runs
     → Checks setting, exits immediately
     → Manual sends from dashboard still work
     → Marker does NOT advance
     → Next day, gap includes accumulated data
SOLUTION: Re-enable auto-send, run send_pending_results.php manually to catch gap
```

**Scenario E: Import During Send Task**
```
16:00:00 → Send task starts, acquires lock
16:00:30 → Import task tries to run
         → Cannot acquire lock, waits or skips
16:00:45 → Send task completes, releases lock
16:01:00 → Next import run proceeds normally
RESULT: No race conditions, sends complete before next import
```

---

## 5. Delivery Tracking and Multi-Channel Support

### 5.1 Channel Architecture
Each result can be sent via multiple independent channels:
- **WhatsApp**: Via BestSMSBulk API
- **SMS**: Via SMS gateway
- **Email**: Via SMTP (PHPMailer)

Each channel maintains separate state:
- Attempt flag (`wp_sent`, `sms_sent`, `email_sent` = 0 or 1)
- Attempt timestamp (`wp_last_attempt_at`, `sms_last_attempt_at`, `email_last_attempt_at`)
- Delivery status (`delivered_at`)

### 5.2 Timestamp Recording
**Key Rule:** Timestamps are recorded for BOTH success AND failure:
```php
'wp_last_attempt_at' => date('Y-m-d H:i:s'),  // Always set when attempted
'wp_sent' => 1,  // Set to 1 if succeeded, 0 if failed
```

**Dashboard Display Logic:**
- **Not Attempted**: `*_last_attempt_at` is NULL → "not sent"
- **Attempted + Success**: `*_last_attempt_at` has value, `*_sent=1` → "sent"
- **Attempted + Failed**: `*_last_attempt_at` has value, `*_sent=0` → "failed"

### 5.3 Delivery Status Polling
**Sync WhatsApp Delivery Status** (`sync_wp_delivery_status.php`):
- Polls BestSMSBulk API for message status
- Matches provider ACK to sent records
- Updates `provider_status`, `delivered_at`, `status_checked_at`
- Accessible from CLI or web (master role required for web)

**Webhook Delivery Updates** (`meta_webhook.php`):
- Receives Meta/provider callbacks
- Updates sent records by provider message ID
- Optional secret validation via header/bearer/query

---

## 6. Setup and Access Rules

### 6.1 setup_database.php
Purpose:
- Creates database tables (`patients`, `patient_results`, `sent_results`, `portal_users`, `json_import_log`).

Access rule:
- Allowed from CLI.
- For web execution, only localhost (`127.0.0.1`, `::1`, `localhost`) is allowed.

### 6.2 setup_json.php
Purpose:
- Full baseline import of all JSON files under `JSON_PATH`.
- Marks baseline readiness flag.

Access rule:
- Allowed from CLI.
- For web execution, only localhost is allowed.

### 6.3 imports/import_json.php
Purpose:
- Incremental import of files modified since import marker.
- Upserts patient demographics and result rows.

Access rule:
- CLI and web callable.
- Intended usage: Task Scheduler (CLI).

### 3.4 send_pending_index.php
Purpose:
- Scheduled WhatsApp sender for pending/changed records, bounded by last-run marker window.

Access rule:
- CLI only.
- Web requests receive forbidden response.

### 3.5 login.php / logout.php
Purpose:
- LDAP authentication for portal roles.
- Session teardown.

Access rule:
- `login.php` is public.
- `logout.php` clears the portal session.
- LDAP users must exist in `portal_users` and be active to gain access.
- If `portal_users` is empty, the first successful LDAP login bootstraps a master record.

### 3.6 user_management.php
Purpose:
- Master-only dashboard for mapping LDAP usernames to portal roles.

Access rule:
- Master role only.

### 3.7 sync_wp_delivery_status.php
Purpose:
- Pulls delivery states from BestSMSBulk `getMessageStatusJson.php` (JSON array payload).
- Updates sent records by provider `ack`.

Access rule:
- CLI allowed.
- Web access requires master role.

### 3.8 meta_webhook.php
Purpose:
- Receives Meta/provider delivery callbacks.
- Updates sent records by provider `ack`/message id.

Access rule:
- Public webhook endpoint.
- If `WHATSAPP_META_WEBHOOK_SECRET` is set, requests must provide matching secret via `X-Webhook-Secret` header, `Authorization: Bearer`, or `secret` query parameter.

---

## 7. Dashboard Views and Access by View

Dashboard requires query parameter `view` with one of:
- `master`
- `lab`
- `imaging`
- `patient`
- `doctor`
- `butler`

If `view=patient`, the page remains public.

All other views require an authenticated portal session. If `view` is omitted, the portal uses the logged-in user's role as the default view.

### 7.1 master view
Intended audience:
- Full operations and administrative control.

Capabilities:
- **Search**: Open MRN, see patients list page
- **View**: Patient details and all results
- **Automated Sending**: Send all not-sent/changed for selected patient
- **Manual Sending**: 
  - Manual PDF upload (any channel)
  - Manual link send (full URL visible)
  - Collection notices
  - Single result resend/retry
- **Admin**: User management link, full audit trail visibility
- **Visual**: Department chips (All/Lab/Imaging), all result types visible

**Manual Operations in Master View:**
- Can see and send results from: Lab, Imaging, Manual Uploads, Collection Notices
- Can resend via any channel (WhatsApp, SMS, Email)
- Can view full URLs for manual links
- Can manually import, run send tasks, view all logs

### 7.2 lab view
Intended audience:
- Laboratory department operators.

Capabilities:
- All master capabilities BUT filtered to laboratory department only
- Manual sending available for lab results
- Collection notice single button available
- Single result resend available

Restrictions:
- Cannot see imaging/radiology results
- Department filter enforced

### 7.3 imaging view
Intended audience:
- Imaging/radiology department operators.

Capabilities:
- All master capabilities BUT filtered to imaging/radiology department only
- Manual sending available for imaging results
- Collection notice single button available
- Single result resend available

Restrictions:
- Cannot see laboratory results
- Department filter enforced

### 7.4 butler view
Intended audience:
- Assisted workflow with restricted link access.

Capabilities:
- Same send/manual operations as master
- Manual sending available (all types)
- Collection notice available
- Single result resend available

Restrictions:
- "Open result link" button is hidden (cannot directly access)
- Manual link URLs shown as truncated `http://....{last6chars}` (privacy)
- Department chips available

**Manual Operations in Butler View:**
- Can send manual PDFs, links, collection notices
- Cannot view/click direct result links
- Limited URL visibility (security feature)

### 7.5 doctor view
Intended audience:
- Doctor read-only workflow with patient lookup.

Capabilities:
- **Search**: MRN search/open, see patients list

Restrictions:
- Cannot send results
- Cannot see manual sends (manual uploads, manual links, collection notices hidden)
- Cannot see manual operations panel
- Can only browse/view lab and imaging result content

### 7.6 patient view
Intended audience:
- Public patient-facing result access (no login required).

Capabilities:
- Browse own results (requires patient query parameter)
- View result content

Restrictions:
- This is the only fully public `view` mode
- Cannot see send metadata or delivery status
- No administrative functions
- Manual operations hidden
- Read-only content viewing only
- If session exists, shows current user and logout option

---

## 8. WhatsApp Templates and Send Record Types

There are two concepts in code:
- Provider template names passed to WhatsApp API.
- Internal DB `template_type` values stored in `sent_results`.

### 8.1 Provider template names (API template parameter)
- `lab_results`: Laboratory result link sending (automated + manual resend)
- `mi_results`: Imaging/radiology result link sending (automated + manual resend)
- `result_sending`: Manual link sending
- `result_collection`: Collection notice hardcopy (1 variable: patient name)
- `result`: Manual PDF upload sending (patient name + PDF attachment)

### 8.2 Internal DB template_type values (`sent_results.template_type`)
- `result`: Standard result sends (lab, imaging, manual links)
- `collection_notice`: Collection notice sends
- `manual_pdf`: Manual PDF upload sends

### 8.3 Internal content_type values (`sent_results.content_type`)
- `link`: Result link content
- `pdf_upload`: PDF file content

### 8.4 Multi-Channel Send Metadata (`sent_results` fields)

**Per-Channel Flags:**
- `wp_sent` (0/1/NULL): WhatsApp delivery state
- `sms_sent` (0/1/NULL): SMS delivery state
- `email_sent` (0/1/NULL): Email delivery state

**Per-Channel Attempt Timestamps:**
- `wp_last_attempt_at`: When WhatsApp send was attempted (YYYY-MM-DD HH:MM:SS)
- `sms_last_attempt_at`: When SMS send was attempted (YYYY-MM-DD HH:MM:SS)
- `email_last_attempt_at`: When Email send was attempted (YYYY-MM-DD HH:MM:SS)

**Delivery Tracking Fields:**
- `provider_ack`: Provider message ID (from API response)
- `provider_status`: Status code from provider
- `provider_recipient`: Phone or email that received message
- `provider_response`: Full API response (JSON)
- `delivered_at`: Confirmed delivery timestamp
- `status_checked_at`: Last time status was polled
- `status_source`: Source of status update (api_poll, webhook, etc.)

**Key Behavior:**
- Timestamps recorded for BOTH success AND failure attempts
- NULL timestamp = never attempted (channel not used)
- Value + sent=1 = succeeded
- Value + sent=0 = failed

### 8.5 Delivery Status Tracking

**WhatsApp Delivery Flow:**
1. Manual/auto send → record `wp_last_attempt_at` + `wp_sent` (1 or 0)
2. Provider ACK received → record `provider_ack`
3. Poll status via `sync_wp_delivery_status.php` → update `delivered_at`, `status_checked_at`
4. Webhook callback via `meta_webhook.php` → update with delivery confirmation

**SMS Delivery Flow:**
1. Manual/auto send → record `sms_last_attempt_at` + `sms_sent` (1 or 0)
2. Provider ACK received → record `provider_ack` if applicable
3. Delivery confirmation → update `delivered_at`

**Email Delivery Flow:**
1. Manual/auto send → record `email_last_attempt_at` + `email_sent` (1 or 0)
2. SMTP response → record `provider_status`
3. Email read receipts (if configured) → update `delivered_at`

---

## 9. Complete Task Scheduler Setup

### 9.1 One-time Deployment Tasks

**Task 1: Initialize Database**
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\Results\setup_database.php
```
- Creates all tables
- Run once before first import
- Safe to re-run (uses CREATE TABLE IF NOT EXISTS)

**Task 2: Baseline Import**
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\Results\setup_json.php
```
- Imports all existing JSON files
- Sets baseline marker
- Run once after database setup
- Creates `logs/import_autosend_ready.flag`

### 9.2 Recurring Automation Tasks

**Task 1: Incremental Import (Every 5 Minutes)**

Windows Task Scheduler Configuration:
```
Name: Results-Import-Incremental
Program: C:\xampp\php\php.exe
Arguments: C:\xampp\htdocs\Results\imports\import_json.php
Trigger: Repeat every 5 minutes
Run as: System (or account with DB/file share access)
Start: Immediately on boot
Conditions:
  - Run only if on battery: OFF
  - Run if idle: OFF
Advanced:
  - Run task as soon as possible if missed
  - Stop if runs longer than: 10 minutes
```

**Manual Trigger:**
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\Results\imports\import_json.php
```

**Output Logs:**
- Primary: `logs/import.log`
- Last run marker: `logs/last_run.txt`
- Lock file (during execution): `logs/import.lock`

---

**Task 2: Automated Send (Daily at 16:00)**

Windows Task Scheduler Configuration:
```
Name: Results-Send-Pending-Daily
Program: C:\xampp\php\php.exe
Arguments: C:\xampp\htdocs\Results\send_pending_results.php
Trigger: Daily at 16:00
Run as: System (or account with DB/file share access)
Start: Immediately on boot
Conditions:
  - Run only if on battery: OFF
  - Run if idle: OFF
Advanced:
  - Run task as soon as possible if missed
  - Stop if runs longer than: 60 minutes
Retry:
  - If task fails, retry after: 5 minutes
  - Retry times: 3
```

**Alternative: Manual Trigger**
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\Results\send_pending_results.php
```

**Output Logs:**
- Primary: `logs/send_pending_results.log`
- Last send marker: `logs/send_pending_last_run.txt`
- Lock file (during execution): `logs/send_pending_results.lock`
- Channel-specific: `logs/wp.log`, `logs/api_calls.log`

**Conditional Behavior:**
- If `WHATSAPP_AUTO_SEND=1`: Sends via enabled channels (WP, SMS, Email)
- If `WHATSAPP_AUTO_SEND=0`: Exits without sending (marker still advances)
- If marker missing: Creates marker, exits (baseline protection on first run)

### 9.3 Optional: Delivery Status Sync Task

**Purpose:** Poll WhatsApp provider for delivery confirmations

Windows Task Scheduler Configuration (Optional):
```
Name: Results-Sync-Delivery-Status
Program: C:\xampp\php\php.exe
Arguments: C:\xampp\htdocs\Results\sync_wp_delivery_status.php
Trigger: Every 30 minutes
Run as: System (or account with DB/file access)
Start: 5 minutes after boot
Advanced:
  - Stop if runs longer than: 5 minutes
```

**Manual Trigger:**
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\Results\sync_wp_delivery_status.php
```

This updates `delivered_at`, `status_checked_at`, `provider_status` for previously sent messages.

---

## 10. Workflow: Automated + Manual Combined

### 10.1 Typical Daily Flow

**05:00** - Server startup
- Both import and send tasks start on boot (scheduled to begin)

**09:00** - New JSON file uploaded
- Import task runs (every 5 min), detects new file
- Result inserted with `result_link_added_at = 2026-07-17 09:05:00`
- `sent_results` entry NOT yet created

**16:00** - Scheduled send task
- Reads marker `logs/send_pending_last_run.txt` (previous day 16:00)
- Finds all pending where `result_link_added_at >= marker_timestamp`
- New result matches filter
- Sends via enabled channels (WP, SMS, Email)
- Records: `wp_last_attempt_at`, `sms_last_attempt_at`, `email_last_attempt_at`
- Records: `wp_sent=1`, `sms_sent=1`, `email_sent=1` (if all succeeded)
- Updates marker to current time 16:00

**16:15** - Manual resend by operator
- Operator sees result in dashboard
- Clicks "Resend via WhatsApp"
- Manual send triggered (outside scheduled window)
- Updates `wp_last_attempt_at` and `wp_sent` with new timestamp
- Result shows as recently sent

### 10.2 Mixed Automation Scenarios

**Auto-send failed, manual recovery:**
```
16:00 → Auto-send attempted, WhatsApp failed (provider down)
        → wp_sent=0, wp_last_attempt_at=2026-07-17 16:00:30
16:15 → Provider restored
16:30 → Operator manually resends via WhatsApp
        → wp_sent=1, wp_last_attempt_at=2026-07-17 16:30:45 (updated)
```

**Auto-send succeeded, manual re-distribution:**
```
16:00 → Auto-send to primary phone succeeded
        → wp_sent=1, provider_recipient=9615...xxx
10:30 (next day) → Operator sends to different phone via Manual Link Send
                  → New sent_results record created
                  → Both history entries visible
```

**Scheduled disabled, manual only:**
```
WHATSAPP_AUTO_SEND=0
→ Import continues running
→ Results accumulate in DB
→ No auto-send at 16:00
→ Operators use Manual Send All from dashboard
→ Operator controls timing
```

---

## 11. Logs, Files, and Troubleshooting

### 11.1 Log Files Location
All logs in: `C:\xampp\htdocs\Results\logs\`

**Import-Related:**
- `import.log`: Detailed import transactions
- `last_run.txt`: Last import timestamp marker
- `setup_json.log`: Baseline import results

**Send-Related:**
- `send_pending_results.log`: Auto-send task execution
- `send_pending_last_run.txt`: Last send timestamp marker
- `wp.log`: WhatsApp API calls and responses
- `api_calls.log`: General API activity

**Lock Files (temporary, during execution):**
- `import.lock`: Present while import task running
- `send_pending_results.lock`: Present while send task running

### 11.2 Lock File Behavior
- Non-blocking locks prevent concurrent execution
- If task crashed, lock remains → prevents re-run until manual cleanup
- Safe to delete if confident task is not running

**To clear stale locks:**
```bash
del C:\xampp\htdocs\Results\logs\import.lock
del C:\xampp\htdocs\Results\logs\send_pending_results.lock
```

### 11.3 Troubleshooting Common Issues

**Issue: "Not sent" showing in dashboard but record exists**
- Check: Is `*_last_attempt_at` NULL in sent_results table?
- Cause: Sent record created but attempt not recorded
- Fix: Re-send manually, or check `send_pending_results.log` for errors

**Issue: Results appear but don't send at 16:00**
- Check: Is `WHATSAPP_AUTO_SEND` enabled?
- Check: Is marker file present? (`logs/send_pending_last_run.txt`)
- Check: Are channel credentials configured in `.env`?
- Fix: Manual send via dashboard, check `send_pending_results.log`

**Issue: Import task not running**
- Check: Task Scheduler → Results-Import-Incremental → Run History
- Check: PHP CLI path correct in Task Scheduler configuration
- Check: File share/DB permissions for service account
- Fix: Test manually: `C:\xampp\php\php.exe C:\xampp\htdocs\Results\imports\import_json.php`

**Issue: "Multiple channels show same failed timestamp"**
- Check: Each channel should have INDEPENDENT `*_last_attempt_at`
- Cause: Bug in earlier versions (now fixed)
- Fix: Manual resend per channel records individual timestamps

**Issue: Manual sends not appearing in history**
- Check: Is `department` set correctly in inserted record?
- Check: Is role viewing filtered results? (doctor/patient views exclude manual uploads)
- Fix: Switch to master/butler view to verify record exists

### 11.4 Log Analysis Examples

**Successful import:**
```
[2026-07-17 10:05:30] Import started
[2026-07-17 10:05:31] Scanning: \\hospital\results\...
[2026-07-17 10:05:35] Found 3 new files
[2026-07-17 10:05:40] Upserted 15 patients, 47 results
[2026-07-17 10:05:41] Marker advanced to 2026-07-17 10:05:40
```

**Successful send:**
```
[2026-07-17 16:00:30] Auto-send started
[2026-07-17 16:00:31] Found 23 pending candidates
[2026-07-17 16:00:45] Sent 23 via WhatsApp, 23 via SMS, 20 via Email (3 no email)
[2026-07-17 16:00:50] Marker advanced to 2026-07-17 16:00:00
```

**Failed send (check why):**
```
[2026-07-17 16:00:31] API Error: Connection refused
[2026-07-17 16:00:32] Retrying in 5 seconds...
[2026-07-17 16:00:37] Still failed - marking as attempted (sent=0)
[2026-07-17 16:00:38] Marker advanced despite failures
```

---

## 12. Complete Migration Checklist (New Environment)

### Phase 1: Infrastructure
- [ ] MySQL server accessible and running
- [ ] XAMPP/PHP installed and CLI working
- [ ] Network file share (JSON_PATH) mounted and readable
- [ ] Service account created with DB/file access
- [ ] Firewall allows DB connections (port 3306)

### Phase 2: Configuration
- [ ] Copy codebase to web root
- [ ] Create `.env` file with all required variables
- [ ] Test DB connection: `php -r "require_once 'env.php'; loadEnvFile();"`
- [ ] Verify file share access: `dir {JSON_PATH}`
- [ ] Configure email settings (if using email channel)
- [ ] Configure WhatsApp API credentials (if using WP channel)
- [ ] Configure SMS gateway (if using SMS channel)

### Phase 3: Database Setup
- [ ] Run `setup_database.php` once
- [ ] Verify tables created: Run SQL `SHOW TABLES;`
- [ ] Verify schema: Check `patient_results` has correct columns

### Phase 4: Initial Import
- [ ] Place JSON files in `{JSON_PATH}` folder
- [ ] Run `setup_json.php` once (baseline import)
- [ ] Verify results in DB: Check `patient_results` row count
- [ ] Check import log: `logs/setup_json.log`
- [ ] Verify marker created: Check `logs/last_run.txt` exists

### Phase 5: LDAP Authentication
- [ ] Configure AD/LDAP connection in `.env`:
  - `AUTH_AD_SERVER`
  - `AUTH_AD_FALLBACK_SERVER`
  - `AUTH_AD_DOMAIN`
  - `AUTH_AD_BASE_DN`
- [ ] Test login: Visit `login.php`, try LDAP user
- [ ] Create first master user (auto-creates on first successful login if table empty)
- [ ] Assign roles to additional users via `user_management.php`

### Phase 6: Automation Setup
- [ ] Create Windows Task Scheduler task: Incremental Import (every 5 min)
- [ ] Create Windows Task Scheduler task: Pending Send (daily 16:00)
- [ ] Create Windows Task Scheduler task: Delivery Sync (optional, every 30 min)
- [ ] Test each task manually (run as service account)
- [ ] Verify logs generated in `logs/` folder
- [ ] Check Task History for any errors

### Phase 7: Dashboard Verification
- [ ] Test dashboard access: `http://localhost/index.php?view=patient`
- [ ] Login with test LDAP user
- [ ] Verify results displayed
- [ ] Test manual send (PDF upload, link, collection notice)
- [ ] Verify send record in DB and dashboard history

### Phase 8: Production Validation
- [ ] Monitor first automated send run at 16:00
- [ ] Check `logs/send_pending_results.log` for success
- [ ] Verify patients received messages
- [ ] Check delivery status sync (optional task)
- [ ] Test failed delivery scenario (provider unavailable)
- [ ] Test manual recovery (re-send via dashboard)

---

## 13. Operational Notes

### 13.1 Design Rationale
- **Two-phase model** (import + send): Separation prevents accidental auto-sends and enables centralized control
- **Marker-based windowing**: Prevents backfilling old data, simplifies resets
- **Multi-channel independence**: Each channel tracked separately for maximum flexibility
- **Per-channel timestamps**: Enables accurate audit trail for compliance
- **Manual operations available always**: System respects operator intent even if automation disabled

### 13.2 Safety Features
- **Non-blocking locks**: Prevents corruption from concurrent execution
- **Baseline marker protection**: First send run creates marker and exits (prevents mass backfill)
- **Role-based permissions**: Operators only see/send results they're authorized for
- **Read-only views**: Doctor/patient views cannot trigger sends
- **URL visibility controls**: Sensitive links hidden from non-admin roles

### 13.3 Best Practices
1. **Daily monitoring**: Check `logs/` folder for import/send task results
2. **Marker files**: Never delete marker files unless intentionally re-baselining
3. **Redundant channels**: Use multiple channels (WP + SMS + Email) for critical notifications
4. **Stale lock cleanup**: Monitor for crashed tasks, clean locks only if confident task not running
5. **Backup markers**: Archive `logs/send_pending_last_run.txt` before major changes
6. **Test first**: Always test manual send before relying on automation
7. **Timezone awareness**: All timestamps in MySQL and logs use configured `APP_TIMEZONE`

### 13.4 Common Customizations
- **Change send time**: Edit trigger in send_pending_results task (currently 16:00)
- **Change import interval**: Edit frequency in import task (currently 5 minutes)
- **Add new channels**: Modify `send_pending_results.php` and `result_sending.php` to invoke new channel handlers
- **Filter by department**: Modify queries in `send_pending_results.php` (currently Lab + Radiology)
- **Add custom roles**: New roles added to `portal_users` table automatically (no code changes needed)
4. Run `setup_database.php` once.
5. Run `setup_json.php` once.
6. Create scheduler tasks:
   - Import every 5 minutes
   - Pending send daily at 16:00
7. Confirm logs are being written under `logs/`.
8. Verify `WHATSAPP_AUTO_SEND` value matches desired behavior.

---

## 13. Operational Notes

- The scheduler model is intentionally split:
  - Import task ingests data.
  - Send task handles WhatsApp dispatch.
- This separation prevents immediate auto-send during import and gives controlled daily send windows.
- If strict no-backfill behavior is required, do not delete `send_pending_last_run.txt` unless you want to re-baseline.

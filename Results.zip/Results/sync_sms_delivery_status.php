<?php

declare(strict_types=1);

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/result_sending.php';

$isCli = PHP_SAPI === 'cli' || PHP_SAPI === 'phpdbg';
if (!$isCli) {
    portalRequireMaster();
}

$limit = (int)($_REQUEST['limit'] ?? 1000);
$result = syncSmsDeliveryStatuses($limit);

if ($isCli) {
    echo 'SMS delivery status sync: ' . ($result['success'] ? 'success' : 'failed') . PHP_EOL;
    echo 'Received: ' . (int)($result['received'] ?? 0) . PHP_EOL;
    echo 'Updated: ' . (int)($result['updated'] ?? 0) . PHP_EOL;
    echo 'Ignored: ' . (int)($result['ignored'] ?? 0) . PHP_EOL;
    if (!empty($result['message'])) {
        echo 'Message: ' . (string)$result['message'] . PHP_EOL;
    }
    exit($result['success'] ? 0 : 1);
}

http_response_code(!empty($result['success']) ? 200 : 502);
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($result, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

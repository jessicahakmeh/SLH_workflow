<?php
// READ-ONLY schema/data check for the send-pending job. Restricted to CLI or private-network clients.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false && $ip !== '::1') {
        http_response_code(403);
        exit('Forbidden');
    }
    header('Content-Type: text/plain; charset=UTF-8');
}

$root = dirname(__DIR__);
require_once $root . '/env.php';
loadEnvFile();
require_once $root . '/sent_results_db.php';

$pdo = openResultsDb();
if ($pdo === null) { exit("DB connection failed\n"); }

$db = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
echo "Connected DB: $db\n\n";

echo "== Databases containing patient_results ==\n";
foreach ($pdo->query("SELECT table_schema, table_rows FROM information_schema.tables WHERE table_name='patient_results'") as $r) {
    echo "  {$r['table_schema']} (rows ~{$r['table_rows']})\n";
}

foreach (['patient_results', 'patients', 'sent_results'] as $t) {
    echo "\n== $t in $db ==\n";
    try {
        $cols = $pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll(PDO::FETCH_COLUMN);
        echo "  columns: " . implode(', ', $cols) . "\n";
        echo "  rows: " . $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn() . "\n";
    } catch (Throwable $e) {
        echo "  ERROR: " . $e->getMessage() . "\n";
    }
}

echo "\n== patient_results summary (current DB) ==\n";
try {
    foreach ($pdo->query("SELECT source, department, COUNT(*) n, MAX(result_link_added_at) latest_link, MAX(visit_date) latest_visit FROM patient_results GROUP BY source, department") as $r) {
        echo "  " . json_encode($r) . "\n";
    }
} catch (Throwable $e) { echo "  ERROR: " . $e->getMessage() . "\n"; }

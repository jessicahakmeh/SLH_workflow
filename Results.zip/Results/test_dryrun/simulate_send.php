<?php
// READ-ONLY dry run of send_pending_results.php. Sends nothing, writes nothing to sent_results.
// Restricted to CLI or private-network clients. Contacts are masked.
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false && $ip !== '::1') {
        http_response_code(403);
        exit('Forbidden');
    }
    header('Content-Type: text/plain; charset=UTF-8');
}

$root = dirname(__DIR__);
require_once $root . '/env.php';
loadEnvFile();
require_once $root . '/sent_results_db.php';
require_once $root . '/result_sending.php';

$mask = static fn(string $s): string => $s === '' ? '-' : (strlen($s) > 4 ? str_repeat('*', strlen($s) - 4) . substr($s, -4) : $s);

echo "Now: " . date('Y-m-d H:i:s') . "\n";
echo "DB: " . (defined('RESULTS_DB_NAME') ? RESULTS_DB_NAME : '?') . " @ " . (defined('RESULTS_DB_HOST') ? RESULTS_DB_HOST : '?') . "\n";
echo "Last run marker: " . trim((string)@file_get_contents($root . '/logs/send_pending_last_run.txt')) . "\n";
echo "WA=" . envValue('WHATSAPP_AUTO_SEND', '0') . " SMS=" . envValue('SMS_AUTO_SEND', '0') . " EMAIL=" . envValue('EMAIL_AUTO_SEND', '0')
    . " AUTO_SEND_START_DATE=" . getenv('AUTO_SEND_START_DATE') . " RETRY_FAILED_SENDS=" . envValue('RETRY_FAILED_SENDS', '14') . "\n\n";

try {
    $rows = getPendingAutoSendResults();
} catch (Throwable $e) {
    echo "getPendingAutoSendResults FAILED: " . $e->getMessage() . "\n";
    exit(1);
}
echo "Candidates: " . count($rows) . "\n\n";

$wa = envValue('WHATSAPP_AUTO_SEND', '0') === '1';
$sms = envValue('SMS_AUTO_SEND', '0') === '1';
$em = envValue('EMAIL_AUTO_SEND', '0') === '1';
$tot = ['WA' => 0, 'SMS' => 0, 'EMAIL' => 0, 'none' => 0];

foreach ($rows as $r) {
    $phone = trim((string)$r['care_mobile']);
    $email = trim((string)$r['email']);
    $added = $r['result_link_added_at'] ?? null;
    $plan = [];
    if ($wa && shouldRetryChannelSend($phone, $r['wp_last_attempt_at'] ?? null, $added)) { $plan[] = 'WA'; $tot['WA']++; }
    if ($sms && shouldRetryChannelSend($phone, $r['sms_last_attempt_at'] ?? null, $added)) { $plan[] = 'SMS'; $tot['SMS']++; }
    if ($em && shouldRetryChannelSend($email, $r['email_last_attempt_at'] ?? null, $added)) { $plan[] = 'EMAIL'; $tot['EMAIL']++; }
    if (!$plan) $tot['none']++;
    printf("#%d MRN=%s %s | %s | added=%s | phone=%s email=%s | lastWA=%s lastSMS=%s lastEM=%s | sent_row=%s => %s\n",
        $r['result_id'], $r['mrn'], $r['department'], $r['request_code'], $added, $mask($phone), $email !== '' ? 'yes' : '-',
        $r['wp_last_attempt_at'] ?? 'never', $r['sms_last_attempt_at'] ?? 'never', $r['email_last_attempt_at'] ?? 'never',
        $r['sent_id'] ? 'yes' : 'no', $plan ? implode('+', $plan) : 'NOTHING (24h/retry window/no contact)');
}
echo "\nWould send: WhatsApp={$tot['WA']} SMS={$tot['SMS']} Email={$tot['EMAIL']}; candidates with no eligible channel={$tot['none']}\n";
